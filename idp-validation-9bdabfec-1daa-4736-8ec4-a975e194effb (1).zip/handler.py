"""
Validation Lambda (idp-validation).
Invoked by Step Functions with input:
  { "queueId": 1, "application": "AFLCOR" }
For each field on the (single Phase-1) document:
  Pass if:  confidence >= configured ConfidenceScore  AND  value matches ValidationRegex
  Else:     fail
If ANY required field fails -> validationStatus = NeedsReview, route to ManualReview.
If ALL required fields pass -> validationStatus = Passed, route to Export.
Output:
  { ...input,
    needsManualReview: bool,
    failedFields: [...],
    validationStatus: "Passed" | "NeedsReview" }
"""
import json
import logging
import re
from decimal import Decimal
from typing import Any, Dict, List, Optional
from shared import config_loader, ddb
logger = logging.getLogger()
logger.setLevel(logging.INFO)

class _DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, Decimal):
            if o == o.to_integral_value():
                return int(o)
            return float(o)
        return super().default(o)

def _j(obj: Any) -> str:
    return json.dumps(obj, cls=_DecimalEncoder)

def _field_config_map(main_page_cfg: Optional[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    """Map FieldName -> field config dict, for fast lookup."""
    if not main_page_cfg:
        return {}
    out = {}
    for f in main_page_cfg.get("Fields", []) or []:
        out[f["FieldName"]] = f
    return out

def _validate_field(field_item: Dict[str, Any],
                    field_cfg: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Returns the original field_item with an updated validationPassed and
    optional validationError reason.
    """
    out = dict(field_item)
    out["validationPassed"] = False
    out.pop("validationError", None)
    if not field_cfg:
        out["validationError"] = "No configuration for field"
        return out
    value = field_item.get("value")
    confidence = field_item.get("confidence")
    # Missing value can never pass validation
    if value in (None, ""):
        out["validationError"] = "Empty value"
        return out
    # Confidence check
    threshold = float(field_cfg.get("ConfidenceScore", 0.8))
    # Textract returns confidence as a percentage 0-100, our threshold is 0-1
    # Normalize: if confidence > 1, treat as percentage and compare against threshold*100
    conf_val = float(confidence) if confidence is not None else 0.0
    threshold_pct = threshold * 100 if threshold <= 1 else threshold
    if conf_val < threshold_pct:
        out["validationError"] = (
            f"Confidence {conf_val:.2f} below threshold {threshold_pct:.2f}"
        )
        return out
    # Regex check
    pattern = field_cfg.get("ValidationRegex")
    if pattern:
        try:
            if not re.fullmatch(pattern, str(value)):
                out["validationError"] = f"Value does not match {pattern}"
                return out
        except re.error:
            logger.warning("Bad ValidationRegex for %s: %r",
                           field_item.get("fieldName"), pattern)
            out["validationError"] = "Bad ValidationRegex"
            return out
    # Passed all checks
    out["validationPassed"] = True
    return out

def lambda_handler(event: Dict[str, Any], _context: Any) -> Dict[str, Any]:
    logger.info("Event: %s", _j(event))
    queue_id = int(event["queueId"])
    application = event["application"]
    start_time = ddb.now_iso()
    ddb.update_batch_status(queue_id, status="Running", current_task="Validation")
    try:
        app_cfg = config_loader.get_application(application)
        doc_types = app_cfg.get("DocumentTypes", [])
        if not doc_types:
            raise RuntimeError(f"No DocumentTypes for {application}")
        doc_type = doc_types[0]
        main_page_cfg = next(
            (pt for pt in doc_type.get("PageTypes", []) if pt.get("PageType") == "MainPage"),
            None,
        )
        cfg_map = _field_config_map(main_page_cfg)
        document = ddb.get_first_document(queue_id)
        if not document:
            raise RuntimeError(f"No document for queueId={queue_id}")
        fields_in = document.get("extractedFields") or []
        validated = [_validate_field(f, cfg_map.get(f.get("fieldName"))) for f in fields_in]
        failed_required = [
            f for f in validated
            if f.get("required") and not f.get("validationPassed")
        ]
        # =====================================================================
        # Stage 5 / POC override: ALWAYS route batches through ManualReview,
        # regardless of whether validation actually passed. This is a
        # temporary POC behavior so reviewers see every batch in the Verify
        # UI even when extraction was perfect.
        #
        # To restore the original "skip ManualReview when all required
        # fields pass" behavior, revert this line to:
        #     needs_review = len(failed_required) > 0
        # =====================================================================
        needs_review = True
        new_status = "NeedsReview" if needs_review else "Passed"
        ddb.update_document_fields(
            queue_id=queue_id,
            doc_id=document["documentId"],
            extracted_fields=validated,
            validation_status=new_status,
        )
        ddb.append_task_history(
            queue_id=queue_id,
            task_name="Validation",
            status="Completed",
            start_time=start_time,
            end_time=ddb.now_iso(),
            operator="system",
            details={
                "validationStatus": new_status,
                "failedFields": [
                    {"fieldName": f.get("fieldName"), "reason": f.get("validationError")}
                    for f in failed_required
                ],
            },
        )
        result = {
            "queueId": queue_id,
            "application": application,
            "validationStatus": new_status,
            "needsManualReview": needs_review,
            "failedFields": [f.get("fieldName") for f in failed_required],
        }
        logger.info("Validation result: %s", _j(result))
        return result
    except Exception:
        logger.exception("Validation failed")
        ddb.append_task_history(
            queue_id=queue_id,
            task_name="Validation",
            status="Failed",
            start_time=start_time,
            end_time=ddb.now_iso(),
            operator="system",
        )
        raise