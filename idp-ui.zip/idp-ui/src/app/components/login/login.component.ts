import { CommonModule } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
 
import { AuthService } from '../../services/auth.service';
 
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent {
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
 
  username = signal('');
  error = signal<string | null>(null);
 
  submit() {
    const name = (this.username() || '').trim();
    if (!name) {
      this.error.set('Please enter a username.');
      return;
    }
    this.error.set(null);
    this.auth.login(name);
 
    const returnUrl = this.route.snapshot.queryParamMap.get('returnUrl') || '/batches';
    this.router.navigateByUrl(returnUrl);
  }
}