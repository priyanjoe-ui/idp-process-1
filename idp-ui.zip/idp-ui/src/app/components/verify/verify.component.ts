import { CommonModule } from '@angular/common';
import {
  Component,
  ElementRef,
  OnInit,
  ViewChild,
  computed,
  effect,
  inject,
  signal,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
 
import {
  ApplicationsResponse,
  BatchDetail,
  ConfigField,
  ConfigLineItemColumn,
  ConfigLineItems,
  ConfigPageType,
  DocumentDetail,
  FieldOption,
  DocumentPayload,
  LineItemRowData,
  PageDetail,
  TaskHistoryItem,
  TreeDocPayload,
  TreeOp,
  TreePagePayload,
} from '../../models/document.model';
import { BatchService } from '../../services/batch.service';
import { CifLookupResult, CifLookupService } from '../../services/cif-lookup.service';
 
interface FieldEdit {
  fieldName: string;
  label: string;
  dataType: 'String' | 'Dropdown' | string;
  originalValue: string;
  currentValue: string;
  confidence: number | null;
  required: boolean;
  disabled: boolean;       // for auto-populated read-only fields
  /** For Dropdown fields, the resolved option list. */
  options?: { value: string; label: string }[];
  validationError?: string | null;
}
 
interface BatchStructureRow {
  rowType: 'batch' | 'doc' | 'page';
  id: string;          // display ID
  type: string;        // display type label
  /** Stage 7: 'OK' is the post-validation success state (Run Validations
   *  passed everything). 'Problem' only flags MainPages with failed
   *  validation. 'Scanned' is the default for any non-MainPage. */
  status: 'Scanned' | 'Problem' | 'OK';
  pageId?: string;     // for page rows, to enable scroll-to
  docId?: string;      // for doc rows, used by tree selection
  indent: number;      // 0, 1, or 2
  /**
   * Stage 7: synthetic id used by selectedTreeId/selectedTreeType so
   * Move/Delete/Split know which row is selected. For pages this is
   * pageId, for docs documentId, for batch the batchNumber.
   */
  treeKey?: string;
}
 
interface LineItemDocRow {
  docId: string;
  docType: string;
  status: string;
  pageCount: number;
  fieldCount: number;
  validation: string;
}
 
/**
 * One row in the editable line items grid. Cells is a string-keyed
 * dictionary so the template can do `row.cells[col.FieldName]` without
 * type gymnastics. rowId is a synthetic local id for tracking selection
 * and Angular's @for trackBy — it is NOT persisted to DDB. On submit we
 * strip rowId and send only the cells.
 */
interface LineItemRow {
  rowId: string;
  cells: { [columnName: string]: string };
}
 
/**
 * Discriminated union representing one slot in the rendered Field
 * Details panel. The template walks this list in order, rendering
 * either a field cell or the line items table inline. Keeping config
 * order means a config edit alone controls placement — no template
 * change needed.
 */
type RenderItem =
  | { kind: 'field'; field: FieldEdit }
  | { kind: 'lineItems'; config: ConfigLineItems };
 
type FitMode = 'width' | 'height';
 
@Component({
  selector: 'app-verify',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './verify.component.html',
  styleUrls: ['./verify.component.scss'],
})
export class VerifyComponent implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly svc = inject(BatchService);
  private readonly cifSvc = inject(CifLookupService);
 
  // ----- State -----
  loading = signal(true);
  errorMessage = signal<string | null>(null);
  detail = signal<BatchDetail | null>(null);
 
  /**
   * Issue 3: per-document field/lineItem state.
   *
   * After Split, a batch can have multiple documents, each with its OWN
   * extracted fields + line items grid. They must not bleed into each
   * other. We keep state in Map<documentId, ...> backing signals, and
   * expose fieldEdits() / lineItems() as computed read-throughs that
   * slice by the currently-viewed document.
   *
   * The currently-viewed document is derived from currentPageId(): find
   * the doc whose pageIds contains that page. When the user clicks a
   * different page in the Batch Structure panel, currentPageId() updates
   * → currentDocId() recomputes → fieldEdits()/lineItems() swap to the
   * new doc.
   *
   * IMPORTANT: writes to these maps must NOT happen inside computeds
   * that read them. Writes happen from explicit handlers (onFieldChange,
   * onLineItemCellChange, applyCifResult, rebuildFieldEdits) or from
   * the single existing effect that runs after detail+appConfig arrive.
   */
  fieldEditsByDoc = signal<Map<string, FieldEdit[]>>(new Map());
  lineItemsByDoc = signal<Map<string, LineItemRow[]>>(new Map());
 
  /** Application config (field definitions + shared dictionaries). */
  appConfig = signal<ApplicationsResponse | null>(null);
 
  // ----- Line items grid state -----
  /** rowId of the currently selected row (for the footer × Delete button). */
  selectedRowId = signal<string | null>(null);
  /** Monotonic counter for synthetic row ids. */
  private nextRowSeq = 1;
  /**
   * Tracks per-document whether lineItems were hydrated from DDB.
   * Used to gate the auto-CIF-lookup: only call CIF when DDB came back
   * empty for THIS doc, never overwrite persisted rows.
   */
  private lineItemsHydratedDocs = new Set<string>();
 
  // ----- CIF lookup state -----
  cifLookupBusy = signal(false);
  cifLookupError = signal<string | null>(null);
  /**
   * Tracks per-document whether auto-CIF-lookup was attempted, so each
   * doc gets at most one auto-lookup per session.
   */
  private autoLookupAttempted = new Set<string>();
 
  // ----- Selected/current page tracking -----
  currentPageId = signal<string | null>(null);
 
  // ----- Stage 7: tree state (selection + pending operations) -----
  /**
   * Currently selected tree row in the Batch Structure panel. Drives
   * which row the Move Up/Down, Delete, Split buttons act on. Value is
   * the row's id (page displayId, document SK, or batch number).
   */
  selectedTreeId = signal<string | null>(null);
  /** Type of currently selected tree row, used to enable/disable ops. */
  selectedTreeType = signal<'batch' | 'doc' | 'page' | null>(null);
  /**
   * Pending structural ops that have been previewed in the UI but not
   * yet committed to DDB. Applied to a mirrored copy of pages+docs for
   * live rendering; the array is sent to the server as part of
   * submit-review or save-draft.
   */
  pendingTreeOps = signal<TreeOp[]>([]);
  /**
   * UI-local validation override. When the user clicks "Run Validations"
   * and all required fields pass, this gets set to 'Reviewed' so the
   * batchStructure() cascade treats the document as Passed (MainPage
   * status flips to OK). On Submit/Hold this value is sent in the
   * payload so the server promotes validationStatus in DDB; if the
   * user navigates away without saving, the override is lost.
   */
  validationOverride = signal<'Reviewed' | null>(null);
 
  // ----- Panel collapse -----
  leftCollapsed = signal(false);
  middleCollapsed = signal(false);
  rightCollapsed = signal(false);
 
  // ----- Viewer transform state -----
  zoom = signal(1.0);              // 1.0 = 100%
  fitMode = signal<FitMode>('width');
  inverted = signal(false);
  brightness = signal(100);        // %
  contrast = signal(100);
  saturation = signal(100);
  showBrightness = signal(false);  // popover open?
  /** Per-page rotation in degrees */
  pageRotation = signal<Record<string, number>>({});
 
  // ----- Submit dialog -----
  showConfirm = signal(false);
  submitting = signal(false);
  /** True while a Hold (save-draft) call is in flight. Disables both
   *  Submit and Hold buttons to prevent double-clicks. */
  holding = signal(false);
  /**
   * Validation errors collected from the latest submit attempt.
   * Cleared on field edit. Stage 5: blocks submit if any are present
   * (per "missing required fields only" rule).
   */
  submitBlockingErrors = signal<string[]>([]);
 
  // ----- Action dropdowns (placeholders) -----
  showViewerActions = signal(false);
  showFieldActions = signal(false);
  showStructureActions = signal(false);
  showTasksMenu = signal(false);
 
  // ----- Click N (draw-to-capture) -----
  drawMode = signal(false);
  /** Current drawing box in pixel coords relative to the active page image. */
  drawBox = signal<{ pageId: string; x: number; y: number; w: number; h: number } | null>(null);
  /** Captured text held in memory after a draw when no field was focused. */
  pendingClickNText = signal<string | null>(null);
  /** Which field input was last focused, used as the auto-insert target. */
  focusedFieldName = signal<string | null>(null);
  /** "Rotate back to 0°" toast. */
  showRotateToast = signal(false);
  /** "Captured text — click any field" popup. */
  showClickNPopup = signal(false);
 
  // ----- Magnifier (rectangular lens overlay) -----
  /**
   * When true, hovering the image shows a rectangular lens that displays
   * a magnified copy of the underlying image region. Mutually exclusive
   * with drawMode (Click N) — turning one on turns the other off.
   */
  magnifierMode = signal(false);
  /**
   * Current lens position + zoom. pageId tells us which page block the
   * lens is currently over (null = hidden). x/y are pixel coords relative
   * to that page's .page-image element (the unrotated source). zoom is
   * the magnification factor AND the lens size multiplier — both grow
   * together so the user sees more *and* sees it bigger when they scroll
   * up.
   */
  magnifier = signal<{ pageId: string; x: number; y: number; zoom: number } | null>(null);
  /**
   * Base lens dimensions at zoom=1.0. The actual rendered lens is
   * baseLens * zoom (clamped by the min/max zoom range), so zooming in
   * via the wheel naturally enlarges the lens rectangle along with the
   * magnification of its contents.
   */
  private readonly magnifierLensBaseW = 70;
  private readonly magnifierLensBaseH = 50;
  /** Starting zoom when the lens first appears (small + tight by default). */
  private readonly magnifierStartZoom = 1.5;
  /** Min/max zoom and step for wheel-driven zoom adjustment. */
  private readonly magMinZoom = 1.25;
  private readonly magMaxZoom = 6.0;
  private readonly magZoomStep = 0.25;
 
  // ----- Search -----
  searchOpen = signal(false);
  searchQuery = signal('');
  currentMatchIndex = signal(0);
 
  // ----- DOM refs -----
  @ViewChild('viewerScroll') viewerScrollRef?: ElementRef<HTMLDivElement>;
 
  // ----- Derived -----
  readonly batch = computed(() => this.detail()?.batch);
  readonly pages = computed<PageDetail[]>(() => this.detail()?.pages || []);
  readonly documents = computed(() => this.detail()?.documents || []);
  readonly taskHistory = computed<TaskHistoryItem[]>(() => this.detail()?.taskHistory || []);
 
  /**
   * Stage 7: pages with pendingTreeOps applied. The detail() signal is
   * the unaltered DDB snapshot; this signal reflects the tree the user
   * sees after Move/Delete/Split operations. Used everywhere the UI
   * needs to render the "current" structure (Batch Structure panel,
   * viewer scroll, page count badges).
   *
   * Operations are applied in order. Each op only mutates a shallow
   * copy of the array; original detail() data stays untouched so undo
   * can simply pop from pendingTreeOps and recompute.
   */
  readonly effectivePages = computed<PageDetail[]>(() => {
    let pages = [...this.pages()];
    let docs = this.documents().map(d => ({ ...d, pageIds: [...(d.pageIds || [])] }));
    ({ pages, docs } = this.applyTreeOps(pages, docs, this.pendingTreeOps()));
    return pages;
  });
 
  readonly effectiveDocuments = computed<DocumentDetail[]>(() => {
    let pages = [...this.pages()];
    let docs = this.documents().map(d => ({ ...d, pageIds: [...(d.pageIds || [])] }));
    ({ pages, docs } = this.applyTreeOps(pages, docs, this.pendingTreeOps()));
    return docs;
  });
 
  /**
   * Issue 3: which document is the user currently editing?
   *
   * Derived from currentPageId(): find the doc whose pageIds contains
   * that page. Falls back to documents[0] when there's no current page
   * (initial load). When the user clicks a page in a different document,
   * currentPageId() updates and this recomputes, causing fieldEdits() /
   * lineItems() to swap to the new doc's state.
   */
  readonly currentDocId = computed<string | null>(() => {
    const pid = this.currentPageId();
    const docs = this.effectiveDocuments();
    if (!docs.length) return null;
    if (pid) {
      const owning = docs.find(d => (d.pageIds || []).includes(pid));
      if (owning) return owning.documentId;
    }
    return docs[0].documentId;
  });
 
  /**
   * Field edits for the current document. Reads from the by-doc map and
   * falls back to [] when the doc hasn't been hydrated yet (e.g. just-
   * split doc before rebuildFieldEdits has populated it).
   */
  readonly fieldEdits = computed<FieldEdit[]>(() => {
    const docId = this.currentDocId();
    if (!docId) return [];
    return this.fieldEditsByDoc().get(docId) || [];
  });
 
  /** Line items for the current document. */
  readonly lineItems = computed<LineItemRow[]>(() => {
    const docId = this.currentDocId();
    if (!docId) return [];
    return this.lineItemsByDoc().get(docId) || [];
  });
 
  /** 0-based position of the current document — used by the header indicator. */
  readonly currentDocIndex = computed<number>(() => {
    const docId = this.currentDocId();
    if (!docId) return 0;
    const idx = this.effectiveDocuments().findIndex(d => d.documentId === docId);
    return idx >= 0 ? idx : 0;
  });
 
  /**
   * Live-computed list of required-field violations. Used for both the
   * submit-disabled tooltip and the validation banner. Empty when all
   * required fields have values.
   */
  readonly requiredFieldErrors = computed<string[]>(() => {
    const out: string[] = [];
    for (const e of this.fieldEdits()) {
      if (!e.required) continue;
      if (e.disabled) continue;  // auto-populated fields can't be empty by user action
      if (!e.currentValue || !e.currentValue.trim()) {
        out.push(`${e.label} is required`);
      }
    }
    return out;
  });
 
  /**
   * Stage 5: editability is decoupled from submittability. Fields are
   * editable whenever the batch is parked in ManualReview, regardless
   * of whether required-field validation passes. Otherwise the user
   * couldn't fix an empty required field, because the gate needed to
   * enable editing was the very thing being blocked.
   *
   * Stage 9: two distinct hold status values are accepted:
   *   - "pending" = system routed to ManualReview after validation failure
   *   - "hold"    = user clicked Hold on this screen
   * Also accepts the legacy "OnHold" still present on un-migrated rows;
   * api-proxy normalizes it on read (splitting OnHold by holdSource) but
   * we accept it here as defense in depth.
   */
  readonly canEdit = computed(() => {
    const b = this.batch();
    if (!b) return false;
    if (b.currentTask !== 'ManualReview') return false;
    return b.status === 'hold' || b.status === 'pending' || b.status === 'OnHold';
  });
 
  /**
   * Submit is allowed only when the batch is editable AND all required
   * fields have values. The button uses this; the inputs use canEdit().
   */
  readonly canSubmit = computed(() => {
    if (!this.canEdit()) return false;
    return this.requiredFieldErrors().length === 0;
  });
 
  /** Tooltip text for the Submit button explaining why it's disabled. */
  readonly submitDisabledReason = computed<string | null>(() => {
    const b = this.batch();
    if (!b) return 'Loading…';
    if (b.currentTask !== 'ManualReview' ||
        (b.status !== 'pending' && b.status !== 'hold' && b.status !== 'OnHold')) {
      return 'Batch is not in Manual Review';
    }
    const errs = this.requiredFieldErrors();
    if (errs.length > 0) {
      return errs.length === 1
        ? errs[0]
        : `${errs.length} required fields are empty`;
    }
    return null;
  });
 
  /** Document table at top of Batch Structure: one row per document. */
  readonly lineItemDocs = computed<LineItemDocRow[]>(() => {
    return this.documents().map(d => ({
      docId: d.documentId,
      docType: d.documentType,
      status: 'Classified',
      pageCount: (d.pageIds || []).length,
      fieldCount: (d.extractedFields || []).length,
      validation: d.validationStatus || '—',
    }));
  });
 
  /** Line items table configuration for the current document type. */
  readonly lineItemsConfig = computed<ConfigLineItems | null>(() => {
    return this.findMainPageConfig()?.lineItems || null;
  });
 
  /** Resolved dropdown options per column name, ready for the template. */
  readonly lineItemColumnOptions = computed<{ [col: string]: { value: string; label: string }[] }>(() => {
    const cfg = this.lineItemsConfig();
    const out: { [col: string]: { value: string; label: string }[] } = {};
    if (!cfg) return out;
    for (const col of cfg.Columns) {
      if (col.DataType === 'Dropdown') {
        out[col.FieldName] = this.resolveOptions(col) || [];
      }
    }
    return out;
  });
 
  /**
   * Ordered list of cells + line items block to render in the Field
   * Details panel. Built from the config: fields render in their array
   * order, the line items block is inserted at lineItems.Position (or
   * after all fields if Position is unset). When config isn't loaded
   * yet, falls back to fieldEdits with no line items.
   */
  readonly renderItems = computed<RenderItem[]>(() => {
    const edits = this.fieldEdits();
    const liCfg = this.lineItemsConfig();
    const items: RenderItem[] = edits.map(f => ({ kind: 'field', field: f } as RenderItem));
    if (!liCfg) return items;
    const pos = (typeof liCfg.Position === 'number' && liCfg.Position >= 0)
      ? Math.min(liCfg.Position, items.length)
      : items.length;
    items.splice(pos, 0, { kind: 'lineItems', config: liCfg });
    return items;
  });
 
  /**
   * Batch structure table — flat list with indent levels.
   *
   * Stage 7 changes:
   *  - Uses effective docs/pages (reflects pending tree ops)
   *  - Only MainPage rows can be 'Problem'; all other page types are
   *    always 'Scanned' regardless of validation state
   *  - When validationOverride === 'Reviewed' (user clicked Run
   *    Validations and required fields passed), MainPage flips from
   *    'Problem' to 'OK' and the cascade propagates upward
   *  - Doc-level Problem rolls up: any MainPage with Problem -> doc Problem
   *  - Batch-level Problem rolls up: any doc with Problem -> batch Problem
   */
  readonly batchStructure = computed<BatchStructureRow[]>(() => {
    const rows: BatchStructureRow[] = [];
    const b = this.batch();
    if (!b) return rows;
 
    const docs = this.effectiveDocuments();
    const pages = this.effectivePages();
    const override = this.validationOverride();
 
    // Per-doc problem flag (validation failed AND no manual override)
    const docProblemMap = new Map<string, boolean>();
    for (const d of docs) {
      const failed = (d.validationStatus !== 'Passed') && (override !== 'Reviewed');
      docProblemMap.set(d.documentId, failed);
    }
 
    // Doc-level Problem rolls up to batch
    const anyDocProblem = Array.from(docProblemMap.values()).some(v => v);
 
    // Batch row
    rows.push({
      rowType: 'batch',
      id: b.batchNumber,
      type: b.application,
      status: anyDocProblem ? 'Problem' : (override === 'Reviewed' ? 'OK' : 'Scanned'),
      indent: 0,
      treeKey: b.batchNumber,
    });
 
    docs.forEach((doc, dIdx) => {
      const docProblem = docProblemMap.get(doc.documentId) === true;
      rows.push({
        rowType: 'doc',
        id: `${b.batchNumber}.${String(dIdx + 1).padStart(2, '0')}`,
        type: doc.documentType,
        status: docProblem ? 'Problem' : (override === 'Reviewed' ? 'OK' : 'Scanned'),
        indent: 1,
        docId: doc.documentId,
        treeKey: doc.documentId,
      });
 
      (doc.pageIds || []).forEach(pid => {
        const page = pages.find(p => p.pageId === pid);
        if (!page) return;
        const displayId = page.displayId || `Page ${page.pageNumber}`;
        // Stage 7: ONLY MainPage can show Problem. Other page types
        // (Trailing, Cover, Blank) are always Scanned because validation
        // applies to the document's extracted fields, which live on
        // MainPage by convention.
        let status: 'Scanned' | 'Problem' | 'OK' = 'Scanned';
        if (page.pageType === 'MainPage') {
          if (docProblem) status = 'Problem';
          else if (override === 'Reviewed') status = 'OK';
        }
        rows.push({
          rowType: 'page',
          id: displayId,
          type: this.pageTypeLabel(page.pageType),
          status,
          pageId: page.pageId,
          indent: 2,
          treeKey: page.pageId,
        });
      });
    });
 
    return rows;
  });
 
  /** Most-recent task history item for the bottom status bar */
  readonly lastEvent = computed<string>(() => {
    const b = this.batch();
    const hist = this.taskHistory();
    if (!b) return '';
    if (hist.length === 0) {
      return `Batch ${b.batchNumber} was started.`;
    }
    const last = hist[hist.length - 1];
    return `Batch ${b.batchNumber} — ${last.taskName} ${last.status === 'Completed' ? 'completed' : last.status.toLowerCase()}.`;
  });
 
  readonly dirtyCount = computed(() =>
    this.fieldEdits().filter(e => e.currentValue !== e.originalValue).length
  );
 
  /** Index of the currently visible page in the pages() array */
  readonly currentPageIndex = computed(() => {
    const id = this.currentPageId();
    if (!id) return 0;
    const idx = this.pages().findIndex(p => p.pageId === id);
    return idx >= 0 ? idx : 0;
  });
 
  // ----- Lifecycle -----
  constructor() {
    // Rebuild fieldEdits whenever appConfig arrives (or changes). The batch
    // detail load may complete before the config response arrives — in that
    // case fieldEdits gets built from the existing extractedFields only, and
    // this effect re-runs it with the config-driven schema once available.
    //
    // Issue 3: maybeAutoCifLookup() now reads currentDocId() which reads
    // currentPageId(). That makes the effect re-fire on every page scroll.
    // The fieldEditsBuilt / lineItemsBuilt flags below ensure we only do
    // the heavy rebuild + hydrate ONCE per detail snapshot — user edits
    // accumulated in the by-doc maps survive subsequent effect runs.
    //
    // allowSignalWrites: rebuildFieldEdits/hydrateLineItemsFromDdb both write
    // signals. Angular forbids signal writes inside effects by default to
    // catch accidental infinite loops, but here the writes are gated by the
    // built-flags and don't feed back into the read signals.
    effect(() => {
      const cfg = this.appConfig();
      const d = this.detail();
      if (!cfg || !d) return;
      if (!this.fieldEditsBuilt) {
        this.rebuildFieldEdits();
        this.fieldEditsBuilt = true;
      }
      if (!this.lineItemsBuilt) {
        this.hydrateLineItemsFromDdb();
        this.lineItemsBuilt = true;
      }
      // maybeAutoCifLookup is itself per-doc gated via autoLookupAttempted,
      // so it's safe to call on every effect run — only one CIF call per doc.
      this.maybeAutoCifLookup();
    }, { allowSignalWrites: true });
  }
 
  /** Issue 3: one-shot guards so effect re-runs don't blow away user edits. */
  private fieldEditsBuilt = false;
  private lineItemsBuilt = false;
 
  ngOnInit(): void {
    const queueId = Number(this.route.snapshot.paramMap.get('queueId'));
    if (!queueId) {
      this.errorMessage.set('No queueId in URL');
      this.loading.set(false);
      return;
    }
    this.load(queueId);
  }
 
  load(queueId: number) {
    this.loading.set(true);
    this.svc.listApplications().subscribe({
      next: cfg => this.appConfig.set(cfg),
      error: err => console.warn('listApplications failed (continuing without config):', err),
    });
    this.svc.getBatch(queueId).subscribe({
      next: d => {
        this.detail.set(d);
        this.rebuildFieldEdits();
        this.hydrateLineItemsFromDdb();
        if (d.pages?.length) {
          this.currentPageId.set(d.pages[0].pageId);
        }
        this.loading.set(false);
        this.maybeAutoCifLookup();
      },
      error: err => {
        console.error('getBatch error:', err);
        this.errorMessage.set(err?.error?.message || err?.message || 'Failed to load batch');
        this.loading.set(false);
      },
    });
  }
 
  /**
   * Stage 5: hydrate the line items grid from the document record in DDB.
   * Runs both on initial getBatch() resolve and on appConfig() arrival
   * (since lineItemsConfig depends on appConfig). Safe to call multiple
   * times — guarded by lineItemsHydratedFromDdb so we don't blow away
  /**
   * Issue 3: hydrate line items from DDB for EVERY document, not just
   * documents[0]. Built once when detail+config arrive; subsequent
   * detail changes only hydrate docs not already in lineItemsHydratedDocs
   * (so we don't blow away user edits after the first hydrate).
   */
  private hydrateLineItemsFromDdb() {
    const d = this.detail();
    if (!d) return;
 
    const nextMap = new Map(this.lineItemsByDoc());
    let touched = false;
    for (const doc of d.documents || []) {
      if (this.lineItemsHydratedDocs.has(doc.documentId)) continue;
      const stored = doc.lineItems;
      if (Array.isArray(stored)) {
        const rows: LineItemRow[] = stored.map(cells => ({
          rowId: `li-${this.nextRowSeq++}`,
          cells: { ...cells },
        }));
        nextMap.set(doc.documentId, rows);
        touched = true;
      } else {
        // Old doc or no lineItems attribute — start with empty grid.
        nextMap.set(doc.documentId, []);
        touched = true;
      }
      this.lineItemsHydratedDocs.add(doc.documentId);
    }
    if (touched) this.lineItemsByDoc.set(nextMap);
  }
 
  /**
   * Build the editable field list for EVERY document from the document-
   * config (preferred) merged with any existing extractedFields on each
   * document. If config isn't loaded yet, falls back to whatever
   * extractedFields each document has.
   *
   * Idempotent and safe to call multiple times — rebuilds the entire map
   * each call so split-created docs get fresh entries from their config.
   * Important: only writes to fieldEditsByDoc, doesn't read from it, so
   * cannot create a re-entrancy loop with the fieldEdits() computed.
   */
  private rebuildFieldEdits() {
    const d = this.detail();
    if (!d) return;
 
    const mainPage = this.findMainPageConfig();
    const nextMap = new Map<string, FieldEdit[]>();
 
    for (const doc of d.documents || []) {
      const extracted = doc.extractedFields || [];
      const byName = new Map<string, any>();
      extracted.forEach(f => byName.set(f.fieldName, f));
 
      if (!mainPage || !mainPage.fields?.length) {
        // No config — show whatever the doc already has.
        const edits: FieldEdit[] = extracted.map(f => ({
          fieldName: f.fieldName,
          label: f.fieldName,
          dataType: 'String',
          originalValue: f.value || '',
          currentValue: f.value || '',
          confidence: f.confidence ?? null,
          required: f.required ?? false,
          disabled: false,
          validationError: (f.validationPassed === false) ? (f.validationError || 'Validation failed') : null,
        }));
        nextMap.set(doc.documentId, edits);
        continue;
      }
 
      const edits: FieldEdit[] = mainPage.fields.map(fc => {
        const stored = byName.get(fc.FieldName);
        let value: string;
 
        if (fc.Disabled && fc.AutoPopulateFrom) {
          // Disabled + AutoPopulateFrom fields (ScanBatch, ReceivedDate,
          // email fields) are populated from batch meta for every doc —
          // including split-created docs that started with empty fields.
          value = this.resolveAutoValue(fc.AutoPopulateFrom, fc.Format, fc.Transform);
        } else if (stored && stored.value != null && stored.value !== '') {
          value = String(stored.value);
        } else if (fc.DefaultValue != null) {
          value = String(fc.DefaultValue);
        } else {
          value = '';
        }
 
        const options = this.resolveOptions(fc);
 
        return {
          fieldName: fc.FieldName,
          label: fc.Label || fc.FieldName,
          dataType: fc.DataType,
          originalValue: value,
          currentValue: value,
          confidence: stored?.confidence ?? null,
          required: fc.Required ?? false,
          disabled: fc.Disabled ?? false,
          options,
          validationError: (stored?.validationPassed === false)
            ? (stored.validationError || 'Validation failed')
            : null,
        };
      });
      nextMap.set(doc.documentId, edits);
    }
 
    this.fieldEditsByDoc.set(nextMap);
  }
 
  /**
   * Helper: write a new FieldEdit[] for the current document into the map.
   * Used by onFieldChange and CIF apply. Updates only the current doc's
   * slice, leaving other docs untouched.
   */
  private setFieldEditsForCurrentDoc(edits: FieldEdit[]): void {
    const docId = this.currentDocId();
    if (!docId) return;
    const next = new Map(this.fieldEditsByDoc());
    next.set(docId, edits);
    this.fieldEditsByDoc.set(next);
  }
 
  /** Same idea for line items. */
  private setLineItemsForCurrentDoc(rows: LineItemRow[]): void {
    const docId = this.currentDocId();
    if (!docId) return;
    const next = new Map(this.lineItemsByDoc());
    next.set(docId, rows);
    this.lineItemsByDoc.set(next);
  }
 
  /** Find the MainPage config for the current batch's application. */
  private findMainPageConfig(): ConfigPageType | null {
    const cfg = this.appConfig();
    const d = this.detail();
    if (!cfg || !d) return null;
    const app = (cfg.applications || []).find(a => a.name === d.batch.application);
    if (!app) return null;
    const docTypes = app.documentTypes as any[];
    if (!docTypes?.length || typeof docTypes[0] === 'string') return null;
    const dt = docTypes[0];
    const main = (dt.pageTypes || []).find((p: ConfigPageType) => p.pageType === 'MainPage');
    return main || null;
  }
 
  /** Resolve a dropdown's option list from inline Options or from a Dictionary ref. */
  private resolveOptions(fc: ConfigField): { value: string; label: string }[] | undefined {
    if (fc.DataType !== 'Dropdown') return undefined;
    let opts: FieldOption[] | undefined = fc.Options;
    if (!opts && fc.OptionsRef) {
      const dict = this.appConfig()?.dictionaries || {};
      opts = dict[fc.OptionsRef];
    }
    if (!opts) return [];
    return opts.map(o => ({ value: o.Value, label: o.Label }));
  }
 
  /** Auto-populate value from a batch property, with optional formatting. */
  private resolveAutoValue(prop: string, format?: string, transform?: string): string {
    const d = this.detail();
    if (!d) return '';
    const raw = (d.batch as any)?.[prop];
    if (raw == null) return '';
    let s = String(raw);
    if (format === 'YYYYMMDD') {
      const ms = Date.parse(s);
      if (!Number.isNaN(ms)) {
        const dt = new Date(ms);
        const y = dt.getFullYear();
        const m = String(dt.getMonth() + 1).padStart(2, '0');
        const day = String(dt.getDate()).padStart(2, '0');
        s = `${y}${m}${day}`;
      }
    }
    if (transform === 'uppercase') s = s.toUpperCase();
    return s;
  }
 
  // ----- Panel toggles -----
  toggleLeft() { this.leftCollapsed.update(v => !v); }
  toggleMiddle() { this.middleCollapsed.update(v => !v); }
  toggleRight() { this.rightCollapsed.update(v => !v); }
 
  // ----- Field editing -----
  onFieldChange(name: string, value: string) {
    const list = this.fieldEdits().map(e =>
      e.fieldName === name ? { ...e, currentValue: value } : e
    );
    this.setFieldEditsForCurrentDoc(list);
    // Clear stale submit-blocking errors as the user types. The live
    // requiredFieldErrors() computed will re-evaluate on every change.
    if (this.submitBlockingErrors().length > 0) {
      this.submitBlockingErrors.set([]);
    }
  }
 
  /**
   * Compute the pixel width for a line item column based on its header
   * label. Uses ~7px per character plus 24px padding (for cell borders
   * + dropdown chevron). Combined with `table-layout: fixed` in SCSS,
   * this locks the column width to the header so longer row content
   * doesn't push the column wider — long cell values truncate with
   * ellipsis instead. Floor at 60px so single-letter labels still have
   * a usable minimum width.
   */
  columnWidth(label: string): number {
    const charCount = (label || '').length;
    return Math.max(60, charCount * 7 + 24);
  }
 
  fieldClass(e: FieldEdit): string {
    const classes = ['field-row'];
    if (e.currentValue !== e.originalValue) classes.push('dirty');
 
    // Red highlight ONLY for required fields that are currently empty.
    // We deliberately do NOT use the backend's validationPassed flag here
    // because that's a snapshot from when the Validation Lambda ran. By
    // the time the user is editing, auto-populate may have filled the
    // value, or the user may already have typed something. The "live"
    // empty check is the source of truth for the UI.
    const isRequired = e.required && !e.disabled;
    const isEmpty = !e.currentValue || !e.currentValue.trim();
    if (isRequired && isEmpty) {
      classes.push('required-empty');
      classes.push('failed');
    }
    return classes.join(' ');
  }
 
  confidenceBarColor(conf: number | null): string {
    if (conf == null) return 'transparent';
    if (conf >= 90) return 'rgba(46, 204, 113, 0.18)';
    if (conf >= 70) return 'rgba(241, 196, 15, 0.20)';
    return 'rgba(231, 76, 60, 0.20)';
  }
 
  // ----- Line items grid -----
 
  addLineItemRow() {
    const cfg = this.lineItemsConfig();
    if (!cfg) return;
    const cells: { [k: string]: string } = {};
    for (const col of cfg.Columns) {
      cells[col.FieldName] = col.DefaultValue != null ? String(col.DefaultValue) : '';
    }
    const row: LineItemRow = { rowId: `li-${this.nextRowSeq++}`, cells };
    this.setLineItemsForCurrentDoc([...this.lineItems(), row]);
    this.selectedRowId.set(row.rowId);
  }
 
  deleteSelectedLineItemRow() {
    const sel = this.selectedRowId();
    if (!sel) return;
    this.setLineItemsForCurrentDoc(this.lineItems().filter(r => r.rowId !== sel));
    this.selectedRowId.set(null);
  }
 
  selectLineItemRow(rowId: string) {
    this.selectedRowId.set(rowId);
  }
 
  onLineItemCellChange(rowId: string, columnName: string, value: string) {
    const updated = this.lineItems().map(r => {
      if (r.rowId !== rowId) return r;
      return { ...r, cells: { ...r.cells, [columnName]: value } };
    });
    this.setLineItemsForCurrentDoc(updated);
  }
 
  private setLineItemsFromCif(items: { [k: string]: string }[]) {
    const rows: LineItemRow[] = items.map(cells => ({
      rowId: `li-${this.nextRowSeq++}`,
      cells: { ...cells },
    }));
    this.setLineItemsForCurrentDoc(rows);
    this.selectedRowId.set(null);
  }
 
  // ============================================================
  // Stage 7: Tree operations (Move/Delete/Split/Undo)
  // ============================================================
 
  /**
   * Pure reducer that applies a sequence of TreeOps to a (pages, docs)
   * snapshot. Returns NEW arrays — does not mutate inputs. Used by the
   * effectivePages/effectiveDocuments computed signals AND will be used
   * server-side by api-proxy to apply the same ops against persisted
   * state (giving identical UI-preview and DDB-persisted outcomes).
   *
   * Each op is best-effort: if a referenced pageId/docId doesn't exist
   * (e.g. another op deleted it earlier in the sequence), the op is
   * skipped silently. This keeps undo simple — pop the last op and
   * recompute, even if intermediate ops referenced ids that are now
   * gone.
   */
  private applyTreeOps(
    pagesIn: PageDetail[],
    docsIn: DocumentDetail[],
    ops: TreeOp[],
  ): { pages: PageDetail[]; docs: DocumentDetail[] } {
    // Work on shallow copies — caller already cloned but be defensive.
    let pages = pagesIn.map(p => ({ ...p }));
    let docs = docsIn.map(d => ({ ...d, pageIds: [...(d.pageIds || [])] }));
 
    const findDocForPage = (pageId: string): DocumentDetail | undefined =>
      docs.find(d => (d.pageIds || []).includes(pageId));
 
    for (const op of ops) {
      switch (op.kind) {
        case 'movePageUp':
        case 'movePageDown': {
          const doc = findDocForPage(op.pageId);
          if (!doc) break;
          const ids = doc.pageIds;
          const idx = ids.indexOf(op.pageId);
          if (idx < 0) break;
          const swapIdx = op.kind === 'movePageUp' ? idx - 1 : idx + 1;
          if (swapIdx < 0 || swapIdx >= ids.length) break;
          [ids[idx], ids[swapIdx]] = [ids[swapIdx], ids[idx]];
          // Re-derive pageNumber from the new order so callers that
          // sort by pageNumber see the right sequence.
          this.renumberPagesInDoc(doc, pages);
          break;
        }
        case 'deletePage': {
          const doc = findDocForPage(op.pageId);
          if (!doc) break;
          doc.pageIds = doc.pageIds.filter(id => id !== op.pageId);
          pages = pages.filter(p => p.pageId !== op.pageId);
          this.renumberPagesInDoc(doc, pages);
          break;
        }
        case 'moveDocUp':
        case 'moveDocDown': {
          const idx = docs.findIndex(d => d.documentId === op.docId);
          if (idx < 0) break;
          const swapIdx = op.kind === 'moveDocUp' ? idx - 1 : idx + 1;
          if (swapIdx < 0 || swapIdx >= docs.length) break;
          [docs[idx], docs[swapIdx]] = [docs[swapIdx], docs[idx]];
          break;
        }
        case 'deleteDoc': {
          const doc = docs.find(d => d.documentId === op.docId);
          if (!doc) break;
          const dropped = new Set(doc.pageIds);
          docs = docs.filter(d => d.documentId !== op.docId);
          pages = pages.filter(p => !dropped.has(p.pageId));
          break;
        }
        case 'splitDoc': {
          const idx = docs.findIndex(d => d.documentId === op.docId);
          if (idx < 0) break;
          const orig = docs[idx];
          const splitAt = orig.pageIds.indexOf(op.atPageId);
          if (splitAt <= 0) break;  // can't split at first page; that's a no-op
          // First [0..splitAt-1] stays with original; [splitAt..end] go to new doc.
          const newPageIds = orig.pageIds.slice(splitAt);
          orig.pageIds = orig.pageIds.slice(0, splitAt);
          // New doc inherits type from parent (per spec).
          const newDoc: DocumentDetail = {
            documentId: `split-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
            documentType: orig.documentType,
            validationStatus: 'NeedsReview',
            pageIds: newPageIds,
            extractedFields: [],
            lineItems: [],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          };
          docs.splice(idx + 1, 0, newDoc);
          // First page of new doc becomes MainPage; rest become TrailingPage.
          newPageIds.forEach((pid, i) => {
            const p = pages.find(pp => pp.pageId === pid);
            if (!p) return;
            p.pageType = i === 0 ? 'MainPage' : 'TrailingPage';
          });
          this.renumberPagesInDoc(orig, pages);
          this.renumberPagesInDoc(newDoc, pages);
          break;
        }
      }
    }
    return { pages, docs };
  }
 
  /** Renumber pageNumber on each page of a doc, 1..N, in pageIds order. */
  private renumberPagesInDoc(doc: DocumentDetail, allPages: PageDetail[]): void {
    doc.pageIds.forEach((pid, i) => {
      const p = allPages.find(pp => pp.pageId === pid);
      if (p) p.pageNumber = i + 1;
    });
  }
 
  // ----- Tree selection -----
 
  /**
   * Called when the user clicks a row in the Batch Structure panel.
   * Tracks both the id and the row type so the toolbar buttons can
   * enable/disable based on what's selected.
   */
  selectTreeRow(row: BatchStructureRow): void {
    this.selectedTreeId.set(row.treeKey || null);
    this.selectedTreeType.set(row.rowType);
    // Page rows still drive the viewer scroll (existing behavior).
    if (row.rowType === 'page' && row.pageId) {
      this.scrollToPage(row.pageId);
    }
  }
 
  /** Currently selected row in the structure panel, if any. */
  private selectedRow(): BatchStructureRow | null {
    const key = this.selectedTreeId();
    if (!key) return null;
    return this.batchStructure().find(r => r.treeKey === key) || null;
  }
 
  // ----- Tree op gates (computed enabled-state for toolbar buttons) -----
 
  readonly canMoveUp = computed<boolean>(() => {
    const row = this.selectedRow();
    if (!row || !this.canEdit()) return false;
    if (row.rowType === 'batch') return false;
    if (row.rowType === 'page') {
      const doc = this.effectiveDocuments().find(d => (d.pageIds || []).includes(row.pageId!));
      return doc ? doc.pageIds.indexOf(row.pageId!) > 0 : false;
    }
    if (row.rowType === 'doc') {
      const idx = this.effectiveDocuments().findIndex(d => d.documentId === row.docId);
      return idx > 0;
    }
    return false;
  });
 
  readonly canMoveDown = computed<boolean>(() => {
    const row = this.selectedRow();
    if (!row || !this.canEdit()) return false;
    if (row.rowType === 'batch') return false;
    if (row.rowType === 'page') {
      const doc = this.effectiveDocuments().find(d => (d.pageIds || []).includes(row.pageId!));
      if (!doc) return false;
      const idx = doc.pageIds.indexOf(row.pageId!);
      return idx >= 0 && idx < doc.pageIds.length - 1;
    }
    if (row.rowType === 'doc') {
      const docs = this.effectiveDocuments();
      const idx = docs.findIndex(d => d.documentId === row.docId);
      return idx >= 0 && idx < docs.length - 1;
    }
    return false;
  });
 
  readonly canDeleteSelected = computed<boolean>(() => {
    const row = this.selectedRow();
    if (!row || !this.canEdit()) return false;
    // Only pages and docs are deletable. Batch itself isn't.
    return row.rowType === 'page' || row.rowType === 'doc';
  });
 
  readonly canSplitSelected = computed<boolean>(() => {
    const row = this.selectedRow();
    if (!row || !this.canEdit()) return false;
    // Split applies to a page. Can't split at the FIRST page of a doc
    // (that's a no-op), so require pageIds.indexOf > 0.
    if (row.rowType !== 'page') return false;
    const doc = this.effectiveDocuments().find(d => (d.pageIds || []).includes(row.pageId!));
    return doc ? doc.pageIds.indexOf(row.pageId!) > 0 : false;
  });
 
  readonly canUndo = computed<boolean>(() =>
    this.canEdit() && this.pendingTreeOps().length > 0,
  );
 
  // ----- Tree op triggers -----
 
  treeMoveUp(): void {
    const row = this.selectedRow();
    if (!row || !this.canMoveUp()) return;
    if (row.rowType === 'page') {
      this.pushTreeOp({ kind: 'movePageUp', pageId: row.pageId! });
    } else if (row.rowType === 'doc') {
      this.pushTreeOp({ kind: 'moveDocUp', docId: row.docId! });
    }
  }
 
  treeMoveDown(): void {
    const row = this.selectedRow();
    if (!row || !this.canMoveDown()) return;
    if (row.rowType === 'page') {
      this.pushTreeOp({ kind: 'movePageDown', pageId: row.pageId! });
    } else if (row.rowType === 'doc') {
      this.pushTreeOp({ kind: 'moveDocDown', docId: row.docId! });
    }
  }
 
  treeDelete(): void {
    const row = this.selectedRow();
    if (!row || !this.canDeleteSelected()) return;
    if (row.rowType === 'page') {
      this.pushTreeOp({ kind: 'deletePage', pageId: row.pageId! });
      // Cleared selection since the row no longer exists.
      this.selectedTreeId.set(null);
      this.selectedTreeType.set(null);
    } else if (row.rowType === 'doc') {
      this.pushTreeOp({ kind: 'deleteDoc', docId: row.docId! });
      this.selectedTreeId.set(null);
      this.selectedTreeType.set(null);
    }
  }
 
  treeSplit(): void {
    const row = this.selectedRow();
    if (!row || !this.canSplitSelected()) return;
    const doc = this.effectiveDocuments().find(d => (d.pageIds || []).includes(row.pageId!));
    if (!doc) return;
    this.pushTreeOp({ kind: 'splitDoc', docId: doc.documentId, atPageId: row.pageId! });
    // Issue 3: after the pushTreeOp, effectiveDocuments() now has a new
    // doc. Seed its field-edits + line-items entries from config so when
    // the user navigates to one of its pages, the panel shows the right
    // schema (required fields blank, disabled+auto fields populated)
    // instead of an empty grid.
    this.seedSplitCreatedDocs();
    this.closeAllDropdowns();
  }
 
  /**
   * For any doc in effectiveDocuments() that doesn't yet have an entry in
   * fieldEditsByDoc, build one from the MainPage config (disabled+auto
   * fields populated from batch meta; everything else empty). Also seeds
   * an empty lineItems array. Idempotent — only seeds docs not already
   * in the maps.
   */
  private seedSplitCreatedDocs(): void {
    const mainPage = this.findMainPageConfig();
    if (!mainPage) return;
    const fEdits = new Map(this.fieldEditsByDoc());
    const lItems = new Map(this.lineItemsByDoc());
    let fTouched = false;
    let lTouched = false;
    for (const doc of this.effectiveDocuments()) {
      if (!fEdits.has(doc.documentId)) {
        const edits: FieldEdit[] = (mainPage.fields || []).map(fc => {
          let value: string;
          if (fc.Disabled && fc.AutoPopulateFrom) {
            value = this.resolveAutoValue(fc.AutoPopulateFrom, fc.Format, fc.Transform);
          } else if (fc.DefaultValue != null) {
            value = String(fc.DefaultValue);
          } else {
            value = '';
          }
          return {
            fieldName: fc.FieldName,
            label: fc.Label || fc.FieldName,
            dataType: fc.DataType,
            originalValue: value,
            currentValue: value,
            confidence: null,
            required: fc.Required ?? false,
            disabled: fc.Disabled ?? false,
            options: this.resolveOptions(fc),
            validationError: null,
          };
        });
        fEdits.set(doc.documentId, edits);
        fTouched = true;
      }
      if (!lItems.has(doc.documentId)) {
        lItems.set(doc.documentId, []);
        lTouched = true;
      }
    }
    if (fTouched) this.fieldEditsByDoc.set(fEdits);
    if (lTouched) this.lineItemsByDoc.set(lItems);
  }
 
  treeUndo(): void {
    if (!this.canUndo()) return;
    this.pendingTreeOps.update(ops => ops.slice(0, -1));
  }
 
  private pushTreeOp(op: TreeOp): void {
    this.pendingTreeOps.update(ops => [...ops, op]);
  }
 
  // ============================================================
  // Stage 7: Run Validations (client-side)
  // ============================================================
 
  /**
   * Validate all configured Required (non-disabled) fields have non-empty
   * values. No server call — uses fieldEdits() which is already the live
   * snapshot of what the user has entered.
   *
   * On pass: sets validationOverride to 'Reviewed'. This drives:
   *   - the batchStructure() cascade so MainPage shows OK and roll-up
   *     propagates to doc/batch
   *   - the validation override sent on next Submit/Hold so DDB
   *     persists the OK state across reopens
   *
   * On fail: surfaces the missing fields via submitBlockingErrors so the
   * user sees which fields to fill in. Override is NOT set.
   */
  onRunValidations(): void {
    this.closeAllDropdowns();
    const errs = this.requiredFieldErrors();
    if (errs.length > 0) {
      this.submitBlockingErrors.set(errs);
      this.validationOverride.set(null);
      return;
    }
    // All required fields pass; promote to "Reviewed" (UI-local for now;
    // persists on next Submit/Hold).
    this.submitBlockingErrors.set([]);
    this.validationOverride.set('Reviewed');
  }
 
  // ----- CIF lookup -----
 
  /**
   * Issue 3: per-document gated auto-CIF-lookup. Each document's
   * PolicyNumber triggers at most one auto-lookup per session. Skip
   * docs that already have line items from DDB.
   *
   * Called from the existing effect when appConfig+detail are ready —
   * NOT registered as its own effect (which had caused the freeze
   * during the failed Stage 11 deploy). The single existing effect
   * still drives this; calling for the current doc only is enough,
   * since CIF can also be triggered manually via Tasks → CIFLookup
   * when the user navigates to a different doc.
   */
  private maybeAutoCifLookup() {
    if (!this.appConfig() || !this.detail()) return;
    const docId = this.currentDocId();
    if (!docId) return;
    if (this.autoLookupAttempted.has(docId)) return;
    this.autoLookupAttempted.add(docId);
 
    // If DDB already gave us line items, do NOT call CIF on load — the
    // user previously submitted these values and we must not overwrite.
    if (this.lineItems().length > 0) return;    const policy = this.getFieldValue('PolicyNumber');
    if (!policy) return;
    this.runCifLookup('policy_number', policy);
  }
 
  onTaskCifLookup() {
    this.closeAllDropdowns();
    const policy = this.getFieldValue('PolicyNumber');
    if (!policy) {
      this.cifLookupError.set('Enter a Policy Number first, then try again.');
      return;
    }
    this.runCifLookup('policy_number', policy);
  }
 
  private runCifLookup(type: 'policy_number' | 'ssn' | 'cif_number', value: string) {
    this.cifLookupBusy.set(true);
    this.cifLookupError.set(null);
    this.cifSvc.lookup(type, value).subscribe({
      next: (result: CifLookupResult) => {
        this.applyCifResult(result);
        this.cifLookupBusy.set(false);
      },
      error: err => {
        console.error('CIF lookup failed:', err);
        this.cifLookupBusy.set(false);
        this.cifLookupError.set(
          err?.error?.detail || err?.message || 'CIF lookup failed (is the local proxy running on :5000?)'
        );
      },
    });
  }
 
  private applyCifResult(r: CifLookupResult) {
    const setIfPresent = (fieldName: string, value: string) => {
      const list = this.fieldEdits();
      const idx = list.findIndex(e => e.fieldName === fieldName);
      if (idx < 0) return;
      const next = [...list];
      next[idx] = { ...next[idx], currentValue: value };
      this.setFieldEditsForCurrentDoc(next);
    };
 
    setIfPresent('PolicyNumber', r.policyNumber);
    setIfPresent('SSN', r.ssn);
    setIfPresent('CIFNumber', r.cifNumber);
    setIfPresent('CustomerName', r.customerName);
    setIfPresent('Address', [r.addressLine1, r.addressLine2, r.addressLine3, r.city, r.state, r.zip]
      .filter(s => s).join(', '));
 
    const rows = r.lineItems.map(li => {
      const cells: { [k: string]: string } = {};
      cells['Policy'] = li.policyNumber;
      cells['LOB'] = li.lineOfBusiness;
      cells['Status'] = li.policyStatus;
      cells['IssueState'] = li.issueState;
      cells['BillForm'] = li.billForm;
      cells['PlanCode'] = li.productCode;
      cells['CustomerName'] = r.customerName;
      return cells;
    });
    this.setLineItemsFromCif(rows);
  }
 
  private getFieldValue(fieldName: string): string {
    return this.fieldEdits().find(e => e.fieldName === fieldName)?.currentValue || '';
  }
 
  // ----- Page navigation -----
  scrollToPage(pageId: string) {
    this.currentPageId.set(pageId);
    const el = document.querySelector(`[data-page-id="${pageId}"]`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }
 
  onViewerScroll() {
    const scroll = this.viewerScrollRef?.nativeElement;
    if (!scroll) return;
    const scrollTop = scroll.scrollTop;
    let candidate: string | null = null;
    const blocks = scroll.querySelectorAll<HTMLElement>('.page-block');
    blocks.forEach(block => {
      if (block.offsetTop <= scrollTop + scroll.clientHeight / 2) {
        candidate = block.getAttribute('data-page-id');
      }
    });
    if (candidate && candidate !== this.currentPageId()) {
      this.currentPageId.set(candidate);
    }
  }
 
  goToPreviousPage() {
    const pages = this.pages();
    const idx = this.currentPageIndex();
    if (idx > 0) {
      const target = pages[idx - 1].pageId;
      this.currentPageId.set(target);
      const el = document.querySelector(`[data-page-id="${target}"]`);
      el?.scrollIntoView({ block: 'start' });
    }
    this.closeAllDropdowns();
  }
 
  goToNextPage() {
    const pages = this.pages();
    const idx = this.currentPageIndex();
    if (idx < pages.length - 1) {
      const target = pages[idx + 1].pageId;
      this.currentPageId.set(target);
      const el = document.querySelector(`[data-page-id="${target}"]`);
      el?.scrollIntoView({ block: 'start' });
    }
    this.closeAllDropdowns();
  }
 
  // ----- Viewer controls -----
  zoomIn() { this.zoom.update(z => Math.min(z + 0.1, 3.0)); }
  zoomOut() { this.zoom.update(z => Math.max(z - 0.1, 0.25)); }
 
  setFitMode(mode: FitMode) {
    this.fitMode.set(mode);
    this.zoom.set(1.0);
    this.closeAllDropdowns();
  }
 
  toggleInvert() { this.inverted.update(v => !v); }
 
  toggleBrightnessPopover() {
    this.showBrightness.update(v => !v);
  }
 
  resetBrightness() {
    this.brightness.set(100);
    this.contrast.set(100);
    this.saturation.set(100);
  }
 
  imageFilter(): string {
    const parts: string[] = [];
    if (this.inverted()) parts.push('invert(1)');
    if (this.brightness() !== 100) parts.push(`brightness(${this.brightness()}%)`);
    if (this.contrast() !== 100) parts.push(`contrast(${this.contrast()}%)`);
    if (this.saturation() !== 100) parts.push(`saturate(${this.saturation()}%)`);
    return parts.join(' ') || 'none';
  }
 
  // ----- Rotation -----
  rotateCurrentPage(delta: number) {
    const pid = this.currentPageId();
    if (!pid) return;
    this.pageRotation.update(map => ({
      ...map,
      [pid]: ((map[pid] || 0) + delta + 360) % 360,
    }));
    this.closeAllDropdowns();
  }
 
  rotateCW() { this.rotateCurrentPage(90); }
  rotateCCW() { this.rotateCurrentPage(-90); }
  rotate180() { this.rotateCurrentPage(180); }
 
  rotationFor(pageId: string): number {
    return this.pageRotation()[pageId] || 0;
  }
 
  imageStyle(pageId: string): Record<string, string> {
    const rot = this.rotationFor(pageId);
    const z = this.zoom();
    return {
      transform: `rotate(${rot}deg) scale(${z})`,
      filter: this.imageFilter(),
      transformOrigin: 'center top',
    };
  }
 
  pageBlockClass(): string {
    return this.fitMode() === 'height' ? 'fit-height' : 'fit-width';
  }
 
  placeholder(name: string) {
    console.log(`Placeholder action: ${name}`);
    this.closeAllDropdowns();
  }
 
  // ----- Click N -----
  toggleClickN() {
    const pid = this.currentPageId();
    if (pid && this.rotationFor(pid) !== 0 && !this.drawMode()) {
      this.showRotateToast.set(true);
      setTimeout(() => this.showRotateToast.set(false), 2500);
      return;
    }
    // Magnifier and Click N are mutually exclusive — turning Click N on
    // turns the magnifier off and vice versa, so the cursor never has
    // an ambiguous behavior.
    if (!this.drawMode()) {
      this.magnifierMode.set(false);
      this.magnifier.set(null);
    }
    this.drawMode.update(v => !v);
    this.drawBox.set(null);
  }
 
  // ----- Magnifier (rectangular lens) -----
  /**
   * Toggle the magnifier lens. Mutually exclusive with Click N. Magnifier
   * needs the page to be unrotated for the source-pixel math to line up
   * — same constraint as Click N.
   */
  toggleMagnifier() {
    const pid = this.currentPageId();
    if (pid && this.rotationFor(pid) !== 0 && !this.magnifierMode()) {
      this.showRotateToast.set(true);
      setTimeout(() => this.showRotateToast.set(false), 2500);
      return;
    }
    if (!this.magnifierMode()) {
      // Turning magnifier ON: disable Click N to avoid cursor conflict.
      this.drawMode.set(false);
      this.drawBox.set(null);
    } else {
      // Turning magnifier OFF: clear the lens overlay.
      this.magnifier.set(null);
    }
    this.magnifierMode.update(v => !v);
  }
 
  /**
   * Update the lens position as the cursor moves over a page image.
   * Called from (mousemove) on .page-image-wrap. We keep the previous
   * zoom level when moving so the user's adjustment via wheel persists.
   */
  onMagnifierMove(event: MouseEvent, pageId: string) {
    if (!this.magnifierMode()) return;
    if (this.rotationFor(pageId) !== 0) {
      // Silently hide — toast already fired when entering magnifier mode.
      if (this.magnifier()) this.magnifier.set(null);
      return;
    }
    const img = (event.currentTarget as HTMLElement).querySelector('img');
    if (!img) return;
    const rect = img.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    // Outside the image bounds? Hide the lens.
    if (x < 0 || y < 0 || x > rect.width || y > rect.height) {
      if (this.magnifier()) this.magnifier.set(null);
      return;
    }
    const prevZoom = this.magnifier()?.zoom ?? this.magnifierStartZoom;
    this.magnifier.set({ pageId, x, y, zoom: prevZoom });
  }
 
  /** Lens hides when cursor leaves the page-image-wrap. */
  onMagnifierLeave() {
    if (!this.magnifierMode()) return;
    this.magnifier.set(null);
  }
 
  /**
   * Mouse wheel adjusts the magnification level while magnifier mode is
   * active and the lens is currently visible. preventDefault stops the
   * outer viewer-scroll from scrolling while the user is zooming.
   *
   * Wheel up (deltaY < 0) = zoom in. Wheel down = zoom out.
   * Clamped to [magMinZoom, magMaxZoom] in magZoomStep increments.
   */
  onMagnifierWheel(event: WheelEvent) {
    if (!this.magnifierMode()) return;
    const m = this.magnifier();
    if (!m) return;
    event.preventDefault();
    event.stopPropagation();
    const delta = event.deltaY < 0 ? this.magZoomStep : -this.magZoomStep;
    const newZoom = Math.max(
      this.magMinZoom,
      Math.min(this.magMaxZoom, m.zoom + delta),
    );
    if (newZoom === m.zoom) return;
    this.magnifier.set({ ...m, zoom: newZoom });
  }
 
  /**
   * Computed CSS style for the magnifier lens. Returns null when the
   * lens isn't visible. The computed signal caches the result, so the
   * template binding only updates when one of its inputs (magnifier
   * position/zoom) actually changes — fixes a Stage 10 freeze where the
   * method form was allocating a new object on every CD cycle, causing
   * the [style] binding to thrash and lock the browser.
   *
   * Note: we read from `this.magnifier()` only — the page image element
   * is looked up via DOM query (`document.querySelector`). The DOM
   * lookup happens once per recompute, not once per CD cycle.
   */
  readonly magnifierLensStyleComputed = computed<Record<string, string> | null>(() => {
    const m = this.magnifier();
    if (!m) return null;
    const img = document.querySelector(
      `[data-page-id="${m.pageId}"] img.page-image`
    ) as HTMLImageElement | null;
    if (!img) return null;
    const rect = img.getBoundingClientRect();
    const lensW = this.magnifierLensBaseW * m.zoom;
    const lensH = this.magnifierLensBaseH * m.zoom;
    const bgW = rect.width * m.zoom;
    const bgH = rect.height * m.zoom;
    const lensLeft = m.x - lensW / 2;
    const lensTop  = m.y - lensH / 2;
    const bgX = -(m.x * m.zoom) + lensW / 2;
    const bgY = -(m.y * m.zoom) + lensH / 2;
    return {
      left:   `${lensLeft}px`,
      top:    `${lensTop}px`,
      width:  `${lensW}px`,
      height: `${lensH}px`,
      'background-image':    `url("${img.src}")`,
      'background-size':     `${bgW}px ${bgH}px`,
      'background-position': `${bgX}px ${bgY}px`,
      'background-repeat':   'no-repeat',
    };
  });
 
  /**
   * Per-page template binding helper. Returns the lens style only if
   * the lens is currently on the requested page; null otherwise. The
   * underlying work is done by the computed above, so this is just a
   * cheap signal read + page-id comparison — safe to call from inside
   * a per-page @for loop in the template.
   */
  magnifierLensStyle(pageId: string): Record<string, string> | null {
    const m = this.magnifier();
    if (!m || m.pageId !== pageId) return null;
    return this.magnifierLensStyleComputed();
  }
 
  /** Read-only accessor used by the template's small zoom label inside the lens. */
  magnifierZoomLabel(): string {
    const m = this.magnifier();
    if (!m) return '';
    return `${m.zoom.toFixed(2)}x`;
  }
 
  onPageMouseDown(event: MouseEvent, pageId: string) {
    if (!this.drawMode()) return;
    if (this.rotationFor(pageId) !== 0) {
      this.showRotateToast.set(true);
      setTimeout(() => this.showRotateToast.set(false), 2500);
      return;
    }
    event.preventDefault();
    const img = (event.currentTarget as HTMLElement).querySelector('img');
    if (!img) return;
    const rect = img.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    this.drawBox.set({ pageId, x, y, w: 0, h: 0 });
  }
 
  onPageMouseMove(event: MouseEvent, pageId: string) {
    // Magnifier mode: update lens position. Returns early afterward —
    // drawMode and magnifierMode can't both be active.
    if (this.magnifierMode()) {
      this.onMagnifierMove(event, pageId);
      return;
    }
    if (!this.drawMode()) return;
    const box = this.drawBox();
    if (!box) return;
    const img = document
      .querySelector(`[data-page-id="${box.pageId}"] img`) as HTMLImageElement | null;
    if (!img) return;
    const rect = img.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    this.drawBox.set({
      pageId: box.pageId,
      x: Math.min(box.x, x),
      y: Math.min(box.y, y),
      w: Math.abs(x - box.x),
      h: Math.abs(y - box.y),
    });
  }
 
  onPageMouseUp(_event: MouseEvent) {
    if (!this.drawMode()) return;
    const box = this.drawBox();
    if (!box || box.w < 4 || box.h < 4) {
      this.drawBox.set(null);
      this.drawMode.set(false);
      return;
    }
 
    const text = this.extractTextFromBox(box);
    this.drawBox.set(null);
    this.drawMode.set(false);
 
    if (!text) return;
 
    const target = this.focusedFieldName();
    if (target) {
      this.applyClickNToField(target, text);
    } else {
      this.pendingClickNText.set(text);
      this.showClickNPopup.set(true);
    }
  }
 
  private extractTextFromBox(box: { pageId: string; x: number; y: number; w: number; h: number }): string {
    const page = this.pages().find(p => p.pageId === box.pageId);
    if (!page || !page.ocrWords?.length) return '';
    const img = document
      .querySelector(`[data-page-id="${box.pageId}"] img`) as HTMLImageElement | null;
    if (!img) return '';
    const rect = img.getBoundingClientRect();
    const nl = box.x / rect.width;
    const nt = box.y / rect.height;
    const nr = (box.x + box.w) / rect.width;
    const nb = (box.y + box.h) / rect.height;
    const inside = page.ocrWords.filter(w => {
      const cx = w.bbox.l + w.bbox.w / 2;
      const cy = w.bbox.t + w.bbox.h / 2;
      return cx >= nl && cx <= nr && cy >= nt && cy <= nb;
    });
    if (!inside.length) return '';
    const sorted = [...inside].sort((a, b) => a.bbox.t - b.bbox.t);
    const lines: typeof inside[] = [];
    const lineTol = (sorted[0].bbox.h ?? 0.02) / 2;
    for (const w of sorted) {
      const last = lines[lines.length - 1];
      if (last && Math.abs(w.bbox.t - last[0].bbox.t) <= lineTol) {
        last.push(w);
      } else {
        lines.push([w]);
      }
    }
    return lines
      .map(line => line.sort((a, b) => a.bbox.l - b.bbox.l).map(w => w.text).join(' '))
      .join(' ')
      .trim();
  }
 
  applyPendingTextToField(fieldName: string) {
    const text = this.pendingClickNText();
    if (text == null) return;
    this.applyClickNToField(fieldName, text);
    this.pendingClickNText.set(null);
  }
 
  private applyClickNToField(fieldName: string, text: string) {
    const list = this.fieldEdits().map(e =>
      e.fieldName === fieldName ? { ...e, currentValue: text } : e
    );
    this.setFieldEditsForCurrentDoc(list);
  }
 
  closeClickNPopup() {
    this.showClickNPopup.set(false);
  }
 
  cancelPendingClickN() {
    this.pendingClickNText.set(null);
    this.showClickNPopup.set(false);
  }
 
  onFieldFocus(fieldName: string) {
    this.focusedFieldName.set(fieldName);
    if (this.pendingClickNText() != null) {
      this.applyPendingTextToField(fieldName);
    }
  }
 
  // ----- Search -----
  toggleSearch() {
    this.searchOpen.update(v => !v);
    if (!this.searchOpen()) {
      this.searchQuery.set('');
    }
  }
 
  closeSearch() {
    this.searchOpen.set(false);
    this.searchQuery.set('');
    this.currentMatchIndex.set(0);
  }
 
  onSearchInput(value: string) {
    this.searchQuery.set(value);
    this.currentMatchIndex.set(0);
  }
 
  readonly searchMatches = computed(() => {
    const q = this.searchQuery().trim().toLowerCase();
    if (!q) return [] as { pageId: string; pageNumber: number; bbox: { l: number; t: number; w: number; h: number } }[];
    const out: { pageId: string; pageNumber: number; bbox: { l: number; t: number; w: number; h: number } }[] = [];
    for (const page of this.pages()) {
      for (const w of (page.ocrWords || [])) {
        if (w.text.toLowerCase().includes(q)) {
          out.push({ pageId: page.pageId, pageNumber: page.pageNumber, bbox: w.bbox });
        }
      }
    }
    return out;
  });
 
  readonly searchMatchCount = computed(() => this.searchMatches().length);
 
  nextMatch() {
    const total = this.searchMatchCount();
    if (total === 0) return;
    const i = (this.currentMatchIndex() + 1) % total;
    this.currentMatchIndex.set(i);
    this.scrollToCurrentMatch();
  }
 
  prevMatch() {
    const total = this.searchMatchCount();
    if (total === 0) return;
    const i = (this.currentMatchIndex() - 1 + total) % total;
    this.currentMatchIndex.set(i);
    this.scrollToCurrentMatch();
  }
 
  private scrollToCurrentMatch() {
    const match = this.searchMatches()[this.currentMatchIndex()];
    if (!match) return;
    const el = document.querySelector(`[data-page-id="${match.pageId}"]`);
    if (el) el.scrollIntoView({ block: 'center' });
  }
 
  matchesForPage(pageId: string): { bbox: { l: number; t: number; w: number; h: number }; isCurrent: boolean }[] {
    const out: { bbox: { l: number; t: number; w: number; h: number }; isCurrent: boolean }[] = [];
    const matches = this.searchMatches();
    const currentIdx = this.currentMatchIndex();
    for (let i = 0; i < matches.length; i++) {
      if (matches[i].pageId !== pageId) continue;
      out.push({ bbox: matches[i].bbox, isCurrent: i === currentIdx });
    }
    return out;
  }
 
  openInNewWindow() {
    const pages = this.pages();
    const cur = pages[this.currentPageIndex()];
    if (cur?.imageUrl) {
      window.open(cur.imageUrl, '_blank');
    }
    this.closeAllDropdowns();
  }
 
  doPrint() {
    window.print();
  }
 
  // ----- Action dropdowns -----
  toggleViewerActions() {
    const open = !this.showViewerActions();
    this.closeAllDropdowns();
    this.showViewerActions.set(open);
  }
  toggleFieldActions() {
    const open = !this.showFieldActions();
    this.closeAllDropdowns();
    this.showFieldActions.set(open);
  }
  toggleStructureActions() {
    const open = !this.showStructureActions();
    this.closeAllDropdowns();
    this.showStructureActions.set(open);
  }
  toggleTasksMenu() {
    const open = !this.showTasksMenu();
    this.closeAllDropdowns();
    this.showTasksMenu.set(open);
  }
  closeAllDropdowns() {
    this.showViewerActions.set(false);
    this.showFieldActions.set(false);
    this.showStructureActions.set(false);
    this.showTasksMenu.set(false);
  }
 
  // ----- Submit / Hold / etc. -----
  openConfirm() {
    // Stage 5: hard-gate on required field violations. The button itself
    // is disabled via canSubmit(), but defense-in-depth: never open the
    // confirm dialog if required fields are empty.
    const errs = this.requiredFieldErrors();
    if (errs.length > 0) {
      this.submitBlockingErrors.set(errs);
      return;
    }
    if (!this.canSubmit()) return;
    this.showConfirm.set(true);
  }
 
  closeConfirm() {
    this.showConfirm.set(false);
  }
 
  submitReview() {
    const b = this.batch();
    if (!b) return;
    this.submitting.set(true);
 
    // Issue 3: build per-document payload. For backward compat we ALSO
    // populate root-level corrections/lineItems from the current doc, so
    // the server can fall back to legacy mode if needed.
    const docsPayload = this.buildDocumentsPayload();
    const currentCorrections = this.collectCurrentCorrections();
    const currentLineItems: LineItemRowData[] = this.lineItems().map(r => ({ ...r.cells }));
 
    // Stage 8: send tree state only when the user made structural changes.
    const treeState = this.buildTreeStatePayload();
    const override = this.validationOverride();
 
    this.svc.submitReview(
      b.queueId, currentCorrections, currentLineItems,
      treeState?.docs ?? null,
      treeState?.pages ?? null,
      override,
      docsPayload,
    ).subscribe({
      next: () => {
        this.submitting.set(false);
        this.showConfirm.set(false);
        this.router.navigate(['/batches']);
      },
      error: err => {
        console.error('submitReview error:', err);
        this.submitting.set(false);
        this.errorMessage.set(err?.error?.message || err?.message || 'Submit failed');
      },
    });
  }
 
  /** Collect corrections from the current doc's fieldEdits (skipping disabled). */
  private collectCurrentCorrections(): { fieldName: string; value: string }[] {
    const out: { fieldName: string; value: string }[] = [];
    this.fieldEdits().forEach(e => {
      if (e.disabled) return;
      out.push({ fieldName: e.fieldName, value: e.currentValue });
    });
    return out;
  }
 
  /**
   * Issue 3: build the per-document payload array — one entry per doc
   * with its own corrections + line items. Each doc's corrections are
   * read from fieldEditsByDoc (skipping disabled fields); line items
   * read from lineItemsByDoc.
   */
  private buildDocumentsPayload(): DocumentPayload[] | null {
    const fMap = this.fieldEditsByDoc();
    const lMap = this.lineItemsByDoc();
    const docs = this.effectiveDocuments();
    if (!docs.length) return null;
    const out: DocumentPayload[] = [];
    for (const doc of docs) {
      const edits = fMap.get(doc.documentId) || [];
      const corrections = edits
        .filter(e => !e.disabled)
        .map(e => ({ fieldName: e.fieldName, value: e.currentValue }));
      const rows = lMap.get(doc.documentId) || [];
      const lineItems: LineItemRowData[] = rows.map(r => ({ ...r.cells }));
      out.push({ documentId: doc.documentId, corrections, lineItems });
    }
    return out;
  }
 
  /**
   * Hold = save the current Verify state to DDB without resuming the
   * Step Function. Captures the same payload as Submit (corrections +
   * line items + tree state + validation override) but routes to
   * /save-draft instead of /submit-review.
   *
   * No validation gate - the user is allowed to save partial work even
   * if required fields are empty. The batch stays in ManualReview/hold
   * and will reopen with all values intact next time. CIF auto-lookup
   * will be skipped because line items will be present in DDB.
   *
   * If the backend call fails we surface the error but still let the
   * user retry rather than silently navigating away with unsaved work.
   */
  onHold() {
    const b = this.batch();
    if (!b) return;
    if (this.holding() || this.submitting()) return;
 
    // Issue 3: per-doc payload (same shape as submitReview). Root-level
    // corrections/lineItems are populated from current doc for legacy
    // fallback compatibility.
    const docsPayload = this.buildDocumentsPayload();
    const currentCorrections = this.collectCurrentCorrections();
    const currentLineItems: LineItemRowData[] = this.lineItems().map(r => ({ ...r.cells }));
    const treeState = this.buildTreeStatePayload();
    const override = this.validationOverride();
 
    this.holding.set(true);
    // Issue 2: pass holdAction=true so backend flips status from
    // 'pending' to 'hold' (holdSource='manual'). Step Function task
    // token stays parked either way.
    this.svc.saveDraft(
      b.queueId, currentCorrections, currentLineItems,
      treeState?.docs ?? null,
      treeState?.pages ?? null,
      override,
      true,           // holdAction
      '',             // holdReason
      docsPayload,    // Issue 3: per-doc payload
    ).subscribe({
      next: () => {
        this.holding.set(false);
        // Silent navigate per Datacap-style UX (no toast).
        this.router.navigate(['/batches']);
      },
      error: err => {
        console.error('saveDraft error:', err);
        this.holding.set(false);
        this.errorMessage.set(err?.error?.message || err?.message || 'Hold failed - changes not saved');
      },
    });
  }
 
  /**
   * Stage 8: build the tree-state payload from effectiveDocuments/Pages.
   * Returns null when no tree ops are pending (no point in sending the
   * server identical state to what's already in DDB). When ops are
   * pending we send the FULL effective state - server diffs against
   * DDB to figure out the writes.
   *
   * The payload is stripped down to only the attributes the server
   * acts on: pageId/pageNumber/pageType for pages, documentId/
   * documentType/validationStatus/pageIds for docs. UI-only fields
   * (s3Key, imageUrl, extractedFields, lineItems, etc.) are dropped
   * because the server already has them and Re-sending them would
   * just be wasted bytes.
   */
  private buildTreeStatePayload(): { docs: TreeDocPayload[]; pages: TreePagePayload[] } | null {
    if (this.pendingTreeOps().length === 0) {
      return null;
    }
    const docs: TreeDocPayload[] = this.effectiveDocuments().map(d => ({
      documentId:       d.documentId,
      documentType:     d.documentType,
      validationStatus: d.validationStatus,
      pageIds:          d.pageIds || [],
    }));
    const pages: TreePagePayload[] = this.effectivePages().map(p => ({
      pageId:     p.pageId,
      pageNumber: p.pageNumber,
      pageType:   p.pageType,
    }));
    return { docs, pages };
  }
 
  // ----- UI helpers -----
  pageTypeLabel(t: string): string {
    switch (t) {
      case 'MainPage': return 'Main';
      case 'TrailingPage': return 'Trailing';
      case 'CoverPage': return 'Cover';
      case 'BlankPage': return 'Blank';
      default: return t || 'Unknown';
    }
  }
 
  statusClass(status: string): string {
    switch (status) {
      case 'JobDone':  return 'status-pill success';
      case 'Finished': return 'status-pill success';
      case 'Running':  return 'status-pill info';
      // Stage 7: new "hold" canonical value plus the legacy "OnHold"
      // value still possible during the migration window.
      case 'hold':     return 'status-pill warning';
      case 'pending':  return 'status-pill warning';
      case 'OnHold':   return 'status-pill warning';
      case 'Failed':   return 'status-pill danger';
      case 'Problem':  return 'status-badge problem';
      case 'Scanned':  return 'status-badge scanned';
      // Stage 7: post-validation OK state (MainPage flips from Problem
      // to OK when Run Validations passes).
      case 'OK':       return 'status-badge ok';
      default:         return 'status-pill';
    }
  }
 
  formatTimestamp(): string {
    const d = new Date();
    return d.toLocaleString('en-US', {
      month: 'numeric', day: 'numeric', year: 'numeric',
      hour: 'numeric', minute: '2-digit', second: '2-digit',
      hour12: true,
    });
  }
 
  appName(): string { return this.batch()?.application || ''; }
  jobName(): string { return this.batch()?.jobName || 'HQIndex'; }
 
  onFieldKeydown(event: KeyboardEvent, idx: number) {
    if (event.key === 'Enter') {
      event.preventDefault();
      const inputs = document.querySelectorAll<HTMLInputElement>('.field-input');
      const next = inputs[idx + 1];
      if (next) next.focus();
    }
  }
}