import { CommonModule, DatePipe } from '@angular/common';
import {
  Component,
  OnDestroy,
  OnInit,
  computed,
  inject,
  signal,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
 
import { environment } from '../../../environments/environment';
import {
  Application,
  BatchDetail,
  BatchPage_DTO,
  BatchRow,
  JobSummary,
  TaskHistoryItem,
} from '../../models/document.model';
import { BatchService } from '../../services/batch.service';
import { RefreshInterval, RefreshService } from '../../services/refresh.service';
 
// Issue 1: filter chip taxonomy aligned with Stage 9 status semantics:
//   "Pending" = system routed to ManualReview (validation failure)
//   "Hold"    = user-initiated Hold from Verify screen
// Backend GET /api/batches expands case-insensitively to cover legacy
// OnHold rows during migration.
const STATUS_OPTIONS: string[] = ['Running', 'Pending', 'Hold', 'JobDone', 'Failed'];
const VERIFY_TASK = 'ManualReview';
const EDIT_STATUS_OPTIONS = ['Running', 'Pending', 'Hold', 'Finished', 'JobDone', 'Aborted'];
const PRIORITY_OPTIONS = [1, 2, 3, 4, 5];
 
function wildcardToRegex(pattern: string): RegExp | null {
  if (!pattern) return null;
  const escaped = pattern.replace(/[.+^${}()|[\]\\]/g, '\\$&');
  const withWildcard = escaped.replace(/\*/g, '.*').replace(/\?/g, '.');
  return new RegExp(withWildcard, 'i');
}
 
@Component({
  selector: 'app-batch-monitor',
  standalone: true,
  imports: [CommonModule, FormsModule, DatePipe],
  templateUrl: './batch-monitor.component.html',
  styleUrls: ['./batch-monitor.component.scss'],
  providers: [RefreshService],
})
export class BatchMonitorComponent implements OnInit, OnDestroy {
  private readonly svc = inject(BatchService);
  private readonly refresher = inject(RefreshService);
  private readonly router = inject(Router);
 
  readonly statusOptions = STATUS_OPTIONS;
  readonly editStatusOptions = EDIT_STATUS_OPTIONS;
  readonly priorityOptions = PRIORITY_OPTIONS;
 
  // ----- Filters / data -----
  application = signal<string>(environment.defaultApplication);
  selectedStatuses = signal<string[]>([]);
  search = signal<string>('');
 
  page = signal(1);
  readonly pageSize = environment.defaultPageSize;
 
  autoRefreshEnabled = signal(false);
  autoRefreshInterval = signal<RefreshInterval>('10s');
 
  loading = signal(false);
  errorMessage = signal<string | null>(null);
  applications = signal<Application[]>([]);
  jobs = signal<JobSummary[]>([]);
 
  pageData = signal<BatchPage_DTO | null>(null);
  readonly allBatches = computed<BatchRow[]>(() => this.pageData()?.batches || []);
 
  readonly batches = computed<BatchRow[]>(() => {
    const all = this.allBatches();
    const term = this.search().trim();
    if (!term) return all;
    const rx = wildcardToRegex(term);
    if (!rx) return all;
    return all.filter(b =>
      rx.test(b.batchId || '') ||
      rx.test(b.batchNumber || '') ||
      rx.test(b.currentTask || '') ||
      rx.test(String(b.queueId)),
    );
  });
 
  readonly totalCount = computed(() => this.batches().length);
  readonly totalPages = computed(() => Math.max(1, Math.ceil(this.totalCount() / this.pageSize)));
 
  readonly visibleBatches = computed<BatchRow[]>(() => {
    const filtered = this.batches();
    const start = (this.page() - 1) * this.pageSize;
    return filtered.slice(start, start + this.pageSize);
  });
 
  lastRefreshTime = signal<number>(Date.now());
  private clockTimer: any = null;
 
  // ----- Selection / detail -----
  selectedQueueId = signal<number | null>(null);
  selectedDetail = signal<BatchDetail | null>(null);
  detailLoading = signal(false);
 
  // ----- Panel collapse -----
  leftCollapsed = signal(false);
  rightCollapsed = signal(false);
 
  // ----- Properties sub-section collapse (new) -----
  propertiesExpanded = signal(true);          // small section default OPEN
  systemPropertiesExpanded = signal(false);   // large section default CLOSED
 
  // ----- Modals -----
  showHistory = signal(false);
  showEditProps = signal(false);
 
  // ----- Edit Job Properties fields -----
  editBatchId = signal('');
  editBatchDirectory = signal('');
  editPageFile = signal('');
  editTaskId = signal('');
  editStatus = signal('');
  editOperator = signal('admin');
  editStation = signal('1');
  editPriority = signal(5);
  editInputManually = signal(false);
  editTaskOptions = signal<string[]>([]);
 
  readonly selectedRow = computed<BatchRow | null>(() => {
    const id = this.selectedQueueId();
    if (id == null) return null;
    return this.allBatches().find(b => b.queueId === id) || null;
  });
 
  readonly canViewHistory = computed(() => this.selectedQueueId() != null);
 
  // ----- Lifecycle -----
  ngOnInit(): void {
    this.svc.listApplications().subscribe({
      next: r => this.applications.set(r.applications),
      error: () => { /* non-fatal */ },
    });
    this.reload();
    this.clockTimer = setInterval(() => this.lastRefreshTime.set(this.lastRefreshTime()), 1000);
  }
 
  ngOnDestroy(): void {
    this.refresher.stop();
    if (this.clockTimer) clearInterval(this.clockTimer);
  }
 
  // ----- App switcher -----
  onApplicationChange(app: string) {
    if (!app || app === this.application()) return;
    this.application.set(app);
    this.selectedQueueId.set(null);
    this.selectedDetail.set(null);
    this.page.set(1);
    this.reload();
  }
 
  // ----- Filters / search -----
  toggleStatus(status: string) {
    const current = this.selectedStatuses();
    if (current.includes(status)) {
      this.selectedStatuses.set(current.filter(s => s !== status));
    } else {
      this.selectedStatuses.set([...current, status]);
    }
    this.page.set(1);
    this.reload();
  }
 
  isStatusSelected(status: string): boolean {
    return this.selectedStatuses().includes(status);
  }
 
  onSearchChange(value: string) {
    this.search.set(value);
    this.page.set(1);
  }
 
  clearSearch() {
    this.search.set('');
    this.page.set(1);
  }
 
  // ----- Pagination -----
  goToPage(p: number) {
    const target = Math.max(1, Math.min(this.totalPages(), p));
    if (target === this.page()) return;
    this.page.set(target);
  }
 
  // ----- Auto-refresh -----
  onAutoRefreshToggle(enabled: boolean) {
    this.autoRefreshEnabled.set(enabled);
    this.applyRefreshSchedule();
  }
 
  onIntervalChange(value: string) {
    this.autoRefreshInterval.set(value as RefreshInterval);
    this.applyRefreshSchedule();
  }
 
  private applyRefreshSchedule() {
    if (!this.autoRefreshEnabled()) {
      this.refresher.stop();
      return;
    }
    this.refresher.start(this.autoRefreshInterval(), () => this.reload());
  }
 
  // ----- Data load -----
  reload() {
    this.loading.set(true);
    this.errorMessage.set(null);
 
    const statuses = this.selectedStatuses();
    const query = {
      application: this.application(),
      status: statuses.length ? statuses.join(',') : undefined,
      page: 1,
      pageSize: this.pageSize,
    };
 
    this.svc.listBatches(query).subscribe({
      next: data => {
        this.pageData.set(data);
        this.loading.set(false);
        this.lastRefreshTime.set(Date.now());
        this.autoSelectFirstIfNeeded();
        if (this.selectedQueueId() != null && !this.selectedRow()) {
          this.selectedQueueId.set(null);
          this.selectedDetail.set(null);
          this.autoSelectFirstIfNeeded();
        }
      },
      error: err => {
        console.error('listBatches error:', err);
        this.errorMessage.set(err?.error?.message || err?.message || 'Failed to load batches');
        this.loading.set(false);
      },
    });
 
    this.svc.listJobs(this.application()).subscribe({
      next: r => this.jobs.set(r.jobs),
      error: () => { /* non-fatal */ },
    });
  }
 
  private autoSelectFirstIfNeeded() {
    if (this.selectedQueueId() != null) return;
    const first = this.allBatches()[0];
    if (first) {
      this.selectedQueueId.set(first.queueId);
      this.loadDetail(first.queueId);
    }
  }
 
  refreshNow() {
    this.reload();
    if (this.selectedQueueId() != null) {
      this.loadDetail(this.selectedQueueId()!);
    }
  }
 
  // ----- Row interaction -----
  onRowSingleClick(row: BatchRow) {
    this.selectedQueueId.set(row.queueId);
    this.loadDetail(row.queueId);
  }
 
  onRowDoubleClick(row: BatchRow) {
    this.selectedQueueId.set(row.queueId);
    if (row.currentTask === VERIFY_TASK) {
      this.router.navigate(['/verify', row.queueId]);
    } else {
      this.loadDetail(row.queueId, () => this.openEditProps(row));
    }
  }
 
  private loadDetail(queueId: number, onComplete?: () => void) {
    this.detailLoading.set(true);
    this.svc.getBatch(queueId).subscribe({
      next: d => {
        this.selectedDetail.set(d);
        this.detailLoading.set(false);
        if (onComplete) onComplete();
      },
      error: err => {
        console.error('getBatch error:', err);
        this.detailLoading.set(false);
        this.errorMessage.set(err?.error?.message || err?.message || 'Failed to load batch detail');
      },
    });
  }
 
  // ----- Panel collapse -----
  toggleLeft() { this.leftCollapsed.update(v => !v); }
  toggleRight() { this.rightCollapsed.update(v => !v); }
  toggleProperties() { this.propertiesExpanded.update(v => !v); }
  toggleSystemProperties() { this.systemPropertiesExpanded.update(v => !v); }
 
  // ----- View History -----
  openHistory() {
    if (!this.canViewHistory()) return;
    this.showHistory.set(true);
  }
  closeHistory() { this.showHistory.set(false); }
 
  readonly historyItems = computed<TaskHistoryItem[]>(() => {
    const d = this.selectedDetail();
    return d?.taskHistory || [];
  });
 
  // ----- Edit Job Properties -----
  private openEditProps(row: BatchRow) {
    const detail = this.selectedDetail();
    const completedTasks = (detail?.taskHistory || [])
      .map(t => t.taskName)
      .filter((t, idx, arr) => arr.indexOf(t) === idx);
    if (row.currentTask && !completedTasks.includes(row.currentTask)) {
      completedTasks.push(row.currentTask);
    }
 
    this.editBatchId.set(row.batchNumber);
    this.editBatchDirectory.set(this.batchDirectory());
    this.editPageFile.set(`${row.currentTask}.xml`);
    this.editTaskId.set(row.currentTask);
    this.editStatus.set(row.status);
    this.editOperator.set(row.operator || 'admin');
    this.editStation.set('1');
    this.editPriority.set(5);
    this.editInputManually.set(false);
    this.editTaskOptions.set(completedTasks);
    this.showEditProps.set(true);
  }
 
  closeEditProps() { this.showEditProps.set(false); }
  applyEditProps() {
    console.log('Edit Job Properties Apply:', {
      batchId: this.editBatchId(),
      batchDirectory: this.editBatchDirectory(),
      pageFile: this.editPageFile(),
      taskId: this.editTaskId(),
      status: this.editStatus(),
      operator: this.editOperator(),
      station: this.editStation(),
      priority: this.editPriority(),
      inputManually: this.editInputManually(),
    });
    this.showEditProps.set(false);
  }
 
  // ----- Properties panel data -----
  batchDirectory(): string {
    const d = this.selectedDetail();
    if (!d?.batch) return '—';
    const sourceKey = d.batch.sourceZipKey;
    if (sourceKey) {
      const parts = sourceKey.split('/');
      parts.pop();
      return parts.join('/') + '/';
    }
    return `aflac_core/applications/${d.batch.application}/Processing/${d.batch.queueId}/`;
  }
 
  taskStartTime(): string | null {
    const d = this.selectedDetail();
    if (!d?.batch) return null;
    return d.batch.manualReviewStartedAt || d.batch.jobStartTime;
  }
 
  // ----- UI helpers -----
  statusClass(status: string): string {
    switch (status) {
      case 'JobDone':  return 'status-pill success';
      case 'Finished': return 'status-pill success';
      case 'Running':  return 'status-pill info';
      // Issue 1: both Pending and Hold are warning (waiting on human).
      case 'Hold':     return 'status-pill warning';
      case 'hold':     return 'status-pill warning';
      case 'Pending':  return 'status-pill warning';
      case 'pending':  return 'status-pill warning';
      case 'OnHold':   return 'status-pill warning';
      case 'Failed':   return 'status-pill danger';
      case 'Aborted':  return 'status-pill danger';
      default:         return 'status-pill';
    }
  }
 
  jobTimeDisplay(secs: number | null): string {
    if (secs == null) return '—';
    if (secs < 60) return `${secs}s`;
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    if (m < 60) return `${m}m ${s}s`;
    const h = Math.floor(m / 60);
    const remainingMin = m % 60;
    return `${h}h ${remainingMin}m`;
  }
 
  lastRefreshAgo(): string {
    const secs = Math.max(0, Math.floor((Date.now() - this.lastRefreshTime()) / 1000));
    if (secs < 5) return 'just now';
    if (secs < 60) return `${secs}s ago`;
    const m = Math.floor(secs / 60);
    return `${m}m ago`;
  }
 
  countFor(status: string): number {
    const job = this.jobs()[0];
    if (!job) return 0;
    const c = job.counts || {};
    // Backend normalizes status before counting (Issue 1 backend change),
    // so legacy OnHold is already split into "hold"/"pending" by holdSource.
    // Case-insensitive lookup matches "Hold" (chip label) to "hold" (backend key).
    return Number(c[status] || c[status.toLowerCase()] || 0);
  }
 
  totalCountAcrossStatuses(): number {
    const job = this.jobs()[0];
    return Number(job?.counts['total'] || 0);
  }
}