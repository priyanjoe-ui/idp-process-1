import { CommonModule } from '@angular/common';
import { Component, computed, inject } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
 
import { AuthService } from '../../services/auth.service';
 
@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, RouterOutlet],
  templateUrl: './shell.component.html',
  styleUrls: ['./shell.component.scss'],
})
export class ShellComponent {
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);
 
  readonly username = computed(() => this.auth.operator() || 'unknown');
  readonly initials = computed(() => {
    const name = this.username();
    if (!name) return '?';
    // Take first two letters of name; if "first.last", take first letters of each
    if (name.includes('.')) {
      const parts = name.split('.');
      return ((parts[0]?.[0] || '') + (parts[1]?.[0] || '')).toUpperCase();
    }
    return name.slice(0, 2).toUpperCase();
  });
 
  logout() {
    this.auth.logout();
    this.router.navigate(['/login']);
  }
}