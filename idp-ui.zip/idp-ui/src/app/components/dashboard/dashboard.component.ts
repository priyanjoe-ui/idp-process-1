import { Component, OnInit, inject, signal, computed } from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BatchService } from '../../services/batch.service';
import {
  DashboardStats,
  DashboardFilter,
  DateRangePreset,
  Application,
} from '../../models/document.model';
 
@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, DecimalPipe, FormsModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  private svc = inject(BatchService);
 
  loading = signal(true);
  stats = signal<DashboardStats | null>(null);
 
  // ---------- Filter state ----------
  applications = signal<Application[]>([]);
  selectedApp = signal<string>('all');
  selectedPreset = signal<DateRangePreset>('today');
  customFrom = signal<string>('');
  customTo = signal<string>('');
 
  // ---------- Derived ----------
  maxTypeCount = computed(() => {
    const s = this.stats();
    if (!s) return 1;
    return Math.max(1, ...s.byDocumentType.map(d => d.count));
  });
 
  maxTimelineCount = computed(() => {
    const s = this.stats();
    if (!s) return 1;
    return Math.max(1, ...s.recentTimeline.map(t => t.processed + t.failed));
  });
 
  filterDescription = computed(() => {
    const app = this.selectedApp() === 'all' ? 'all applications' : this.selectedApp();
    const range = this.presetLabel(this.selectedPreset());
    return `${range} · ${app}`;
  });
 
  ngOnInit(): void {
    this.svc.listApplications().subscribe({
      next: r => this.applications.set(r.applications || []),
      error: () => {},
    });
    this.refresh();
  }
 
  // ---------- Actions ----------
  onPresetChange(preset: DateRangePreset) {
    this.selectedPreset.set(preset);
    if (preset !== 'custom') {
      this.refresh();
    }
  }
 
  onAppChange(app: string) {
    this.selectedApp.set(app);
    this.refresh();
  }
 
  onApplyCustomRange() {
    if (this.selectedPreset() === 'custom') {
      this.refresh();
    }
  }
 
  refresh() {
    this.loading.set(true);
    const filter = this.buildFilter();
    this.svc.dashboard(filter).subscribe({
      next: s => {
        this.stats.set(s);
        this.loading.set(false);
      },
      error: () => this.loading.set(false),
    });
  }
 
  private buildFilter(): DashboardFilter {
    const f: DashboardFilter = {};
    const app = this.selectedApp();
    if (app && app !== 'all') f.application = app;
    const [from, to] = this.resolveDateRange();
    if (from) f.from = from;
    if (to) f.to = to;
    return f;
  }
 
  private resolveDateRange(): [string | undefined, string | undefined] {
    const preset = this.selectedPreset();
    const today = new Date();
    const fmt = (d: Date) =>
      `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
 
    if (preset === 'today') {
      const s = fmt(today);
      return [s, s];
    }
    if (preset === 'yesterday') {
      const y = new Date(today);
      y.setDate(y.getDate() - 1);
      const s = fmt(y);
      return [s, s];
    }
    if (preset === 'last7') {
      const start = new Date(today);
      start.setDate(start.getDate() - 6);
      return [fmt(start), fmt(today)];
    }
    if (preset === 'last30') {
      const start = new Date(today);
      start.setDate(start.getDate() - 29);
      return [fmt(start), fmt(today)];
    }
    if (preset === 'mtd') {
      const start = new Date(today.getFullYear(), today.getMonth(), 1);
      return [fmt(start), fmt(today)];
    }
    if (preset === 'custom') {
      const from = this.customFrom();
      const to = this.customTo();
      return [
        from ? from.replace(/-/g, '') : undefined,
        to ? to.replace(/-/g, '') : undefined,
      ];
    }
    return [undefined, undefined];
  }
 
  presetLabel(p: DateRangePreset): string {
    switch (p) {
      case 'today':     return 'Today';
      case 'yesterday': return 'Yesterday';
      case 'last7':     return 'Last 7 days';
      case 'last30':    return 'Last 30 days';
      case 'mtd':       return 'This month';
      case 'custom':    return 'Custom range';
    }
  }
 
  pctOf(part: number, total: number): number {
    if (!total) return 0;
    return Math.round((part / total) * 100);
  }
 
  barWidth(count: number, max: number): string {
    if (!max) return '0%';
    return Math.max(2, (count / max) * 100) + '%';
  }
}