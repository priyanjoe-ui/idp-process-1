import { Injectable } from '@angular/core';
import { Observable, Subject, Subscription, timer } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
 
export type RefreshInterval = 'off' | '10s' | '30s';
 
@Injectable() // NOT providedIn:root - one per consumer
export class RefreshService {
  private subscription: Subscription | null = null;
  private stop$ = new Subject<void>();
 
  /**
   * Start (or restart) the auto-refresh loop.
   *
   *   start('10s', () => loadData())
   *
   * Calling start() while already running cancels the previous loop
   * and begins a new one with the given interval. Calling stop() (or
   * passing 'off') stops the loop.
   */
  start(interval: RefreshInterval, callback: () => void): void {
    this.stop();
 
    if (interval === 'off') return;
    const ms = this._intervalMs(interval);
    if (!ms) return;
 
    this.subscription = timer(ms, ms).pipe(takeUntil(this.stop$)).subscribe(() => {
      try { callback(); } catch (e) { console.error('Refresh callback error:', e); }
    });
  }
 
  stop(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
      this.subscription = null;
    }
    this.stop$.next();
  }
 
  isRunning(): boolean {
    return !!this.subscription;
  }
 
  private _intervalMs(interval: RefreshInterval): number {
    switch (interval) {
      case '10s': return 10_000;
      case '30s': return 30_000;
      default:    return 0;
    }
  }
}