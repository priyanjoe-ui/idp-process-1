import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';
 
import { environment } from '../../environments/environment';
 
/**
 * Result of a CIF lookup call. The XML returned by the AFLAC service has
 * three logical sections (Party / Address / PolicyProduct) — we flatten
 * them here so the Verify screen can map each value directly to a field.
 *
 * `lineItems` is left as an array because future LOB lookups may return
 * multiple line items per policy. Today the proxy returns a single
 * Policy block, so the array has 0 or 1 entries.
 */
export interface CifLookupResult {
  policyNumber: string;
  ssn: string;          // GovtID (when GovtIDTC == "SSN")
  cifNumber: string;    // IDReferenceNo (when IDReferenceType == "CIFNumber")
  firstName: string;
  middleName: string;
  lastName: string;
  customerName: string; // composed "First Middle Last"
  addressLine1: string;
  addressLine2: string;
  addressLine3: string;
  city: string;
  state: string;
  zip: string;
  /** Repeated PolicyProduct rows. Maps to the Line Items grid. */
  lineItems: CifLineItem[];
}
 
export interface CifLineItem {
  policyNumber: string;
  productCode: string;
  lineOfBusiness: string;
  policyStatus: string;
  issueState: string;
  billForm: string;
}
 
export type CifLookupType = 'policy_number' | 'ssn' | 'cif_number';
 
@Injectable({ providedIn: 'root' })
export class CifLookupService {
  private readonly http = inject(HttpClient);
  private readonly base = environment.cifLookupUrl;
 
  /**
   * Call the local proxy (cif-lookup-proxy.js on port 5000). The proxy
   * forwards to the on-prem AFLAC service with cert handling. We can't
   * call the AFLAC service directly from the browser because of CORS
   * and client-cert constraints — that's the whole reason the local
   * proxy exists.
   */
  lookup(type: CifLookupType, value: string): Observable<CifLookupResult> {
    const url = `${this.base}/cif-lookup`;
    return this.http
      .post(url, { type, value }, { responseType: 'text' })
      .pipe(map(xml => this.parseXml(xml)));
  }
 
  /**
   * Parse the AflacData/Holding/Policy XML shape. Defensive against
   * missing nodes — every field defaults to '' rather than throwing,
   * so a partial response still renders something useful in the UI.
   */
  private parseXml(xml: string): CifLookupResult {
    const empty: CifLookupResult = {
      policyNumber: '', ssn: '', cifNumber: '',
      firstName: '', middleName: '', lastName: '', customerName: '',
      addressLine1: '', addressLine2: '', addressLine3: '',
      city: '', state: '', zip: '',
      lineItems: [],
    };
    if (!xml) return empty;
 
    let doc: Document;
    try {
      doc = new DOMParser().parseFromString(xml, 'application/xml');
    } catch {
      return empty;
    }
    // DOMParser doesn't throw on bad XML — it returns a doc with a <parsererror>.
    if (doc.getElementsByTagName('parsererror').length > 0) return empty;
 
    const party = doc.querySelector('AflacData > Holding > Policy > Party');
    const person = party?.querySelector('Person');
    const address = party?.querySelector('Address');
 
    const firstName = this.text(person, 'FirstName');
    const middleName = this.text(person, 'MiddleName');
    const lastName = this.text(person, 'LastName');
    const customerName = [firstName, middleName, lastName].filter(s => s).join(' ');
 
    // GovtID is only SSN when GovtIDTC=="SSN" — guard so we don't put
    // a non-SSN identifier into the SSN field.
    const govtId = this.text(party, 'GovtID');
    const govtIdTc = this.text(party, 'GovtIDTC');
    const ssn = govtIdTc.toUpperCase() === 'SSN' ? govtId : '';
 
    // Same guard for CIF reference number.
    const refNo = this.text(party, 'IDReferenceNo');
    const refType = this.text(party, 'IDReferenceType');
    const cifNumber = refType.toUpperCase() === 'CIFNUMBER' ? refNo : '';
 
    const products = doc.querySelectorAll('AflacData > Holding > Policy > PolicyProduct');
    const lineItems: CifLineItem[] = [];
    products.forEach(p => {
      lineItems.push({
        policyNumber: this.text(p, 'PolNumber'),
        productCode: this.text(p, 'ProductCode'),
        lineOfBusiness: this.text(p, 'LineOfBusiness'),
        policyStatus: this.text(p, 'PolicyStatus'),
        issueState: this.text(p, 'IssueState'),
        billForm: this.text(p, 'BillForm'),
      });
    });
 
    return {
      policyNumber: this.text(party, 'PolNumber'),
      ssn,
      cifNumber,
      firstName,
      middleName,
      lastName,
      customerName,
      addressLine1: this.text(address, 'Line1'),
      addressLine2: this.text(address, 'Line2'),
      addressLine3: this.text(address, 'Line3'),
      city: this.text(address, 'City'),
      state: this.text(address, 'AddressState'),
      zip: this.text(address, 'ResidenceZip'),
      lineItems,
    };
  }
 
  private text(parent: Element | null | undefined, tag: string): string {
    if (!parent) return '';
    // Use querySelector against the parent so we only match descendants of
    // this Party/Address/PolicyProduct, not siblings elsewhere in the doc.
    const el = parent.querySelector(tag);
    return el?.textContent?.trim() || '';
  }
}