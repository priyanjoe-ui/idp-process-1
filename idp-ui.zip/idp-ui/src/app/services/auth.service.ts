import { Injectable, signal } from '@angular/core';
 
const STORAGE_KEY = 'aflaccore.operator';
 
@Injectable({ providedIn: 'root' })
export class AuthService {
  /** Currently signed-in operator username, or null. Signal so templates auto-update. */
  readonly operator = signal<string | null>(this._readStored());
 
  /** Convenience derived state. */
  isAuthenticated(): boolean {
    const op = this.operator();
    return !!op && op.length > 0;
  }
 
  /** Mock sign-in: store the username locally. */
  login(username: string): void {
    const clean = (username || '').trim();
    if (!clean) return;
    localStorage.setItem(STORAGE_KEY, clean);
    this.operator.set(clean);
  }
 
  /** Clear local credential. */
  logout(): void {
    localStorage.removeItem(STORAGE_KEY);
    this.operator.set(null);
  }
 
  private _readStored(): string | null {
    try {
      const v = localStorage.getItem(STORAGE_KEY);
      return v && v.length > 0 ? v : null;
    } catch {
      return null;
    }
  }
}