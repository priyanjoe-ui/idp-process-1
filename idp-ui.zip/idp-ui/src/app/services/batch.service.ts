import { Injectable, inject } from '@angular/core';
import { Observable, map, of } from 'rxjs';
 
import { environment } from '../../environments/environment';
import {
  Application,
  ApplicationsResponse,
  BatchDetail,
  BatchListQuery,
  BatchPage_DTO,
  DashboardFilter,
  DashboardStats,
  DocumentPayload,
  JobSummary,
  LineItemRowData,
  SubmitReviewRequest,
  SubmitReviewResponse,
  TreeDocPayload,
  TreePagePayload,
} from '../models/document.model';
import { ApiBatchService } from './api-batch.service';
import { AuthService } from './auth.service';
import { MockBatchService } from './mock-batch.service';
 
/**
 * Facade that switches between the live API and the mock data source
 * based on environment.dataSource. All UI components depend on THIS
 * service, not the underlying api/mock services.
 */
@Injectable({ providedIn: 'root' })
export class BatchService {
  private readonly api = inject(ApiBatchService);
  private readonly mock = inject(MockBatchService);
  private readonly auth = inject(AuthService);
 
  private get useMock(): boolean {
    return environment.dataSource === 'mock';
  }
 
  listApplications(): Observable<ApplicationsResponse> {
    return this.useMock ? this.mock.listApplications() : this.api.listApplications();
  }
 
  listJobs(application: string): Observable<{ application: string; jobs: JobSummary[] }> {
    return this.useMock ? this.mock.listJobs(application) : this.api.listJobs(application);
  }
 
  listBatches(q: BatchListQuery): Observable<BatchPage_DTO> {
    return this.useMock ? this.mock.listBatches(q) : this.api.listBatches(q);
  }
 
  getBatch(queueId: number): Observable<BatchDetail> {
    return this.useMock ? this.mock.getBatch(queueId) : this.api.getBatch(queueId);
  }
 
  pageImageUrl(queueId: number, pageId: string): string {
    return this.api.pageImageUrl(queueId, pageId);
  }
 
  /**
   * Submit the manual-review screen back to the pipeline.
   *
   * Stage 8: tree state is sent as final pages+docs arrays (not ops).
   * Server diffs against DDB and applies the diff. Pass null/omit for
   * batches with no structural changes. validationOverride='Reviewed'
   * promotes the document's validationStatus when Run Validations passed.
   */
  submitReview(
    queueId: number,
    corrections: { fieldName: string; value: string }[],
    lineItems: LineItemRowData[] = [],
    treeDocuments: TreeDocPayload[] | null = null,
    treePages: TreePagePayload[] | null = null,
    validationOverride: 'Reviewed' | null = null,
    documents: DocumentPayload[] | null = null,
  ): Observable<SubmitReviewResponse> {
    const body: SubmitReviewRequest = {
      reviewer: this.auth.operator() || 'anonymous',
      corrections,
      lineItems,
      validationOverride,
    };
    // Only attach the tree state when caller provided BOTH arrays;
    // server requires they ride together.
    if (treeDocuments && treePages) {
      body.treeDocuments = treeDocuments;
      body.treePages = treePages;
    }
    // Issue 3: per-document payload (corrections/lineItems per doc).
    if (documents) {
      body.documents = documents;
    }
    return this.useMock ? this.mock.submitReview(queueId, body) : this.api.submitReview(queueId, body);
  }
 
  /**
   * Save the Verify screen state without resuming the Step Function.
   * Same shape as submitReview - takes the optional tree-state pair.
   *
   * Issue 2: when holdAction is true (e.g. user clicked Hold), the
   * server additionally flips status pending->hold (holdSource='manual'),
   * so the batch shows under the Hold tile. Step Function task token
   * stays parked; a later submit-review (or /release then submit-review)
   * resumes the same execution.
   */
  saveDraft(
    queueId: number,
    corrections: { fieldName: string; value: string }[],
    lineItems: LineItemRowData[] = [],
    treeDocuments: TreeDocPayload[] | null = null,
    treePages: TreePagePayload[] | null = null,
    validationOverride: 'Reviewed' | null = null,
    holdAction: boolean = false,
    holdReason: string = '',
    documents: DocumentPayload[] | null = null,
  ): Observable<SubmitReviewResponse> {
    const body: SubmitReviewRequest = {
      reviewer: this.auth.operator() || 'anonymous',
      corrections,
      lineItems,
      validationOverride,
    };
    if (treeDocuments && treePages) {
      body.treeDocuments = treeDocuments;
      body.treePages = treePages;
    }
    if (holdAction) {
      body.holdAction = true;
      if (holdReason) body.holdReason = holdReason;
    }
    if (documents) {
      body.documents = documents;
    }
    if (this.useMock) {
      return this.mock.submitReview(queueId, body);
    }
    return this.api.saveDraft(queueId, body);
  }
 
  /**
   * Fetch dashboard metrics from the server-side computed endpoint.
   * Filter on jobStartTime range plus application scope.
   */
  dashboard(filter: DashboardFilter = {}): Observable<DashboardStats> {
    return this.api.dashboard(filter);
  }
}