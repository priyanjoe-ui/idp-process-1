import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
 
import { AuthService } from './auth.service';
 
export const authGuard: CanActivateFn = (_route, state) => {
  const auth = inject(AuthService);
  const router = inject(Router);
 
  if (auth.isAuthenticated()) {
    return true;
  }
  // Preserve the desired URL so login can redirect back here
  return router.createUrlTree(['/login'], {
    queryParams: { returnUrl: state.url },
  });
};