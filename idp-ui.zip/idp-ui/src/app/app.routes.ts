import { Routes } from '@angular/router';
 
import { ShellComponent } from './components/shell/shell.component';
import { authGuard } from './services/auth.guard';
 
export const routes: Routes = [
  {
    path: 'login',
    loadComponent: () =>
      import('./components/login/login.component').then(m => m.LoginComponent),
  },
  {
    path: '',
    component: ShellComponent,
    canActivate: [authGuard],
    children: [
      { path: '', redirectTo: 'batches', pathMatch: 'full' },
      {
        path: 'batches',
        loadComponent: () =>
          import('./components/batch-monitor/batch-monitor.component').then(m => m.BatchMonitorComponent),
      },
      {
        path: 'verify/:queueId',
        loadComponent: () =>
          import('./components/verify/verify.component').then(m => m.VerifyComponent),
      },
      {
        path: 'dashboard',
        loadComponent: () =>
          import('./components/dashboard/dashboard.component').then(m => m.DashboardComponent),
      },
    ],
  },
  { path: '**', redirectTo: '' },
];