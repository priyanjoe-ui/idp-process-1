/* ================================================================
   Domain models — match the API contract from local-api-proxy.js
   ================================================================ */
 
// ----- Auth -----
export interface AuthUser {
  operator: string | null;
  authenticated: boolean;
}
 
// ----- Applications & Jobs -----
 
/** A single dropdown option (used for both Dropdown fields and dictionary references). */
export interface FieldOption {
  Value: string;
  Label: string;
}
 
/** A field definition coming from document-config.json. */
export interface ConfigField {
  FieldName: string;
  Label: string;
  DataType: 'String' | 'Dropdown' | 'Number' | string;
  Required?: boolean;
  Disabled?: boolean;
  /** For Dropdown fields, inline option list. */
  Options?: FieldOption[];
  /** For Dropdown fields, reference to a shared dictionary (e.g. "TransCodes"). */
  OptionsRef?: string;
  /** Default value used when the document doesn't have a stored value yet. */
  DefaultValue?: string | null;
  /** For Disabled fields, the batch property to read from. */
  AutoPopulateFrom?: string;
  /** Optional date format for auto-populated date fields. */
  Format?: string;
  /** Optional transform: 'uppercase', etc. */
  Transform?: string;
  ExtractionRegex?: string;
  ValidationRegex?: string;
  ConfidenceScore?: number;
  FieldKeywords?: string[];
}
 
/** A line items grid column. Same shape as ConfigField, just used in a table cell context. */
export interface ConfigLineItemColumn extends ConfigField {}
 
/** Line items configuration for a page type. */
export interface ConfigLineItems {
  Name: string;
  EmptyText?: string;
  MinRows?: number;
  Columns: ConfigLineItemColumn[];
  /**
   * 0-based insertion index into the rendered Fields sequence. When set,
   * the Verify screen places the line items grid between fields[Position-1]
   * and fields[Position]. When omitted, the grid renders after all fields.
   */
  Position?: number;
}
 
/** A configured page type (MainPage, CoverPage, etc.). */
export interface ConfigPageType {
  pageType: string;
  fields: ConfigField[];
  lineItems: ConfigLineItems | null;
  keywords: string[];
}
 
/** A configured document type. */
export interface ConfigDocumentType {
  name: string;
  pageTypes: ConfigPageType[];
}
 
export interface Application {
  name: string;
  displayName: string;
  classificationMode?: string;
  /** Phase 1: just the type names. Phase 2C: full type definitions. */
  documentTypes: string[] | ConfigDocumentType[];
}
 
/** Top-level response from GET /api/applications. */
export interface ApplicationsResponse {
  applications: Application[];
  /** Shared option lists (e.g. TransCodes) referenced by ConfigField.OptionsRef. */
  dictionaries?: { [name: string]: FieldOption[] };
}
 
export interface JobStatusCounts {
  total: number;
  // Plus dynamic keys per status (Running, OnHold, JobDone, Failed, ...)
  [status: string]: number;
}
 
export interface JobSummary {
  jobName: string;
  counts: JobStatusCounts;
}
 
// ----- Batches (list view) -----
/**
 * Stage 7: batch hold values.
 *   - "hold": canonical lower-case value. Used both for system-initiated
 *     (manualReview routing) and user-initiated (Hold from Verify) holds;
 *     the two are distinguished by `holdSource` attribute.
 *   - "pending": reserved for future use (forward-compat).
 *   - "OnHold": legacy value still on un-migrated DDB rows; the api-proxy
 *     normalizes it to "hold" on read but accept the legacy value here
 *     during the migration window.
 */
export type BatchStatus = 'Running' | 'hold' | 'pending' | 'OnHold' | 'JobDone' | 'Failed' | string;
 
export interface BatchRow {
  queueId: number;
  batchId: string;
  batchNumber: string;
  application: string;
  source: string;
  jobName: string;
  currentTask: string;
  status: BatchStatus;
  jobStartTime: string;       // ISO
  jobTime: number | null;     // seconds since jobStartTime (live)
  jobDuration: number | null; // ms (for terminal states)
  operator: string;
  documentCount: number;
  pageCount: number;
  updatedAt: string;
}
 
export interface BatchPage_DTO {  // pagination metadata
  page: number;
  pageSize: number;
  totalCount: number;
  totalPages: number;
  batches: BatchRow[];
}
 
// ----- Batch detail (Verify screen) -----
export interface ExtractedField {
  fieldName: string;
  value: string | null;
  confidence: number | null;
  validationPassed: boolean;
  sourcePageId: string | null;
  required: boolean;
  dataType: string;
  validationError: string | null;
  correctedBy: string | null;
  correctedAt: string | null;
}
 
/**
 * A single line item row as stored in DDB and sent to/from the API.
 * Stage 5: persisted as a list of column-name -> string-value maps on
 * the document record. Backward-compatible with old batches: missing
 * attribute is treated as empty array.
 */
export type LineItemRowData = { [columnName: string]: string };
 
export interface DocumentDetail {
  documentId: string;
  documentType: string;
  validationStatus: string;
  pageIds: string[];
  extractedFields: ExtractedField[];
  /**
   * Optional in the API response so old batches that pre-date Stage 5
   * (no lineItems attribute in DDB) just come back as undefined and the
   * UI treats that as empty.
   */
  lineItems?: LineItemRowData[];
  createdAt: string;
  updatedAt: string;
}
 
export type PageType = 'MainPage' | 'TrailingPage' | 'CoverPage' | 'BlankPage' | 'Unclassified' | string;
 
/** A single OCR word with its bounding box in normalized 0..1 coordinates. */
export interface OcrWord {
  text: string;
  bbox: { l: number; t: number; w: number; h: number };
}
 
export interface PageDetail {
  pageId: string;
  displayId?: string | null;     // human-friendly TM000001 style, null for older batches
  pageNumber: number;
  pageType: PageType;
  pageStatus: string;
  wordCount: number | null;
  s3Key: string;
  ocrTextS3Key: string | null;
  imageUrl: string;          // local URL into the proxy
  ocrWords?: OcrWord[];      // populated for new batches; older batches: []
  createdAt: string;
  updatedAt: string;
}
 
export interface TaskHistoryItem {
  taskName: string;
  status: string;
  startTime: string;
  endTime: string;
  operator: string;
  durationMs: number | null;
  details?: any;
}
 
export interface TextractJob {
  jobId: string;
  pageId: string;
  status: string;
  createdAt: string;
  completedAt: string | null;
  durationMs: number | null;
  resultS3Key: string | null;
  errorMessage: string | null;
}
 
export interface BatchDetail {
  batch: BatchRow & {
    sourceZipKey: string | null;
    xmlMetadata: Record<string, string>;
    holdSource?: 'manual' | 'manualReview' | null;
    holdReason?: string | null;
    manualReviewStartedAt?: string | null;
    manualReviewCompletedAt?: string | null;
    createdAt?: string;
  };
  documents: DocumentDetail[];
  pages: PageDetail[];
  taskHistory: TaskHistoryItem[];
  textractJobs: TextractJob[];
}
 
// ----- Submit Review -----
export interface FieldCorrection {
  fieldName: string;
  value: string;
}
 
/**
 * Stage 7: structural tree operations are previewed client-side via
 * the TreeOp discriminated union (kept here for the in-memory undo
 * stack). The wire format to the server is the FINAL state, not the
 * ops list - see SubmitReviewRequest.treeDocuments/treePages below.
 *
 * - movePageUp/Down  : swap pageNumber with neighbor within the same doc
 * - deletePage       : remove the page record + pageIds reference
 * - moveDocUp/Down   : reorder documents within a batch
 * - deleteDoc        : remove a document and all its pages
 * - splitDoc         : at atPageId, break the document so that
 *                      [atPageId, ...rest] become a new document of the
 *                      same documentType.
 */
export type TreeOp =
  | { kind: 'movePageUp';   pageId: string }
  | { kind: 'movePageDown'; pageId: string }
  | { kind: 'deletePage';   pageId: string }
  | { kind: 'moveDocUp';    docId:  string }
  | { kind: 'moveDocDown';  docId:  string }
  | { kind: 'deleteDoc';    docId:  string }
  | { kind: 'splitDoc';     docId:  string; atPageId: string };
 
/**
 * Stage 8: minimal page shape sent in the tree-state payload.
 * Only the attributes the server can change via tree ops
 * (pageNumber, pageType) plus the id are included.
 */
export interface TreePagePayload {
  pageId: string;
  pageNumber: number;
  pageType: string;
}
 
/**
 * Stage 8: minimal document shape sent in the tree-state payload.
 * pageIds is the desired ordering; documentType comes through so the
 * server knows the type for newly-split docs.
 */
export interface TreeDocPayload {
  documentId: string;
  documentType: string;
  validationStatus?: string;
  pageIds: string[];
}
 
export interface SubmitReviewRequest {
  reviewer: string;
  corrections: FieldCorrection[];
  /** Stage 5: full snapshot of the line items grid at submit time. */
  lineItems?: LineItemRowData[];
  /**
   * Stage 8: tree-state payload. The UI runs the tree-ops reducer
   * locally and sends the FINAL desired state. Server diffs against
   * current DDB and writes the differences. Both arrays must be sent
   * together or neither (server returns 400 otherwise).
   */
  treeDocuments?: TreeDocPayload[];
  treePages?: TreePagePayload[];
  /**
   * Stage 7: when set to 'Reviewed', the document's validationStatus is
   * promoted to 'Reviewed' on save (used by "Run Validations" -> Hold/Submit
   * flow so the OK state persists across reopens).
   */
  validationOverride?: 'Reviewed' | null;
  /**
   * Issue 2: save-draft only. When true, server also flips batch status
   * from 'pending' to 'hold' (holdSource='manual') so the dashboard
   * shows the batch under the Hold tile. Step Function task token
   * stays parked; the batch can later be Released (back to 'pending')
   * or Submitted (resumes SF).
   */
  holdAction?: boolean;
  holdReason?: string;
  /**
   * Issue 3: per-document field state. After Split, a batch can have
   * multiple documents; each has its OWN field edits + line items.
   * The UI sends one entry per document. Server iterates and writes
   * each independently. Legacy single-doc payload (root-level
   * corrections + lineItems) still works for backward compat.
   */
  documents?: DocumentPayload[];
}
 
/** Issue 3: per-document field state in submit/save-draft payloads. */
export interface DocumentPayload {
  documentId: string;
  corrections: { fieldName: string; value: string }[];
  lineItems: LineItemRowData[];
}
 
export interface SubmitReviewResponse {
  queueId: number;
  status: string;
  reviewer: string;
  correctionCount: number;
  /** Stage 5: number of line item rows persisted. */
  lineItemCount?: number;
  message: string;
}
 
// ----- Search/Filter (BatchMonitor) -----
export interface BatchListQuery {
  application: string;
  status?: string;          // comma-separated
  search?: string;          // wildcard
  page?: number;
  pageSize?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}
 
// ----- Dashboard -----
export interface DashboardFilter {
  application?: string;     // 'all' or specific app name
  from?: string;            // ISO date or yyyymmdd
  to?: string;              // ISO date or yyyymmdd
}
 
export type DateRangePreset = 'today' | 'yesterday' | 'last7' | 'last30' | 'mtd' | 'custom';
 
export interface DashboardStats {
  filter: {
    application: string;
    from: string | null;
    to: string | null;
  };
  totalIngested: number;
  pendingReview: number;
  stpBatches: number;
  abortedBatches: number;
  stpPercentage: number;          // e.g. 11.1
  byDocumentType: { type: string; count: number }[];
  byStatus: { status: string; count: number }[];
  recentTimeline: { bucket: string; processed: number; failed: number }[];
}