export const environment = {
  production: false,
  // /api is proxied by Angular dev server (proxy.conf.json) to local-api-proxy.js on :3001
  apiBaseUrl: 'https://bjuhr4h45nh45igikc22v2d3c40kfzxm.lambda-url.us-east-1.on.aws/api',
  dataSource: 'api' as 'mock' | 'api',
  defaultApplication: 'AFLCOR',
  defaultPageSize: 100,
  // Local Node proxy (cif-lookup-proxy.js) that forwards to the on-prem
  // AFLAC CIF service. Runs on :5000 because of firewall + client cert
  // constraints that make a direct browser call impossible.
  cifLookupUrl: 'http://localhost:5000',
};