export const environment = {
  production: true,
  // In production this points at the internal proxy URL.
  apiBaseUrl: '/api',
  dataSource: 'api' as 'mock' | 'api',
  defaultApplication: 'AFLCOR',
  defaultPageSize: 100,
};