# iDP Document Processing — Angular UI

A web app for reviewing extracted document fields, modeled on the vendor "Job Monitor → Verify" pattern but rebuilt with original branding (professional blue/grey theme) for the IDP pipeline.

**Three views:**
- **Batch Monitor** — paginated list of batches with filter rail (left), batch list (center), properties pane (right). Click a batch to open it for review.
- **Verify** — three-column workspace: document viewer, editable Field Details with confidence indicators, and Batch Structure tree.
- **Dashboard** — KPI tiles, document type breakdown, status distribution, and throughput timeline.

The app talks to the API Gateway endpoints created by the IDP CloudFormation stack (`/reviews`, `/reviews/{documentId}`, `/dashboard`). For local development without a backend, it ships with a built-in mock service.

---

## Table of contents

1. [Project structure](#project-structure)
2. [Run locally in VS Code](#run-locally-in-vs-code)
3. [Connect to your real API Gateway](#connect-to-your-real-api-gateway)
4. [Deploy to AWS (S3 + CloudFront — recommended)](#deploy-to-aws-s3--cloudfront--recommended)
5. [AWS hosting options compared](#aws-hosting-options-compared)
6. [Production checklist](#production-checklist)
7. [Troubleshooting](#troubleshooting)

---

## Project structure

```
idp-ui/
├── package.json
├── angular.json
├── tsconfig.json
├── tsconfig.app.json
├── src/
│   ├── index.html
│   ├── main.ts
│   ├── styles.scss                 # Design tokens + global styles
│   ├── environments/
│   │   ├── environment.ts          # Dev (mock data by default)
│   │   └── environment.prod.ts     # Prod (set your API URL here)
│   └── app/
│       ├── app.component.ts
│       ├── app.routes.ts
│       ├── models/document.model.ts
│       ├── services/
│       │   ├── batch.service.ts        # Facade (chooses mock vs api)
│       │   ├── mock-batch.service.ts   # Local mock data
│       │   └── api-batch.service.ts    # Real API Gateway calls
│       └── components/
│           ├── shell/                  # Top header + tabs
│           ├── batch-monitor/          # Job Monitor pattern
│           ├── verify/                 # Verify tab
│           └── dashboard/              # KPIs + charts
```

---

## Run locally in VS Code

### Prerequisites

| Tool | Version | Install |
|---|---|---|
| **Node.js** | 18.13+ or 20.x LTS | https://nodejs.org/ |
| **npm** | 9+ (bundled with Node) | — |
| **Angular CLI** | 17.x | `npm install -g @angular/cli@17` |
| **VS Code** | Latest | https://code.visualstudio.com/ |

Recommended VS Code extensions:
- Angular Language Service (`Angular.ng-template`)
- ESLint (`dbaeumer.vscode-eslint`)
- Prettier (`esbenp.prettier-vscode`)
- SCSS IntelliSense (`mrmlnc.vscode-scss`)

### Steps

**1. Open the folder in VS Code**

```bash
cd idp-ui
code .
```

**2. Open a terminal inside VS Code** (`Ctrl+`` ` ` or `View → Terminal`).

**3. Install dependencies** (first time only, takes ~2 minutes):

```bash
npm install
```

**4. Run the dev server:**

```bash
npm start
```

After ~10–20 seconds you'll see:

```
✔ Compiled successfully.
Local:   http://localhost:4200/
```

**5. Open** http://localhost:4200 in your browser.

You should see the Batch Monitor with 6 sample documents. The mock service simulates network latency, so you'll see a brief "Loading…" then the table populates. Click any batch row to see the properties pane on the right; click the batch ID link or the "Open Batch" button to navigate to the Verify tab. Try the **Dashboard** tab to see KPI tiles and charts.

The dev server watches your files — any edit to a `.ts`, `.html`, or `.scss` file rebuilds the app and refreshes the browser automatically.

### Useful VS Code keyboard shortcuts

| Action | Shortcut |
|---|---|
| Open command palette | `Ctrl+Shift+P` (or `Cmd+Shift+P` on Mac) |
| Quick file open | `Ctrl+P` |
| Find in all files | `Ctrl+Shift+F` |
| Toggle terminal | ``Ctrl+` `` |
| Format file | `Shift+Alt+F` |

### Common dev tasks

```bash
# Run with a different port
npx ng serve --port 4300

# Build for production locally (output goes to dist/idp-document-processing)
npm run build

# Build for development (faster, sourcemaps, no minification)
npm run build:dev
```

---

## Connect to your real API Gateway

By default the app uses the mock data service so you can develop without any AWS resources. To point at your real backend:

**1. Find your API Gateway invoke URL**

Either from the CloudFormation stack outputs (look for `ReviewApiUrl`):

```bash
aws cloudformation describe-stacks \
  --stack-name idp-prod \
  --query "Stacks[0].Outputs[?OutputKey=='ReviewApiUrl'].OutputValue" \
  --output text \
  --region us-east-1
```

Or in the API Gateway Console → idp-review-api → Stages → prod → Invoke URL.

It looks like `https://abcd1234.execute-api.us-east-1.amazonaws.com/prod`.

**2. Edit `src/environments/environment.prod.ts`:**

```typescript
export const environment = {
  production: true,
  apiBaseUrl: 'https://abcd1234.execute-api.us-east-1.amazonaws.com/prod',
  dataSource: 'api' as 'mock' | 'api'
};
```

**3. (Optional) Run the app locally against the live API** — edit `environment.ts`:

```typescript
export const environment = {
  production: false,
  apiBaseUrl: 'https://abcd1234.execute-api.us-east-1.amazonaws.com/prod',
  dataSource: 'api' as 'mock' | 'api'
};
```

For this to work, the API Gateway needs CORS enabled (the CloudFormation template already does this — every method has a matching OPTIONS mock with `Access-Control-Allow-Origin: '*'`).

**4. Build for production:**

```bash
npm run build
```

The output goes to `dist/idp-document-processing/browser/`. That's the folder you upload to S3.

---

## Deploy to AWS (S3 + CloudFront — recommended)

This is the standard pattern for production Angular apps and the one I recommend for this project. The full comparison vs other AWS options is in the next section.

**What you'll create:**
- An S3 bucket configured for static website hosting
- A CloudFront distribution in front of it (HTTPS, global CDN, custom domain support)
- A bucket policy that lets only CloudFront read objects (Origin Access Control)

### Option A: One-shot via AWS CLI

This is the fastest path — five commands. Replace `<bucket>` and `<region>` first:

```bash
# Set variables
export BUCKET=idp-ui-acme-prod
export REGION=us-east-1

# 1. Create the S3 bucket
aws s3 mb s3://$BUCKET --region $REGION

# 2. Block all public access (CloudFront will use OAC instead)
aws s3api put-public-access-block --bucket $BUCKET \
  --public-access-block-configuration \
  "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"

# 3. Build the Angular app
npm run build

# 4. Upload the dist files
aws s3 sync dist/idp-document-processing/browser/ s3://$BUCKET/ --delete

# 5. Create CloudFront distribution (takes ~5 min to fully deploy)
aws cloudfront create-distribution \
  --origin-domain-name $BUCKET.s3.$REGION.amazonaws.com \
  --default-root-object index.html
```

After the CloudFront distribution finishes deploying, you'll get a URL like `https://d1234abcd.cloudfront.net`. That's your app.

**Important:** the manual CLI approach above creates a CloudFront distribution with default settings (no custom error pages, no OAC). The CloudFormation template below is better.

### Option B: CloudFormation (recommended for production)

Save this as `idp-ui-hosting.yaml`:

```yaml
AWSTemplateFormatVersion: '2010-09-09'
Description: S3 + CloudFront hosting for IDP Angular UI

Parameters:
  BucketName:
    Type: String
    Description: Globally unique S3 bucket name (e.g. idp-ui-acme-prod)

Resources:
  UiBucket:
    Type: AWS::S3::Bucket
    Properties:
      BucketName: !Ref BucketName
      PublicAccessBlockConfiguration:
        BlockPublicAcls: true
        BlockPublicPolicy: true
        IgnorePublicAcls: true
        RestrictPublicBuckets: true
      BucketEncryption:
        ServerSideEncryptionConfiguration:
          - ServerSideEncryptionByDefault:
              SSEAlgorithm: AES256

  OriginAccessControl:
    Type: AWS::CloudFront::OriginAccessControl
    Properties:
      OriginAccessControlConfig:
        Name: !Sub 'oac-${BucketName}'
        OriginAccessControlOriginType: s3
        SigningBehavior: always
        SigningProtocol: sigv4

  Distribution:
    Type: AWS::CloudFront::Distribution
    Properties:
      DistributionConfig:
        Enabled: true
        DefaultRootObject: index.html
        HttpVersion: http2
        PriceClass: PriceClass_100
        Origins:
          - Id: S3Origin
            DomainName: !GetAtt UiBucket.RegionalDomainName
            OriginAccessControlId: !GetAtt OriginAccessControl.Id
            S3OriginConfig:
              OriginAccessIdentity: ''
        DefaultCacheBehavior:
          TargetOriginId: S3Origin
          ViewerProtocolPolicy: redirect-to-https
          AllowedMethods: [GET, HEAD, OPTIONS]
          CachedMethods: [GET, HEAD]
          Compress: true
          CachePolicyId: 658327ea-f89d-4fab-a63d-7e88639e58f6  # Managed-CachingOptimized
        # SPA fallback: any unknown path returns index.html so Angular routes work
        CustomErrorResponses:
          - ErrorCode: 403
            ResponseCode: 200
            ResponsePagePath: /index.html
          - ErrorCode: 404
            ResponseCode: 200
            ResponsePagePath: /index.html

  BucketPolicy:
    Type: AWS::S3::BucketPolicy
    Properties:
      Bucket: !Ref UiBucket
      PolicyDocument:
        Statement:
          - Effect: Allow
            Principal:
              Service: cloudfront.amazonaws.com
            Action: s3:GetObject
            Resource: !Sub '${UiBucket.Arn}/*'
            Condition:
              StringEquals:
                AWS:SourceArn: !Sub 'arn:aws:cloudfront::${AWS::AccountId}:distribution/${Distribution}'

Outputs:
  CloudFrontUrl:
    Description: HTTPS URL for the app
    Value: !Sub 'https://${Distribution.DomainName}'
  BucketName:
    Value: !Ref UiBucket
  DistributionId:
    Value: !Ref Distribution
```

Deploy:

```bash
aws cloudformation deploy \
  --stack-name idp-ui-hosting \
  --template-file idp-ui-hosting.yaml \
  --parameter-overrides BucketName=idp-ui-acme-prod \
  --region us-east-1

# Build + upload + invalidate (one-liner you'll re-run for every deploy)
npm run build && \
aws s3 sync dist/idp-document-processing/browser/ s3://idp-ui-acme-prod/ --delete && \
aws cloudfront create-invalidation \
  --distribution-id $(aws cloudformation describe-stacks --stack-name idp-ui-hosting \
    --query "Stacks[0].Outputs[?OutputKey=='DistributionId'].OutputValue" --output text) \
  --paths "/*"

# Get the URL
aws cloudformation describe-stacks --stack-name idp-ui-hosting \
  --query "Stacks[0].Outputs[?OutputKey=='CloudFrontUrl'].OutputValue" --output text
```

Open the URL → your app is live.

### Step-by-step explanation of what happens

**1. S3 bucket — origin storage.**
Your built Angular files (HTML, JS, CSS) live here. The bucket is **private** (no public access). Only CloudFront is allowed to read it via the Origin Access Control (OAC) we wire up below. This is more secure than the older "make the bucket public" pattern.

**2. CloudFront distribution — global CDN.**
CloudFront caches your files at ~600 edge locations worldwide. When a user in Singapore visits your app, they hit the Singapore edge (~50ms latency) instead of your US bucket (~300ms+). CloudFront also gives you:
- Free HTTPS via AWS-managed certificates
- Compression (gzip/brotli) — your 800KB Angular bundle becomes ~250KB on the wire
- DDoS protection (AWS Shield Standard, free)
- Custom domain support (when you're ready, attach a Route 53 record + ACM certificate)

**3. Origin Access Control (OAC).**
This is what tells CloudFront "use these credentials when reading from S3." The bucket policy then says "only requests with these specific OAC credentials can read me." Result: your bucket is invisible to the public internet, but CloudFront has full read access.

**4. SPA fallback (`CustomErrorResponses`).**
Angular is a single-page app. When a user visits `/verify/abc-123` directly, S3 returns 404 (no such file). The custom error response intercepts the 404 and serves `index.html` instead — Angular's router then handles `/verify/abc-123` client-side. Without this, deep links break.

**5. Cache invalidation.**
CloudFront caches files for up to 24 hours by default. After deploying new build artifacts, the `create-invalidation --paths "/*"` command tells CloudFront "drop everything cached, re-fetch from S3." Without invalidation, returning users see stale assets for hours. Each invalidation of up to 1000 paths is free; additional ones cost $0.005 each.

**6. CORS on API Gateway.**
Your app at `https://d1234.cloudfront.net` calls API Gateway at `https://abcd.execute-api.us-east-1.amazonaws.com/prod`. Different origin → browser blocks the request unless API Gateway returns `Access-Control-Allow-Origin`. The CloudFormation template that creates the API Gateway already handles this with OPTIONS mock methods returning `*`. **In production, change `*` to your specific CloudFront domain.**

### Adding a custom domain (optional)

When you're ready to use `idp.acme.com` instead of the random CloudFront URL:

1. **Register the domain** (Route 53, GoDaddy, anywhere) and create a hosted zone in Route 53.
2. **Request an ACM certificate** in `us-east-1` (CloudFront only accepts certs from us-east-1):
   ```bash
   aws acm request-certificate --domain-name idp.acme.com --validation-method DNS --region us-east-1
   ```
3. Validate the cert by adding the DNS record ACM gives you.
4. **Update the CloudFront distribution** to add your custom domain (Aliases) and reference the certificate.
5. **Create an A-record (Alias) in Route 53** pointing `idp.acme.com` to the CloudFront distribution.

A clean way to do all of this in one shot is to extend the CloudFormation template above with `AWS::CertificateManager::Certificate`, `Aliases` on the distribution, and an `AWS::Route53::RecordSet`. Happy to provide that on request.

### CI/CD — automate the deploy

For a real team, wire deploys into a pipeline. Easiest options:

**GitHub Actions** — create `.github/workflows/deploy.yml`:

```yaml
name: Deploy IDP UI
on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    permissions:
      id-token: write
      contents: read
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
      - run: npm ci
      - run: npm run build
      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::ACCOUNT_ID:role/github-deploy-idp-ui
          aws-region: us-east-1
      - name: Sync to S3
        run: aws s3 sync dist/idp-document-processing/browser/ s3://idp-ui-acme-prod/ --delete
      - name: Invalidate CloudFront
        run: aws cloudfront create-invalidation --distribution-id ${{ secrets.CF_DIST_ID }} --paths "/*"
```

You'll need a one-time IAM setup: create a GitHub OIDC provider in AWS, then a role `github-deploy-idp-ui` with permissions for `s3:PutObject` on the bucket and `cloudfront:CreateInvalidation` on the distribution.

---

## AWS hosting options compared

For a static Single Page App (which is what an Angular build is — pure HTML/JS/CSS), here are the realistic choices on AWS, ranked by suitability:

### 1. S3 + CloudFront ⭐ Recommended

**What it is:** Files in S3, CloudFront CDN in front. The pattern shown above.

| Pros | Cons |
|---|---|
| Cheapest at any scale (typically <$5/month for low traffic, scales linearly) | Requires manual setup (~1 hour first time) |
| Best performance — global edge caching, HTTP/2, compression | No built-in CI/CD pipeline (use GitHub Actions / CodePipeline separately) |
| Highly available (S3: 99.99%, CloudFront: 99.9% SLA) | You manage cache invalidation on deploy |
| Free TLS certs via ACM, custom domain via Route 53 | Doesn't support server-side rendering (irrelevant here) |
| AWS Shield Standard DDoS protection included | |
| OAC keeps the bucket private — no exposed origin | |

**When to choose:** any production deployment of an SPA. This is the AWS-recommended pattern for static sites.

**Cost example (low traffic, 1000 daily users):** S3 ~$0.50, CloudFront ~$2 (data transfer), ACM cert free, Route 53 $0.50/month per hosted zone = **~$3-4/month total**.

---

### 2. AWS Amplify Hosting

**What it is:** A managed service that wraps S3 + CloudFront + CodeBuild. You connect a Git repo, and Amplify auto-builds and deploys on push.

| Pros | Cons |
|---|---|
| Zero infra setup — connect repo, get a URL | More expensive than raw S3+CloudFront (~$0.15 per build minute + $0.15/GB served) |
| Built-in CI/CD with branch previews | Less control over CloudFront caching, headers, edge behaviors |
| Pull request preview deployments out of the box | Vendor lock-in — your config lives in Amplify console / amplify.yml |
| Built-in basic-auth, redirects, rewrites | Build minutes count even for failed builds |
| Custom domains + free TLS, like CloudFront | Cold-start delays during build (3-5 min for Angular) |
| Easy rollback to previous deploys | |

**When to choose:** a small team that wants to ship fast without managing CI infrastructure, and doesn't mind paying ~2-3x the S3+CloudFront cost. Excellent for hackathons, MVPs, and internal tools.

**Cost example (same 1000 daily users, daily deploys):** ~$8-15/month.

**How to deploy:**
1. AWS Console → Amplify → Host web app → Connect GitHub.
2. Pick repo + branch.
3. Amplify auto-detects Angular and sets up build.
4. Save and deploy. Done.

---

### 3. AWS App Runner

**What it is:** Fully-managed container hosting. You give it a Docker image (or a GitHub repo + Dockerfile), it runs it.

| Pros | Cons |
|---|---|
| Auto-scaling, zero ops | **Massive overkill for static sites** — you're paying for a running container 24/7 (~$25-50/month minimum) |
| Good for full-stack apps with backend logic | No global edge caching — single-region only |
| HTTPS + custom domain managed for you | Higher latency than CDN-fronted static |
| | Requires Docker knowledge |

**When to choose:** never, for a static SPA. App Runner is for containerized backend services that need autoscaling. If you adopted SSR (server-side Angular Universal), it could make sense — but you'd still wrap it in CloudFront.

---

### 4. Elastic Beanstalk

**What it is:** AWS's PaaS for web apps. Provisions EC2 instances, load balancer, auto-scaling group automatically.

| Pros | Cons |
|---|---|
| Familiar pattern if you came from Heroku | **Extreme overkill for a static SPA** — you're running EC2 instances ($30-100/month minimum) |
| Good for traditional web servers (Node, Java, .NET) | EC2 patching, OS updates, capacity planning all become your problem |
| Auto-scaling, blue/green deploys | Higher latency, no edge caching |
| | Slow deploys (5-15 min vs 30 sec for S3 sync) |

**When to choose:** never, for a static SPA. Beanstalk is from the pre-serverless era. Use it for legacy apps that need a real OS environment.

---

### 5. EC2 + Nginx (DIY)

**What it is:** Spin up an EC2 instance, install nginx, copy your dist files, configure SSL via Let's Encrypt or an ELB.

| Pros | Cons |
|---|---|
| Full control over everything | **Don't do this for a static SPA** — you become responsible for: |
| | • OS patching |
| | • Nginx config and security |
| | • Certificate renewal |
| | • Single point of failure (one instance = no HA) |
| | • Backups and DR |
| | • Capacity scaling |
| | $20-50/month minimum, plus your time |

**When to choose:** never, for static hosting. The only reason to run EC2 in 2026 is for legacy software that absolutely must have a persistent host.

---

### 6. AWS Lambda@Edge / CloudFront Functions

**What it is:** Run JavaScript code at CloudFront edge locations.

**Not a hosting option on its own** — it's a complement to S3 + CloudFront. Use cases:
- Add custom security headers to every response
- Inject auth checks (verify a JWT before serving)
- A/B testing routes
- Geo-redirects

You'll likely want one of these eventually. For the initial deploy, skip it.

---

### 7. AWS Lightsail

**What it is:** "Simple" VPS hosting. Pre-bundled instance + bandwidth at a fixed monthly price.

| Pros | Cons |
|---|---|
| Predictable pricing ($3.50/month minimum) | Same downsides as EC2 — you're managing a server |
| Easier than raw EC2 | No edge caching |
| | No autoscaling |

**When to choose:** never, for a static SPA. Lightsail makes sense for a personal WordPress install, not a corporate app.

---

### 8. S3 static website hosting (without CloudFront)

**What it is:** S3 has a built-in "Static website hosting" option — make a bucket public, get a `*.s3-website-region.amazonaws.com` URL.

| Pros | Cons |
|---|---|
| Cheapest possible (just S3 storage + bandwidth) | **No HTTPS** (HTTP only — modern browsers will warn users) |
| One-step setup | No edge caching → slow for distant users |
| | Bucket must be public (security audit nightmare) |
| | No custom domain with TLS |

**When to choose:** internal demos and prototypes. **Never for production.** Just use CloudFront in front of it — the marginal cost is tiny and you get HTTPS, edge caching, and a private bucket.

---

### Decision matrix

| Scenario | Best choice |
|---|---|
| Production deployment, any company size | **S3 + CloudFront** (option 1) |
| Small team, want auto-CI without setup | **Amplify Hosting** (option 2) |
| Demo / sandbox, < 1 week life | S3 static website (option 8) |
| Backend service (not static) | App Runner (option 3) or ECS/Fargate |
| Compliance environment requiring full control | S3 + CloudFront with custom Lambda@Edge for headers |

**My recommendation for this project:** **S3 + CloudFront** via the CloudFormation template above, with a GitHub Actions workflow for CI/CD. This gives you production-grade hosting at minimal cost, with proper security boundaries, and works the same way every other static site at AWS works.

---

## Production checklist

Before going live with real users:

### Security
- [ ] API Gateway uses Cognito or IAM authorizer (not `AuthorizationType: NONE`)
- [ ] CORS on API Gateway changed from `*` to your specific CloudFront domain
- [ ] CloudFront has WAF rules attached (rate limiting, geo-blocks if needed)
- [ ] S3 bucket has Block Public Access enabled (CFN template does this)
- [ ] CloudFront distribution requires HTTPS (`ViewerProtocolPolicy: redirect-to-https`)
- [ ] Security headers added via CloudFront response headers policy (CSP, HSTS, X-Frame-Options)

### Performance
- [ ] Run `npm run build` and check bundle size — should be under 1MB initial
- [ ] Compression enabled on CloudFront (`Compress: true` in CFN template)
- [ ] Long cache TTLs on hashed assets (`*-A1B2C3.js`), short on `index.html`
- [ ] Use Lighthouse to audit (target: 90+ scores)

### Operations
- [ ] CloudWatch alarms on CloudFront 4xx/5xx error rates
- [ ] CI/CD pipeline running on every push to main
- [ ] Cache invalidation in deploy script
- [ ] Cognito User Pool for reviewer login (replace the hardcoded `'reviewer@example.com'` in `verify.component.ts`)
- [ ] Audit logging enabled on the bucket and CloudTrail for the account

### UX
- [ ] Real document preview (signed S3 URL embedded in iframe), replacing the simulated SVG preview
- [ ] Form validation rules per document type (e.g. invoice_date must be a real date)
- [ ] Keyboard shortcuts (`s` to submit, `h` to hold, etc.) for power users
- [ ] Empty states with helpful guidance ("No batches pending review — all caught up!")

---

## Troubleshooting

**Blank page after deploying to CloudFront**
Check the browser console for 403 errors. Most likely the OAC + bucket policy isn't right. Verify:
- The bucket policy `AWS:SourceArn` matches your distribution's ARN
- The distribution has `OriginAccessControlId` set on its origin

**404 on deep links like `/verify/abc-123`**
Custom error responses for 403 and 404 → 200 with `/index.html` aren't configured. Check the CloudFormation template's `CustomErrorResponses` block exists.

**CORS errors in browser console**
The browser is blocking requests to API Gateway because it doesn't return `Access-Control-Allow-Origin`. Fix the OPTIONS methods on each API Gateway resource (the IDP CloudFormation template handles this — make sure both stacks are deployed).

**`npm install` fails with "EACCES: permission denied"**
Don't use `sudo` with npm. Set up a proper Node version manager (nvm on Mac/Linux, nvm-windows on Windows).

**Angular CLI version mismatch warning**
The `angular.json` is for Angular 17. If you have a different global CLI version, run `npx ng …` instead of `ng …` to use the project-local one.

**Stale content after deploy**
You forgot the `cloudfront create-invalidation` step. Run it.

**`Cannot read properties of undefined`**
Probably reading `extractedFields` from an item that doesn't have it. The mock data has it; real DynamoDB rows might not. Check the `normalize` method in `api-batch.service.ts`.

---

## License

Internal project — use within your organization.
