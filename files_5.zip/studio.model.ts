/* ================================================================
   Studio view models.

   Shapes here mirror the DynamoDB row shapes 1:1 so the UI never
   translates between "wire format" and "storage format".

   Naming: PascalCase for anything that is part of the runtime
   document-config schema (interoperability with existing pipeline).
   camelCase for Studio-only metadata (versions, timestamps, counts).
   ================================================================ */

import { ConfigDocumentType, ConfigStatus, DocumentClassificationMode, FieldOption } from './document-config.model';
import { AslDefinition } from './asl.model';

// ---------- Session / display -----------------------------------------------

export type Environment = 'dev' | 'qa' | 'prod';

export interface StudioUser {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'designer' | 'reviewer';
}

// ---------- Optimistic-concurrency envelope --------------------------------

/** Fields every writeable row carries; the backend owns them. */
export interface RowAudit {
  version: number;
  lastModifiedAt: string;
  lastModifiedBy: string;
}

// ---------- Applications ---------------------------------------------------

/** Summary shape used by the Applications list page. */
export interface ApplicationSummary extends RowAudit {
  appId: string;
  name: string;
  classificationMode: 'Sequential' | 'Parallel' | string;
  docTypeCount: number;
}

/** Full application record. Today identical to summary; will grow. */
export interface ApplicationRecord extends ApplicationSummary {}

export interface NewApplicationInput {
  appId: string;              // caller-chosen id, e.g. "LOANS"
  name: string;
  classificationMode?: 'Sequential' | 'Parallel' | string;
}

export interface UpdateApplicationInput {
  name?: string;
  classificationMode?: 'Sequential' | 'Parallel' | string;
}

// ---------- Document Types -------------------------------------------------

export interface DocumentTypeSummary extends RowAudit {
  appId: string;
  docTypeId: string;
  name: string;
  pageCount: number;
  fieldCount: number;
  jobCount: number;
  stpRate: number | null;
  status: ConfigStatus;
  /** Rendered relative time ("2 days ago"). Backend or UI can compute. */
  lastModifiedLabel?: string;
}

export interface DocumentTypeRecord extends DocumentTypeSummary {
  body: ConfigDocumentType;
}

export interface NewDocumentTypeInput {
  docTypeId: string;
  name: string;
  /** Seeds MainPage/TrailingPage's IdentificationMethod. Defaults to
   *  'Sequential' on the backend if omitted. */
  classificationMode?: DocumentClassificationMode;
  /** Seeds BlankPage's MaxWordCount. Defaults to 5 on the backend if omitted. */
  blankPageMaxWordCount?: number;
  body?: ConfigDocumentType;   // if omitted, backend creates the standard scaffold using the two fields above
}

// ---------- Dictionaries ---------------------------------------------------

export interface DictionaryRecord extends RowAudit {
  name: string;
  options: FieldOption[];
}

// ---------- Dashboard ------------------------------------------------------

/**
 * Nullable fields have no real data source yet. The UI shows an honest
 * "not available yet" placeholder for these rather than fabricating a
 * number — see DashboardComponent.
 */
export interface DashboardKpis {
  documentsToday: number;
  /** No historical comparison available yet. */
  documentsTrendPct: number | null;
  stpRatePct: number;
  /** No historical comparison available yet. */
  stpRateTrendPts: number | null;
  /** Scoped to the same window as the rest of the snapshot (last 7 days),
   *  not an unbounded all-time backlog count. */
  pendingReview: number;
  /** Nothing tracks concurrent reviewer sessions yet. */
  activeIndexers: number | null;
  /** Batch rows don't currently record enough timing detail to compute this. */
  avgProcessingSec: number | null;
}

/** One day's worth of throughput, rebucketed client-side from hourly data. */
export interface VolumePoint {
  day: string;
  processed: number;
  failed: number;
}

export interface ActivityItem {
  id: string;
  message: string;
  timestamp: string;
  category: 'export' | 'review' | 'deploy' | 'connector' | 'config' | 'workflow';
}

export interface TopDocumentTypeRow {
  name: string;
  count: number;
  /** Per-document-type STP isn't computed by the backend yet. */
  stpRate: number | null;
  confidence: 'high' | 'med' | 'low' | null;
}

export interface StatusCount {
  status: string;
  count: number;
}

export type ServiceHealthState = 'healthy' | 'degraded' | 'down' | 'paused' | 'info' | 'unknown';

export interface ServiceHealth {
  name: string;
  state: ServiceHealthState;
  detail?: string;
}

export interface DashboardSnapshot {
  environment: Environment;
  lastSyncedAt: string;
  /** Start of the window this snapshot covers (last 7 days). */
  windowFrom: string;
  windowTo: string;
  kpis: DashboardKpis;
  volume: VolumePoint[];
  byStatus: StatusCount[];
  topDocumentTypes: TopDocumentTypeRow[];
  /** Empty until activity logging exists — UI shows a placeholder. */
  activity: ActivityItem[];
  /** Empty until infra health checks exist — UI shows a placeholder. */
  serviceHealth: ServiceHealth[];
}

// ---------- Workflows (Jobs & Workflow Builder) -----------------------------

/**
 * Unlike Applications/Document Types (single-state, no draft/publish),
 * Workflows have a real draft/deployed split — Deploy calls
 * CreateStateMachine/UpdateStateMachine, a genuine infrastructure action
 * against a pipeline that may be processing real documents right now.
 * Editing the draft never touches the live state machine; only Deploy does.
 */
export type WorkflowStatus = 'draft' | 'deployed';

/**
 * A Workflow is a shared, independent entity — NOT owned by one
 * Application. Any number of Applications can be mapped to reuse the same
 * pipeline, and the mapping is editable after creation (not fixed at
 * create time). Storage-wise this means Workflows live in their own flat
 * partition (PK: 'WORKFLOW'), the same pattern Dictionaries already use,
 * rather than being nested under an Application's partition key.
 */
export interface WorkflowSummary extends RowAudit {
  workflowId: string;
  name: string;
  status: WorkflowStatus;
  stateCount: number;
  stateMachineArn?: string;
  /** Every Application currently using this workflow. Editable after creation. */
  mappedApplicationIds: string[];
}

export interface WorkflowRecord extends WorkflowSummary {
  definition: AslDefinition;
}

export interface NewWorkflowInput {
  workflowId: string;
  name: string;
  /** Applications to map at creation time — optional; can be empty and set later. */
  applicationIds: string[];
}

/** Partial update — the canvas's Save sends only `definition`; the "Manage
 *  Applications" modal sends only `mappedApplicationIds`. Either or both. */
export interface UpdateWorkflowInput {
  definition?: AslDefinition;
  mappedApplicationIds?: string[];
}

export interface DeployWorkflowResult {
  stateMachineArn: string;
  action: 'created' | 'updated';
  version: number;
}

// ---------- Connectors -------------------------------------------------

/**
 * Each connector is its own independent entity — not one config object per
 * Application. An application can have several (e.g. separate S3 sources
 * for Fax vs Email intake), matching the wireframe's list-of-cards design
 * (multiple Ingestion connectors, multiple Export connectors, each
 * individually selectable, enabled/disabled, deletable).
 */
export type ConnectorDirection = 'import' | 'export';

/** S3 only for now — other platforms (Azure Blob, SharePoint, FileNet,
 *  other ECM) are a future, separate connector type. Modeled as a union
 *  (not a bare string) so adding one later is a type-level change with
 *  compiler-checked call sites, not a silent string typo. */
export type ConnectorPlatform = 'S3';

/** Manual toggle, not a live-tested connectivity status — "enabled" means
 *  "idp-ingestion should route matching files through this connector",
 *  not "we just verified it's reachable" (that's what Test Connection is
 *  for, as a separate, explicit action). New connectors start disabled
 *  until someone configures and enables them on purpose. */
export type ConnectorStatus = 'enabled' | 'disabled';

export interface ConnectorS3Config {
  bucket: string;
  prefix: string;
  /** File extensions to watch for when importing, e.g. [".pdf", ".tif", ".zip"].
   *  Matches the wireframe's "Suffix filter". */
  fileTypes: string[];
}

export interface ConnectorSummary extends RowAudit {
  connectorId: string;
  name: string;
  direction: ConnectorDirection;
  platform: ConnectorPlatform;
  appId: string;
  status: ConnectorStatus;
  /** Present once the platform-specific config has been filled in — a
   *  freshly created connector has none yet. */
  bucket?: string;
  prefix?: string;
}

export interface ConnectorRecord extends ConnectorSummary {
  s3Config?: ConnectorS3Config;
}

export interface NewConnectorInput {
  name: string;
  direction: ConnectorDirection;
  platform: ConnectorPlatform;
  appId: string;
}

/** Partial update — name/status/s3Config, any or all. Immediately
 *  persisted, no draft concept — this is plain configuration metadata
 *  idp-ingestion reads at runtime, not something with a deploy step. */
export interface UpdateConnectorInput {
  name?: string;
  status?: ConnectorStatus;
  s3Config?: ConnectorS3Config;
}

export interface TestConnectorResult {
  success: boolean;
  message: string;
}

// ---------- S3 browsing (backs the Connectors bucket/folder picker) --------

export interface S3BucketSummary {
  name: string;
}

export interface S3FolderSummary {
  /** Full prefix path, e.g. "idp/applications/AFLCOR/Import/". */
  prefix: string;
  /** Last path segment only, for display, e.g. "Import". */
  name: string;
}


