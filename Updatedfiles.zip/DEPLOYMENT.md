# Deploying IDP into a new AWS environment

This deploys the renamed pipeline (S3 → Ingestion Lambda → Step Functions
→ Textract → DynamoDB → Export, plus the API proxy behind the Angular UI)
into any AWS account with **zero hardcoded account IDs, regions, or
resource names**. Everything in `infra/template.yaml` and
`infra/stepfunction-pipeline.asl.json` uses SAM intrinsics
(`!Ref`, `!GetAtt`, `!Sub`) so it will deploy cleanly wherever you point it.

## What was hardcoded before, and how it's fixed now

| Old (Aflac Core, account 421031118220) | New |
|---|---|
| `arn:aws:lambda:us-east-1:421031118220:function:aflaccore-*` inside `stepfunction-pipeline.json` | `${ClassificationFunctionArn}` etc. — injected at deploy time via `DefinitionSubstitutions` in `template.yaml`, resolved from `!GetAtt <Function>.Arn` |
| `AFLACCORE_TABLE` / `AFLACCORE_COUNTER_TABLE` env vars pointing at fixed table names | `IDP_TABLE` / `IDP_COUNTER_TABLE`, set automatically from `!Ref` to the tables SAM creates |
| `aflac-ecm-datacap-dev` bucket name baked into 3 different Lambdas as a fallback default | `DOCS_BUCKET` injected from the actual bucket SAM creates (or a name you choose) |
| No IaC for the state machine, IAM roles, SNS topic, or DynamoDB tables — these existed only as a bare `.json` ASL file and Python `boto3.resource("dynamodb")` calls | Full `AWS::Serverless::*` / `AWS::DynamoDB::Table` / `AWS::SNS::Topic` / `AWS::IAM::Role` definitions in `template.yaml` |

## Prerequisites

```bash
# AWS SAM CLI
pip install aws-sam-cli --break-system-packages   # or: brew install aws-sam-cli
sam --version

# AWS CLI configured for the target account
aws configure   # or aws configure sso
aws sts get-caller-identity   # confirm you're pointed at the NEW account
```

Python 3.12 and Node.js 20.x should be available locally (SAM uses containers
to build by default, so this is only needed if you build without `--use-container`).

## 1. Directory layout expected by the template

```
renamed/
├── infra/
│   ├── template.yaml
│   ├── stepfunction-pipeline.asl.json
│   └── DEPLOYMENT.md          <- this file
└── lambda_and_stepfunctions/
    └── lambda/
        ├── idp-shared-layer/
        ├── idp-ingestion/
        ├── idp-classification/
        ├── idp-extraction/
        ├── idp-extraction-callback/
        ├── idp-validation/
        ├── idp-manual-review/
        ├── idp-export/
        └── idp-api-proxy/
```
This is exactly how the files you're downloading are laid out — don't move
`infra/` relative to `lambda_and_stepfunctions/`, since `template.yaml` uses
relative `CodeUri` paths (`../lambda_and_stepfunctions/lambda/...`).

## 2. Build

```bash
cd renamed/infra
sam build --use-container
```

`--use-container` builds each Lambda inside a Docker image matching the real
Lambda runtime, which matters here because `idp-api-proxy` depends on
`sharp` (a native module) — building it on your laptop's OS/arch can produce
a binary that fails at runtime on Lambda. If you don't have Docker, at least
build `idp-api-proxy` with:
```bash
cd ../lambda_and_stepfunctions/lambda/idp-api-proxy
npm run build:lambda   # installs the linux/x64 glibc build of sharp
```

## 3. Deploy

First time (interactive — saves your answers to `samconfig.toml`):
```bash
sam deploy --guided
```
You'll be asked for:
- **Stack name** — e.g. `idp-dev`
- **Region** — pick the new account's target region
- **Parameter EnvName** — `dev` / `test` / `prod`
- **Parameter DocsBucketName** — leave blank to auto-generate a globally-unique name
- **Parameter ExportBucketName** — leave blank to auto-generate one
- **Confirm changes before deploy** — yes, for the first deploy
- **Allow SAM CLI IAM role creation** — yes (it needs to create the Lambda
  execution roles, the Textract→SNS role, and Step Functions role)
- **Save arguments to samconfig.toml** — yes

Subsequent deploys:
```bash
sam deploy
```

## 4. Post-deploy: upload the config file

The pipeline reads `document-config.json` from
`s3://<DocsBucket>/idp/config/document-config.json` on cold start:

```bash
DOCS_BUCKET=$(aws cloudformation describe-stacks --stack-name idp-dev \
  --query "Stacks[0].Outputs[?OutputKey=='DocsBucketName'].OutputValue" --output text)

aws s3 cp ../document-config.json "s3://${DOCS_BUCKET}/idp/config/document-config.json"
```

## 5. Test the ingestion trigger end-to-end

Drop a test zip in the exact path pattern the Ingestion Lambda expects
(`idp/applications/<App>/Import/<Source>/<file>.zip`):

```bash
aws s3 cp ./sample-batch.zip \
  "s3://${DOCS_BUCKET}/idp/applications/AFLCOR/Import/Email/test-batch.zip"
```
Then watch the execution:
```bash
STATE_MACHINE_ARN=$(aws cloudformation describe-stacks --stack-name idp-dev \
  --query "Stacks[0].Outputs[?OutputKey=='StateMachineArn'].OutputValue" --output text)

aws stepfunctions list-executions --state-machine-arn "$STATE_MACHINE_ARN" --max-results 5
```

> Note: the sample data still uses `AFLCOR` as the `ApplicationName` (e.g. in
> `document-config.json` and the S3 key convention above). That wasn't part of
> your rename request — it's an application/business code, not the "Aflac
> Core" solution name — so I left it as-is. Say the word if you'd also like
> that renamed (and to what).

## 6. Deploy the Angular UI

```bash
cd ../idp-ui/idp-ui
npm ci

API_URL=$(aws cloudformation describe-stacks --stack-name idp-dev \
  --query "Stacks[0].Outputs[?OutputKey=='ApiProxyFunctionUrl'].OutputValue" --output text)
```
Edit `src/environments/environment.prod.ts` and set `apiUrl` (or equivalent
key) to `$API_URL`, then:
```bash
npm run build -- --configuration production
```
Host the `dist/` output anywhere static (S3 + CloudFront is the simplest —
`idp-ui/README.md` in this bundle already has a worked example using
`aws s3 sync` + a CloudFront OAC distribution). Point CloudFront's origin at
the `dist/` bucket, not at the API proxy.

## 7. The CIF-lookup proxy (`cif-proxy/cif-lookup-proxy.js`)

This is a **separate, standalone** Node process — it's not a Lambda in this
template. It exists to bridge the browser to the real on-prem Aflac CIF
service (client-cert auth, so it can't be called directly from the browser).
Deploy it wherever it can reach that on-prem endpoint (a small EC2 instance,
an on-prem host, or a container with network-level access) — it doesn't move
into the new AWS account automatically just because the rest of the stack
does, since its whole job is proximity to that private endpoint.

## Securing the API (do this before real use)

`ApiProxyFunction`'s Function URL is deployed with `AuthType: NONE` in
`template.yaml` because the Angular app calls it directly with a plain
`fetch()` — matching how the original code was written — but that means
**anyone with the URL can hit it**. Before this handles real data, put one
of these in front of it:
- API Gateway HTTP API + a Cognito or Lambda authorizer, or
- CloudFront + AWS WAF + a shared-secret header check, or
- restrict the Function URL to a VPC via a CloudFront Origin Access + custom
  header, since native IP allow-listing isn't available on Function URLs.

## Things this template does NOT provision (out of scope / need your input)

- **IBM FileNet export target** — the `idp-export` Lambda writes to
  `EXPORT_BUCKET`/`EXPORT_PREFIX` in S3; wiring that through to FileNet (via
  CMIS REST or SOAP, per your earlier FileNet research) isn't in the supplied
  code, so it isn't in this template either.
- **VPC / networking** — nothing here needs a VPC (no RDS, no private
  endpoints called from Lambda) since the code you gave me uses DynamoDB, not
  Oracle RDS. If your target design still calls for Oracle RDS, that's a
  separate piece of infra (VPC, subnets, security groups, RDS instance) not
  represented in this codebase — flag it and I'll add it.
- **Custom domain / TLS** for the API proxy or the UI.
- **CI/CD** — `idp-ui/README.md` has a GitHub Actions example for the UI; the
  Lambda side would need its own pipeline (`sam build && sam deploy` in CI).
