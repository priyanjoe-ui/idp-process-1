"""
Manual Review Lambda (aflaccore-manual-review).
Invoked by Step Functions with .waitForTaskToken pattern.
Input: { "queueId": N, "application": "...", "taskToken": "..." }
What this Lambda does:
  1. Stash the taskToken on BATCH/META under manualReviewTaskToken
  2. Update batch status to "pending", currentTask = "ManualReview"
     ("pending" = routed here by the system after validation; "hold" is
     reserved exclusively for user-initiated Hold from the Verify screen)
  3. Write a TASKHIST row marking ManualReview as Started
  4. Return (the Step Function stays paused; Sub-step 2 API will resume it
     when the UI submits the review)
"""
import json
import logging
from decimal import Decimal
from typing import Any, Dict
import boto3
from shared import ddb
logger = logging.getLogger()
logger.setLevel(logging.INFO)
 
class _DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, Decimal):
            if o == o.to_integral_value():
                return int(o)
            return float(o)
        return super().default(o)
 
def _j(obj: Any) -> str:
    return json.dumps(obj, cls=_DecimalEncoder)
 
def lambda_handler(event: Dict[str, Any], _context: Any) -> Dict[str, Any]:
    logger.info("Event: %s", _j(event))
    queue_id = int(event["queueId"])
    application = event["application"]
    task_token = event["taskToken"]
    start_time = ddb.now_iso()
    try:
        ddb.set_manual_review_pending(queue_id, task_token)
        # Status "pending" means the system routed this batch into manual
        # review (e.g. validation failed or low confidence). Distinct from
        # "hold", which is reserved exclusively for a user-initiated Hold
        # from the Verify screen via POST /api/batches/:queueId/hold.
        ddb.update_batch_status(
            queue_id, status="pending", current_task="ManualReview",
        )
        ddb.append_task_history(
            queue_id=queue_id,
            task_name="ManualReview",
            status="WaitingForReviewer",
            start_time=start_time,
            end_time=ddb.now_iso(),
            operator="system",
            details={"taskTokenStashed": True},
        )
        result = {
            "queueId": queue_id,
            "application": application,
            "status": "WaitingForReviewer",
        }
        logger.info("ManualReview parked: %s", _j(result))
        return result
    except Exception:
        logger.exception("ManualReview kickoff failed")
        ddb.append_task_history(
            queue_id=queue_id,
            task_name="ManualReview",
            status="Failed",
            start_time=start_time,
            end_time=ddb.now_iso(),
            operator="system",
        )
        try:
            _sfn = boto3.client("stepfunctions")
            _sfn.send_task_failure(
                taskToken=task_token,
                error="ManualReviewKickoffFailed",
                cause="See aflaccore-manual-review logs",
            )
        except Exception:
            logger.exception("Also failed to SendTaskFailure")
        raise