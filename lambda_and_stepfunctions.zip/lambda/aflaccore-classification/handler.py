 
"""
 
Classification Lambda (aflaccore-classification).
 
Shared code is loaded from the aflaccore-shared Lambda Layer.
 
"""
 
import json
 
import logging
 
import os
 
from decimal import Decimal
 
from typing import Any, Dict, List
 
import boto3
 
from shared import config_loader, ddb
 
logger = logging.getLogger()
 
logger.setLevel(logging.INFO)
 
_textract = boto3.client("textract")
 
 
class _DecimalEncoder(json.JSONEncoder):
 
    def default(self, o):
 
        if isinstance(o, Decimal):
 
            if o == o.to_integral_value():
 
                return int(o)
 
            return float(o)
 
        return super().default(o)
 
 
def _json(obj: Any) -> str:
 
    return json.dumps(obj, cls=_DecimalEncoder)
 
 
def _classify_sequential(pages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
 
    results = []
 
    for idx, p in enumerate(pages):
 
        page_type = "MainPage" if idx == 0 else "TrailingPage"
 
        results.append({
 
            "pageId": p["pageId"],
 
            "pageNumber": int(p["pageNumber"]),
 
            "pageType": page_type,
 
        })
 
    return results
 
 
def _ocr_words(bucket: str, key: str) -> List[str]:
 
    resp = _textract.detect_document_text(
 
        Document={"S3Object": {"Bucket": bucket, "Name": key}},
 
    )
 
    return [b["Text"] for b in resp.get("Blocks", []) if b.get("BlockType") == "WORD"]
 
 
def _classify_ocr(pages: List[Dict[str, Any]],
 
                  doc_type: Dict[str, Any]) -> List[Dict[str, Any]]:
 
    docs_bucket = os.environ["DOCS_BUCKET"]
 
    page_types = doc_type.get("PageTypes", [])
 
    results = []
 
    for p in pages:
 
        words = _ocr_words(docs_bucket, p["s3Key"])
 
        text_lower = " ".join(words).lower()
 
        best_type = "MainPage"
 
        best_score = -1
 
        for pt in page_types:
 
            keywords = [k.lower() for k in (pt.get("Keywords") or [])]
 
            if not keywords:
 
                continue
 
            hits = sum(1 for k in keywords if k in text_lower)
 
            if hits > best_score:
 
                best_score = hits
 
                best_type = pt["PageType"]
 
        results.append({
 
            "pageId": p["pageId"],
 
            "pageNumber": int(p["pageNumber"]),
 
            "pageType": best_type,
 
        })
 
    return results
 
 
def lambda_handler(event: Dict[str, Any], _context: Any) -> Dict[str, Any]:
 
    logger.info("Event: %s", _json(event))
 
    queue_id = int(event["queueId"])
 
    application = event["application"]
 
    start_time = ddb.now_iso()
 
    ddb.update_batch_status(queue_id, status="Running", current_task="Classification")
 
    try:
 
        app_cfg = config_loader.get_application(application)
 
        mode = app_cfg.get("ClassificationMode", "Sequential")
 
        doc_types = app_cfg.get("DocumentTypes", [])
 
        if not doc_types:
 
            raise RuntimeError(f"No DocumentTypes in config for {application}")
 
        doc_type = doc_types[0]
 
        pages = ddb.list_pages(queue_id)
 
        if not pages:
 
            raise RuntimeError(f"No pages found for queueId={queue_id}")
 
        if mode == "Sequential":
 
            decisions = _classify_sequential(pages)
 
        elif mode == "OCR":
 
            decisions = _classify_ocr(pages, doc_type)
 
        else:
 
            logger.warning("Unknown ClassificationMode %r, falling back to Sequential", mode)
 
            decisions = _classify_sequential(pages)
 
        for d in decisions:
 
            ddb.update_page_type(queue_id, d["pageId"], d["pageType"])
 
        ddb.append_task_history(queue_id=queue_id, task_name="Classification",
 
                                status="Completed", start_time=start_time,
 
                                end_time=ddb.now_iso(), operator="system")
 
        summary = {
 
            "queueId": queue_id,
 
            "application": application,
 
            "mode": mode,
 
            "pagesClassified": len(decisions),
 
            "decisions": decisions,
 
        }
 
        logger.info("Classification result: %s", _json(summary))
 
        return summary
 
    except Exception:
 
        logger.exception("Classification failed")
 
        ddb.append_task_history(queue_id=queue_id, task_name="Classification",
 
                                status="Failed", start_time=start_time,
 
                                end_time=ddb.now_iso(), operator="system")
 
        raise