"""
Export Lambda (aflaccore-export) - Phase 3 / Stage 6.
 
Writes ONE JSON metadata file per batch to the export folder. PDF
generation is deferred (needs Pillow layer); for now the JSON is the
only export artifact. The JSON includes the list of page S3 keys so a
downstream consumer can fetch the original TIFFs if needed.
 
Output:
  s3://<EXPORT_BUCKET>/<EXPORT_PREFIX>/<application>/export/<queueId>/
<batchNumber>.json
 
Env vars (all optional; defaults shown):
  EXPORT_BUCKET    -- s3 bucket for exports (default: "aflac-ecm-datacap-dev")
  EXPORT_PREFIX    -- root prefix (default: "aflac_core/applications")
  DOCS_BUCKET      -- bucket where source TIFFs live (default: "aflac-ecm-datacap-dev")
 
Invoked by Step Functions with input:
  { "queueId": N, "application": "AFLCOR" }
"""
 
import json
import logging
import os
from decimal import Decimal
from typing import Any, Dict, List
 
import boto3
 
from shared import ddb
 
logger = logging.getLogger()
logger.setLevel(logging.INFO)
 
# ---------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------
DOCS_BUCKET   = os.environ.get("DOCS_BUCKET",   "aflac-ecm-datacap-dev")
EXPORT_BUCKET = os.environ.get("EXPORT_BUCKET", DOCS_BUCKET)
EXPORT_PREFIX = os.environ.get("EXPORT_PREFIX", "aflac_core/applications").rstrip("/")
 
_s3 = boto3.client("s3")
 
# DDB table reference for this Lambda's targeted updates (export keys
# on the document record). We don't go through the shared ddb module
# for this because there's no public helper for adding export tracking
# attributes - direct boto3 is the cleanest path for a single targeted
# update.
_ddb_resource = boto3.resource("dynamodb")
_table = _ddb_resource.Table(os.environ["AFLACCORE_TABLE"])
 
 
# ---------------------------------------------------------------
# JSON helper - DDB returns Decimal, which json.dumps can't handle natively
# ---------------------------------------------------------------
class _DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, Decimal):
            if o == o.to_integral_value():
                return int(o)
            return float(o)
        return super().default(o)
 
 
def _j(obj: Any) -> str:
    return json.dumps(obj, cls=_DecimalEncoder)
 
 
# ---------------------------------------------------------------
# Metadata JSON building
# ---------------------------------------------------------------
def _build_metadata(meta: Dict[str, Any],
                    document: Dict[str, Any],
                    pages: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Build the export JSON. Pulls fields + line items + audit info.
 
    Includes the per-page S3 keys so a downstream consumer can fetch
    the source TIFFs directly. Once we add the Pillow layer, this same
    handler will also produce a merged PDF and the JSON will reference
    that PDF's key.
    """
    # Convert extractedFields list to a flat name->value dict so the
    # downstream consumer doesn't need to parse the IDP-internal shape.
    fields_flat: Dict[str, Any] = {}
    for f in (document.get("extractedFields") or []):
        name = f.get("fieldName")
        if name:
            fields_flat[name] = f.get("value")
 
    # Line items: emit exactly what's stored (list of column-name maps).
    line_items = document.get("lineItems") or []
 
    return {
        "batchNumber": meta.get("batchNumber"),
        "queueId": int(meta.get("queueId", 0)),
        "application": meta.get("application"),
        "jobName": meta.get("jobName"),
        "exportedAt": ddb.now_iso(),
        "exportedBy": "system",
        "reviewer": meta.get("operator") or None,
        "review": {
            "startedAt":   meta.get("manualReviewStartedAt"),
            "completedAt": meta.get("manualReviewCompletedAt"),
        },
        "document": {
            "documentId":        document.get("documentId"),
            "documentType":      document.get("documentType"),
            "validationStatus":  document.get("validationStatus"),
            "fields":            fields_flat,
            "lineItems":         line_items,
        },
        "pages": [
            {
                "displayId":  p.get("displayId"),
                "pageNumber": int(p.get("pageNumber", 0)),
                "pageType":   p.get("pageType"),
                # Include the S3 key so a downstream consumer can fetch
                # the raw TIFF if needed. Bucket comes from the
                # pagesBucket field below for clarity.
                "s3Key":      p.get("s3Key"),
            }
            for p in pages
        ],
        "pagesBucket":  DOCS_BUCKET,
        "sourceZipKey": meta.get("sourceZipKey"),
        # Placeholder for when PDF generation comes online. Today this
        # is intentionally null; once the Pillow layer is attached and
        # the PDF logic is re-enabled, this field will hold the PDF
        # object key.
        "pdfKey":       None,
    }
 
 
# ---------------------------------------------------------------
# Main handler
# ---------------------------------------------------------------
def lambda_handler(event: Dict[str, Any], _context: Any) -> Dict[str, Any]:
    logger.info("Event: %s", _j(event))
 
    queue_id = int(event["queueId"])
    application = event["application"]
 
    start_time = ddb.now_iso()
    ddb.update_batch_status(queue_id, status="Running", current_task="Export")
 
    try:
        meta = ddb.get_batch(queue_id)
        if not meta:
            raise RuntimeError(f"No batch META for queueId={queue_id}")
 
        document = ddb.get_first_document(queue_id)
        if not document:
            raise RuntimeError(f"No document for queueId={queue_id}")
 
        pages = ddb.list_pages(queue_id)
        if not pages:
            raise RuntimeError(f"No pages for queueId={queue_id}")
 
        batch_number = meta.get("batchNumber") or f"queue-{queue_id}"
 
        # Build destination key. queueId is the folder, batchNumber is
        # the file name so files within a queue folder are identifiable
        # independently.
        export_dir = f"{EXPORT_PREFIX}/{application}/export/{queue_id}"
        json_key   = f"{export_dir}/{batch_number}.json"
 
        # ----- JSON metadata -----
        metadata = _build_metadata(meta, document, pages)
        json_bytes = _j(metadata).encode("utf-8")
        _s3.put_object(
            Bucket=EXPORT_BUCKET,
            Key=json_key,
            Body=json_bytes,
            ContentType="application/json",
            Metadata={
                "queueId":     str(queue_id),
                "batchNumber": batch_number,
                "application": application,
            },
        )
        logger.info("Wrote JSON: s3://%s/%s (%d bytes)", EXPORT_BUCKET, json_key, len(json_bytes))
 
        # ----- Record export location on the document for traceability -----
        # exportPdfKey is intentionally left unset for now; future PDF-
        # enabled runs will fill it in.
        _table.update_item(
            Key={"PK": f"BATCH#{queue_id}", "SK": document["SK"]},
            UpdateExpression="SET exportJsonKey = :jk, exportedAt = :ts, updatedAt = :now",
            ExpressionAttributeValues={
                ":jk": json_key,
                ":ts": ddb.now_iso(),
                ":now": ddb.now_iso(),
            },
        )
 
        # ----- Mark batch done -----
        ddb.update_batch_status(queue_id, status="JobDone", current_task="Export")
 
        ddb.append_task_history(
            queue_id=queue_id,
            task_name="Export",
            status="Completed",
            start_time=start_time,
            end_time=ddb.now_iso(),
            operator="system",
            details={
                "jsonKey":   json_key,
                "pageCount": len(pages),
                "note":      "PDF generation skipped (Pillow layer not attached)",
            },
        )
 
        result = {
            "queueId":     queue_id,
            "application": application,
            "status":      "JobDone",
            "jsonKey":     json_key,
        }
        logger.info("Export result: %s", _j(result))
        return result
 
    except Exception as e:
        logger.exception("Export failed")
        ddb.append_task_history(
            queue_id=queue_id,
            task_name="Export",
            status="Failed",
            start_time=start_time,
            end_time=ddb.now_iso(),
            operator="system",
            details={"error": str(e)},
        )
        raise