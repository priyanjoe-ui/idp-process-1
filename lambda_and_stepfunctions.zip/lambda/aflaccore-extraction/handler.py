"""
Extraction Lambda (aflaccore-extraction).
Submits per-page async Textract jobs and returns immediately.
Resumes via SNS callback -> aflaccore-extraction-callback Lambda.
"""
import json
import logging
import os
from decimal import Decimal
from typing import Any, Dict
import boto3
from shared import ddb
logger = logging.getLogger()
logger.setLevel(logging.INFO)
_textract = boto3.client("textract")

class _DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, Decimal):
            if o == o.to_integral_value():
                return int(o)
            return float(o)
        return super().default(o)

def _j(obj: Any) -> str:
    return json.dumps(obj, cls=_DecimalEncoder)

def _submit_textract_job(bucket: str, key: str, queue_id: int,
                         page_id: str, sns_topic_arn: str,
                         textract_role_arn: str) -> str:
    job_tag = f"q{queue_id}-p{page_id[:24]}"
    resp = _textract.start_document_analysis(
        DocumentLocation={"S3Object": {"Bucket": bucket, "Name": key}},
        FeatureTypes=["FORMS", "TABLES"],
        NotificationChannel={
            "RoleArn": textract_role_arn,
            "SNSTopicArn": sns_topic_arn,
        },
        JobTag=job_tag,
    )
    return resp["JobId"]

def lambda_handler(event: Dict[str, Any], _context: Any) -> Dict[str, Any]:
    logger.info("Event: %s", _j(event))
    queue_id = int(event["queueId"])
    application = event["application"]
    task_token = event["taskToken"]
    start_time = ddb.now_iso()
    ddb.update_batch_status(queue_id, status="Running", current_task="Extraction")
    try:
        docs_bucket = os.environ["DOCS_BUCKET"]
        sns_topic_arn = os.environ["TEXTRACT_SNS_TOPIC_ARN"]
        textract_role_arn = os.environ["TEXTRACT_ROLE_ARN"]
        pages = ddb.list_pages(queue_id)
        if not pages:
            raise RuntimeError(f"No pages for queueId={queue_id}")
        ddb.init_pending_pages_count(
            queue_id=queue_id,
            count=len(pages),
            task_token=task_token,
        )
        submitted = []
        for page in pages:
            page_id = page["pageId"]
            page_s3_key = page["s3Key"]
            job_id = _submit_textract_job(
                bucket=docs_bucket,
                key=page_s3_key,
                queue_id=queue_id,
                page_id=page_id,
                sns_topic_arn=sns_topic_arn,
                textract_role_arn=textract_role_arn,
            )
            ddb.put_textract_job(
                queue_id=queue_id,
                job_id=job_id,
                page_id=page_id,
                task_token=task_token,
                page_s3_key=page_s3_key,
            )
            submitted.append({"pageId": page_id, "jobId": job_id})
        ddb.append_task_history(
            queue_id=queue_id,
            task_name="Extraction",
            status="JobsSubmitted",
            start_time=start_time,
            end_time=ddb.now_iso(),
            operator="system",
            details={"jobsSubmitted": submitted},
        )
        result = {
            "queueId": queue_id,
            "application": application,
            "pagesSubmitted": len(submitted),
            "submitted": submitted,
        }
        logger.info("Extraction kickoff: %s", _j(result))
        return result
    except Exception:
        logger.exception("Extraction kickoff failed")
        ddb.append_task_history(
            queue_id=queue_id,
            task_name="Extraction",
            status="Failed",
            start_time=start_time,
            end_time=ddb.now_iso(),
            operator="system",
        )
        try:
            _sfn = boto3.client("stepfunctions")
            _sfn.send_task_failure(
                taskToken=task_token,
                error="ExtractionKickoffFailed",
                cause="See aflaccore-extraction logs",
            )
        except Exception:
            logger.exception("Also failed to SendTaskFailure")
        raise