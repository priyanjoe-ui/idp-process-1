\
Stage 7 migration: rewrite legacy status='OnHold' to status='hold' on
BATCH/META items. Also rewrites the GSI1PK index value that mirrors
status so the secondary index stays consistent.

Idempotent: skips items that are already 'hold'. Safe to run multiple
times during the rollout window.

Usage:
    # Dry run (no writes), just shows what would change:
    python migrate-onhold-to-hold.py --table aflaccore-batch-tracking \\\\
        --region us-east-1 --dry-run

    # Real run:
    python migrate-onhold-to-hold.py --table aflaccore-batch-tracking \\\\
        --region us-east-1

Run from CloudShell or any box with credentials that have
dynamodb:Scan + dynamodb:UpdateItem on the target table.
\
import argparse
import sys
from typing import Iterator, Dict, Any

import boto3
from boto3.dynamodb.conditions import Attr


def _scan_onhold_metas(table) -> Iterator[Dict[str, Any]]:
    \

    A FilterExpression scopes the scan server-side; we still pay for
    the full table read but only the matching items come back over the
    wire. For thousands of items this is fine; for millions, switch to
    a GSI query on GSI1PK = STATUS#OnHold.
    \
    kwargs = {
        'FilterExpression': Attr('SK').eq('META') & Attr('status').eq('OnHold'),
    }
    while True:
        page = table.scan(**kwargs)
        for item in page.get('Items', []):
            yield item
        token = page.get('LastEvaluatedKey')
        if not token:
            return
        kwargs['ExclusiveStartKey'] = token


def _rewrite(table, item, dry_run: bool) -> None:
    \
    pk = item['PK']
    sk = item['SK']
    queue_id = item.get('queueId', '?')
    batch_number = item.get('batchNumber', '?')

    msg = f\
    if dry_run:
        print(f\
        return

    table.update_item(
        Key={'PK': pk, 'SK': sk},
        UpdateExpression='SET #s = :new_s, GSI1PK = :new_gsi',
        ConditionExpression='#s = :old_s',
        ExpressionAttributeNames={'#s': 'status'},
        ExpressionAttributeValues={
            ':new_s':   'hold',
            ':new_gsi': 'STATUS#hold',
            ':old_s':   'OnHold',
        },
    )
    print(f\


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description='Rewrite OnHold to hold on BATCH/META items')
    parser.add_argument('--table',  required=True, help='DDB table name (e.g. aflaccore-batch-tracking)')
    parser.add_argument('--region', default='us-east-1', help='AWS region')
    parser.add_argument('--dry-run', action='store_true', help='Show changes without applying them')
    args = parser.parse_args(argv)

    ddb = boto3.resource('dynamodb', region_name=args.region)
    table = ddb.Table(args.table)

    print(f\

    count = 0
    for item in _scan_onhold_metas(table):
        _rewrite(table, item, args.dry_run)
        count += 1

    verb = 'would update' if args.dry_run else 'updated'
    print(f\
    return 0


if __name__ == '__main__':
    sys.exit(main())
