"""
Stage 7 migration: rewrite status='OnHold' → status='hold' on BATCH/META items.
Also rewrites GSI1PK to keep the secondary index consistent.
Idempotent — safe to run multiple times.

Usage:
  # Dry run (no writes):
  python migrate-onhold-to-hold.py --table aflaccore-batch-tracking --region us-east-1 --dry-run

  # Real run:
  python migrate-onhold-to-hold.py --table aflaccore-batch-tracking --region us-east-1
"""
import argparse
import sys
from typing import Any, Dict, Iterator

import boto3
from boto3.dynamodb.conditions import Attr


def _scan_onhold_metas(table) -> Iterator[Dict[str, Any]]:
    kwargs = {
        "FilterExpression": Attr("SK").eq("META") & Attr("status").eq("OnHold"),
    }
    while True:
        page = table.scan(**kwargs)
        for item in page.get("Items", []):
            yield item
        token = page.get("LastEvaluatedKey")
        if not token:
            return
        kwargs["ExclusiveStartKey"] = token


def _rewrite(table, item, dry_run: bool) -> None:
    pk = item["PK"]
    sk = item["SK"]
    queue_id    = item.get("queueId", "?")
    batch_number = item.get("batchNumber", "?")
    msg = f"  queueId={queue_id} batch={batch_number}: OnHold → hold"
    if dry_run:
        print(f"[DRY-RUN]{msg}")
        return
    table.update_item(
        Key={"PK": pk, "SK": sk},
        UpdateExpression="SET #s = :new_s, GSI1PK = :new_gsi",
        ConditionExpression="#s = :old_s",
        ExpressionAttributeNames={"#s": "status"},
        ExpressionAttributeValues={
            ":new_s":   "hold",
            ":new_gsi": "STATUS#hold",
            ":old_s":   "OnHold",
        },
    )
    print(f"[OK]    {msg}")


def main(argv=None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--table",   required=True)
    parser.add_argument("--region",  default="us-east-1")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)

    ddb   = boto3.resource("dynamodb", region_name=args.region)
    table = ddb.Table(args.table)

    prefix = "DRY-RUN: " if args.dry_run else ""
    print(f"{prefix}Scanning {args.table} in {args.region} for OnHold items…")

    count = 0
    for item in _scan_onhold_metas(table):
        _rewrite(table, item, args.dry_run)
        count += 1

    verb = "would update" if args.dry_run else "updated"
    print(f"\nDone: {verb} {count} item(s).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
