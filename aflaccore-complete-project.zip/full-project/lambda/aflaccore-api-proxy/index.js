/**
 * aflaccore-api-proxy — Node.js 20 Lambda (Express)
 * Serves all REST API endpoints to the Angular UI.
 *
 * Endpoints:
 *   GET  /health
 *   POST /auth/login
 *   GET  /auth/me
 *   GET  /api/applications
 *   GET  /api/applications/:app/jobs
 *   GET  /api/batches              ?application=&status=&search=&page=&pageSize=
 *   GET  /api/batches/:queueId
 *   GET  /api/batches/:queueId/pages/:pageId/image  (presigned URL redirect)
 *   POST /api/batches/:queueId/submit-review
 *   POST /api/batches/:queueId/save-draft
 *   POST /api/batches/:queueId/hold
 *   POST /api/batches/:queueId/release
 *   POST /api/batches/:queueId/tree-state
 *   GET  /api/dashboard
 *
 * Environment variables:
 *   AFLACCORE_TABLE          DynamoDB table name
 *   DOCS_BUCKET              S3 bucket for source TIFFs
 *   STATE_MACHINE_ARN        Step Functions ARN (for SendTaskSuccess)
 *   AWS_REGION               (set by Lambda runtime)
 */

'use strict';

const express = require('express');
const serverless = require('serverless-http');
const {
  DynamoDBClient,
} = require('@aws-sdk/client-dynamodb');
const {
  DynamoDBDocumentClient,
  QueryCommand,
  UpdateCommand,
  PutCommand,
  DeleteCommand,
  GetCommand,
} = require('@aws-sdk/lib-dynamodb');
const {
  S3Client,
  GetObjectCommand,
} = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');
const {
  SFNClient,
  SendTaskSuccessCommand,
  SendTaskFailureCommand,
} = require('@aws-sdk/client-sfn');

// ─── AWS clients ────────────────────────────────────────────────────────────
const region = process.env.AWS_REGION || 'us-east-1';
const ddbClient = new DynamoDBClient({ region });
const ddb = DynamoDBDocumentClient.from(ddbClient, {
  marshallOptions: { removeUndefinedValues: true },
});
const s3 = new S3Client({ region });
const sfn = new SFNClient({ region });

const TABLE       = process.env.AFLACCORE_TABLE || 'aflaccore-batch-tracking';
const DOCS_BUCKET = process.env.DOCS_BUCKET || 'aflac-ecm-datacap-dev';

// ─── Helpers ────────────────────────────────────────────────────────────────
function nowIso() {
  return new Date().toISOString();
}

function jsonError(res, status, code, message) {
  return res.status(status).json({ error: code, message });
}

function safeNumber(val, fallback) {
  const n = parseInt(val, 10);
  return isNaN(n) ? fallback : n;
}

function getOperator(req) {
  return req.headers['x-operator'] || req.body?.reviewer || 'anonymous';
}

/** Query ALL items for a batch (META + DOC + PAGE + TASK rows). */
async function queryBatchAll(queueId) {
  const resp = await ddb.send(new QueryCommand({
    TableName: TABLE,
    KeyConditionExpression: 'PK = :pk',
    ExpressionAttributeValues: { ':pk': `BATCH#${queueId}` },
  }));
  return resp.Items || [];
}

/** Get just the META row for a batch. */
async function getBatchMeta(queueId) {
  const resp = await ddb.send(new GetCommand({
    TableName: TABLE,
    Key: { PK: `BATCH#${queueId}`, SK: 'META' },
  }));
  return resp.Item || null;
}

/** Query GSI1 (BatchByStatus) for a specific status. */
async function queryByStatus(status, limit = 500) {
  const resp = await ddb.send(new QueryCommand({
    TableName: TABLE,
    IndexName: 'GSI1-BatchByStatus',
    KeyConditionExpression: 'GSI1PK = :pk',
    ExpressionAttributeValues: { ':pk': `STATUS#${status}` },
    ScanIndexForward: false,
    Limit: limit,
  }));
  return resp.Items || [];
}

/** Query GSI2 (BatchByApp) for a specific application. */
async function queryByApp(application, limit = 1000) {
  const resp = await ddb.send(new QueryCommand({
    TableName: TABLE,
    IndexName: 'GSI2-BatchByApp',
    KeyConditionExpression: 'GSI2PK = :pk',
    ExpressionAttributeValues: { ':pk': `APP#${application}` },
    ScanIndexForward: false,
    Limit: limit,
  }));
  return resp.Items || [];
}

/**
 * Shape a raw DDB META row into the BatchRow DTO the UI expects.
 * jobTime = live seconds counter for non-terminal batches.
 * jobDuration = ms elapsed for terminal (JobDone/Failed) batches.
 */
function shapeBatch(meta) {
  const startedAt = meta.createdAt || meta.updatedAt;
  const now = Date.now();
  const startMs = startedAt ? new Date(startedAt).getTime() : now;
  const terminal = ['JobDone', 'Failed'].includes(meta.status);
  const lastUpdatedMs = meta.lastTaskUpdatedAt
    ? new Date(meta.lastTaskUpdatedAt).getTime()
    : now;

  return {
    queueId:       Number(meta.queueId),
    batchId:       String(meta.queueId),
    batchNumber:   meta.batchNumber || '',
    application:   meta.application || '',
    source:        meta.source || 'S3',
    jobName:       meta.jobName || '',
    currentTask:   meta.currentTask || '',
    status:        meta.status || 'pending',
    jobStartTime:  startedAt || nowIso(),
    jobTime:       terminal ? null : Math.floor((now - startMs) / 1000),
    jobDuration:   terminal ? (lastUpdatedMs - startMs) : null,
    operator:      meta.operator || '',
    documentCount: Number(meta.documentCount || 0),
    pageCount:     Number(meta.pageCount || 0),
    updatedAt:     meta.updatedAt || nowIso(),
    // Extended fields for Verify screen
    sourceZipKey:              meta.sourceZipKey || null,
    xmlMetadata:               meta.xmlMetadata || {},
    holdSource:                meta.holdSource || null,
    holdReason:                meta.holdReason || null,
    manualReviewStartedAt:     meta.manualReviewStartedAt || null,
    manualReviewCompletedAt:   meta.manualReviewCompletedAt || null,
    createdAt:                 meta.createdAt || null,
  };
}

/** Shape a DOC row into the DocumentDetail DTO. */
function shapeDocument(doc) {
  return {
    documentId:      doc.documentId || doc.SK?.replace('DOC#', '') || '',
    documentType:    doc.documentType || 'Unclassified',
    validationStatus: doc.validationStatus || 'NeedsReview',
    pageIds:         doc.pageIds || [],
    extractedFields: (doc.extractedFields || []).map(f => ({
      fieldName:       f.fieldName || '',
      value:           f.value ?? null,
      confidence:      f.confidence ?? null,
      validationPassed: f.validationPassed ?? false,
      sourcePageId:    f.sourcePageId || null,
      required:        f.required ?? false,
      disabled:        f.disabled ?? false,
      dataType:        f.dataType || 'String',
      validationError: f.validationError || null,
      correctedBy:     f.correctedBy || null,
      correctedAt:     f.correctedAt || null,
      autoPopulateFrom: f.autoPopulateFrom || null,
    })),
    lineItems:  doc.lineItems || [],
    createdAt:  doc.createdAt || null,
    updatedAt:  doc.updatedAt || null,
  };
}

/** Shape a PAGE row into the PageDetail DTO. */
async function shapePage(page, queueId) {
  // Generate a fresh pre-signed URL for the TIFF so the UI can display it
  let imageUrl = '';
  if (page.s3Key) {
    try {
      const cmd = new GetObjectCommand({ Bucket: DOCS_BUCKET, Key: page.s3Key });
      imageUrl = await getSignedUrl(s3, cmd, { expiresIn: 3600 });
    } catch (e) {
      console.warn(`presign failed for ${page.s3Key}:`, e.message);
      imageUrl = `/api/batches/${queueId}/pages/${encodeURIComponent(page.pageId)}/image`;
    }
  }
  return {
    pageId:       page.pageId || page.SK?.replace('PAGE#', '') || '',
    displayId:    page.displayId || null,
    pageNumber:   Number(page.pageNumber || 0),
    pageType:     page.pageType || 'Unclassified',
    pageStatus:   page.pageStatus || 'Processed',
    wordCount:    page.wordCount ?? null,
    s3Key:        page.s3Key || '',
    ocrTextS3Key: page.ocrTextS3Key || null,
    imageUrl,
    ocrWords:     page.ocrWords || [],
    createdAt:    page.createdAt || null,
    updatedAt:    page.updatedAt || null,
  };
}

/** Shape a TEXTRACTJOB row. */
function shapeTextractJob(row) {
  return {
    jobId:        row.textractJobId || '',
    pageId:       row.pageId || '',
    status:       row.status || '',
    createdAt:    row.createdAt || null,
    completedAt:  row.completedAt || null,
    durationMs:   row.durationMs ?? null,
    resultS3Key:  row.resultS3Key || null,
    errorMessage: row.errorMessage || null,
  };
}

/** Shape a TASKHIST row. */
function shapeTaskHistoryItem(row) {
  const startMs = row.startTime ? new Date(row.startTime).getTime() : null;
  const endMs   = row.endTime   ? new Date(row.endTime).getTime()   : null;
  return {
    taskName:   row.taskName || '',
    status:     row.status || '',
    startTime:  row.startTime || '',
    endTime:    row.endTime || '',
    operator:   row.operator || 'system',
    durationMs: (startMs && endMs) ? (endMs - startMs) : null,
    details:    row.details || {},
  };
}

/** Persist tree-state changes (Stage 8). Diffs desired vs current DDB state. */
async function persistTreeState(queueId, desiredDocs, desiredPages) {
  if (!Array.isArray(desiredDocs) || !Array.isArray(desiredPages)) {
    throw new Error('persistTreeState: desiredDocs and desiredPages must be arrays');
  }

  const rawItems = await queryBatchAll(queueId);
  const currentDocs  = rawItems.filter(i => i.SK?.startsWith('DOC#'));
  const currentPages = rawItems.filter(i => i.SK?.startsWith('PAGE#'));

  const currentDocById  = new Map(currentDocs.map(d => [d.documentId, d]));
  const currentPageById = new Map(currentPages.map(p => [p.pageId, p]));
  const desiredDocIds   = new Set(desiredDocs.map(d => d.documentId));
  const desiredPageIds  = new Set(desiredPages.map(p => p.pageId));

  const summary = { docsCreated: 0, docsUpdated: 0, docsDeleted: 0, pagesUpdated: 0, pagesDeleted: 0 };

  // Pages: delete if gone, update if changed
  for (const pageItem of currentPages) {
    if (!desiredPageIds.has(pageItem.pageId)) {
      await ddb.send(new DeleteCommand({ TableName: TABLE, Key: { PK: pageItem.PK, SK: pageItem.SK } }));
      summary.pagesDeleted++;
    }
  }
  for (const dp of desiredPages) {
    const cur = currentPageById.get(dp.pageId);
    if (!cur) continue;
    if (Number(cur.pageNumber) === Number(dp.pageNumber) && cur.pageType === dp.pageType) continue;
    await ddb.send(new UpdateCommand({
      TableName: TABLE,
      Key: { PK: cur.PK, SK: cur.SK },
      UpdateExpression: 'SET pageNumber = :pn, pageType = :pt, updatedAt = :now',
      ExpressionAttributeValues: { ':pn': Number(dp.pageNumber), ':pt': dp.pageType, ':now': nowIso() },
    }));
    summary.pagesUpdated++;
  }

  // Documents: delete if gone, create/update if present
  for (const docItem of currentDocs) {
    if (!desiredDocIds.has(docItem.documentId)) {
      await ddb.send(new DeleteCommand({ TableName: TABLE, Key: { PK: docItem.PK, SK: docItem.SK } }));
      summary.docsDeleted++;
    }
  }
  for (const dd of desiredDocs) {
    const cur = currentDocById.get(dd.documentId);
    if (!cur) {
      const ts = nowIso();
      await ddb.send(new PutCommand({
        TableName: TABLE,
        Item: {
          PK: `BATCH#${queueId}`, SK: `DOC#${dd.documentId}`, Type: 'DOC',
          documentId: dd.documentId, documentType: dd.documentType || 'Unclassified',
          validationStatus: dd.validationStatus || 'NeedsReview',
          pageIds: dd.pageIds || [], extractedFields: [], lineItems: [],
          createdAt: ts, updatedAt: ts,
        },
      }));
      summary.docsCreated++;
      continue;
    }
    const curIds = JSON.stringify(cur.pageIds || []);
    const desIds = JSON.stringify(dd.pageIds || []);
    if (curIds === desIds) continue;
    await ddb.send(new UpdateCommand({
      TableName: TABLE,
      Key: { PK: cur.PK, SK: cur.SK },
      UpdateExpression: 'SET pageIds = :pi, updatedAt = :now',
      ExpressionAttributeValues: { ':pi': dd.pageIds || [], ':now': nowIso() },
    }));
    summary.docsUpdated++;
  }

  // Update META counters
  const meta = rawItems.find(i => i.SK === 'META');
  if (meta) {
    if (Number(meta.documentCount) !== desiredDocs.length || Number(meta.pageCount) !== desiredPages.length) {
      await ddb.send(new UpdateCommand({
        TableName: TABLE,
        Key: { PK: meta.PK, SK: meta.SK },
        UpdateExpression: 'SET documentCount = :dc, pageCount = :pc, updatedAt = :now',
        ExpressionAttributeValues: { ':dc': desiredDocs.length, ':pc': desiredPages.length, ':now': nowIso() },
      }));
    }
  }
  return summary;
}

// ─── Express app ────────────────────────────────────────────────────────────
const app = express();
app.use(express.json({ limit: '10mb' }));
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Operator');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
});

// ─── Health ─────────────────────────────────────────────────────────────────
app.get('/health', (_req, res) => {
  res.json({ ok: true, ts: nowIso(), region, table: TABLE });
});

// ─── Auth ────────────────────────────────────────────────────────────────────
app.post('/auth/login', (req, res) => {
  const { username } = req.body || {};
  if (!username) return jsonError(res, 400, 'BadRequest', 'username required');
  res.json({ operator: username, authenticated: true });
});

app.get('/auth/me', (req, res) => {
  const op = getOperator(req);
  res.json({ operator: op || null, authenticated: !!op });
});

// ─── Applications ────────────────────────────────────────────────────────────
app.get('/api/applications', async (_req, res) => {
  try {
    // In Phase 2 this reads from S3 application config; for POC return static
    const applications = [
      {
        name: 'AFLCOR',
        displayName: 'AFLCOR / Policy Service',
        classificationMode: 'keyword',
        documentTypes: [
          {
            name: 'Correspondence',
            pageTypes: [
              {
                pageType: 'MainPage',
                keywords: [],
                fields: [
                  { FieldName: 'PolicyNumber', Label: 'Policy Number', DataType: 'String', Required: true },
                  { FieldName: 'TransCode', Label: 'Transaction Code', DataType: 'String', Required: true },
                  { FieldName: 'RouteTo', Label: 'Route To', DataType: 'Dropdown', Required: true,
                    Options: [
                      { Value: 'Workflow', Label: 'Workflow' },
                      { Value: 'Archive', Label: 'Archive' },
                      { Value: 'NoNumber', Label: 'No Number' },
                      { Value: 'Trash', Label: 'Trash' },
                    ],
                  },
                  { FieldName: 'Annotation', Label: 'Annotation / Comment', DataType: 'String' },
                  { FieldName: 'CompanyCode', Label: 'Company Code', DataType: 'String', Disabled: true, AutoPopulateFrom: 'application' },
                  { FieldName: 'ScanBatch', Label: 'Scan Batch', DataType: 'String', Disabled: true, AutoPopulateFrom: 'jobName' },
                  { FieldName: 'ReceivedDate', Label: 'Received Date', DataType: 'String', Disabled: true, AutoPopulateFrom: 'jobStartTime', Format: 'YYYYMMDD' },
                ],
                lineItems: {
                  Name: 'Policy Lines',
                  EmptyText: 'No policy lines added yet',
                  MinRows: 0,
                  Position: 3,
                  Columns: [
                    { FieldName: 'Policy', Label: 'Policy #', DataType: 'String' },
                    { FieldName: 'TransCode', Label: 'Trans Code', DataType: 'String' },
                    { FieldName: 'LOB', Label: 'LOB', DataType: 'String' },
                    { FieldName: 'Status', Label: 'Status', DataType: 'String' },
                  ],
                },
              },
            ],
          },
        ],
      },
      {
        name: 'PLADS',
        displayName: 'PLADS',
        classificationMode: 'keyword',
        documentTypes: [{ name: 'Correspondence', pageTypes: [{ pageType: 'MainPage', fields: [], lineItems: null, keywords: [] }] }],
      },
    ];
    res.json({ applications });
  } catch (e) {
    console.error('GET /api/applications error:', e);
    jsonError(res, 500, 'InternalError', e.message);
  }
});

app.get('/api/applications/:application/jobs', async (req, res) => {
  try {
    const { application } = req.params;
    const items = await queryByApp(application, 200);
    const metas = items.filter(i => i.SK === 'META');
    const byJob = {};
    for (const m of metas) {
      const jn = m.jobName || 'Unknown';
      if (!byJob[jn]) byJob[jn] = { jobName: jn, counts: { total: 0 } };
      byJob[jn].counts.total++;
      byJob[jn].counts[m.status] = (byJob[jn].counts[m.status] || 0) + 1;
    }
    res.json({ application, jobs: Object.values(byJob) });
  } catch (e) {
    console.error('GET /api/applications/:app/jobs error:', e);
    jsonError(res, 500, 'InternalError', e.message);
  }
});

// ─── Batches (list) ──────────────────────────────────────────────────────────
app.get('/api/batches', async (req, res) => {
  try {
    const { application, status, search, page = '1', pageSize = '50' } = req.query;
    if (!application) return jsonError(res, 400, 'BadRequest', 'application is required');

    let items;
    if (status && status !== 'all') {
      // Query GSI1 for each status (comma-separated)
      const statuses = status.split(',').map(s => s.trim()).filter(Boolean);
      const arrays = await Promise.all(statuses.map(s => queryByStatus(s)));
      items = arrays.flat();
      items = items.filter(i => i.SK === 'META' && i.application === application);
    } else {
      items = await queryByApp(application);
      items = items.filter(i => i.SK === 'META');
    }

    // Simple search filter
    if (search) {
      const q = search.toLowerCase();
      items = items.filter(m =>
        (m.batchNumber || '').toLowerCase().includes(q) ||
        (m.jobName || '').toLowerCase().includes(q) ||
        (m.status || '').toLowerCase().includes(q)
      );
    }

    // Sort by updatedAt desc
    items.sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''));

    const pg = Math.max(1, parseInt(page, 10));
    const ps = Math.max(1, Math.min(200, parseInt(pageSize, 10)));
    const totalCount = items.length;
    const totalPages = Math.ceil(totalCount / ps);
    const sliced = items.slice((pg - 1) * ps, pg * ps);

    res.json({
      page: pg,
      pageSize: ps,
      totalCount,
      totalPages,
      batches: sliced.map(shapeBatch),
    });
  } catch (e) {
    console.error('GET /api/batches error:', e);
    jsonError(res, 500, 'InternalError', e.message);
  }
});

// ─── Batch detail ────────────────────────────────────────────────────────────
app.get('/api/batches/:queueId', async (req, res) => {
  try {
    const queueId = safeNumber(req.params.queueId, null);
    if (queueId == null) return jsonError(res, 400, 'BadRequest', 'queueId must be an integer');

    const allItems = await queryBatchAll(queueId);
    const meta = allItems.find(i => i.SK === 'META');
    if (!meta) return jsonError(res, 404, 'BatchNotFound', `No batch with queueId=${queueId}`);

    const docs  = allItems.filter(i => i.SK?.startsWith('DOC#'));
    const pages = allItems.filter(i => i.SK?.startsWith('PAGE#'));
    const tasks = allItems.filter(i => i.SK?.startsWith('TASK#'));
    const textractJobs = allItems.filter(i => i.Type === 'TEXTRACTJOB');

    const shapedPages = await Promise.all(
      pages.sort((a, b) => Number(a.pageNumber || 0) - Number(b.pageNumber || 0))
           .map(p => shapePage(p, queueId))
    );

    res.json({
      batch: shapeBatch(meta),
      documents: docs.map(shapeDocument),
      pages: shapedPages,
      taskHistory: tasks
        .sort((a, b) => (a.SK || '').localeCompare(b.SK || ''))
        .map(shapeTaskHistoryItem),
      textractJobs: textractJobs.map(shapeTextractJob),
    });
  } catch (e) {
    console.error('GET /api/batches/:queueId error:', e);
    jsonError(res, 500, 'InternalError', e.message);
  }
});

// ─── Page image (presigned URL redirect) ────────────────────────────────────
app.get('/api/batches/:queueId/pages/:pageId/image', async (req, res) => {
  try {
    const queueId = safeNumber(req.params.queueId, null);
    const { pageId } = req.params;
    const allItems = await queryBatchAll(queueId);
    const page = allItems.find(i => i.SK === `PAGE#${pageId}` || i.pageId === pageId);
    if (!page?.s3Key) return jsonError(res, 404, 'PageNotFound', 'Page or s3Key not found');
    const cmd = new GetObjectCommand({ Bucket: DOCS_BUCKET, Key: page.s3Key });
    const url = await getSignedUrl(s3, cmd, { expiresIn: 3600 });
    res.redirect(url);
  } catch (e) {
    console.error('GET /api/batches/:queueId/pages/:pageId/image error:', e);
    jsonError(res, 500, 'InternalError', e.message);
  }
});

// ─── Submit review (resumes Step Function) ────────────────────────────────────
app.post('/api/batches/:queueId/submit-review', async (req, res) => {
  try {
    const queueId = safeNumber(req.params.queueId, null);
    if (queueId == null) return jsonError(res, 400, 'BadRequest', 'queueId must be an integer');
    const body = req.body || {};
    const reviewer = body.reviewer || getOperator(req) || 'anonymous';
    const corrections = Array.isArray(body.corrections) ? body.corrections : [];
    const incomingLineItems = Array.isArray(body.lineItems) ? body.lineItems : [];

    const lineItemsToStore = incomingLineItems
      .filter(row => row && typeof row === 'object')
      .map(row => Object.fromEntries(Object.entries(row).map(([k, v]) => [k, v == null ? '' : String(v)])));

    const meta = await getBatchMeta(queueId);
    if (!meta) return jsonError(res, 404, 'BatchNotFound', `No batch with queueId=${queueId}`);
    if (!meta.manualReviewTaskToken) return jsonError(res, 409, 'NoPendingReview', 'No pending ManualReview task token');

    const allItems = await queryBatchAll(queueId);
    const documents = allItems.filter(i => i.SK?.startsWith('DOC#'));
    if (!documents.length) return jsonError(res, 500, 'NoDocument', 'No document found in batch');
    const doc = documents[0];

    // Apply corrections
    const correctionMap = {};
    for (const c of corrections) {
      if (c?.fieldName) correctionMap[c.fieldName] = c;
    }
    const currentFields = doc.extractedFields || [];
    const newFields = currentFields.map(fld => {
      const c = correctionMap[fld.fieldName];
      if (!c) return fld;
      return { ...fld, value: c.value, validationPassed: true, confidence: 100,
               correctedBy: reviewer, correctedAt: nowIso() };
    });

    // Server-side required field guard
    const missingRequired = newFields
      .filter(f => f.required === true)
      .filter(f => f.value == null || String(f.value).trim() === '')
      .map(f => f.fieldName);
    if (missingRequired.length > 0) {
      return jsonError(res, 400, 'RequiredFieldsMissing', `Required fields are empty: ${missingRequired.join(', ')}`);
    }

    // Persist corrections + line items
    await ddb.send(new UpdateCommand({
      TableName: TABLE,
      Key: { PK: `BATCH#${queueId}`, SK: doc.SK },
      UpdateExpression: 'SET extractedFields = :ef, lineItems = :li, validationStatus = :vs, updatedAt = :now',
      ExpressionAttributeValues: { ':ef': newFields, ':li': lineItemsToStore, ':vs': 'Reviewed', ':now': nowIso() },
    }));

    // Task history
    const reviewTime = nowIso();
    await ddb.send(new UpdateCommand({
      TableName: TABLE,
      Key: { PK: `BATCH#${queueId}`, SK: `TASK#${reviewTime}#ManualReview` },
      UpdateExpression: 'SET #t = :t, taskName = :tn, #s = :s, startTime = :st, endTime = :et, #op = :op, queueId = :qid',
      ExpressionAttributeNames: { '#t': 'Type', '#s': 'status', '#op': 'operator' },
      ExpressionAttributeValues: {
        ':t': 'TASKHIST', ':tn': 'ManualReview', ':s': 'Completed',
        ':st': meta.manualReviewStartedAt || reviewTime, ':et': reviewTime,
        ':op': reviewer, ':qid': queueId,
      },
    }));

    // Clear task token
    await ddb.send(new UpdateCommand({
      TableName: TABLE,
      Key: { PK: `BATCH#${queueId}`, SK: 'META' },
      UpdateExpression: 'REMOVE manualReviewTaskToken SET manualReviewCompletedAt = :now, operator = :op, updatedAt = :now',
      ExpressionAttributeValues: { ':now': reviewTime, ':op': reviewer },
    }));

    // Resume Step Function
    await sfn.send(new SendTaskSuccessCommand({
      taskToken: meta.manualReviewTaskToken,
      output: JSON.stringify({ queueId, application: meta.application, status: 'Reviewed', reviewer }),
    }));

    console.log(`✓ submit-review queueId=${queueId} by ${reviewer} (${corrections.length} corrections, ${lineItemsToStore.length} line items)`);
    res.json({ queueId, status: 'Reviewed', reviewer, correctionCount: corrections.length, lineItemCount: lineItemsToStore.length, message: 'Review submitted; Step Function resumed.' });
  } catch (e) {
    console.error('POST /api/batches/:queueId/submit-review error:', e);
    jsonError(res, 500, 'InternalError', e.message);
  }
});

// ─── Save draft (Step Function stays paused) ─────────────────────────────────
app.post('/api/batches/:queueId/save-draft', async (req, res) => {
  try {
    const queueId = safeNumber(req.params.queueId, null);
    if (queueId == null) return jsonError(res, 400, 'BadRequest', 'queueId must be an integer');
    const body = req.body || {};
    const reviewer = body.reviewer || getOperator(req) || 'anonymous';
    const corrections = Array.isArray(body.corrections) ? body.corrections : [];
    const incomingLineItems = Array.isArray(body.lineItems) ? body.lineItems : [];
    const lineItemsToStore = incomingLineItems
      .filter(row => row && typeof row === 'object')
      .map(row => Object.fromEntries(Object.entries(row).map(([k, v]) => [k, v == null ? '' : String(v)])));

    const meta = await getBatchMeta(queueId);
    if (!meta) return jsonError(res, 404, 'BatchNotFound', `No batch with queueId=${queueId}`);
    if (meta.currentTask !== 'ManualReview') {
      return jsonError(res, 409, 'BatchNotInReview', `Batch is in currentTask=${meta.currentTask}, not ManualReview`);
    }

    const allItems = await queryBatchAll(queueId);
    const documents = allItems.filter(i => i.SK?.startsWith('DOC#'));
    if (!documents.length) return jsonError(res, 500, 'NoDocument', 'No document found in batch');
    const doc = documents[0];

    const correctionMap = {};
    for (const c of corrections) {
      if (c?.fieldName) correctionMap[c.fieldName] = c;
    }
    const newFields = (doc.extractedFields || []).map(fld => {
      const c = correctionMap[fld.fieldName];
      if (!c) return fld;
      return { ...fld, value: c.value, correctedBy: reviewer, correctedAt: nowIso() };
    });

    await ddb.send(new UpdateCommand({
      TableName: TABLE,
      Key: { PK: `BATCH#${queueId}`, SK: doc.SK },
      UpdateExpression: 'SET extractedFields = :ef, lineItems = :li, validationStatus = :vs, updatedAt = :now',
      ExpressionAttributeValues: { ':ef': newFields, ':li': lineItemsToStore, ':vs': 'Draft', ':now': nowIso() },
    }));

    const ts = nowIso();
    await ddb.send(new UpdateCommand({
      TableName: TABLE,
      Key: { PK: `BATCH#${queueId}`, SK: `TASK#${ts}#ManualReview` },
      UpdateExpression: 'SET #t = :t, taskName = :tn, #s = :s, startTime = :st, endTime = :et, #op = :op, queueId = :qid',
      ExpressionAttributeNames: { '#t': 'Type', '#s': 'status', '#op': 'operator' },
      ExpressionAttributeValues: {
        ':t': 'TASKHIST', ':tn': 'ManualReview', ':s': 'Saved',
        ':st': ts, ':et': ts, ':op': reviewer, ':qid': queueId,
      },
    }));

    await ddb.send(new UpdateCommand({
      TableName: TABLE,
      Key: { PK: `BATCH#${queueId}`, SK: 'META' },
      UpdateExpression: 'SET updatedAt = :now',
      ExpressionAttributeValues: { ':now': ts },
    }));

    console.log(`✓ save-draft queueId=${queueId} by ${reviewer}`);
    res.json({ queueId, status: 'Saved', reviewer, correctionCount: corrections.length, lineItemCount: lineItemsToStore.length, message: 'Draft saved; batch remains in ManualReview' });
  } catch (e) {
    console.error('POST /api/batches/:queueId/save-draft error:', e);
    jsonError(res, 500, 'InternalError', e.message);
  }
});

// ─── Hold (manual, not tied to Step Function) ────────────────────────────────
app.post('/api/batches/:queueId/hold', async (req, res) => {
  try {
    const queueId = safeNumber(req.params.queueId, null);
    if (queueId == null) return jsonError(res, 400, 'BadRequest', 'queueId must be an integer');
    const body = req.body || {};
    const operator = body.operator || getOperator(req);
    const reason = body.reason || '';

    const meta = await getBatchMeta(queueId);
    if (!meta) return jsonError(res, 404, 'BatchNotFound', `No batch with queueId=${queueId}`);
    if (meta.status === 'hold' || meta.status === 'OnHold') {
      return jsonError(res, 409, 'AlreadyOnHold', 'Batch is already on hold');
    }
    if (meta.currentTask === 'ManualReview') {
      return jsonError(res, 409, 'BatchInReview', 'Batch is in ManualReview; use submit-review to resolve');
    }

    const previousStatus = meta.status;
    const updateTime = nowIso();
    await ddb.send(new UpdateCommand({
      TableName: TABLE,
      Key: { PK: `BATCH#${queueId}`, SK: 'META' },
      UpdateExpression: 'SET #s = :s, GSI1PK = :gsi1, holdSource = :hs, holdReason = :hr, previousStatus = :ps, heldBy = :op, heldAt = :now, updatedAt = :now',
      ExpressionAttributeNames: { '#s': 'status' },
      ExpressionAttributeValues: {
        ':s': 'hold', ':gsi1': 'STATUS#hold', ':hs': 'manual', ':hr': reason,
        ':ps': previousStatus, ':op': operator, ':now': updateTime,
      },
    }));
    res.json({ queueId, status: 'hold', heldBy: operator, reason });
  } catch (e) {
    console.error('POST /api/batches/:queueId/hold error:', e);
    jsonError(res, 500, 'InternalError', e.message);
  }
});

// ─── Release (manual hold) ───────────────────────────────────────────────────
app.post('/api/batches/:queueId/release', async (req, res) => {
  try {
    const queueId = safeNumber(req.params.queueId, null);
    if (queueId == null) return jsonError(res, 400, 'BadRequest', 'queueId must be an integer');
    const body = req.body || {};
    const operator = body.operator || getOperator(req);

    const meta = await getBatchMeta(queueId);
    if (!meta) return jsonError(res, 404, 'BatchNotFound', `No batch with queueId=${queueId}`);
    if (meta.status !== 'hold' && meta.status !== 'OnHold') {
      return jsonError(res, 409, 'NotOnHold', `Batch is in status=${meta.status}, not hold`);
    }
    if (meta.holdSource !== 'manual') {
      return jsonError(res, 409, 'NotManualHold', 'Batch is not in manual hold; cannot release (use submit-review)');
    }

    const restoreStatus = meta.previousStatus || 'pending';
    await ddb.send(new UpdateCommand({
      TableName: TABLE,
      Key: { PK: `BATCH#${queueId}`, SK: 'META' },
      UpdateExpression: 'SET #s = :s, GSI1PK = :gsi1, releasedBy = :op, releasedAt = :now, updatedAt = :now REMOVE holdSource, holdReason, previousStatus, heldBy, heldAt',
      ExpressionAttributeNames: { '#s': 'status' },
      ExpressionAttributeValues: {
        ':s': restoreStatus, ':gsi1': `STATUS#${restoreStatus}`, ':op': operator, ':now': nowIso(),
      },
    }));
    res.json({ queueId, status: restoreStatus, releasedBy: operator });
  } catch (e) {
    console.error('POST /api/batches/:queueId/release error:', e);
    jsonError(res, 500, 'InternalError', e.message);
  }
});

// ─── Tree state (Stage 8) ─────────────────────────────────────────────────────
app.post('/api/batches/:queueId/tree-state', async (req, res) => {
  try {
    const queueId = safeNumber(req.params.queueId, null);
    if (queueId == null) return jsonError(res, 400, 'BadRequest', 'queueId must be an integer');
    const { documents, pages } = req.body || {};
    if (!Array.isArray(documents) || !Array.isArray(pages)) {
      return jsonError(res, 400, 'BadRequest', 'documents and pages must be arrays');
    }
    const summary = await persistTreeState(queueId, documents, pages);
    res.json({ queueId, ...summary });
  } catch (e) {
    console.error('POST /api/batches/:queueId/tree-state error:', e);
    jsonError(res, 500, 'InternalError', e.message);
  }
});

// ─── Dashboard ────────────────────────────────────────────────────────────────
app.get('/api/dashboard', async (req, res) => {
  try {
    const { application = 'all', from, to } = req.query;
    let metas = [];
    if (application === 'all') {
      for (const s of ['pending', 'Running', 'hold', 'JobDone', 'Failed']) {
        const items = await queryByStatus(s, 1000);
        metas.push(...items.filter(i => i.SK === 'META'));
      }
    } else {
      const items = await queryByApp(application, 2000);
      metas = items.filter(i => i.SK === 'META');
    }

    // Optional date filter
    if (from || to) {
      metas = metas.filter(m => {
        const d = m.createdAt || m.updatedAt || '';
        if (from && d < from) return false;
        if (to && d > to + 'Z') return false;
        return true;
      });
    }

    const total = metas.length;
    const pendingReview = metas.filter(m => m.currentTask === 'ManualReview').length;
    const stpBatches = metas.filter(m => m.status === 'JobDone' && m.currentTask !== 'ManualReview').length;
    const abortedBatches = metas.filter(m => m.status === 'Failed').length;

    const byStatus = {};
    const byType = {};
    for (const m of metas) {
      byStatus[m.status] = (byStatus[m.status] || 0) + 1;
      const t = m.documentType || 'Unknown';
      byType[t] = (byType[t] || 0) + 1;
    }

    res.json({
      filter: { application, from: from || null, to: to || null },
      totalIngested: total,
      pendingReview,
      stpBatches,
      abortedBatches,
      stpPercentage: total > 0 ? parseFloat(((stpBatches / total) * 100).toFixed(1)) : 0,
      byDocumentType: Object.entries(byType).map(([type, count]) => ({ type, count })),
      byStatus: Object.entries(byStatus).map(([status, count]) => ({ status, count })),
      recentTimeline: [],
    });
  } catch (e) {
    console.error('GET /api/dashboard error:', e);
    jsonError(res, 500, 'InternalError', e.message);
  }
});

// ─── Export handler ───────────────────────────────────────────────────────────
module.exports.handler = serverless(app);
