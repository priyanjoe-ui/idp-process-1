\
Export Lambda (aflaccore-export).\r
 \r
Phase 2A: ends the pipeline. Sets META.status = JobDone, writes\r
TASKHIST. Real delivery to the end system happens in Phase 3.\r
 \r
Invoked by Step Functions with input including queueId.\r
\
 \r
import json\r
import logging\r
from decimal import Decimal\r
from typing import Any, Dict\r
 \r
from shared import ddb\r
 \r
logger = logging.getLogger()\r
logger.setLevel(logging.INFO)\r
 \r
 \r
class _DecimalEncoder(json.JSONEncoder):\r
    def default(self, o):\r
        if isinstance(o, Decimal):\r
            if o == o.to_integral_value():\r
                return int(o)\r
            return float(o)\r
        return super().default(o)\r
 \r
 \r
def _j(obj: Any) -> str:\r
    return json.dumps(obj, cls=_DecimalEncoder)\r
 \r
 \r
def lambda_handler(event: Dict[str, Any], _context: Any) -> Dict[str, Any]:\r
    logger.info(\
 \r
    queue_id = int(event[\
    application = event[\
 \r
    start_time = ddb.now_iso()\r
    ddb.update_batch_status(queue_id, status=\
 \r
    try:\r
        # Phase 3 will:\r
        #   - look up document + xmlMetadata\r
        #   - generate output file(s) and put them somewhere (S3 / SFTP / API)\r
        #   - record the export reference on the document\r
        # Phase 2A just marks the batch done.\r
 \r
        ddb.update_batch_status(queue_id, status=\
 \r
        ddb.append_task_history(\r
            queue_id=queue_id,\r
            task_name=\
            status=\
            start_time=start_time,\r
            end_time=ddb.now_iso(),\r
            operator=\
            details={\
        )\r
 \r
        result = {\r
            \
            \
            \
        }\r
        logger.info(\
        return result\r
 \r
    except Exception:\r
        logger.exception(\
        ddb.append_task_history(\r
            queue_id=queue_id,\r
            task_name=\
            status=\
            start_time=start_time,\r
            end_time=ddb.now_iso(),\r
            operator=\
        )\r
        raise