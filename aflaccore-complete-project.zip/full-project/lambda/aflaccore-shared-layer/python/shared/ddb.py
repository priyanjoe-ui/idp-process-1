"""
DynamoDB helpers for the AflacCore single-table schema.
Phase 2A-revised: TEXTRACTJOB rows, GSI3 lookup, atomic counter.
Phase 2C-revised: lastTaskUpdatedAt freeze point for Job Time.
Stage 9: holdSource / GSI1PK updates for hold taxonomy.
"""
import os
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any, Dict, List, Optional

import boto3
from boto3.dynamodb.conditions import Key

_ddb = boto3.resource("dynamodb")


def _table():
    return _ddb.Table(os.environ["AFLACCORE_TABLE"])


def _counter_table():
    return _ddb.Table(os.environ["AFLACCORE_COUNTER_TABLE"])


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def to_ddb(value: Any) -> Any:
    """Recursively convert floats to Decimal for DynamoDB."""
    if isinstance(value, float):
        return Decimal(str(value))
    if isinstance(value, list):
        return [to_ddb(v) for v in value]
    if isinstance(value, dict):
        return {k: to_ddb(v) for k, v in value.items()}
    return value


_to_ddb = to_ddb


# ── Counters ─────────────────────────────────────────────────────────────────

def next_queue_id() -> int:
    """Globally unique, monotonically increasing queueId."""
    resp = _counter_table().update_item(
        Key={"CounterKey": "QUEUE_GLOBAL"},
        UpdateExpression="SET #v = if_not_exists(#v, :zero) + :one",
        ExpressionAttributeNames={"#v": "value"},
        ExpressionAttributeValues={":zero": Decimal(0), ":one": Decimal(1)},
        ReturnValues="UPDATED_NEW",
    )
    return int(resp["Attributes"]["value"])


def next_batch_number(application: str, date_str: str) -> str:
    """Per-app per-day sequence number → e.g. '20260520.000005'"""
    counter_key = f"{application}#{date_str}"
    resp = _counter_table().update_item(
        Key={"CounterKey": counter_key},
        UpdateExpression="SET #v = if_not_exists(#v, :zero) + :one",
        ExpressionAttributeNames={"#v": "value"},
        ExpressionAttributeValues={":zero": Decimal(0), ":one": Decimal(1)},
        ReturnValues="UPDATED_NEW",
    )
    seq = int(resp["Attributes"]["value"])
    return f"{date_str}.{seq:06d}"


# ── Task History ──────────────────────────────────────────────────────────────

def append_task_history(
    queue_id: int,
    task_name: str,
    status: str,
    start_time: str,
    end_time: str,
    operator: str = "system",
    details: Optional[Dict[str, Any]] = None,
) -> None:
    """Write a TASKHIST row for audit trail."""
    _table().put_item(Item=to_ddb({
        "PK":        f"BATCH#{queue_id}",
        "SK":        f"TASK#{end_time}#{task_name}",
        "Type":      "TASKHIST",
        "taskName":  task_name,
        "status":    status,
        "startTime": start_time,
        "endTime":   end_time,
        "operator":  operator,
        "queueId":   Decimal(queue_id),
        "details":   details or {},
    }))


# ── Batch Status ──────────────────────────────────────────────────────────────

def update_batch_status(
    queue_id: int,
    status: str,
    current_task: Optional[str] = None,
    hold_source: Optional[str] = None,
    manual_review_task_token: Optional[str] = None,
    manual_review_started_at: Optional[str] = None,
    **_kwargs: Any,
) -> None:
    """
    Update the META row status and related fields.
    Always keeps GSI1PK in sync with status.
    """
    now = now_iso()
    expr_parts = [
        "#s = :s",
        "GSI1PK = :gsi1",
        "updatedAt = :now",
        "lastTaskUpdatedAt = :now",
    ]
    names  = {"#s": "status"}
    values: Dict[str, Any] = {
        ":s":    status,
        ":gsi1": f"STATUS#{status}",
        ":now":  now,
    }

    if current_task is not None:
        expr_parts.append("currentTask = :ct")
        values[":ct"] = current_task

    if hold_source is not None:
        expr_parts.append("holdSource = :hs")
        values[":hs"] = hold_source

    if manual_review_task_token is not None:
        expr_parts.append("manualReviewTaskToken = :tt")
        values[":tt"] = manual_review_task_token

    if manual_review_started_at is not None:
        expr_parts.append("manualReviewStartedAt = :mrs")
        values[":mrs"] = manual_review_started_at

    _table().update_item(
        Key={"PK": f"BATCH#{queue_id}", "SK": "META"},
        UpdateExpression="SET " + ", ".join(expr_parts),
        ExpressionAttributeNames=names,
        ExpressionAttributeValues=to_ddb(values),
    )


def set_manual_review_pending(queue_id: int, task_token: str) -> None:
    """Stash the Step Function task token so the API can resume later."""
    _table().update_item(
        Key={"PK": f"BATCH#{queue_id}", "SK": "META"},
        UpdateExpression=(
            "SET manualReviewTaskToken = :tt, "
            "manualReviewStartedAt = :now, "
            "lastTaskUpdatedAt = :now, "
            "updatedAt = :now"
        ),
        ExpressionAttributeValues={":tt": task_token, ":now": now_iso()},
    )


# ── Reads ─────────────────────────────────────────────────────────────────────

def get_batch(queue_id: int) -> Optional[Dict[str, Any]]:
    """Get the META row for a batch."""
    resp = _table().get_item(Key={"PK": f"BATCH#{queue_id}", "SK": "META"})
    return resp.get("Item")


def list_pages(queue_id: int) -> List[Dict[str, Any]]:
    """Get all PAGE rows sorted by pageNumber."""
    resp = _table().query(
        KeyConditionExpression=Key("PK").eq(f"BATCH#{queue_id}") & Key("SK").begins_with("PAGE#")
    )
    items = resp.get("Items", [])
    return sorted(items, key=lambda p: int(p.get("pageNumber", 0)))


def list_documents(queue_id: int) -> List[Dict[str, Any]]:
    """Get all DOC rows for a batch."""
    resp = _table().query(
        KeyConditionExpression=Key("PK").eq(f"BATCH#{queue_id}") & Key("SK").begins_with("DOC#")
    )
    return resp.get("Items", [])


def get_first_document(queue_id: int) -> Optional[Dict[str, Any]]:
    """Get the first DOC row for a batch."""
    docs = list_documents(queue_id)
    return docs[0] if docs else None


def get_textract_job_by_id(textract_job_id: str) -> Optional[Dict[str, Any]]:
    """Look up a batch by Textract job ID using GSI3."""
    resp = _table().query(
        IndexName="GSI3-TextractJobId",
        KeyConditionExpression=Key("textractJobId").eq(textract_job_id),
    )
    items = resp.get("Items", [])
    return items[0] if items else None
