"""
Classification Lambda (aflaccore-classification).

Invoked by Step Functions with: { "queueId": N, "application": "AFLCOR" }

Phase 2A POC: uses simple keyword/heuristic classification based on
XML metadata and the application name. Phase 2 will add barcode detection,
Textract Queries, and Bedrock fallback.
"""
import json
import logging
from decimal import Decimal
from typing import Any, Dict

from shared import ddb

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Per-application default document type when no other signal is found
_APP_DEFAULT_DOC_TYPE: Dict[str, str] = {
    "AFLCOR": "Correspondence",
    "PLADS":  "Correspondence",
    "EFR":    "EFR_Document",
    "NAS":    "NAS_Document",
    "GB":     "GB_Document",
    "FCC":    "FCC_Correspondence",
    "INC":    "INC_Correspondence",
    "Claims": "Claims_Document",
    "NBUS":   "NBUS_Document",
}

# Keywords in XML metadata that indicate specific document types
_KEYWORD_MAP = [
    (["replacement", "regulation 60", "replaced", "replacing"], "ReplacementNotification"),
    (["life status", "LSS"], "LifeStatusSheet"),
    (["correction", "worksheet"], "CorrectionWorksheet"),
    (["ua#", "ua number"], "UADocument"),
    (["invoice"], "Invoice"),
]


def _classify(application: str, xml_meta: Dict[str, str]) -> tuple[str, int]:
    """
    Returns (documentType, confidence_pct).
    Confidence 95 = keyword match, 60 = default fallback.
    """
    combined = " ".join(xml_meta.values()).lower()
    for keywords, doc_type in _KEYWORD_MAP:
        if any(kw.lower() in combined for kw in keywords):
            logger.info("Keyword match: %s → %s", keywords, doc_type)
            return doc_type, 95

    default_type = _APP_DEFAULT_DOC_TYPE.get(application, "Correspondence")
    return default_type, 60


def lambda_handler(event: Dict[str, Any], _context: Any) -> Dict[str, Any]:
    logger.info("Classification event: %s", json.dumps(event))
    queue_id    = int(event["queueId"])
    application = event["application"]

    ddb.update_batch_status(queue_id, status="Running", current_task="Classification")
    start_time = ddb.now_iso()

    try:
        meta = ddb.get_batch(queue_id)
        if not meta:
            raise RuntimeError(f"No batch META for queueId={queue_id}")

        xml_meta = meta.get("xmlMetadata") or {}
        doc_type, confidence = _classify(application, xml_meta)

        # Update the DOC row with the classified type
        document = ddb.get_first_document(queue_id)
        if document:
            ddb._table().update_item(
                Key={"PK": f"BATCH#{queue_id}", "SK": document["SK"]},
                UpdateExpression="SET documentType = :dt, updatedAt = :now",
                ExpressionAttributeValues={
                    ":dt":  doc_type,
                    ":now": ddb.now_iso(),
                },
            )

        ddb.append_task_history(
            queue_id=queue_id,
            task_name="Classification",
            status="Completed",
            start_time=start_time,
            end_time=ddb.now_iso(),
            operator="system",
            details={"documentType": doc_type, "confidence": confidence},
        )

        return {
            **event,
            "documentType":            doc_type,
            "classificationConfidence": confidence,
        }

    except Exception:
        logger.exception("Classification failed")
        ddb.append_task_history(
            queue_id=queue_id, task_name="Classification", status="Failed",
            start_time=start_time, end_time=ddb.now_iso(), operator="system",
        )
        raise
