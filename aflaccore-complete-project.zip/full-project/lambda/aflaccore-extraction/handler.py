"""
Extraction Lambda (aflaccore-extraction).

Invoked by Step Functions. Starts an async Textract AnalyzeDocument job
for each page's TIFF. Uses SNS notification to trigger the callback Lambda
when Textract completes.

The Step Function uses .waitForTaskToken on this step — the task token is
stored on the TEXTRACTJOB row. The extraction-callback Lambda calls
SendTaskSuccess with the token once Textract is done.

Environment variables:
  DOCS_BUCKET           S3 bucket containing source TIFFs
  TEXTRACT_SNS_TOPIC    SNS topic ARN for Textract completion notifications
  TEXTRACT_ROLE_ARN     IAM role ARN that Textract assumes to publish to SNS
"""
import json
import logging
import os
import uuid
from decimal import Decimal
from typing import Any, Dict

import boto3

from shared import ddb

logger = logging.getLogger()
logger.setLevel(logging.INFO)

DOCS_BUCKET       = os.environ.get("DOCS_BUCKET",       "aflac-ecm-datacap-dev")
TEXTRACT_SNS_TOPIC = os.environ.get("TEXTRACT_SNS_TOPIC", "")
TEXTRACT_ROLE_ARN  = os.environ.get("TEXTRACT_ROLE_ARN",  "")

textract = boto3.client("textract")


def lambda_handler(event: Dict[str, Any], _context: Any) -> Dict[str, Any]:
    logger.info("Extraction event: %s", json.dumps(event))
    queue_id    = int(event["queueId"])
    application = event["application"]
    task_token  = event.get("taskToken", "")

    ddb.update_batch_status(queue_id, status="Running", current_task="Extraction")
    start_time = ddb.now_iso()

    try:
        pages = ddb.list_pages(queue_id)
        if not pages:
            raise RuntimeError(f"No pages found for queueId={queue_id}")

        # For POC: process first page only. Phase 2 processes all pages.
        page = pages[0]
        s3_key = page.get("s3Key", "")
        if not s3_key:
            raise RuntimeError("First page has no s3Key")

        # Start Textract async job
        kwargs: Dict[str, Any] = {
            "DocumentLocation": {
                "S3Object": {"Bucket": DOCS_BUCKET, "Name": s3_key}
            },
            "FeatureTypes": ["FORMS", "TABLES"],
        }

        if TEXTRACT_SNS_TOPIC and TEXTRACT_ROLE_ARN:
            kwargs["NotificationChannel"] = {
                "SNSTopicArn": TEXTRACT_SNS_TOPIC,
                "RoleArn":     TEXTRACT_ROLE_ARN,
            }
            # Store clientRequestToken for idempotency
            kwargs["ClientRequestToken"] = f"idp-{queue_id}-{page['pageId'][:8]}"

        resp = textract.start_document_analysis(**kwargs)
        job_id = resp["JobId"]

        logger.info("Started Textract job %s for page %s", job_id, page["pageId"])

        # Store the Textract job row (GSI3 lookup by job_id)
        now = ddb.now_iso()
        ddb._table().put_item(Item=ddb.to_ddb({
            "PK":            f"BATCH#{queue_id}",
            "SK":            f"TEXTRACTJOB#{job_id}",
            "Type":          "TEXTRACTJOB",
            "textractJobId": job_id,
            "pageId":        page["pageId"],
            "status":        "IN_PROGRESS",
            "taskToken":     task_token,
            "queueId":       Decimal(queue_id),
            "application":   application,
            "createdAt":     now,
            "updatedAt":     now,
        }))

        ddb.append_task_history(
            queue_id=queue_id,
            task_name="Extraction",
            status="Started",
            start_time=start_time,
            end_time=now,
            operator="system",
            details={"textractJobId": job_id, "pageId": page["pageId"]},
        )

        return {**event, "textractJobId": job_id}

    except Exception:
        logger.exception("Extraction failed")
        ddb.append_task_history(
            queue_id=queue_id, task_name="Extraction", status="Failed",
            start_time=start_time, end_time=ddb.now_iso(), operator="system",
        )
        raise
