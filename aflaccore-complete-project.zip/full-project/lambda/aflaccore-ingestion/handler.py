"""
Ingestion Lambda (aflaccore-ingestion).

Triggered by S3 PutObject on the source bucket.
S3 key format: aflac_core/<APPLICATION>/input/<date>/<batchNumber>.zip

Steps:
  1. Parse S3 key → application, date_str
  2. Read ZIP from S3 → extract TIFFs + metadata XML
  3. Call next_queue_id() + next_batch_number()
  4. Copy each TIFF to Processing/<application>/<queueId>/pages/<idx>.tif
  5. Write DDB records: META + DOC# + PAGE# rows
  6. Start the Step Function
"""
import io
import json
import logging
import os
import re
import uuid
import zipfile
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import unquote_plus

import boto3

from shared import ddb

logger = logging.getLogger()
logger.setLevel(logging.INFO)

S3_CLIENT  = boto3.client("s3")
SFN_CLIENT = boto3.client("stepfunctions")

DOCS_BUCKET        = os.environ.get("DOCS_BUCKET",        "aflac-ecm-datacap-dev")
STATE_MACHINE_ARN  = os.environ.get("STATE_MACHINE_ARN",  "")
PROCESSING_PREFIX  = "aflac_core/applications"


# ── Helpers ───────────────────────────────────────────────────────────────────

def _format_display_id(page_idx: int) -> str:
    return f"pg-{page_idx + 1:04d}"


def _parse_key_path(key: str) -> Tuple[str, str, str]:
    """
    Parse: aflac_core/<APPLICATION>/input/<date_str>/<batch>.zip
    Returns: (application, date_str, batch_name)
    """
    key = unquote_plus(key)
    parts = key.split("/")
    # parts: ['aflac_core', '<APP>', 'input', '<date>', '<batch>.zip']
    if len(parts) >= 5:
        application = parts[1]
        date_str    = parts[3]
        batch_name  = os.path.splitext(parts[4])[0]
    else:
        application = "UNKNOWN"
        date_str    = datetime.now(timezone.utc).strftime("%Y%m%d")
        batch_name  = "BATCH"
    return application, date_str, batch_name


def _read_zip_from_s3(bucket: str, key: str) -> zipfile.ZipFile:
    resp = S3_CLIENT.get_object(Bucket=bucket, Key=key)
    data = resp["Body"].read()
    return zipfile.ZipFile(io.BytesIO(data))


def _classify_entries(zf: zipfile.ZipFile) -> Tuple[List[str], List[str]]:
    """Separate TIFF pages from XML metadata files."""
    tiffs, xmls = [], []
    for name in zf.namelist():
        lower = name.lower()
        if lower.endswith((".tif", ".tiff")):
            tiffs.append(name)
        elif lower.endswith(".xml") and not lower.startswith("__"):
            xmls.append(name)
    tiffs.sort()
    return tiffs, xmls


def _natural_key(s: str) -> List[Any]:
    """Sort key that handles numeric segments naturally."""
    return [int(c) if c.isdigit() else c.lower() for c in re.split(r"(\d+)", s)]


def _parse_xml(xml_bytes: bytes) -> Dict[str, str]:
    """Extract flat key→value metadata from Datacap-style XML."""
    result: Dict[str, str] = {}
    try:
        root = ET.fromstring(xml_bytes.decode("utf-8", errors="replace"))
        for elem in root.iter():
            if elem.text and elem.text.strip():
                tag = elem.tag.split("}")[-1] if "}" in elem.tag else elem.tag
                result[tag] = elem.text.strip()
    except Exception as exc:
        logger.warning("XML parse warning: %s", exc)
    return result


def _start_state_machine(queue_id: int, application: str) -> str:
    resp = SFN_CLIENT.start_execution(
        stateMachineArn=STATE_MACHINE_ARN,
        input=json.dumps({"queueId": queue_id, "application": application}),
    )
    return resp["executionArn"]


# ── Main ──────────────────────────────────────────────────────────────────────

def lambda_handler(event: Dict[str, Any], _context: Any) -> Dict[str, Any]:
    logger.info("Ingestion event: %s", json.dumps(event))
    results = []
    for record in event.get("Records", []):
        try:
            result = _process_record(record)
            results.append(result)
        except Exception:
            logger.exception("Failed to process record: %s", record)
    return {"processed": len(results), "results": results}


def _process_record(record: Dict[str, Any]) -> Dict[str, Any]:
    bucket = record["s3"]["bucket"]["name"]
    key    = record["s3"]["object"]["key"]
    logger.info("Processing s3://%s/%s", bucket, key)

    application, date_str, batch_name = _parse_key_path(key)
    queue_id     = ddb.next_queue_id()
    batch_number = ddb.next_batch_number(application, date_str)
    job_name     = batch_name

    logger.info("queueId=%d batchNumber=%s application=%s", queue_id, batch_number, application)

    zf = _read_zip_from_s3(bucket, key)
    tiff_names, xml_names = _classify_entries(zf)
    tiff_names.sort(key=_natural_key)

    # Parse XML metadata if present
    xml_metadata: Dict[str, str] = {}
    for xname in xml_names[:1]:
        xml_metadata = _parse_xml(zf.read(xname))

    now = ddb.now_iso()
    page_ids: List[str] = []
    page_records: List[Dict[str, Any]] = []

    # Copy TIFFs to S3 Processing folder
    for idx, tiff_name in enumerate(tiff_names):
        page_id     = str(uuid.uuid4())
        display_id  = _format_display_id(idx)
        target_key  = (
            f"{PROCESSING_PREFIX}/{application}/Processing/{queue_id}"
            f"/pages/{idx:04d}.tif"
        )
        tiff_bytes = zf.read(tiff_name)
        S3_CLIENT.put_object(
            Bucket=DOCS_BUCKET,
            Key=target_key,
            Body=tiff_bytes,
            ContentType="image/tiff",
        )
        page_ids.append(page_id)
        page_records.append({
            "PK":        f"BATCH#{queue_id}",
            "SK":        f"PAGE#{page_id}",
            "Type":      "PAGE",
            "pageId":    page_id,
            "displayId": display_id,
            "pageNumber": Decimal(idx + 1),
            "pageType":  "Unclassified",
            "pageStatus": "Ingested",
            "s3Key":     target_key,
            "wordCount": None,
            "ocrWords":  [],
            "createdAt": now,
            "updatedAt": now,
        })
        logger.info("Copied page %d → s3://%s/%s", idx, DOCS_BUCKET, target_key)

    # Document ID
    doc_id = str(uuid.uuid4())

    # Write DDB: META
    _table_put({
        "PK":            f"BATCH#{queue_id}",
        "SK":            "META",
        "Type":          "META",
        "queueId":       Decimal(queue_id),
        "batchNumber":   batch_number,
        "application":   application,
        "jobName":       job_name,
        "status":        "pending",
        "currentTask":   "Ingestion",
        "GSI1PK":        "STATUS#pending",
        "GSI2PK":        f"APP#{application}",
        "source":        "S3",
        "sourceZipKey":  key,
        "xmlMetadata":   xml_metadata,
        "documentCount": Decimal(1),
        "pageCount":     Decimal(len(tiff_names)),
        "lastTaskUpdatedAt": now,
        "createdAt":     now,
        "updatedAt":     now,
    })

    # Write DDB: DOC
    _table_put({
        "PK":              f"BATCH#{queue_id}",
        "SK":              f"DOC#{doc_id}",
        "Type":            "DOC",
        "documentId":      doc_id,
        "documentType":    "Unclassified",
        "validationStatus": "NeedsReview",
        "pageIds":         page_ids,
        "extractedFields": [],
        "lineItems":       [],
        "createdAt":       now,
        "updatedAt":       now,
    })

    # Write DDB: PAGEs (sequential, no transactions per project convention)
    for pr in page_records:
        _table_put(pr)

    # Write TASKHIST
    ddb.append_task_history(
        queue_id=queue_id,
        task_name="Ingestion",
        status="Completed",
        start_time=now,
        end_time=ddb.now_iso(),
        operator="system",
        details={"pageCount": len(tiff_names), "sourceZipKey": key},
    )

    # Start Step Function
    execution_arn = ""
    if STATE_MACHINE_ARN:
        execution_arn = _start_state_machine(queue_id, application)
        logger.info("Started execution: %s", execution_arn)
    else:
        logger.warning("STATE_MACHINE_ARN not set; Step Function not started")

    return {
        "queueId":      queue_id,
        "batchNumber":  batch_number,
        "application":  application,
        "pageCount":    len(tiff_names),
        "executionArn": execution_arn,
    }


def _table_put(item: Dict[str, Any]) -> None:
    ddb._table().put_item(Item=ddb.to_ddb(item))
