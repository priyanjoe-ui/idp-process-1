\
Validation Lambda (aflaccore-validation).\r
 \r
Invoked by Step Functions with input:\r
  { \
 \r
For each field on the (single Phase-1) document:\r
  Pass if:  confidence >= configured ConfidenceScore  AND  value matches ValidationRegex\r
  Else:     fail\r
 \r
If ANY required field fails -> validationStatus = NeedsReview, route to ManualReview.\r
If ALL required fields pass -> validationStatus = Passed, route to Export.\r
 \r
Output:\r
  { ...input,\r
    needsManualReview: bool,\r
    failedFields: [...],\r
    validationStatus: \
\
 \r
import json\r
import logging\r
import re\r
from decimal import Decimal\r
from typing import Any, Dict, List, Optional\r
 \r
from shared import config_loader, ddb\r
 \r
logger = logging.getLogger()\r
logger.setLevel(logging.INFO)\r
 \r
 \r
class _DecimalEncoder(json.JSONEncoder):\r
    def default(self, o):\r
        if isinstance(o, Decimal):\r
            if o == o.to_integral_value():\r
                return int(o)\r
            return float(o)\r
        return super().default(o)\r
 \r
 \r
def _j(obj: Any) -> str:\r
    return json.dumps(obj, cls=_DecimalEncoder)\r
 \r
 \r
def _field_config_map(main_page_cfg: Optional[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:\r
    \
    if not main_page_cfg:\r
        return {}\r
    out = {}\r
    for f in main_page_cfg.get(\
        out[f[\
    return out\r
 \r
 \r
def _validate_field(field_item: Dict[str, Any],\r
                    field_cfg: Optional[Dict[str, Any]]) -> Dict[str, Any]:\r
    \
    Returns the original field_item with an updated validationPassed and\r
    optional validationError reason.\r
    \
    out = dict(field_item)\r
    out[\
    out.pop(\
 \r
    if not field_cfg:\r
        out[\
        return out\r
 \r
    value = field_item.get(\
    confidence = field_item.get(\
 \r
    # Missing value can never pass validation\r
    if value in (None, \
        out[\
        return out\r
 \r
    # Confidence check\r
    threshold = float(field_cfg.get(\
    # Textract returns confidence as a percentage 0-100, our threshold is 0-1\r
    # Normalize: if confidence > 1, treat as percentage and compare against threshold*100\r
    conf_val = float(confidence) if confidence is not None else 0.0\r
    threshold_pct = threshold * 100 if threshold <= 1 else threshold\r
    if conf_val < threshold_pct:\r
        out[\
            f\
        )\r
        return out\r
 \r
    # Regex check\r
    pattern = field_cfg.get(\
    if pattern:\r
        try:\r
            if not re.fullmatch(pattern, str(value)):\r
                out[\
                return out\r
        except re.error:\r
            logger.warning(\
                           field_item.get(\
            out[\