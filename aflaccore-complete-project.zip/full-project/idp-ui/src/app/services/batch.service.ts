import { Injectable, inject } from '@angular/core';
import { Observable, map, of } from 'rxjs';

import { environment } from '../../environments/environment';
import {
  Application,
  ApplicationsResponse,
  BatchDetail,
  BatchListQuery,
  BatchPage_DTO,
  DashboardFilter,
  DashboardStats,
  JobSummary,
  LineItemRowData,
  SubmitReviewRequest,
  SubmitReviewResponse,
} from '../models/document.model';
import { ApiBatchService } from './api-batch.service';
import { AuthService } from './auth.service';
import { MockBatchService } from './mock-batch.service';

/**
 * Facade that switches between the live API and the mock data source
 * based on environment.dataSource. All UI components depend on THIS
 * service, not the underlying api/mock services.
 */
@Injectable({ providedIn: 'root' })
export class BatchService {
  private readonly api = inject(ApiBatchService);
  private readonly mock = inject(MockBatchService);
  private readonly auth = inject(AuthService);

  private get useMock(): boolean {
    return environment.dataSource === 'mock';
  }

  listApplications(): Observable<ApplicationsResponse> {
    return this.useMock ? this.mock.listApplications() : this.api.listApplications();
  }

  listJobs(application: string): Observable<{ application: string; jobs: JobSummary[] }> {
    return this.useMock ? this.mock.listJobs(application) : this.api.listJobs(application);
  }

  listBatches(q: BatchListQuery): Observable<BatchPage_DTO> {
    return this.useMock ? this.mock.listBatches(q) : this.api.listBatches(q);
  }

  getBatch(queueId: number): Observable<BatchDetail> {
    return this.useMock ? this.mock.getBatch(queueId) : this.api.getBatch(queueId);
  }

  pageImageUrl(queueId: number, pageId: string): string {
    return this.api.pageImageUrl(queueId, pageId);
  }

  /**
   * Submit the manual-review screen back to the pipeline.
   *
   * Stage 5: lineItems is now part of the payload. Pass an empty array
   * (or omit) if the grid had no rows. Backend writes both extractedFields
   * (via corrections) and lineItems on the document record in one DDB
   * update, then resumes the Step Function.
   */
  submitReview(
    queueId: number,
    corrections: { fieldName: string; value: string }[],
    lineItems: LineItemRowData[] = [],
  ): Observable<SubmitReviewResponse> {
    const body: SubmitReviewRequest = {
      reviewer: this.auth.operator() || 'anonymous',
      corrections,
      lineItems,
    };
    return this.useMock ? this.mock.submitReview(queueId, body) : this.api.submitReview(queueId, body);
  }

  /**
   * Fetch dashboard metrics from the server-side computed endpoint.
   * Filter on jobStartTime range plus application scope.
   */
  dashboard(filter: DashboardFilter = {}): Observable<DashboardStats> {
    return this.api.dashboard(filter);
  }
}
