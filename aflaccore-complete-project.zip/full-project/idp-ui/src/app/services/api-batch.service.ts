import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
 
import { environment } from '../../environments/environment';
import {
  Application,
  ApplicationsResponse,
  AuthUser,
  BatchDetail,
  BatchListQuery,
  BatchPage_DTO,
  DashboardFilter,
  DashboardStats,
  JobSummary,
  SubmitReviewRequest,
  SubmitReviewResponse,
} from '../models/document.model';
import { AuthService } from './auth.service';
 
@Injectable({ providedIn: 'root' })
export class ApiBatchService {
  private readonly http = inject(HttpClient);
  private readonly auth = inject(AuthService);
 
  private get base(): string {
    return environment.apiBaseUrl;
  }
 
  private opHeaders(): HttpHeaders {
    const op = this.auth.operator() || '';
    return new HttpHeaders({ 'X-Operator': op });
  }
 
  // ----- Health -----
  health(): Observable<{ ok: boolean; ts: string; region: string; table: string }> {
    return this.http.get<any>(`${this.base}/health`);
  }
 
  // ----- Auth -----
  login(username: string): Observable<AuthUser> {
    return this.http.post<AuthUser>(`${this.base}/auth/login`, { username });
  }
 
  me(): Observable<AuthUser> {
    return this.http.get<AuthUser>(`${this.base}/auth/me`, { headers: this.opHeaders() });
  }
 
  // ----- Applications & Jobs -----
  listApplications(): Observable<ApplicationsResponse> {
    return this.http.get<ApplicationsResponse>(`${this.base}/applications`);
  }
 
  listJobs(application: string): Observable<{ application: string; jobs: JobSummary[] }> {
    return this.http.get<{ application: string; jobs: JobSummary[] }>(
      `${this.base}/applications/${encodeURIComponent(application)}/jobs`,
    );
  }
 
  // ----- Batches -----
  listBatches(q: BatchListQuery): Observable<BatchPage_DTO> {
    let params = new HttpParams().set('application', q.application);
    if (q.status)    params = params.set('status', q.status);
    if (q.search)    params = params.set('search', q.search);
    if (q.page)      params = params.set('page', q.page);
    if (q.pageSize)  params = params.set('pageSize', q.pageSize);
    if (q.sortBy)    params = params.set('sortBy', q.sortBy);
    if (q.sortOrder) params = params.set('sortOrder', q.sortOrder);
    return this.http.get<BatchPage_DTO>(`${this.base}/batches`, { params });
  }
 
  getBatch(queueId: number): Observable<BatchDetail> {
    return this.http.get<BatchDetail>(`${this.base}/batches/${queueId}`);
  }
 
  // ----- Page image URL (just builds the URL; UI binds img src) -----
  pageImageUrl(queueId: number, pageId: string): string {
    return `${this.base}/batches/${queueId}/pages/${encodeURIComponent(pageId)}/image`;
  }
 
  // ----- Submit Review -----
  submitReview(queueId: number, body: SubmitReviewRequest): Observable<SubmitReviewResponse> {
    return this.http.post<SubmitReviewResponse>(
      `${this.base}/batches/${queueId}/submit-review`,
      body,
      { headers: this.opHeaders() },
    );
  }
 
  // ----- Hold / Release (operational) -----
  holdBatch(queueId: number, operator: string, reason: string): Observable<any> {
    return this.http.post<any>(
      `${this.base}/batches/${queueId}/hold`,
      { operator, reason },
      { headers: this.opHeaders() },
    );
  }
 
  releaseBatch(queueId: number, operator: string): Observable<any> {
    return this.http.post<any>(
      `${this.base}/batches/${queueId}/release`,
      { operator },
      { headers: this.opHeaders() },
    );
  }
 
  // ----- Dashboard -----
  dashboard(filter: DashboardFilter): Observable<DashboardStats> {
    let params = new HttpParams();
    if (filter.application) params = params.set('application', filter.application);
    if (filter.from)        params = params.set('from', filter.from);
    if (filter.to)          params = params.set('to', filter.to);
    return this.http.get<DashboardStats>(`${this.base}/dashboard`, { params });
  }
}