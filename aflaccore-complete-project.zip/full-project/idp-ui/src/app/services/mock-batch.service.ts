import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import {
  ApplicationsResponse,
  BatchDetail,
  BatchListQuery,
  BatchPage_DTO,
  JobSummary,
  SubmitReviewRequest,
  SubmitReviewResponse,
} from '../models/document.model';

/**
 * Mock data source for local development without a live api-proxy.
 * Activated when environment.dataSource === 'mock'.
 */
@Injectable({ providedIn: 'root' })
export class MockBatchService {
  listApplications(): Observable<ApplicationsResponse> {
    return of({
      applications: [
        { name: 'AFLCOR', displayName: 'AFLCOR / Policy Service', documentTypes: [] },
        { name: 'PLADS', displayName: 'PLADS', documentTypes: [] },
      ],
    });
  }

  listJobs(_application: string): Observable<{ application: string; jobs: JobSummary[] }> {
    return of({ application: _application, jobs: [] });
  }

  listBatches(_q: BatchListQuery): Observable<BatchPage_DTO> {
    return of({ page: 1, pageSize: 50, totalCount: 0, totalPages: 0, batches: [] });
  }

  getBatch(_queueId: number): Observable<BatchDetail> {
    throw new Error('MockBatchService.getBatch: not implemented');
  }

  submitReview(_queueId: number, _body: SubmitReviewRequest): Observable<SubmitReviewResponse> {
    return of({ queueId: _queueId, status: 'Reviewed', reviewer: 'mock', correctionCount: 0, message: 'Mock submit' });
  }
}
