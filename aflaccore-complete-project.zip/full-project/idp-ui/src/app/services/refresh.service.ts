import { Injectable } from '@angular/core';
import { Observable, interval, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class RefreshService {
  private readonly destroy$ = new Subject<void>();
  private readonly INTERVAL_MS = 30_000; // 30 seconds

  /** Emits every 30s. Subscribe in components that need auto-refresh. */
  tick$(): Observable<number> {
    return interval(this.INTERVAL_MS).pipe(takeUntil(this.destroy$));
  }

  stop(): void {
    this.destroy$.next();
  }
}
