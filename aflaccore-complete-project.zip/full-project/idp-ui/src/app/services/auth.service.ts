import { Injectable, signal } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class AuthService {
  readonly operator = signal<string | null>(null);
  readonly authenticated = signal(false);

  constructor() {
    this.restore();
  }

  login(username: string): void {
    this.operator.set(username);
    this.authenticated.set(true);
    sessionStorage.setItem('idp_operator', username);
  }

  logout(): void {
    this.operator.set(null);
    this.authenticated.set(false);
    sessionStorage.removeItem('idp_operator');
  }

  restore(): void {
    const op = sessionStorage.getItem('idp_operator');
    if (op) {
      this.operator.set(op);
      this.authenticated.set(true);
    }
  }
}
