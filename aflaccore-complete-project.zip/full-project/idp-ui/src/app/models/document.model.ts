/* ================================================================
   Domain models \u2014 match the API contract from local-api-proxy.js
   ================================================================ */

// ----- Auth -----
export interface AuthUser {
  operator: string | null;
  authenticated: boolean;
}

// ----- Applications & Jobs -----

/** A single dropdown option (used for both Dropdown fields and dictionary references). */
export interface FieldOption {
  Value: string;
  Label: string;
}

/** A field definition coming from document-config.json. */
export interface ConfigField {
  FieldName: string;
  Label: string;
  DataType: 'String' | 'Dropdown' | 'Number' | string;
  Required?: boolean;
  Disabled?: boolean;
  /** For Dropdown fields, inline option list. */
  Options?: FieldOption[];
  /** For Dropdown fields, reference to a shared dictionary (e.g. "TransCodes"). */
  OptionsRef?: string;
  /** Default value used when the document doesn't have a stored value yet. */
  DefaultValue?: string | null;
  /** For Disabled fields, the batch property to read from. */
  AutoPopulateFrom?: string;
  /** Optional date format for auto-populated date fields. */
  Format?: string;
  /** Optional transform: 'uppercase', etc. */
  Transform?: string;
  ExtractionRegex?: string;
  ValidationRegex?: string;
  ConfidenceScore?: number;
  FieldKeywords?: string[];
}

/** A line items grid column. Same shape as ConfigField, just used in a table cell context. */
export interface ConfigLineItemColumn extends ConfigField {}

/** Line items configuration for a page type. */
export interface ConfigLineItems {
  Name: string;
  EmptyText?: string;
  MinRows?: number;
  Columns: ConfigLineItemColumn[];
  /**
   * 0-based insertion index into the rendered Fields sequence. When set,
   * the Verify screen places the line items grid between fields[Position-1]
   * and fields[Position]. When omitted, the grid renders after all fields.
   */
  Position?: number;
}

/** A configured page type (MainPage, CoverPage, etc.). */
export interface ConfigPageType {
  pageType: string;
  fields: ConfigField[];
  lineItems: ConfigLineItems | null;
  keywords: string[];
}

/** A configured document type. */
export interface ConfigDocumentType {
  name: string;
  pageTypes: ConfigPageType[];
}

export interface Application {
  name: string;
  displayName: string;
  classificationMode?: string;
  /** Phase 1: just the type names. Phase 2C: full type definitions. */
  documentTypes: string[] | ConfigDocumentType[];
}

/** Top-level response from GET /api/applications. */
export interface ApplicationsResponse {
  applications: Application[];
  /** Shared option lists (e.g. TransCodes) referenced by ConfigField.OptionsRef. */
  dictionaries?: { [name: string]: FieldOption[] };
}

export interface JobStatusCounts {
  total: number;
  // Plus dynamic keys per status (Running, OnHold, JobDone, Failed, ...)
  [status: string]: number;
}

export interface JobSummary {
  jobName: string;
  counts: JobStatusCounts;
}

// ----- Batches (list view) -----
export type BatchStatus = 'Running' | 'OnHold' | 'JobDone' | 'Failed' | string;

export interface BatchRow {
  queueId: number;
  batchId: string;
  batchNumber: string;
  application: string;
  source: string;
  jobName: string;
  currentTask: string;
  status: BatchStatus;
  jobStartTime: string;       // ISO
  jobTime: number | null;     // seconds since jobStartTime (live)
  jobDuration: number | null; // ms (for terminal states)
  operator: string;
  documentCount: number;
  pageCount: number;
  updatedAt: string;
}

export interface BatchPage_DTO {  // pagination metadata
  page: number;
  pageSize: number;
  totalCount: number;
  totalPages: number;
  batches: BatchRow[];
}

// ----- Batch detail (Verify screen) -----
export interface ExtractedField {
  fieldName: string;
  value: string | null;
  confidence: number | null;
  validationPassed: boolean;
  sourcePageId: string | null;
  required: boolean;
  dataType: string;
  validationError: string | null;
  correctedBy: string | null;
  correctedAt: string | null;
}

/**
 * A single line item row as stored in DDB and sent to/from the API.
 * Stage 5: persisted as a list of column-name -> string-value maps on
 * the document record. Backward-compatible with old batches: missing
 * attribute is treated as empty array.
 */
export type LineItemRowData = { [columnName: string]: string };

export interface DocumentDetail {
  documentId: string;
  documentType: string;
  validationStatus: string;
  pageIds: string[];
  extractedFields: ExtractedField[];
  /**
   * Optional in the API response so old batches that pre-date Stage 5
   * (no lineItems attribute in DDB) just come back as undefined and the
   * UI treats that as empty.
   */
  lineItems?: LineItemRowData[];
  createdAt: string;
  updatedAt: string;
}

export type PageType = 'MainPage' | 'TrailingPage' | 'CoverPage' | 'BlankPage' | 'Unclassified' | string;

/** A single OCR word with its bounding box in normalized 0..1 coordinates. */
export interface OcrWord {
  text: string;
  bbox: { l: number; t: number; w: number; h: number };
}

export interface PageDetail {
  pageId: string;
  displayId?: string | null;     // human-friendly TM000001 style, null for older batches
  pageNumber: number;
  pageType: PageType;
  pageStatus: string;
  wordCount: number | null;
  s3Key: string;
  ocrTextS3Key: string | null;
  imageUrl: string;          // local URL into the proxy
  ocrWords?: OcrWord[];      // populated for new batches; older batches: []
  createdAt: string;
  updatedAt: string;
}

export interface TaskHistoryItem {
  taskName: string;
  status: string;
  startTime: string;
  endTime: string;
  operator: string;
  durationMs: number | null;
  details?: any;
}

export interface TextractJob {
  jobId: string;
  pageId: string;
  status: string;
  createdAt: string;
  completedAt: string | null;
  durationMs: number | null;
  resultS3Key: string | null;
  errorMessage: string | null;
}

export interface BatchDetail {
  batch: BatchRow & {
    sourceZipKey: string | null;
    xmlMetadata: Record<string, string>;
    holdSource?: 'manual' | 'manualReview' | null;
    holdReason?: string | null;
    manualReviewStartedAt?: string | null;
    manualReviewCompletedAt?: string | null;
    createdAt?: string;
  };
  documents: DocumentDetail[];
  pages: PageDetail[];
  taskHistory: TaskHistoryItem[];
  textractJobs: TextractJob[];
}

// ----- Submit Review -----
export interface FieldCorrection {
  fieldName: string;
  value: string;
}

export interface SubmitReviewRequest {
  reviewer: string;
  corrections: FieldCorrection[];
  /** Stage 5: full snapshot of the line items grid at submit time. */
  lineItems?: LineItemRowData[];
}

export interface SubmitReviewResponse {
  queueId: number;
  status: string;
  reviewer: string;
  correctionCount: number;
  /** Stage 5: number of line item rows persisted. */
  lineItemCount?: number;
  message: string;
}

// ----- Search/Filter (BatchMonitor) -----
export interface BatchListQuery {
  application: string;
  status?: string;          // comma-separated
  search?: string;          // wildcard
  page?: number;
  pageSize?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

// ----- Dashboard -----
export interface DashboardFilter {
  application?: string;     // 'all' or specific app name
  from?: string;            // ISO date or yyyymmdd
  to?: string;              // ISO date or yyyymmdd
}

export type DateRangePreset = 'today' | 'yesterday' | 'last7' | 'last30' | 'mtd' | 'custom';

export interface DashboardStats {
  filter: {
    application: string;
    from: string | null;
    to: string | null;
  };
  totalIngested: number;
  pendingReview: number;
  stpBatches: number;
  abortedBatches: number;
  stpPercentage: number;          // e.g. 11.1
  byDocumentType: { type: string; count: number }[];
  byStatus: { status: string; count: number }[];
  recentTimeline: { bucket: string; processed: number; failed: number }[];
}
