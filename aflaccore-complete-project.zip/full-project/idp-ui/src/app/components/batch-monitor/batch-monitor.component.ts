import { Component, OnInit, OnDestroy, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

import { BatchRow, BatchListQuery } from '../../models/document.model';
import { BatchService } from '../../services/batch.service';
import { RefreshService } from '../../services/refresh.service';
import { AuthService } from '../../services/auth.service';

type FilterChip = 'all' | 'Running' | 'pending' | 'hold' | 'JobDone' | 'Failed';

@Component({
  selector: 'app-batch-monitor',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './batch-monitor.component.html',
  styleUrls: ['./batch-monitor.component.scss'],
})
export class BatchMonitorComponent implements OnInit, OnDestroy {
  private readonly svc     = inject(BatchService);
  private readonly refresh = inject(RefreshService);
  private readonly auth    = inject(AuthService);
  private readonly router  = inject(Router);
  private sub?: Subscription;

  // ── State ──
  loading       = signal(false);
  error         = signal<string | null>(null);
  batches       = signal<BatchRow[]>([]);
  selectedApp   = signal('AFLCOR');
  activeFilter  = signal<FilterChip>('all');
  searchText    = signal('');
  page          = signal(1);
  totalCount    = signal(0);
  readonly PAGE_SIZE = 50;

  applications = ['AFLCOR', 'PLADS', 'EFR', 'NAS', 'GB', 'FCC', 'INC', 'Claims', 'NBUS'];

  // ── Filter chip counts (derived from current batch list) ──
  readonly counts = computed(() => {
    const all = this.batches();
    const count = (s: string) => all.filter(b => b.status?.toLowerCase() === s.toLowerCase()).length;
    return {
      all:     all.length,
      Running: count('Running'),
      pending: count('pending'),
      hold:    count('hold'),
      JobDone: count('JobDone'),
      Failed:  count('Failed'),
    };
  });

  ngOnInit(): void {
    this.load();
    this.sub = this.refresh.tick$().subscribe(() => this.load());
  }

  ngOnDestroy(): void {
    this.sub?.unsubscribe();
  }

  load() {
    this.loading.set(true);
    this.error.set(null);

    const q: BatchListQuery = {
      application: this.selectedApp(),
      page:        this.page(),
      pageSize:    this.PAGE_SIZE,
    };

    const f = this.activeFilter();
    if (f !== 'all') q.status = f;
    if (this.searchText().trim()) q.search = this.searchText().trim();

    this.svc.listBatches(q).subscribe({
      next: resp => {
        this.batches.set(resp.batches);
        this.totalCount.set(resp.totalCount);
        this.loading.set(false);
      },
      error: err => {
        this.error.set(err?.error?.message || err?.message || 'Failed to load batches');
        this.loading.set(false);
      },
    });
  }

  setFilter(chip: FilterChip) {
    this.activeFilter.set(chip);
    this.page.set(1);
    this.load();
  }

  onAppChange(app: string) {
    this.selectedApp.set(app);
    this.page.set(1);
    this.load();
  }

  onSearchInput(val: string) {
    this.searchText.set(val);
    this.page.set(1);
    this.load();
  }

  openVerify(batch: BatchRow) {
    if (batch.currentTask === 'ManualReview' || batch.status === 'hold') {
      this.router.navigate(['/verify', batch.queueId]);
    }
  }

  statusClass(status: string): string {
    switch (status) {
      case 'JobDone':  return 'pill success';
      case 'Running':  return 'pill info';
      case 'hold':     return 'pill warning';
      case 'pending':  return 'pill muted';
      case 'Failed':   return 'pill danger';
      default:         return 'pill';
    }
  }

  statusLabel(status: string): string {
    switch (status) {
      case 'pending': return 'Pending';
      case 'hold':    return 'Hold';
      case 'JobDone': return 'Done';
      default:        return status;
    }
  }

  formatDuration(ms: number | null): string {
    if (ms == null) return '—';
    const s = Math.floor(ms / 1000);
    if (s < 60) return `${s}s`;
    const m = Math.floor(s / 60);
    if (m < 60) return `${m}m ${s % 60}s`;
    return `${Math.floor(m / 60)}h ${m % 60}m`;
  }

  formatDate(iso: string): string {
    if (!iso) return '—';
    try {
      return new Date(iso).toLocaleString('en-US', {
        month: 'numeric', day: 'numeric', year: '2-digit',
        hour: 'numeric', minute: '2-digit', hour12: true,
      });
    } catch { return iso; }
  }

  get totalPages(): number {
    return Math.ceil(this.totalCount() / this.PAGE_SIZE);
  }

  prevPage() {
    if (this.page() > 1) { this.page.update(p => p - 1); this.load(); }
  }

  nextPage() {
    if (this.page() < this.totalPages) { this.page.update(p => p + 1); this.load(); }
  }

  trackByQueueId(_i: number, b: BatchRow) { return b.queueId; }
}
