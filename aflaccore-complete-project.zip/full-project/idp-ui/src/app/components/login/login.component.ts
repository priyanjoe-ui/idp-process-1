import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ApiBatchService } from '../../services/api-batch.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent {
  private readonly auth   = inject(AuthService);
  private readonly api    = inject(ApiBatchService);
  private readonly router = inject(Router);

  username  = signal('');
  loading   = signal(false);
  error     = signal<string | null>(null);

  onSubmit() {
    const name = this.username().trim();
    if (!name) {
      this.error.set('Please enter your operator ID.');
      return;
    }
    this.loading.set(true);
    this.error.set(null);
    // Call api-proxy /auth/login to validate (POC: any non-empty name succeeds)
    this.api.login(name).subscribe({
      next: user => {
        this.auth.login(user.operator || name);
        this.router.navigate(['/batches']);
      },
      error: err => {
        console.error('login error:', err);
        // Fall back to local auth if proxy unreachable
        this.auth.login(name);
        this.router.navigate(['/batches']);
      },
    });
  }
}
