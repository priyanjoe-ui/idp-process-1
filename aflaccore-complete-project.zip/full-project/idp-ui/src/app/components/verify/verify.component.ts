import { CommonModule } from '@angular/common';
import {
  Component,
  ElementRef,
  OnInit,
  ViewChild,
  computed,
  effect,
  inject,
  signal,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import {
  ApplicationsResponse,
  BatchDetail,
  ConfigField,
  ConfigLineItemColumn,
  ConfigLineItems,
  ConfigPageType,
  FieldOption,
  LineItemRowData,
  PageDetail,
  TaskHistoryItem,
} from '../../models/document.model';
import { BatchService } from '../../services/batch.service';
import { CifLookupResult, CifLookupService } from '../../services/cif-lookup.service';

interface FieldEdit {
  fieldName: string;
  label: string;
  dataType: 'String' | 'Dropdown' | string;
  originalValue: string;
  currentValue: string;
  confidence: number | null;
  required: boolean;
  disabled: boolean;       // for auto-populated read-only fields
  /** For Dropdown fields, the resolved option list. */
  options?: { value: string; label: string }[];
  validationError?: string | null;
}

interface BatchStructureRow {
  rowType: 'batch' | 'doc' | 'page';
  id: string;          // display ID
  type: string;        // display type label
  status: 'Scanned' | 'Problem';
  pageId?: string;     // for page rows, to enable scroll-to
  indent: number;      // 0, 1, or 2
}

interface LineItemDocRow {
  docId: string;
  docType: string;
  status: string;
  pageCount: number;
  fieldCount: number;
  validation: string;
}

/**
 * One row in the editable line items grid. Cells is a string-keyed
 * dictionary so the template can do `row.cells[col.FieldName]` without
 * type gymnastics. rowId is a synthetic local id for tracking selection
 * and Angular's @for trackBy \u2014 it is NOT persisted to DDB. On submit we
 * strip rowId and send only the cells.
 */
interface LineItemRow {
  rowId: string;
  cells: { [columnName: string]: string };
}

/**
 * Discriminated union representing one slot in the rendered Field
 * Details panel. The template walks this list in order, rendering
 * either a field cell or the line items table inline. Keeping config
 * order means a config edit alone controls placement \u2014 no template
 * change needed.
 */
type RenderItem =
  | { kind: 'field'; field: FieldEdit }
  | { kind: 'lineItems'; config: ConfigLineItems };

type FitMode = 'width' | 'height';

@Component({
  selector: 'app-verify',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './verify.component.html',
  styleUrls: ['./verify.component.scss'],
})
export class VerifyComponent implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly svc = inject(BatchService);
  private readonly cifSvc = inject(CifLookupService);

  // ----- State -----
  loading = signal(true);
  errorMessage = signal<string | null>(null);
  detail = signal<BatchDetail | null>(null);
  fieldEdits = signal<FieldEdit[]>([]);

  /** Application config (field definitions + shared dictionaries). */
  appConfig = signal<ApplicationsResponse | null>(null);

  // ----- Line items grid state -----
  lineItems = signal<LineItemRow[]>([]);
  /** rowId of the currently selected row (for the footer \u00d7 Delete button). */
  selectedRowId = signal<string | null>(null);
  /** Monotonic counter for synthetic row ids. */
  private nextRowSeq = 1;
  /**
   * Tracks whether the lineItems signal has been hydrated from the
   * BatchDetail at least once. We use this to gate the auto-CIF-lookup:
   * only call CIF when DDB came back empty, never overwrite persisted
   * rows that were already submitted in a prior review.
   */
  private lineItemsHydratedFromDdb = false;

  // ----- CIF lookup state -----
  cifLookupBusy = signal(false);
  cifLookupError = signal<string | null>(null);
  /** True after the first auto-lookup on screen load has fired so we
   *  don't repeatedly call the service on every config rebuild. */
  private autoLookupAttempted = false;

  // ----- Selected/current page tracking -----
  currentPageId = signal<string | null>(null);

  // ----- Panel collapse -----
  leftCollapsed = signal(false);
  middleCollapsed = signal(false);
  rightCollapsed = signal(false);

  // ----- Viewer transform state -----
  zoom = signal(1.0);              // 1.0 = 100%
  fitMode = signal<FitMode>('width');
  inverted = signal(false);
  brightness = signal(100);        // %
  contrast = signal(100);
  saturation = signal(100);
  showBrightness = signal(false);  // popover open?
  /** Per-page rotation in degrees */
  pageRotation = signal<Record<string, number>>({});

  // ----- Submit dialog -----
  showConfirm = signal(false);
  submitting = signal(false);
  /**
   * Validation errors collected from the latest submit attempt.
   * Cleared on field edit. Stage 5: blocks submit if any are present
   * (per "missing required fields only" rule).
   */
  submitBlockingErrors = signal<string[]>([]);

  // ----- Action dropdowns (placeholders) -----
  showViewerActions = signal(false);
  showFieldActions = signal(false);
  showStructureActions = signal(false);
  showTasksMenu = signal(false);

  // ----- Click N (draw-to-capture) -----
  drawMode = signal(false);
  /** Current drawing box in pixel coords relative to the active page image. */
  drawBox = signal<{ pageId: string; x: number; y: number; w: number; h: number } | null>(null);
  /** Captured text held in memory after a draw when no field was focused. */
  pendingClickNText = signal<string | null>(null);
  /** Which field input was last focused, used as the auto-insert target. */
  focusedFieldName = signal<string | null>(null);
  /** "Rotate back to 0\u00b0" toast. */
  showRotateToast = signal(false);
  /** "Captured text \u2014 click any field" popup. */
  showClickNPopup = signal(false);

  // ----- Search -----
  searchOpen = signal(false);
  searchQuery = signal('');
  currentMatchIndex = signal(0);

  // ----- DOM refs -----
  @ViewChild('viewerScroll') viewerScrollRef?: ElementRef<HTMLDivElement>;

  // ----- Derived -----
  readonly batch = computed(() => this.detail()?.batch);
  readonly pages = computed<PageDetail[]>(() => this.detail()?.pages || []);
  readonly documents = computed(() => this.detail()?.documents || []);
  readonly taskHistory = computed<TaskHistoryItem[]>(() => this.detail()?.taskHistory || []);

  /**
   * Stage 5: submit is allowed only when the batch is OnHold/ManualReview
   * AND there are no blocking validation errors (missing required fields).
   * The errors are computed live from fieldEdits \u2014 no need to re-run a
   * validation pass before each render.
   */
  readonly requiredFieldErrors = computed<string[]>(() => {
    const out: string[] = [];
    for (const e of this.fieldEdits()) {
      if (!e.required) continue;
      if (e.disabled) continue;  // auto-populated fields can't be empty by user action
      if (!e.currentValue || !e.currentValue.trim()) {
        out.push(`${e.label} is required`);
      }
    }
    return out;
  });

  readonly canSubmit = computed(() => {
    const b = this.batch();
    if (!b) return false;
    if (b.currentTask !== 'ManualReview' || b.status !== 'OnHold') return false;
    // Per Stage 5 Q1: block on missing required fields only
    return this.requiredFieldErrors().length === 0;
  });

  /** Tooltip text for the Submit button explaining why it's disabled. */
  readonly submitDisabledReason = computed<string | null>(() => {
    const b = this.batch();
    if (!b) return 'Loading\u2026';
    if (b.currentTask !== 'ManualReview' || b.status !== 'OnHold') {
      return 'Batch is not in Manual Review';
    }
    const errs = this.requiredFieldErrors();
    if (errs.length > 0) {
      return errs.length === 1
        ? errs[0]
        : `${errs.length} required fields are empty`;
    }
    return null;
  });

  /** Document table at top of Batch Structure: one row per document. */
  readonly lineItemDocs = computed<LineItemDocRow[]>(() => {
    return this.documents().map(d => ({
      docId: d.documentId,
      docType: d.documentType,
      status: 'Classified',
      pageCount: (d.pageIds || []).length,
      fieldCount: (d.extractedFields || []).length,
      validation: d.validationStatus || '\u2014',
    }));
  });

  /** Line items table configuration for the current document type. */
  readonly lineItemsConfig = computed<ConfigLineItems | null>(() => {
    return this.findMainPageConfig()?.lineItems || null;
  });

  /** Resolved dropdown options per column name, ready for the template. */
  readonly lineItemColumnOptions = computed<{ [col: string]: { value: string; label: string }[] }>(() => {
    const cfg = this.lineItemsConfig();
    const out: { [col: string]: { value: string; label: string }[] } = {};
    if (!cfg) return out;
    for (const col of cfg.Columns) {
      if (col.DataType === 'Dropdown') {
        out[col.FieldName] = this.resolveOptions(col) || [];
      }
    }
    return out;
  });

  /**
   * Ordered list of cells + line items block to render in the Field
   * Details panel. Built from the config: fields render in their array
   * order, the line items block is inserted at lineItems.Position (or
   * after all fields if Position is unset). When config isn't loaded
   * yet, falls back to fieldEdits with no line items.
   */
  readonly renderItems = computed<RenderItem[]>(() => {
    const edits = this.fieldEdits();
    const liCfg = this.lineItemsConfig();
    const items: RenderItem[] = edits.map(f => ({ kind: 'field', field: f } as RenderItem));
    if (!liCfg) return items;
    const pos = (typeof liCfg.Position === 'number' && liCfg.Position >= 0)
      ? Math.min(liCfg.Position, items.length)
      : items.length;
    items.splice(pos, 0, { kind: 'lineItems', config: liCfg });
    return items;
  });

  /** Batch structure table \u2014 flat list with indent levels */
  readonly batchStructure = computed<BatchStructureRow[]>(() => {
    const rows: BatchStructureRow[] = [];
    const b = this.batch();
    if (!b) return rows;

    // Determine if any doc is in problem state
    const anyDocProblem = this.documents().some(d => d.validationStatus !== 'Passed');

    // Batch row
    rows.push({
      rowType: 'batch',
      id: b.batchNumber,
      type: b.application,
      status: anyDocProblem ? 'Problem' : 'Scanned',
      indent: 0,
    });

    // Doc + page rows
    this.documents().forEach((doc, dIdx) => {
      const docProblem = doc.validationStatus !== 'Passed';
      rows.push({
        rowType: 'doc',
        id: `${b.batchNumber}.${String(dIdx + 1).padStart(2, '0')}`,
        type: doc.documentType,
        status: docProblem ? 'Problem' : 'Scanned',
        indent: 1,
      });

      (doc.pageIds || []).forEach(pid => {
        const page = this.pages().find(p => p.pageId === pid);
        if (!page) return;
        const displayId = page.displayId || `Page ${page.pageNumber}`;
        rows.push({
          rowType: 'page',
          id: displayId,
          type: this.pageTypeLabel(page.pageType),
          status: docProblem ? 'Problem' : 'Scanned',
          pageId: page.pageId,
          indent: 2,
        });
      });
    });

    return rows;
  });

  /** Most-recent task history item for the bottom status bar */
  readonly lastEvent = computed<string>(() => {
    const b = this.batch();
    const hist = this.taskHistory();
    if (!b) return '';
    if (hist.length === 0) {
      return `Batch ${b.batchNumber} was started.`;
    }
    const last = hist[hist.length - 1];
    return `Batch ${b.batchNumber} \u2014 ${last.taskName} ${last.status === 'Completed' ? 'completed' : last.status.toLowerCase()}.`;
  });

  readonly dirtyCount = computed(() =>
    this.fieldEdits().filter(e => e.currentValue !== e.originalValue).length
  );

  /** Index of the currently visible page in the pages() array */
  readonly currentPageIndex = computed(() => {
    const id = this.currentPageId();
    if (!id) return 0;
    const idx = this.pages().findIndex(p => p.pageId === id);
    return idx >= 0 ? idx : 0;
  });

  // ----- Lifecycle -----
  constructor() {
    // Rebuild fieldEdits whenever appConfig arrives (or changes). The batch
    // detail load may complete before the config response arrives \u2014 in that
    // case fieldEdits gets built from the existing extractedFields only, and
    // this effect re-runs it with the config-driven schema once available.
    effect(() => {
      const cfg = this.appConfig();
      if (cfg && this.detail()) {
        this.rebuildFieldEdits();
        this.hydrateLineItemsFromDdb();
        this.maybeAutoCifLookup();
      }
    });
  }

  ngOnInit(): void {
    const queueId = Number(this.route.snapshot.paramMap.get('queueId'));
    if (!queueId) {
      this.errorMessage.set('No queueId in URL');
      this.loading.set(false);
      return;
    }
    this.load(queueId);
  }

  load(queueId: number) {
    this.loading.set(true);
    this.svc.listApplications().subscribe({
      next: cfg => this.appConfig.set(cfg),
      error: err => console.warn('listApplications failed (continuing without config):', err),
    });
    this.svc.getBatch(queueId).subscribe({
      next: d => {
        this.detail.set(d);
        this.rebuildFieldEdits();
        this.hydrateLineItemsFromDdb();
        if (d.pages?.length) {
          this.currentPageId.set(d.pages[0].pageId);
        }
        this.loading.set(false);
        this.maybeAutoCifLookup();
      },
      error: err => {
        console.error('getBatch error:', err);
        this.errorMessage.set(err?.error?.message || err?.message || 'Failed to load batch');
        this.loading.set(false);
      },
    });
  }

  /**
   * Stage 5: hydrate the line items grid from the document record in DDB.
   * Runs both on initial getBatch() resolve and on appConfig() arrival
   * (since lineItemsConfig depends on appConfig). Safe to call multiple
   * times \u2014 guarded by lineItemsHydratedFromDdb so we don't blow away
   * user edits after the first successful hydrate.
   *
   * Backward compat: old batches without a lineItems attribute just give
   * us `undefined`, which we treat as an empty array.
   */
  private hydrateLineItemsFromDdb() {
    if (this.lineItemsHydratedFromDdb) return;
    const d = this.detail();
    if (!d) return;
    const doc0 = d.documents?.[0];
    const stored = doc0?.lineItems;
    if (!Array.isArray(stored)) {
      // Old batch, or no document. Leave grid empty \u2014 CIF lookup may
      // populate it later if PolicyNumber is set.
      this.lineItemsHydratedFromDdb = true;
      return;
    }
    const rows: LineItemRow[] = stored.map(cells => ({
      rowId: `li-${this.nextRowSeq++}`,
      cells: { ...cells },
    }));
    this.lineItems.set(rows);
    this.lineItemsHydratedFromDdb = true;
  }

  /**
   * Build the editable field list from the document-config (preferred) merged
   * with any existing extractedFields on the document. If config isn't loaded
   * yet, falls back to whatever extractedFields the document has.
   */
  private rebuildFieldEdits() {
    const d = this.detail();
    if (!d) return;

    const doc0 = d.documents?.[0];
    const extracted = doc0?.extractedFields || [];
    const byName = new Map<string, any>();
    extracted.forEach(f => byName.set(f.fieldName, f));

    const mainPage = this.findMainPageConfig();

    if (!mainPage || !mainPage.fields?.length) {
      const edits: FieldEdit[] = extracted.map(f => ({
        fieldName: f.fieldName,
        label: f.fieldName,
        dataType: 'String',
        originalValue: f.value || '',
        currentValue: f.value || '',
        confidence: f.confidence ?? null,
        required: f.required ?? false,
        disabled: false,
        validationError: (f.validationPassed === false) ? (f.validationError || 'Validation failed') : null,
      }));
      this.fieldEdits.set(edits);
      return;
    }

    const edits: FieldEdit[] = mainPage.fields.map(fc => {
      const stored = byName.get(fc.FieldName);
      let value: string;

      if (fc.Disabled && fc.AutoPopulateFrom) {
        value = this.resolveAutoValue(fc.AutoPopulateFrom, fc.Format, fc.Transform);
      } else if (stored && stored.value != null && stored.value !== '') {
        value = String(stored.value);
      } else if (fc.DefaultValue != null) {
        value = String(fc.DefaultValue);
      } else {
        value = '';
      }

      const options = this.resolveOptions(fc);

      return {
        fieldName: fc.FieldName,
        label: fc.Label || fc.FieldName,
        dataType: fc.DataType,
        originalValue: value,
        currentValue: value,
        confidence: stored?.confidence ?? null,
        required: fc.Required ?? false,
        disabled: fc.Disabled ?? false,
        options,
        validationError: (stored?.validationPassed === false)
          ? (stored.validationError || 'Validation failed')
          : null,
      };
    });
    this.fieldEdits.set(edits);
  }

  /** Find the MainPage config for the current batch's application. */
  private findMainPageConfig(): ConfigPageType | null {
    const cfg = this.appConfig();
    const d = this.detail();
    if (!cfg || !d) return null;
    const app = (cfg.applications || []).find(a => a.name === d.batch.application);
    if (!app) return null;
    const docTypes = app.documentTypes as any[];
    if (!docTypes?.length || typeof docTypes[0] === 'string') return null;
    const dt = docTypes[0];
    const main = (dt.pageTypes || []).find((p: ConfigPageType) => p.pageType === 'MainPage');
    return main || null;
  }

  /** Resolve a dropdown's option list from inline Options or from a Dictionary ref. */
  private resolveOptions(fc: ConfigField): { value: string; label: string }[] | undefined {
    if (fc.DataType !== 'Dropdown') return undefined;
    let opts: FieldOption[] | undefined = fc.Options;
    if (!opts && fc.OptionsRef) {
      const dict = this.appConfig()?.dictionaries || {};
      opts = dict[fc.OptionsRef];
    }
    if (!opts) return [];
    return opts.map(o => ({ value: o.Value, label: o.Label }));
  }

  /** Auto-populate value from a batch property, with optional formatting. */
  private resolveAutoValue(prop: string, format?: string, transform?: string): string {
    const d = this.detail();
    if (!d) return '';
    const raw = (d.batch as any)?.[prop];
    if (raw == null) return '';
    let s = String(raw);
    if (format === 'YYYYMMDD') {
      const ms = Date.parse(s);
      if (!Number.isNaN(ms)) {
        const dt = new Date(ms);
        const y = dt.getFullYear();
        const m = String(dt.getMonth() + 1).padStart(2, '0');
        const day = String(dt.getDate()).padStart(2, '0');
        s = `${y}${m}${day}`;
      }
    }
    if (transform === 'uppercase') s = s.toUpperCase();
    return s;
  }

  // ----- Panel toggles -----
  toggleLeft() { this.leftCollapsed.update(v => !v); }
  toggleMiddle() { this.middleCollapsed.update(v => !v); }
  toggleRight() { this.rightCollapsed.update(v => !v); }

  // ----- Field editing -----
  onFieldChange(name: string, value: string) {
    const list = this.fieldEdits().map(e =>
      e.fieldName === name ? { ...e, currentValue: value } : e
    );
    this.fieldEdits.set(list);
    // Clear stale submit-blocking errors as the user types. The live
    // requiredFieldErrors() computed will re-evaluate on every change.
    if (this.submitBlockingErrors().length > 0) {
      this.submitBlockingErrors.set([]);
    }
  }

  fieldClass(e: FieldEdit): string {
    const classes = ['field-row'];
    if (e.currentValue !== e.originalValue) classes.push('dirty');
    if (e.validationError) classes.push('failed');
    // Stage 5: visually flag required-empty fields so the user can find
    // what's blocking submit without hunting through the panel.
    if (e.required && !e.disabled && (!e.currentValue || !e.currentValue.trim())) {
      classes.push('required-empty');
    }
    return classes.join(' ');
  }

  confidenceBarColor(conf: number | null): string {
    if (conf == null) return 'transparent';
    if (conf >= 90) return 'rgba(46, 204, 113, 0.18)';
    if (conf >= 70) return 'rgba(241, 196, 15, 0.20)';
    return 'rgba(231, 76, 60, 0.20)';
  }

  // ----- Line items grid -----

  addLineItemRow() {
    const cfg = this.lineItemsConfig();
    if (!cfg) return;
    const cells: { [k: string]: string } = {};
    for (const col of cfg.Columns) {
      cells[col.FieldName] = col.DefaultValue != null ? String(col.DefaultValue) : '';
    }
    const row: LineItemRow = { rowId: `li-${this.nextRowSeq++}`, cells };
    this.lineItems.update(rows => [...rows, row]);
    this.selectedRowId.set(row.rowId);
  }

  deleteSelectedLineItemRow() {
    const sel = this.selectedRowId();
    if (!sel) return;
    this.lineItems.update(rows => rows.filter(r => r.rowId !== sel));
    this.selectedRowId.set(null);
  }

  selectLineItemRow(rowId: string) {
    this.selectedRowId.set(rowId);
  }

  onLineItemCellChange(rowId: string, columnName: string, value: string) {
    this.lineItems.update(rows => rows.map(r => {
      if (r.rowId !== rowId) return r;
      return { ...r, cells: { ...r.cells, [columnName]: value } };
    }));
  }

  private setLineItemsFromCif(items: { [k: string]: string }[]) {
    const rows: LineItemRow[] = items.map(cells => ({
      rowId: `li-${this.nextRowSeq++}`,
      cells: { ...cells },
    }));
    this.lineItems.set(rows);
    this.selectedRowId.set(null);
  }

  // ----- CIF lookup -----

  /**
   * Stage 5 change: only auto-fire CIF if we have NO line items in DDB
   * already. Previously this fired whenever PolicyNumber was set, which
   * would overwrite persisted user edits on every screen open.
   */
  private maybeAutoCifLookup() {
    if (this.autoLookupAttempted) return;
    if (!this.appConfig() || !this.detail()) return;
    this.autoLookupAttempted = true;

    // If DDB already gave us line items, do NOT call CIF on load \u2014 the
    // user previously submitted these values and we must not overwrite.
    // They can still manually trigger via Tasks -> CIFLookup.
    if (this.lineItems().length > 0) return;

    const policy = this.getFieldValue('PolicyNumber');
    if (!policy) return;
    this.runCifLookup('policy_number', policy);
  }

  onTaskCifLookup() {
    this.closeAllDropdowns();
    const policy = this.getFieldValue('PolicyNumber');
    if (!policy) {
      this.cifLookupError.set('Enter a Policy Number first, then try again.');
      return;
    }
    this.runCifLookup('policy_number', policy);
  }

  private runCifLookup(type: 'policy_number' | 'ssn' | 'cif_number', value: string) {
    this.cifLookupBusy.set(true);
    this.cifLookupError.set(null);
    this.cifSvc.lookup(type, value).subscribe({
      next: (result: CifLookupResult) => {
        this.applyCifResult(result);
        this.cifLookupBusy.set(false);
      },
      error: err => {
        console.error('CIF lookup failed:', err);
        this.cifLookupBusy.set(false);
        this.cifLookupError.set(
          err?.error?.detail || err?.message || 'CIF lookup failed (is the local proxy running on :5000?)'
        );
      },
    });
  }

  private applyCifResult(r: CifLookupResult) {
    const setIfPresent = (fieldName: string, value: string) => {
      const list = this.fieldEdits();
      const idx = list.findIndex(e => e.fieldName === fieldName);
      if (idx < 0) return;
      const next = [...list];
      next[idx] = { ...next[idx], currentValue: value };
      this.fieldEdits.set(next);
    };

    setIfPresent('PolicyNumber', r.policyNumber);
    setIfPresent('SSN', r.ssn);
    setIfPresent('CIFNumber', r.cifNumber);
    setIfPresent('CustomerName', r.customerName);
    setIfPresent('Address', [r.addressLine1, r.addressLine2, r.addressLine3, r.city, r.state, r.zip]
      .filter(s => s).join(', '));

    const rows = r.lineItems.map(li => {
      const cells: { [k: string]: string } = {};
      cells['Policy'] = li.policyNumber;
      cells['LOB'] = li.lineOfBusiness;
      cells['Status'] = li.policyStatus;
      cells['IssueState'] = li.issueState;
      cells['BillForm'] = li.billForm;
      cells['PlanCode'] = li.productCode;
      cells['CustomerName'] = r.customerName;
      return cells;
    });
    this.setLineItemsFromCif(rows);
  }

  private getFieldValue(fieldName: string): string {
    return this.fieldEdits().find(e => e.fieldName === fieldName)?.currentValue || '';
  }

  // ----- Page navigation -----
  scrollToPage(pageId: string) {
    this.currentPageId.set(pageId);
    const el = document.querySelector(`[data-page-id="${pageId}"]`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }

  onViewerScroll() {
    const scroll = this.viewerScrollRef?.nativeElement;
    if (!scroll) return;
    const scrollTop = scroll.scrollTop;
    let candidate: string | null = null;
    const blocks = scroll.querySelectorAll<HTMLElement>('.page-block');
    blocks.forEach(block => {
      if (block.offsetTop <= scrollTop + scroll.clientHeight / 2) {
        candidate = block.getAttribute('data-page-id');
      }
    });
    if (candidate && candidate !== this.currentPageId()) {
      this.currentPageId.set(candidate);
    }
  }

  goToPreviousPage() {
    const pages = this.pages();
    const idx = this.currentPageIndex();
    if (idx > 0) {
      const target = pages[idx - 1].pageId;
      this.currentPageId.set(target);
      const el = document.querySelector(`[data-page-id="${target}"]`);
      el?.scrollIntoView({ block: 'start' });
    }
    this.closeAllDropdowns();
  }

  goToNextPage() {
    const pages = this.pages();
    const idx = this.currentPageIndex();
    if (idx < pages.length - 1) {
      const target = pages[idx + 1].pageId;
      this.currentPageId.set(target);
      const el = document.querySelector(`[data-page-id="${target}"]`);
      el?.scrollIntoView({ block: 'start' });
    }
    this.closeAllDropdowns();
  }

  // ----- Viewer controls -----
  zoomIn() { this.zoom.update(z => Math.min(z + 0.1, 3.0)); }
  zoomOut() { this.zoom.update(z => Math.max(z - 0.1, 0.25)); }

  setFitMode(mode: FitMode) {
    this.fitMode.set(mode);
    this.zoom.set(1.0);
    this.closeAllDropdowns();
  }

  toggleInvert() { this.inverted.update(v => !v); }

  toggleBrightnessPopover() {
    this.showBrightness.update(v => !v);
  }

  resetBrightness() {
    this.brightness.set(100);
    this.contrast.set(100);
    this.saturation.set(100);
  }

  imageFilter(): string {
    const parts: string[] = [];
    if (this.inverted()) parts.push('invert(1)');
    if (this.brightness() !== 100) parts.push(`brightness(${this.brightness()}%)`);
    if (this.contrast() !== 100) parts.push(`contrast(${this.contrast()}%)`);
    if (this.saturation() !== 100) parts.push(`saturate(${this.saturation()}%)`);
    return parts.join(' ') || 'none';
  }

  // ----- Rotation -----
  rotateCurrentPage(delta: number) {
    const pid = this.currentPageId();
    if (!pid) return;
    this.pageRotation.update(map => ({
      ...map,
      [pid]: ((map[pid] || 0) + delta + 360) % 360,
    }));
    this.closeAllDropdowns();
  }

  rotateCW() { this.rotateCurrentPage(90); }
  rotateCCW() { this.rotateCurrentPage(-90); }
  rotate180() { this.rotateCurrentPage(180); }

  rotationFor(pageId: string): number {
    return this.pageRotation()[pageId] || 0;
  }

  imageStyle(pageId: string): Record<string, string> {
    const rot = this.rotationFor(pageId);
    const z = this.zoom();
    return {
      transform: `rotate(${rot}deg) scale(${z})`,
      filter: this.imageFilter(),
      transformOrigin: 'center top',
    };
  }

  pageBlockClass(): string {
    return this.fitMode() === 'height' ? 'fit-height' : 'fit-width';
  }

  placeholder(name: string) {
    console.log(`Placeholder action: ${name}`);
    this.closeAllDropdowns();
  }

  // ----- Click N -----
  toggleClickN() {
    const pid = this.currentPageId();
    if (pid && this.rotationFor(pid) !== 0 && !this.drawMode()) {
      this.showRotateToast.set(true);
      setTimeout(() => this.showRotateToast.set(false), 2500);
      return;
    }
    this.drawMode.update(v => !v);
    this.drawBox.set(null);
  }

  onPageMouseDown(event: MouseEvent, pageId: string) {
    if (!this.drawMode()) return;
    if (this.rotationFor(pageId) !== 0) {
      this.showRotateToast.set(true);
      setTimeout(() => this.showRotateToast.set(false), 2500);
      return;
    }
    event.preventDefault();
    const img = (event.currentTarget as HTMLElement).querySelector('img');
    if (!img) return;
    const rect = img.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    this.drawBox.set({ pageId, x, y, w: 0, h: 0 });
  }

  onPageMouseMove(event: MouseEvent) {
    if (!this.drawMode()) return;
    const box = this.drawBox();
    if (!box) return;
    const img = document
      .querySelector(`[data-page-id="${box.pageId}"] img`) as HTMLImageElement | null;
    if (!img) return;
    const rect = img.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    this.drawBox.set({
      pageId: box.pageId,
      x: Math.min(box.x, x),
      y: Math.min(box.y, y),
      w: Math.abs(x - box.x),
      h: Math.abs(y - box.y),
    });
  }

  onPageMouseUp(_event: MouseEvent) {
    if (!this.drawMode()) return;
    const box = this.drawBox();
    if (!box || box.w < 4 || box.h < 4) {
      this.drawBox.set(null);
      this.drawMode.set(false);
      return;
    }

    const text = this.extractTextFromBox(box);
    this.drawBox.set(null);
    this.drawMode.set(false);

    if (!text) return;

    const target = this.focusedFieldName();
    if (target) {
      this.applyClickNToField(target, text);
    } else {
      this.pendingClickNText.set(text);
      this.showClickNPopup.set(true);
    }
  }

  private extractTextFromBox(box: { pageId: string; x: number; y: number; w: number; h: number }): string {
    const page = this.pages().find(p => p.pageId === box.pageId);
    if (!page || !page.ocrWords?.length) return '';
    const img = document
      .querySelector(`[data-page-id="${box.pageId}"] img`) as HTMLImageElement | null;
    if (!img) return '';
    const rect = img.getBoundingClientRect();
    const nl = box.x / rect.width;
    const nt = box.y / rect.height;
    const nr = (box.x + box.w) / rect.width;
    const nb = (box.y + box.h) / rect.height;
    const inside = page.ocrWords.filter(w => {
      const cx = w.bbox.l + w.bbox.w / 2;
      const cy = w.bbox.t + w.bbox.h / 2;
      return cx >= nl && cx <= nr && cy >= nt && cy <= nb;
    });
    if (!inside.length) return '';
    const sorted = [...inside].sort((a, b) => a.bbox.t - b.bbox.t);
    const lines: typeof inside[] = [];
    const lineTol = (sorted[0].bbox.h ?? 0.02) / 2;
    for (const w of sorted) {
      const last = lines[lines.length - 1];
      if (last && Math.abs(w.bbox.t - last[0].bbox.t) <= lineTol) {
        last.push(w);
      } else {
        lines.push([w]);
      }
    }
    return lines
      .map(line => line.sort((a, b) => a.bbox.l - b.bbox.l).map(w => w.text).join(' '))
      .join(' ')
      .trim();
  }

  applyPendingTextToField(fieldName: string) {
    const text = this.pendingClickNText();
    if (text == null) return;
    this.applyClickNToField(fieldName, text);
    this.pendingClickNText.set(null);
  }

  private applyClickNToField(fieldName: string, text: string) {
    const list = this.fieldEdits().map(e =>
      e.fieldName === fieldName ? { ...e, currentValue: text } : e
    );
    this.fieldEdits.set(list);
  }

  closeClickNPopup() {
    this.showClickNPopup.set(false);
  }

  cancelPendingClickN() {
    this.pendingClickNText.set(null);
    this.showClickNPopup.set(false);
  }

  onFieldFocus(fieldName: string) {
    this.focusedFieldName.set(fieldName);
    if (this.pendingClickNText() != null) {
      this.applyPendingTextToField(fieldName);
    }
  }

  // ----- Search -----
  toggleSearch() {
    this.searchOpen.update(v => !v);
    if (!this.searchOpen()) {
      this.searchQuery.set('');
    }
  }

  closeSearch() {
    this.searchOpen.set(false);
    this.searchQuery.set('');
    this.currentMatchIndex.set(0);
  }

  onSearchInput(value: string) {
    this.searchQuery.set(value);
    this.currentMatchIndex.set(0);
  }

  readonly searchMatches = computed(() => {
    const q = this.searchQuery().trim().toLowerCase();
    if (!q) return [] as { pageId: string; pageNumber: number; bbox: { l: number; t: number; w: number; h: number } }[];
    const out: { pageId: string; pageNumber: number; bbox: { l: number; t: number; w: number; h: number } }[] = [];
    for (const page of this.pages()) {
      for (const w of (page.ocrWords || [])) {
        if (w.text.toLowerCase().includes(q)) {
          out.push({ pageId: page.pageId, pageNumber: page.pageNumber, bbox: w.bbox });
        }
      }
    }
    return out;
  });

  readonly searchMatchCount = computed(() => this.searchMatches().length);

  nextMatch() {
    const total = this.searchMatchCount();
    if (total === 0) return;
    const i = (this.currentMatchIndex() + 1) % total;
    this.currentMatchIndex.set(i);
    this.scrollToCurrentMatch();
  }

  prevMatch() {
    const total = this.searchMatchCount();
    if (total === 0) return;
    const i = (this.currentMatchIndex() - 1 + total) % total;
    this.currentMatchIndex.set(i);
    this.scrollToCurrentMatch();
  }

  private scrollToCurrentMatch() {
    const match = this.searchMatches()[this.currentMatchIndex()];
    if (!match) return;
    const el = document.querySelector(`[data-page-id="${match.pageId}"]`);
    if (el) el.scrollIntoView({ block: 'center' });
  }

  matchesForPage(pageId: string): { bbox: { l: number; t: number; w: number; h: number }; isCurrent: boolean }[] {
    const out: { bbox: { l: number; t: number; w: number; h: number }; isCurrent: boolean }[] = [];
    const matches = this.searchMatches();
    const currentIdx = this.currentMatchIndex();
    for (let i = 0; i < matches.length; i++) {
      if (matches[i].pageId !== pageId) continue;
      out.push({ bbox: matches[i].bbox, isCurrent: i === currentIdx });
    }
    return out;
  }

  openInNewWindow() {
    const pages = this.pages();
    const cur = pages[this.currentPageIndex()];
    if (cur?.imageUrl) {
      window.open(cur.imageUrl, '_blank');
    }
    this.closeAllDropdowns();
  }

  doPrint() {
    window.print();
  }

  // ----- Action dropdowns -----
  toggleViewerActions() {
    const open = !this.showViewerActions();
    this.closeAllDropdowns();
    this.showViewerActions.set(open);
  }
  toggleFieldActions() {
    const open = !this.showFieldActions();
    this.closeAllDropdowns();
    this.showFieldActions.set(open);
  }
  toggleStructureActions() {
    const open = !this.showStructureActions();
    this.closeAllDropdowns();
    this.showStructureActions.set(open);
  }
  toggleTasksMenu() {
    const open = !this.showTasksMenu();
    this.closeAllDropdowns();
    this.showTasksMenu.set(open);
  }
  closeAllDropdowns() {
    this.showViewerActions.set(false);
    this.showFieldActions.set(false);
    this.showStructureActions.set(false);
    this.showTasksMenu.set(false);
  }

  // ----- Submit / Hold / etc. -----
  openConfirm() {
    // Stage 5: hard-gate on required field violations. The button itself
    // is disabled via canSubmit(), but defense-in-depth: never open the
    // confirm dialog if required fields are empty.
    const errs = this.requiredFieldErrors();
    if (errs.length > 0) {
      this.submitBlockingErrors.set(errs);
      return;
    }
    if (!this.canSubmit()) return;
    this.showConfirm.set(true);
  }

  closeConfirm() {
    this.showConfirm.set(false);
  }

  submitReview() {
    const b = this.batch();
    if (!b) return;
    this.submitting.set(true);

    // Header field corrections: full snapshot of editable values. Disabled
    // (auto-populated) fields are skipped \u2014 they're derived from batch
    // metadata, not stored on the document.
    const corrections: { fieldName: string; value: string }[] = [];
    this.fieldEdits().forEach(e => {
      if (e.disabled) return;
      corrections.push({ fieldName: e.fieldName, value: e.currentValue });
    });

    // Stage 5: line items as a list of cell-maps. Strip the synthetic
    // rowId \u2014 that's a UI-only identifier, never persisted.
    const lineItemsPayload: LineItemRowData[] = this.lineItems().map(r => ({ ...r.cells }));

    this.svc.submitReview(b.queueId, corrections, lineItemsPayload).subscribe({
      next: () => {
        this.submitting.set(false);
        this.showConfirm.set(false);
        this.router.navigate(['/batches']);
      },
      error: err => {
        console.error('submitReview error:', err);
        this.submitting.set(false);
        this.errorMessage.set(err?.error?.message || err?.message || 'Submit failed');
      },
    });
  }

  onHold() {
    this.router.navigate(['/batches']);
  }

  onRunValidations() {
    this.placeholder('Run Validations');
  }

  // ----- UI helpers -----
  pageTypeLabel(t: string): string {
    switch (t) {
      case 'MainPage': return 'Main';
      case 'TrailingPage': return 'Trailing';
      case 'CoverPage': return 'Cover';
      case 'BlankPage': return 'Blank';
      default: return t || 'Unknown';
    }
  }

  statusClass(status: string): string {
    switch (status) {
      case 'JobDone':  return 'status-pill success';
      case 'Finished': return 'status-pill success';
      case 'Running':  return 'status-pill info';
      case 'OnHold':   return 'status-pill warning';
      case 'Failed':   return 'status-pill danger';
      case 'Problem':  return 'status-badge problem';
      case 'Scanned':  return 'status-badge scanned';
      default:         return 'status-pill';
    }
  }

  formatTimestamp(): string {
    const d = new Date();
    return d.toLocaleString('en-US', {
      month: 'numeric', day: 'numeric', year: 'numeric',
      hour: 'numeric', minute: '2-digit', second: '2-digit',
      hour12: true,
    });
  }

  appName(): string { return this.batch()?.application || ''; }
  jobName(): string { return this.batch()?.jobName || 'HQIndex'; }

  onFieldKeydown(event: KeyboardEvent, idx: number) {
    if (event.key === 'Enter') {
      event.preventDefault();
      const inputs = document.querySelectorAll<HTMLInputElement>('.field-input');
      const next = inputs[idx + 1];
      if (next) next.focus();
    }
  }
}
