import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BatchService } from '../../services/batch.service';
import { DashboardStats } from '../../models/document.model';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent implements OnInit {
  private readonly svc = inject(BatchService);

  loading = signal(false);
  error   = signal<string | null>(null);
  stats   = signal<DashboardStats | null>(null);
  selectedApp = signal('all');

  applications = ['all', 'AFLCOR', 'PLADS', 'EFR', 'NAS', 'GB', 'FCC', 'INC', 'Claims', 'NBUS'];

  ngOnInit(): void { this.load(); }

  load() {
    this.loading.set(true);
    this.error.set(null);
    this.svc.dashboard({ application: this.selectedApp() }).subscribe({
      next: s  => { this.stats.set(s); this.loading.set(false); },
      error: e => { this.error.set(e?.message || 'Failed to load dashboard'); this.loading.set(false); },
    });
  }

  onAppChange(app: string) {
    this.selectedApp.set(app);
    this.load();
  }

  pct(n: number, total: number): number {
    return total > 0 ? Math.round((n / total) * 100) : 0;
  }
}
