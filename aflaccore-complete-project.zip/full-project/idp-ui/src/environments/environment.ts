export const environment = {
  production: false,
  // /api is proxied by Angular dev server (proxy.conf.json) to local-api-proxy.js on :3001
  apiBaseUrl: 'https://bjuhr4h45nh45igikc22v2d3c40kfzxm.lambda-url.us-east-1.on.aws/api',
  dataSource: 'api' as 'mock' | 'api',
  defaultApplication: 'AFLCOR',
  defaultPageSize: 100,
};