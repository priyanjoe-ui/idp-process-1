export const environment = {
  production: true,
  apiBaseUrl:    'https://YOUR_API_GATEWAY_URL/prod',
  cifLookupUrl:  '',
  dataSource:    'live' as const,
};
