# Akrify Studio

Workflow designer for the IDP platform. Analogous to IBM Datacap Studio, but native to AWS + Bedrock.

Studio produces configuration; the runtime IDP pipeline consumes it. Same JSON schema on both sides.

## Repo layout

```
akrify-studio/
├── projects/
│   ├── studio/          # Studio Angular app
│   └── shared/          # Shared lib: domain models
├── angular.json         # Multi-project workspace
├── tsconfig.json        # Path map so studio consumes @akrify/shared by source
└── package.json
```

## Getting started

```bash
npm install
npm run start           # ng serve on :4300 (dev environment)
```

Open http://localhost:4300 — lands on the Dashboard.

## Environments

One Angular build per environment; each deploys as its own stack. No cross-environment access from the browser.

```bash
npm run build:dev       # dev  build (default when serving)
npm run build:qa        # qa   build → environment.qa.ts
npm run build:prod      # prod build → environment.prod.ts
```

The topbar shows an environment chip driven by `environment.envLabel`:
- **dev** — neutral grey
- **qa** — amber, with a thin amber strip across the top of the app
- **prod** — red, with a red strip across the top

The strip is intentional visual friction: if you're about to change something in prod, you should see red before you click save.

## Data model (DynamoDB, one table per environment)

No `tenantId` — one stack per environment means "the environment" is implicit in which stack you hit.

```
Main table (e.g. IDP_Config_dev, IDP_Config_qa, IDP_Config_prod):

  PK                 SK              Row shape                  type
  ─────────────────  ──────────────  ─────────────────────────  ───────────
  "APP#LOANS"        "META"          ApplicationRecord          APPLICATION
  "APP#LOANS"        "DT#LOAN_APP"   DocumentTypeRecord         DOC_TYPE
  "APP#LOANS"        "DT#ID_PROOF"   DocumentTypeRecord         DOC_TYPE
  "APP#CLAIMS"       "META"          ApplicationRecord          APPLICATION
  "APP#CLAIMS"       "DT#CLAIM_FORM" DocumentTypeRecord         DOC_TYPE
  "DICT"             "TransCodes"    DictionaryRecord           DICTIONARY

GSI 1: type-lastModifiedAt-index
  PK: type              → "APPLICATION" | "DOC_TYPE" | "DICTIONARY"
  SK: lastModifiedAt

  Used by:
    - listApplications()       → Query type = "APPLICATION"
    - listAllDocumentTypes()   → Query type = "DOC_TYPE"
```

**Row envelope** — every row carries:
- `type` (feeds the GSI)
- `version` (integer, incremented per save)
- `lastModifiedAt` (ISO timestamp)
- `lastModifiedBy` (server-populated from JWT claim; stubbed as `"studio-admin"` today)

**Optimistic concurrency** — every `PUT` includes an `expectedVersion`. Backend uses
`ConditionExpression: "version = :expected"`. On mismatch, backend returns 409;
Studio surfaces "This was modified by someone else — reload."

Single source of truth. No draft/publish separation. Whoever saves last wins,
protected against silent overwrites by the version check.

## Studio hierarchy

The UI mirrors the data model:

```
Applications              /applications              Card grid
  └─ Document Types       /applications/:appId/document-types   Table
       └─ Editor          /applications/:appId/document-types/:id   (next round)
```

A **global** doc-types view lives at `/document-types` — reads via the GSI so it doesn't Scan.
Useful for search across applications.

## Backend integration

Applications endpoints are wired to the `idp-api-proxy` Lambda (Node.js/Express). Point `apiBaseUrl` in `environment.ts` at the proxy — locally `http://localhost:3001/api`, deployed `https://<function-url>/api`.

See `idp-api-proxy/STUDIO-SETUP.md` for the full backend setup: creating the `idp-config` DynamoDB table, IAM policy for the Lambda, and running the one-shot migration script that seeds DDB from the existing S3 `document-config.json`.

**What's live vs. mocked in the frontend:**

| Section | Frontend | Backend |
|---|---|---|
| Applications CRUD | ✅ Live HTTP | ✅ Live |
| Document Types CRUD | 🟡 Mock | ✅ Live (backend ready, UI not wired yet) |
| Dictionaries CRUD | 🟡 Mock | ✅ Live (backend ready, UI not wired yet) |
| Dashboard | 🟡 Mock | 🟡 Not started |

Document Types and Dictionaries stay mocked in the UI until we build those screens — the backend endpoints are already deployed, so wiring them is a straightforward service-file change with no backend work.

## Screens

| Screen | Route | Status |
|---|---|---|
| Dashboard | `/dashboard` | ✅ Full mock |
| Applications | `/applications` | ✅ Card grid, search |
| Document Types (per app) | `/applications/:appId/document-types` | ✅ Table, search, tabs, sort, pagination, breadcrumb |
| Document Types (global) | `/document-types` | ✅ Same table, adds Application column |
| Document Type editor | `/applications/:appId/document-types/:id` | 🟡 Next round |
| Jobs & Workflows | `/jobs` | 🟡 Stub |
| Connectors | `/connectors` | 🟡 Stub |
| Test Bench | `/test-bench` | 🟡 Stub |
| Deployments | `/deployments` | 🟡 Stub |
| Users & Access | `/users` | 🟡 Stub |
| Settings | `/settings` | 🟡 Stub |

## Backend contract

Every method on `StudioConfigService` maps 1:1 to a REST endpoint. The mock service simulates the wire behavior (delays, version conflicts, cascades) so components exercise the same code paths they will in production.

```
Applications
  GET    /applications                                        -> ApplicationSummary[]
  GET    /applications/:appId                                 -> ApplicationRecord
  POST   /applications                                        -> ApplicationRecord
  PUT    /applications/:appId                                 -> ApplicationRecord
  DELETE /applications/:appId                                 -> 204

Document Types
  GET    /applications/:appId/document-types                  -> DocumentTypeSummary[]
  GET    /document-types                                      -> DocumentTypeSummary[]   (GSI)
  GET    /applications/:appId/document-types/:docTypeId       -> DocumentTypeRecord
  POST   /applications/:appId/document-types                  -> DocumentTypeRecord
  PUT    /applications/:appId/document-types/:docTypeId       -> DocumentTypeRecord
  DELETE /applications/:appId/document-types/:docTypeId       -> 204

Dictionaries
  GET    /dictionaries                                        -> DictionaryRecord[]
  GET    /dictionaries/:name                                  -> DictionaryRecord
  PUT    /dictionaries/:name                                  -> DictionaryRecord

All PUT and DELETE requests carry an X-Expected-Version header. Backend enforces
via DynamoDB ConditionExpression.
```

## Design decisions locked in this round

- **Separate Angular app**, shared lib for domain models. Two personas, two apps, one schema.
- **DynamoDB single-state** — no draft/publish separation. Optimistic concurrency (`expectedVersion`) prevents silent overwrites.
- **Applications are visible in the UI** as a top-level workspace. Doc types nest under them.
- **One AWS stack per environment.** Environment shown as a chip + top strip in the UI; not selectable at runtime.
- **`lastModifiedBy` is server-populated** from JWT claims. UI never sends it. Stubbed as `"studio-admin"` until auth wires in.

## What's next

The Document Type editor is the big one — tabbed interface (Pages / Fields / Classification / Validation / Indexer UI / Preview), field inspector with AI/Anchor/Regex/Position extraction methods, AI configuration for Bedrock. That's the round after this.
