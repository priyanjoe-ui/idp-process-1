/* ================================================================
   Studio view models.

   Shapes here mirror the DynamoDB row shapes 1:1 so the UI never
   translates between "wire format" and "storage format".

   Naming: PascalCase for anything that is part of the runtime
   document-config schema (interoperability with existing pipeline).
   camelCase for Studio-only metadata (versions, timestamps, counts).
   ================================================================ */

import { ConfigDocumentType, ConfigStatus, FieldOption } from './document-config.model';

// ---------- Session / display -----------------------------------------------

export type Environment = 'dev' | 'qa' | 'prod';

export interface StudioUser {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'designer' | 'reviewer';
}

// ---------- Optimistic-concurrency envelope --------------------------------

/** Fields every writeable row carries; the backend owns them. */
export interface RowAudit {
  version: number;
  lastModifiedAt: string;
  lastModifiedBy: string;
}

// ---------- Applications ---------------------------------------------------

/** Summary shape used by the Applications list page. */
export interface ApplicationSummary extends RowAudit {
  appId: string;
  name: string;
  classificationMode: 'Sequential' | 'Parallel' | string;
  docTypeCount: number;
}

/** Full application record. Today identical to summary; will grow. */
export interface ApplicationRecord extends ApplicationSummary {
  blankPageMaxWordCount?: number;
}

export interface NewApplicationInput {
  appId: string;              // caller-chosen id, e.g. "LOANS"
  name: string;
  classificationMode?: 'Sequential' | 'Parallel' | string;
  blankPageMaxWordCount?: number;
}

export interface UpdateApplicationInput {
  name?: string;
  classificationMode?: 'Sequential' | 'Parallel' | string;
  blankPageMaxWordCount?: number;
}

// ---------- Document Types -------------------------------------------------

export interface DocumentTypeSummary extends RowAudit {
  appId: string;
  docTypeId: string;
  name: string;
  pageCount: number;
  fieldCount: number;
  jobCount: number;
  stpRate: number | null;
  status: ConfigStatus;
  /** Rendered relative time ("2 days ago"). Backend or UI can compute. */
  lastModifiedLabel?: string;
}

export interface DocumentTypeRecord extends DocumentTypeSummary {
  body: ConfigDocumentType;
}

export interface NewDocumentTypeInput {
  docTypeId: string;
  name: string;
  body?: ConfigDocumentType;   // if omitted, backend creates an empty scaffold
}

// ---------- Dictionaries ---------------------------------------------------

export interface DictionaryRecord extends RowAudit {
  name: string;
  options: FieldOption[];
}

// ---------- Dashboard ------------------------------------------------------

export interface DashboardKpis {
  documentsToday: number;
  documentsTrendPct: number;
  stpRatePct: number;
  stpRateTrendPts: number;
  pendingReview: number;
  activeIndexers: number;
  avgProcessingSec: number;
}

export interface VolumePoint {
  day: string;
  values: Record<string, number>;
}

export interface ActivityItem {
  id: string;
  message: string;
  timestamp: string;
  category: 'export' | 'review' | 'deploy' | 'connector' | 'config';
}

export interface TopDocumentTypeRow {
  name: string;
  count: number;
  stpRate: number;
  confidence: 'high' | 'med' | 'low';
}

export type ServiceHealthState = 'healthy' | 'degraded' | 'down' | 'paused';

export interface ServiceHealth {
  name: string;
  state: ServiceHealthState;
  detail?: string;
}

export interface DashboardSnapshot {
  environment: Environment;
  lastSyncedAt: string;
  kpis: DashboardKpis;
  volume: VolumePoint[];
  activity: ActivityItem[];
  topDocumentTypes: TopDocumentTypeRow[];
  serviceHealth: ServiceHealth[];
}
