/* ================================================================
   Document Config models — the source-of-truth schema shared by the
   runtime IDP pipeline (Lambdas + Step Functions) and the Studio UI.

   These names use PascalCase to stay wire-compatible with the
   existing document-config.json used by the runtime today.
   ================================================================ */

export type FieldDataType = 'String' | 'Number' | 'Date' | 'Currency' | 'Dropdown' | 'Boolean' | string;

/** Method used to pull a value off a page. */
export type ExtractionMethod = 'Anchor' | 'Position' | 'Regex' | 'AI';

/** Lifecycle status of a config artifact. */
export type ConfigStatus = 'draft' | 'production' | 'archived';

export interface FieldOption {
  Value: string;
  Label: string;
}

/** AI-extraction config for a single field (used when ExtractionMethod === 'AI'). */
export interface AiExtractionConfig {
  /** Bedrock model id, e.g. 'claude-sonnet-4-6'. */
  Model?: string;
  /** Natural-language description passed into the extraction prompt. */
  Description: string;
  /** Optional few-shot example values to steer the model. */
  Examples?: string[];
  /** Fallback method when AI confidence is below threshold or extraction fails. */
  Fallback?: Exclude<ExtractionMethod, 'AI'>;
}

/** A field definition on a page type. */
export interface ConfigField {
  FieldName: string;
  Label: string;
  DataType: FieldDataType;
  Required?: boolean;
  Disabled?: boolean;

  Options?: FieldOption[];
  OptionsRef?: string;
  DefaultValue?: string | null;
  AutoPopulateFrom?: string;
  Format?: string;
  Transform?: string;

  /** Explicit extraction method. When absent, runtime falls back to Regex/Keyword heuristics. */
  ExtractionMethod?: ExtractionMethod;
  ExtractionRegex?: string;
  ValidationRegex?: string;
  ConfidenceScore?: number;
  FieldKeywords?: string[];
  AI?: AiExtractionConfig;
}

export interface ConfigLineItemColumn extends ConfigField {}

export interface ConfigLineItems {
  Name: string;
  EmptyText?: string;
  MinRows?: number;
  Columns: ConfigLineItemColumn[];
  Position?: number;
}

export interface ConfigPageType {
  PageType: string;
  Fields?: ConfigField[];
  LineItems?: ConfigLineItems;
  Keywords?: string[];
  ClassificationKeywords?: string[];
}

export interface ConfigDocumentType {
  DocumentTypeName: string;
  PageTypes: ConfigPageType[];
}

export interface ConfigApplication {
  ApplicationName: string;
  ClassificationMode?: 'Sequential' | 'Parallel' | string;
  BlankPageMaxWordCount?: number;
  DocumentTypes: ConfigDocumentType[];
}

export interface DocumentConfig {
  Applications: ConfigApplication[];
  Dictionaries?: Record<string, FieldOption[]>;
}
