import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { DashboardSnapshot } from '@akrify/shared';

/**
 * Dashboard data source.
 * Backed by a mock today. When the cif-proxy config endpoints ship,
 * this service is the only file that changes: swap `of(...)` for an
 * HttpClient GET to /studio/dashboard.
 */
@Injectable({ providedIn: 'root' })
export class DashboardService {
  getSnapshot(): Observable<DashboardSnapshot> {
    return of(MOCK_SNAPSHOT);
  }
}

const MOCK_SNAPSHOT: DashboardSnapshot = {
  environment: 'dev',
  lastSyncedAt: new Date(Date.now() - 2 * 60_000).toISOString(),
  kpis: {
    documentsToday: 8432,
    documentsTrendPct: 12,
    stpRatePct: 73.4,
    stpRateTrendPts: 4.1,
    pendingReview: 142,
    activeIndexers: 4,
    avgProcessingSec: 8.2,
  },
  volume: [
    { day: 'Mon', values: { newPolicy: 1420, renewal: 980, claim: 520, other: 240 } },
    { day: 'Tue', values: { newPolicy: 1180, renewal: 1120, claim: 610, other: 300 } },
    { day: 'Wed', values: { newPolicy: 1600, renewal: 1050, claim: 480, other: 260 } },
    { day: 'Thu', values: { newPolicy: 1720, renewal: 1240, claim: 590, other: 320 } },
    { day: 'Fri', values: { newPolicy: 1980, renewal: 1360, claim: 640, other: 350 } },
    { day: 'Sat', values: { newPolicy: 640,  renewal: 420,  claim: 180, other: 90  } },
    { day: 'Sun', values: { newPolicy: 720,  renewal: 490,  claim: 210, other: 110 } },
  ],
  activity: [
    { id: 'a1', message: '12 documents exported to FileNet',              timestamp: '2 min ago',  category: 'export'   },
    { id: 'a2', message: '3 batches enqueued for review',                 timestamp: '5 min ago',  category: 'review'   },
    { id: 'a3', message: "Workflow 'Renewal Intake' deployed v3",         timestamp: '1 hr ago',   category: 'deploy'   },
    { id: 'a4', message: "Connector 'SharePoint-HR' reconnected",         timestamp: '2 hr ago',   category: 'connector'},
    { id: 'a5', message: "Field 'Premium' confidence threshold updated",  timestamp: 'yesterday',  category: 'config'   },
  ],
  topDocumentTypes: [
    { name: 'Loan Application',    count: 3210, stpRate: 82, confidence: 'high' },
    { name: 'Income Statement',    count: 2488, stpRate: 91, confidence: 'high' },
    { name: 'Claim Form',          count: 1520, stpRate: 61, confidence: 'med'  },
    { name: 'ID Proof',            count: 894,  stpRate: 94, confidence: 'high' },
    { name: 'Coverage Update',     count: 320,  stpRate: 44, confidence: 'low'  },
  ],
  serviceHealth: [
    { name: 'Step Functions',    state: 'healthy' },
    { name: 'Textract',          state: 'healthy' },
    { name: 'Bedrock (Claude)',  state: 'healthy' },
    { name: 'DynamoDB',          state: 'healthy' },
    { name: 'Export connectors', state: 'paused', detail: '1 paused' },
  ],
};
