import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, delay, map, of, throwError } from 'rxjs';
import {
  ApplicationRecord,
  ApplicationSummary,
  ConfigDocumentType,
  DictionaryRecord,
  DocumentTypeRecord,
  DocumentTypeSummary,
  FieldOption,
  NewApplicationInput,
  NewDocumentTypeInput,
  UpdateApplicationInput,
} from '@akrify/shared';
import { environment } from '../../environments/environment';

/**
 * Studio config service.
 *
 * Applications endpoints are wired to the real idp-api-proxy backend.
 * Document Types and Dictionaries stay MOCKED until we wire their screens.
 * The seam is clear — each section below is marked LIVE or MOCK. When we
 * build the Document Type editor next round, we swap the MOCK block for
 * HTTP calls; nothing else in the app changes.
 *
 * Backend (all under environment.apiBaseUrl):
 *
 *   Applications                                                LIVE
 *     GET    /applications                                → nested tree (used by reviewer app; Studio doesn't call)
 *     GET    /applications/summary                        → { applications: ApplicationSummary[] }
 *     GET    /applications/:appId                         → ApplicationRecord
 *     POST   /applications                                → 201 ApplicationRecord
 *     PUT    /applications/:appId                         → ApplicationRecord   (X-Expected-Version)
 *     DELETE /applications/:appId                         → 204
 *
 *   Document Types                                              MOCK (backend exists; UI wires next round)
 *     GET    /applications/:appId/document-types
 *     GET    /document-types
 *     GET    /applications/:appId/document-types/:docTypeId
 *     POST   /applications/:appId/document-types
 *     PUT    /applications/:appId/document-types/:docTypeId     (X-Expected-Version)
 *     DELETE /applications/:appId/document-types/:docTypeId
 *
 *   Dictionaries                                                MOCK (backend exists; UI wires later)
 *     GET    /dictionaries
 *     GET    /dictionaries/:name
 *     PUT    /dictionaries/:name                                (X-Expected-Version for updates)
 */
@Injectable({ providedIn: 'root' })
export class StudioConfigService {
  private readonly http = inject(HttpClient);
  private readonly baseUrl = environment.apiBaseUrl.replace(/\/+$/, '');

  // ═══════════════════════════════════════════════════════════════════
  // Applications — LIVE
  // ═══════════════════════════════════════════════════════════════════

  listApplications(): Observable<ApplicationSummary[]> {
    return this.http
      .get<{ applications: ApplicationSummary[] }>(`${this.baseUrl}/applications/summary`)
      .pipe(map(r => r.applications ?? []));
  }

  getApplication(appId: string): Observable<ApplicationRecord> {
    return this.http.get<ApplicationRecord>(`${this.baseUrl}/applications/${encodeURIComponent(appId)}`);
  }

  createApplication(input: NewApplicationInput): Observable<ApplicationRecord> {
    return this.http.post<ApplicationRecord>(`${this.baseUrl}/applications`, input);
  }

  updateApplication(
    appId: string,
    input: UpdateApplicationInput,
    expectedVersion: number,
  ): Observable<ApplicationRecord> {
    return this.http.put<ApplicationRecord>(
      `${this.baseUrl}/applications/${encodeURIComponent(appId)}`,
      input,
      { headers: versionHeader(expectedVersion) },
    );
  }

  deleteApplication(appId: string): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/applications/${encodeURIComponent(appId)}`);
  }

  // ═══════════════════════════════════════════════════════════════════
  // Document Types — MOCK (swap to HTTP when Document Type screens are built)
  // ═══════════════════════════════════════════════════════════════════

  listDocumentTypes(appId: string): Observable<DocumentTypeSummary[]> {
    const rows = DOC_TYPES_MOCK.filter(d => d.appId === appId).map(stripBody);
    return of(rows).pipe(delay(60));
  }

  listAllDocumentTypes(): Observable<DocumentTypeSummary[]> {
    return of(DOC_TYPES_MOCK.map(stripBody)).pipe(delay(60));
  }

  getDocumentType(appId: string, docTypeId: string): Observable<DocumentTypeRecord> {
    const row = DOC_TYPES_MOCK.find(d => d.appId === appId && d.docTypeId === docTypeId);
    return row ? of({ ...row }).pipe(delay(50))
               : throwError(() => new Error(`Document type ${appId}/${docTypeId} not found`));
  }

  createDocumentType(appId: string, input: NewDocumentTypeInput): Observable<DocumentTypeRecord> {
    if (DOC_TYPES_MOCK.some(d => d.appId === appId && d.docTypeId === input.docTypeId)) {
      return throwError(() => new Error(`Document type ${input.docTypeId} already exists in ${appId}`));
    }
    const body: ConfigDocumentType = input.body ?? {
      DocumentTypeName: input.docTypeId,
      PageTypes: [{ PageType: 'MainPage', Fields: [] }],
    };
    const record: DocumentTypeRecord = {
      appId, docTypeId: input.docTypeId, name: input.name, body,
      fieldCount: countFields(body), pageCount: body.PageTypes.length,
      jobCount: 0, stpRate: null, status: 'draft',
      version: 1, lastModifiedAt: new Date().toISOString(), lastModifiedBy: 'studio-admin',
    };
    DOC_TYPES_MOCK.push(record);
    return of({ ...record }).pipe(delay(60));
  }

  updateDocumentType(
    appId: string, docTypeId: string, body: ConfigDocumentType, expectedVersion: number,
  ): Observable<DocumentTypeRecord> {
    const idx = DOC_TYPES_MOCK.findIndex(d => d.appId === appId && d.docTypeId === docTypeId);
    if (idx === -1) return throwError(() => new Error(`Document type ${appId}/${docTypeId} not found`));
    const current = DOC_TYPES_MOCK[idx];
    if (current.version !== expectedVersion) {
      return throwError(() => new VersionConflictError('DOC_TYPE', docTypeId, current.version));
    }
    const updated: DocumentTypeRecord = {
      ...current, body,
      fieldCount: countFields(body), pageCount: body.PageTypes.length,
      version: current.version + 1,
      lastModifiedAt: new Date().toISOString(), lastModifiedBy: 'studio-admin',
    };
    DOC_TYPES_MOCK[idx] = updated;
    return of({ ...updated }).pipe(delay(60));
  }

  deleteDocumentType(appId: string, docTypeId: string): Observable<void> {
    const before = DOC_TYPES_MOCK.length;
    for (let i = DOC_TYPES_MOCK.length - 1; i >= 0; i--) {
      if (DOC_TYPES_MOCK[i].appId === appId && DOC_TYPES_MOCK[i].docTypeId === docTypeId) {
        DOC_TYPES_MOCK.splice(i, 1);
      }
    }
    if (DOC_TYPES_MOCK.length === before) {
      return throwError(() => new Error(`Document type ${appId}/${docTypeId} not found`));
    }
    return of(void 0).pipe(delay(60));
  }

  // ═══════════════════════════════════════════════════════════════════
  // Dictionaries — MOCK
  // ═══════════════════════════════════════════════════════════════════

  listDictionaries(): Observable<DictionaryRecord[]> {
    return of(DICTIONARIES_MOCK.map(d => ({ ...d }))).pipe(delay(50));
  }
  getDictionary(name: string): Observable<DictionaryRecord> {
    const d = DICTIONARIES_MOCK.find(x => x.name === name);
    return d ? of({ ...d }).pipe(delay(40))
             : throwError(() => new Error(`Dictionary ${name} not found`));
  }
  saveDictionary(name: string, options: FieldOption[], expectedVersion: number): Observable<DictionaryRecord> {
    const idx = DICTIONARIES_MOCK.findIndex(x => x.name === name);
    if (idx === -1) {
      const created: DictionaryRecord = {
        name, options, version: 1,
        lastModifiedAt: new Date().toISOString(), lastModifiedBy: 'studio-admin',
      };
      DICTIONARIES_MOCK.push(created);
      return of({ ...created }).pipe(delay(50));
    }
    const current = DICTIONARIES_MOCK[idx];
    if (current.version !== expectedVersion) {
      return throwError(() => new VersionConflictError('DICTIONARY', name, current.version));
    }
    const updated: DictionaryRecord = {
      name, options,
      version: current.version + 1,
      lastModifiedAt: new Date().toISOString(), lastModifiedBy: 'studio-admin',
    };
    DICTIONARIES_MOCK[idx] = updated;
    return of({ ...updated }).pipe(delay(50));
  }
}

// ─── Errors ───────────────────────────────────────────────────────────

/**
 * Thrown when a save's expectedVersion doesn't match the current row.
 * The HTTP interceptor produces this for 409 responses; the mock
 * document-type/dictionary methods also throw it locally.
 */
export class VersionConflictError extends Error {
  constructor(
    public readonly kind: 'APPLICATION' | 'DOC_TYPE' | 'DICTIONARY' | string,
    public readonly id: string,
    public readonly currentVersion: number,
  ) {
    super(`${kind} ${id} was modified by someone else (now at v${currentVersion}).`);
    this.name = 'VersionConflictError';
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────

function versionHeader(v: number): HttpHeaders {
  return new HttpHeaders({ 'X-Expected-Version': String(v) });
}

function stripBody(d: DocumentTypeRecord): DocumentTypeSummary {
  const { body: _body, ...summary } = d;
  return summary;
}

function countFields(body: ConfigDocumentType): number {
  return body.PageTypes.reduce((sum, pt) => sum + (pt.Fields?.length ?? 0), 0);
}

// ─── Mock data (Document Types + Dictionaries) ────────────────────────

const NOW = new Date().toISOString();

const DOC_TYPES_MOCK: DocumentTypeRecord[] = [
  makeDocType('LOANS',  'LOAN_APPLICATION', 'Loan Application',   5, 14, 2, 82,   'active',  7, '2 days ago'),
  makeDocType('LOANS',  'INCOME_STMT',      'Income Statement',   2,  8, 1, 91,   'active',  4, '1 week ago'),
  makeDocType('LOANS',  'ID_PROOF',         'ID Proof',           1,  4, 0, 94,   'draft',   1, '1 month ago'),
  makeDocType('LOANS',  'BANK_STMT',        'Bank Statement',     3, 11, 1, 44,   'active',  3, 'yesterday'),
  makeDocType('CLAIMS', 'CLAIM_FORM',       'Claim Form',         8, 22, 1, 61,   'active', 12, '3 days ago'),
  makeDocType('CLAIMS', 'MEDICAL_CERT',     'Medical Certificate',4, 16, 1, 67,   'active',  2, '3 weeks ago'),
  makeDocType('CLAIMS', 'POLICY_CANCEL',    'Policy Cancellation',1,  5, 1, 88,   'active',  6, '1 week ago'),
  makeDocType('CLAIMS', 'BENEFICIARY',      'Beneficiary Change', 2,  6, 0, null, 'draft',   1, '2 weeks ago'),
  makeDocType('CLAIMS', 'COVERAGE_UPD',     'Coverage Update',    3, 11, 1, 44,   'active',  3, 'yesterday'),
  makeDocType('HR',     'OFFER_LETTER',     'Offer Letter',       2,  9, 1, 78,   'active',  5, '5 days ago'),
  makeDocType('HR',     'W4',               'W-4 Form',           1,  7, 0, null, 'draft',   1, 'today'),
];

function makeDocType(
  appId: string, docTypeId: string, name: string,
  pageCount: number, fieldCount: number, jobCount: number,
  stpRate: number | null, status: 'draft' | 'active' | 'archived',
  version: number, label: string,
): DocumentTypeRecord {
  return {
    appId, docTypeId, name,
    body: { DocumentTypeName: docTypeId, PageTypes: [{ PageType: 'MainPage', Fields: [] }] },
    pageCount, fieldCount, jobCount, stpRate,
    status: status as any, version,
    lastModifiedAt: NOW, lastModifiedBy: 'studio-admin', lastModifiedLabel: label,
  };
}

const DICTIONARIES_MOCK: DictionaryRecord[] = [
  {
    name: 'TransCodes',
    options: [
      { Value: 'ARCHIVE',   Label: 'Archive' },
      { Value: 'NO_NUMBER', Label: 'No Number' },
      { Value: 'TRASH',     Label: 'Trash' },
      { Value: 'WORKFLOW',  Label: 'Workflow' },
    ],
    version: 1, lastModifiedAt: NOW, lastModifiedBy: 'studio-admin',
  },
];
