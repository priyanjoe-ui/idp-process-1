import { Routes } from '@angular/router';
import { ShellComponent } from './layout/shell/shell.component';

export const routes: Routes = [
  {
    path: '',
    component: ShellComponent,
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },

      {
        path: 'dashboard',
        loadComponent: () =>
          import('./features/dashboard/dashboard.component').then(m => m.DashboardComponent),
      },

      // Applications ------------------------------------------------
      {
        path: 'applications',
        loadComponent: () =>
          import('./features/applications/list/applications-list.component').then(
            m => m.ApplicationsListComponent,
          ),
      },
      {
        path: 'applications/:appId/document-types',
        loadComponent: () =>
          import('./features/document-types/list/document-types-list.component').then(
            m => m.DocumentTypesListComponent,
          ),
      },

      // Global document-types view (across all applications, powered by GSI)
      {
        path: 'document-types',
        loadComponent: () =>
          import('./features/document-types/list/document-types-list.component').then(
            m => m.DocumentTypesListComponent,
          ),
      },

      // Stubs -------------------------------------------------------
      {
        path: 'jobs',
        loadComponent: () => import('./features/stub/stub.component').then(m => m.StubComponent),
        data: { title: 'Jobs & Workflows' },
      },
      {
        path: 'connectors',
        loadComponent: () => import('./features/stub/stub.component').then(m => m.StubComponent),
        data: { title: 'Connectors' },
      },
      {
        path: 'test-bench',
        loadComponent: () => import('./features/stub/stub.component').then(m => m.StubComponent),
        data: { title: 'Test Bench' },
      },
      {
        path: 'deployments',
        loadComponent: () => import('./features/stub/stub.component').then(m => m.StubComponent),
        data: { title: 'Deployments' },
      },
      {
        path: 'users',
        loadComponent: () => import('./features/stub/stub.component').then(m => m.StubComponent),
        data: { title: 'Users & Access' },
      },
      {
        path: 'settings',
        loadComponent: () => import('./features/stub/stub.component').then(m => m.StubComponent),
        data: { title: 'Settings' },
      },
    ],
  },
  { path: '**', redirectTo: '' },
];
