import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, computed, inject, OnInit, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ApplicationSummary } from '@akrify/shared';
import { StudioConfigService } from '../../../services/studio-config.service';

@Component({
  selector: 'app-applications-list',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './applications-list.component.html',
  styleUrls: ['./applications-list.component.scss'],
})
export class ApplicationsListComponent implements OnInit {
  private readonly configService = inject(StudioConfigService);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly rows = signal<ApplicationSummary[]>([]);
  readonly search = signal('');

  readonly filtered = computed(() => {
    const q = this.search().trim().toLowerCase();
    if (!q) return this.rows();
    return this.rows().filter(
      a => a.name.toLowerCase().includes(q) || a.appId.toLowerCase().includes(q),
    );
  });

  ngOnInit() {
    this.configService.listApplications().subscribe({
      next: rows => {
        this.rows.set(rows);
        this.loading.set(false);
      },
      error: err => {
        this.error.set(err?.message || 'Failed to load applications.');
        this.loading.set(false);
      },
    });
  }

  onSearchInput(v: string) { this.search.set(v); }

  /** Palette for the small colored app-glyph on each card. Deterministic per appId. */
  glyphColor(appId: string): string {
    const palette = ['#4F46E5', '#7C3AED', '#0891B2', '#059669', '#D97706', '#DB2777'];
    let hash = 0;
    for (let i = 0; i < appId.length; i++) hash = (hash * 31 + appId.charCodeAt(i)) >>> 0;
    return palette[hash % palette.length];
  }

  initial(name: string): string {
    return name.trim()[0]?.toUpperCase() ?? '?';
  }
}
