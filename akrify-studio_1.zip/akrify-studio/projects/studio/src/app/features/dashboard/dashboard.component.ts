import { CommonModule, DecimalPipe, PercentPipe } from '@angular/common';
import { Component, computed, inject, OnInit, signal } from '@angular/core';
import { DashboardSnapshot, ServiceHealthState, VolumePoint } from '@akrify/shared';
import { DashboardService } from '../../services/dashboard.service';

interface ChartBar {
  day: string;
  segments: { key: string; height: number; y: number; color: string }[];
  total: number;
}

const SERIES: { key: string; label: string; color: string }[] = [
  { key: 'newPolicy', label: 'New Policy',    color: '#4F46E5' },
  { key: 'renewal',   label: 'Renewal',       color: '#7C3AED' },
  { key: 'claim',     label: 'Claim',         color: '#A78BFA' },
  { key: 'other',     label: 'Other',         color: '#C7D2FE' },
];

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, DecimalPipe, PercentPipe],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent implements OnInit {
  private readonly dashboardService = inject(DashboardService);

  readonly snapshot = signal<DashboardSnapshot | null>(null);
  readonly loading = signal(true);

  readonly series = SERIES;

  readonly chart = computed(() => {
    const snap = this.snapshot();
    if (!snap) return { bars: [] as ChartBar[], max: 0, yTicks: [] as number[] };
    return buildChart(snap.volume);
  });

  ngOnInit() {
    this.dashboardService.getSnapshot().subscribe(s => {
      this.snapshot.set(s);
      this.loading.set(false);
    });
  }

  healthChipClass(state: ServiceHealthState): string {
    switch (state) {
      case 'healthy':   return 'chip chip-success';
      case 'paused':    return 'chip chip-neutral';
      case 'degraded':  return 'chip chip-warning';
      case 'down':      return 'chip chip-danger';
      default:          return 'chip chip-neutral';
    }
  }

  confidenceChipClass(c: 'high' | 'med' | 'low'): string {
    return c === 'high' ? 'chip chip-success' : c === 'med' ? 'chip chip-warning' : 'chip chip-danger';
  }
}

const CHART_HEIGHT = 180;

function buildChart(points: VolumePoint[]): { bars: ChartBar[]; max: number; yTicks: number[] } {
  const totals = points.map(p => Object.values(p.values).reduce((a, b) => a + b, 0));
  const rawMax = Math.max(...totals, 1);
  const max = niceCeiling(rawMax);
  const bars: ChartBar[] = points.map((p, _i) => {
    let cursorY = CHART_HEIGHT;
    const segments = SERIES.map(s => {
      const value = p.values[s.key] ?? 0;
      const height = (value / max) * CHART_HEIGHT;
      cursorY -= height;
      return { key: s.key, height, y: cursorY, color: s.color };
    });
    return { day: p.day, segments, total: totals[_i] };
  });
  const yTicks = [0, max * 0.25, max * 0.5, max * 0.75, max].map(v => Math.round(v));
  return { bars, max, yTicks };
}

function niceCeiling(n: number): number {
  const magnitude = Math.pow(10, Math.floor(Math.log10(n)));
  const scaled = n / magnitude;
  const nice = scaled <= 2 ? 2 : scaled <= 5 ? 5 : 10;
  return nice * magnitude;
}
