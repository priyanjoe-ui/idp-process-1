export const environment = {
  production: false,
  envLabel: 'dev',
  envTone: 'neutral' as 'neutral' | 'warning' | 'danger',
  /**
   * Base URL for the idp-api-proxy Lambda (or the local proxy).
   * Local dev typical:  'http://localhost:3001/api'
   * Deployed:           'https://<lambda-function-url>/api'
   * UPDATE THIS to your actual proxy URL.
   */
  apiBaseUrl: 'http://localhost:3001/api',
};
