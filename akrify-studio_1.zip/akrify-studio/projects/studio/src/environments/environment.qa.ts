export const environment = {
  production: false,
  envLabel: 'qa',
  envTone: 'warning' as 'neutral' | 'warning' | 'danger',
  apiBaseUrl: 'https://api-qa.idp.example.com',
};
