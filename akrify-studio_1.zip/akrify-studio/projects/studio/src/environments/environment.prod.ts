export const environment = {
  production: true,
  envLabel: 'prod',
  envTone: 'danger' as 'neutral' | 'warning' | 'danger',
  apiBaseUrl: 'https://api.idp.example.com',
};
