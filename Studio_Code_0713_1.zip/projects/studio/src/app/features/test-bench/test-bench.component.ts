import { CommonModule } from '@angular/common';
import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { ApplicationSummary, DocumentTypeSummary, TestBenchRunResult } from '@akrify/shared';
import { StudioConfigService } from '../../services/studio-config.service';
import { TestBenchService } from './test-bench.service';

const ACCEPTED_EXTENSIONS = ['.tif', '.tiff', '.zip'];

@Component({
  selector: 'app-test-bench',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './test-bench.component.html',
  styleUrls: ['./test-bench.component.scss'],
})
export class TestBenchComponent implements OnInit {
  private readonly configService = inject(StudioConfigService);
  private readonly testBenchService = inject(TestBenchService);

  // Selector data --------------------------------------------------------
  readonly applications = signal<ApplicationSummary[]>([]);
  readonly documentTypes = signal<DocumentTypeSummary[]>([]);
  readonly applicationsLoading = signal(true);
  readonly documentTypesLoading = signal(false);

  readonly selectedAppId = signal<string | null>(null);
  readonly selectedDocTypeId = signal<string | null>(null);

  // Upload + run state -----------------------------------------------------
  readonly selectedFile = signal<File | null>(null);
  readonly dragOver = signal(false);
  readonly running = signal(false);
  readonly error = signal<string | null>(null);
  readonly result = signal<TestBenchRunResult | null>(null);
  readonly selectedPageNumber = signal<number | null>(null);

  readonly selectedApp = computed(() =>
    this.applications().find(a => a.appId === this.selectedAppId()) ?? null,
  );
  readonly selectedDocType = computed(() =>
    this.documentTypes().find(d => d.docTypeId === this.selectedDocTypeId()) ?? null,
  );
  readonly canRun = computed(() =>
    !!this.selectedAppId() && !!this.selectedDocTypeId() && !!this.selectedFile() && !this.running(),
  );
  readonly selectedPage = computed(() => {
    const r = this.result();
    const n = this.selectedPageNumber();
    if (!r || n == null) return null;
    return r.pages.find(p => p.pageNumber === n) ?? null;
  });

  ngOnInit(): void {
    this.configService.listApplications().subscribe({
      next: apps => {
        this.applications.set(apps);
        this.applicationsLoading.set(false);
      },
      error: () => this.applicationsLoading.set(false),
    });
  }

  onAppChange(appId: string): void {
    this.selectedAppId.set(appId || null);
    this.selectedDocTypeId.set(null);
    this.documentTypes.set([]);
    this.resetRun();
    if (!appId) return;

    this.documentTypesLoading.set(true);
    this.configService.listDocumentTypes(appId).subscribe({
      next: dts => {
        this.documentTypes.set(dts);
        this.documentTypesLoading.set(false);
      },
      error: () => this.documentTypesLoading.set(false),
    });
  }

  onDocTypeChange(docTypeId: string): void {
    this.selectedDocTypeId.set(docTypeId || null);
    this.resetRun();
  }

  onDragOver(event: DragEvent): void {
    event.preventDefault();
    this.dragOver.set(true);
  }

  onDragLeave(): void {
    this.dragOver.set(false);
  }

  onDrop(event: DragEvent): void {
    event.preventDefault();
    this.dragOver.set(false);
    const file = event.dataTransfer?.files?.[0];
    if (file) this.setFile(file);
  }

  onFileInputChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (file) this.setFile(file);
    input.value = ''; // allow re-selecting a file with the same name later
  }

  private setFile(file: File): void {
    const lower = file.name.toLowerCase();
    if (!ACCEPTED_EXTENSIONS.some(ext => lower.endsWith(ext))) {
      this.error.set(`"${file.name}" isn't a supported file type -- Test Bench accepts .tif, .tiff, or .zip`);
      return;
    }
    this.error.set(null);
    this.result.set(null);
    this.selectedPageNumber.set(null);
    this.selectedFile.set(file);
  }

  /** Clears the selected file, the last result, and any error -- keeps
   *  the Application/Document Type selection, since testing another
   *  sample against the same config is the common next action. */
  resetRun(): void {
    this.selectedFile.set(null);
    this.result.set(null);
    this.selectedPageNumber.set(null);
    this.error.set(null);
  }

  runTest(): void {
    const appId = this.selectedAppId();
    const docTypeId = this.selectedDocTypeId();
    const file = this.selectedFile();
    if (!appId || !docTypeId || !file) return;

    this.running.set(true);
    this.error.set(null);
    this.result.set(null);

    this.testBenchService.runTest(appId, docTypeId, file).subscribe({
      next: res => {
        this.running.set(false);
        this.result.set(res);
        this.selectedPageNumber.set(res.pages[0]?.pageNumber ?? null);
      },
      error: err => {
        this.running.set(false);
        // Matches the proxy's jsonError() shape exactly: { error: code, message }.
        this.error.set(err?.error?.message || 'Test Bench run failed -- please try again');
      },
    });
  }

  selectPage(pageNumber: number): void {
    this.selectedPageNumber.set(pageNumber);
  }

  confidenceChipClass(confidence: number | null): string {
    if (confidence == null) return 'chip-neutral';
    if (confidence >= 90) return 'chip-success';
    if (confidence >= 70) return 'chip-warning';
    return 'chip-danger';
  }
}
