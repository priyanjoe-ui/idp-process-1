/* ================================================================
   Amazon States Language (ASL) types.

   These mirror ASL directly — the Jobs & Workflow Builder canvas edits
   objects of this exact shape, and Deploy sends `AslDefinition` straight
   to `CreateStateMachine`/`UpdateStateMachine` with no translation layer.
   Scoped to what the IDP pipeline actually uses: Task and Choice states
   are fully supported; Wait/Parallel/Map/Succeed/Fail are typed for
   forward-compatibility but not yet editable in the inspector.
   ================================================================ */

export type AslStateType = 'Task' | 'Choice' | 'Wait' | 'Parallel' | 'Map' | 'Succeed' | 'Fail';

export interface AslRetry {
  ErrorEquals: string[];
  IntervalSeconds: number;
  MaxAttempts: number;
  BackoffRate: number;
}

export interface AslCatch {
  ErrorEquals: string[];
  Next: string;
}

export interface AslChoiceRule {
  Variable: string;
  BooleanEquals?: boolean;
  StringEquals?: string;
  NumericEquals?: number;
  Next: string;
}

export interface AslState {
  Type: AslStateType;
  Resource?: string;
  Parameters?: Record<string, any>;
  ResultPath?: string;
  Next?: string;
  End?: boolean;
  TimeoutSeconds?: number;
  Retry?: AslRetry[];
  Catch?: AslCatch[];
  Choices?: AslChoiceRule[];
  Default?: string;
  Comment?: string;
  /** Fail state only. */
  Error?: string;
  Cause?: string;
  /** Wait state only — exactly one of these is set. */
  Seconds?: number;
  Timestamp?: string;
}

export interface AslDefinition {
  Comment?: string;
  StartAt: string;
  States: Record<string, AslState>;
}

/** Task integration pattern, inferred from Resource shape — not a literal
 *  ASL field, a Studio-only concept for the inspector's dropdown. */
export type TaskIntegrationPattern = 'RequestResponse' | 'WaitForTaskToken' | 'RunAJob';
