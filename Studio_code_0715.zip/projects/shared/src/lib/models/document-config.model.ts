/* ================================================================
   Document Config models — the source-of-truth schema shared by the
   runtime IDP pipeline (Lambdas + Step Functions) and the Studio UI.

   These names use PascalCase to stay wire-compatible with the
   existing document-config.json used by the runtime today.
   ================================================================ */

export type FieldDataType = 'String' | 'Number' | 'Date' | 'Currency' | 'Dropdown' | 'Boolean' | string;

/** Method used to pull a value off a page. */
export type ExtractionMethod = 'Anchor' | 'Position' | 'Regex' | 'AI';

/** Lifecycle status of a config artifact. */
export type ConfigStatus = 'draft' | 'active' | 'archived';

export interface FieldOption {
  Value: string;
  Label: string;
}

/** AI-extraction config for a single field (used when ExtractionMethod === 'AI'). */
export interface AiExtractionConfig {
  /** Bedrock model id, e.g. 'claude-sonnet-4-6'. */
  Model?: string;
  /** Natural-language description passed into the extraction prompt. */
  Description: string;
  /** Optional few-shot example values to steer the model. */
  Examples?: string[];
  /** Fallback method when AI confidence is below threshold or extraction fails. */
  Fallback?: Exclude<ExtractionMethod, 'AI'>;
}

/** Fixed on-page coordinates for the Position extraction method. */
export interface FieldPosition {
  /** 1-based page number within the page type, for multi-page page types. */
  Page?: number;
  X: number;
  Y: number;
  Width: number;
  Height: number;
}

/**
 * Validation is independent of how a value was extracted (AI, Anchor,
 * Regex, Position) — a field extracted via AI still needs its format
 * checked, same as one extracted via regex.
 *
 * 'Format' reuses the existing ValidationRegex (non-Date types) or Format
 * (Date types, e.g. "YYYYMMDD") fields below — no separate storage needed.
 * A dedicated 'Length' type was considered and dropped: a regex like
 * `{6,12}` already encodes length as part of the pattern, so Format
 * subsumes it.
 */
export type ValidationType = 'Format' | 'Range';

/** A field definition on a page type. */
export interface ConfigField {
  FieldName: string;
  Label: string;
  DataType: FieldDataType;
  Required?: boolean;
  Disabled?: boolean;

  Options?: FieldOption[];
  OptionsRef?: string;
  DefaultValue?: string | null;
  AutoPopulateFrom?: string;
  /** Date-format string (e.g. "YYYYMMDD") when DataType is 'Date' and 'Format' validation is on. */
  Format?: string;
  Transform?: string;

  /** Explicit extraction method. When absent, runtime falls back to Regex/Keyword heuristics. */
  ExtractionMethod?: ExtractionMethod;
  ExtractionRegex?: string;
  /** Pattern the extracted value must match, when 'Format' validation is on and DataType isn't 'Date'. */
  ValidationRegex?: string;
  ConfidenceScore?: number;
  FieldKeywords?: string[];
  AI?: AiExtractionConfig;
  /** Used when ExtractionMethod === 'Position'. */
  Position?: FieldPosition;

  /** Which validation types are active. Undefined/absent = validation off
   *  for this field (matches most fields in the real data, which have none). */
  ValidationTypes?: ValidationType[];
  /** Used when 'Range' validation is on. */
  MinValue?: number;
  MaxValue?: number;
}

export interface ConfigLineItemColumn extends ConfigField {}

export interface ConfigLineItems {
  Name: string;
  EmptyText?: string;
  MinRows?: number;
  Columns: ConfigLineItemColumn[];
  Position?: number;
}

/** How a page is recognized as belonging to a given page type. */
export type PageIdentificationMethod = 'Sequential' | 'Keyword' | 'WordCount';

export interface ConfigPageType {
  PageType: string;
  Fields?: ConfigField[];
  /** A page can have any number of Line Items tables (repeating grids,
   *  typically Textract table extractions) — not limited to one. */
  LineItems?: ConfigLineItems[];
  Keywords?: string[];

  /** How this page type is identified. Defaults to 'Keyword' when absent. */
  IdentificationMethod?: PageIdentificationMethod;
  /** Position within the document type, 1-based. Drives 'Sequential' identification
   *  and also doubles as display/processing order regardless of method. */
  SequenceOrder?: number;
  /** Used when IdentificationMethod === 'WordCount' (typically the BlankPage type):
   *  pages with fewer words than this are treated as this page type. */
  MaxWordCount?: number;
}

/**
 * Decides which DOCUMENT TYPE a batch belongs to in the first place — a
 * different layer than ConfigPageType's per-page identification (which
 * distinguishes page types *within* an already-identified document type).
 */
export interface ClassificationConfig {
  Keywords: string[];
  /** Minimum keyword-match confidence required to classify a batch as this document type. */
  ConfidenceThreshold?: number;
}

/** How pages within this document type get classified at runtime.
 *  'Sequential' — position-based (the Nth page of the batch is always the
 *  Nth page type). 'Keyword' — OCR text matching against each page
 *  type's Keywords. This is a whole-document-type switch, not mixable
 *  per page — the runtime pipeline classifies every page in a batch with
 *  one algorithm or the other, not a blend. */
export type DocumentClassificationMode = 'Sequential' | 'Keyword';

export interface ConfigDocumentType {
  DocumentTypeName: string;
  PageTypes: ConfigPageType[];
  Classification?: ClassificationConfig;
  /** Seeds the IdentificationMethod assigned to auto-created pages when
   *  this document type is first created (Sequential+SequenceOrder, or
   *  Keyword with an empty Keywords list to fill in). Editing this later
   *  does not retroactively change existing pages — it's a default for
   *  new pages, not a live binding, so customizing a page's own method
   *  afterward is never silently overwritten. */
  ClassificationMode?: DocumentClassificationMode;
  /** Seeds the auto-created BlankPage's MaxWordCount. Same non-retroactive
   *  behavior as ClassificationMode above. */
  BlankPageMaxWordCount?: number;
}

export interface ConfigApplication {
  ApplicationName: string;
  ClassificationMode?: 'Sequential' | 'Parallel' | string;
  DocumentTypes: ConfigDocumentType[];
}

export interface DocumentConfig {
  Applications: ConfigApplication[];
  Dictionaries?: Record<string, FieldOption[]>;
}
