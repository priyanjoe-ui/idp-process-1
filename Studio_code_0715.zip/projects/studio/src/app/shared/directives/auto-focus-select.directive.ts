import { AfterViewInit, Directive, ElementRef } from '@angular/core';

/**
 * Focuses and selects all text in an input as soon as it's rendered.
 * Used for inline-rename fields — e.g. double-clicking a name to edit it,
 * or a freshly-created item whose default name should be immediately
 * replaceable by typing.
 *
 * Usage: <input appAutoFocusSelect ... />
 */
@Directive({
  selector: '[appAutoFocusSelect]',
  standalone: true,
})
export class AutoFocusSelectDirective implements AfterViewInit {
  constructor(private readonly el: ElementRef<HTMLInputElement>) {}

  ngAfterViewInit() {
    // Deferred a tick so the element is fully in the DOM (it's typically
    // rendered via *ngIf toggling on the same change-detection cycle).
    setTimeout(() => {
      this.el.nativeElement.focus();
      this.el.nativeElement.select();
    });
  }
}
