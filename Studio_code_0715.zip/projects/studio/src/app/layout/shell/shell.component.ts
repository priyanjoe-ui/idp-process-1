import { CommonModule } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { environment } from '../../../environments/environment';
import { OperatorService } from '../../services/operator.service';

interface NavItem {
  label: string;
  route: string;
  icon: string;
  group: 'standalone' | 'build' | 'automate' | 'manage';
}

@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, RouterOutlet],
  templateUrl: './shell.component.html',
  styleUrls: ['./shell.component.scss'],
})
export class ShellComponent {
  readonly envLabel = environment.envLabel;
  readonly envTone = environment.envTone;
  readonly collapsed = signal(false);

  toggleCollapsed() {
    this.collapsed.update(v => !v);
  }

  private readonly operatorService = inject(OperatorService);

  // Was a local hardcoded signal ("Placeholder until auth wires in").
  // Now backed by OperatorService, the single source of truth read by both
  // this display and the HTTP interceptor that stamps X-Operator on every
  // request -- what lets the audit log attribute changes to a real name.
  readonly user = this.operatorService.current;

  /** Minimal, no-verification way to change who you're identified as --
   *  same honest scope as the header this feeds (X-Operator), just with a
   *  UI entry point instead of editing localStorage by hand. Swap for a
   *  real login flow later without touching anything downstream, since
   *  everything else reads OperatorService.current, not this method. */
  changeOperatorName(): void {
    const next = window.prompt('Signed in as:', this.user().name);
    if (next && next.trim()) this.operatorService.setName(next);
  }

  readonly version = 'v0.5.0 · Bedrock';

  readonly navItems: NavItem[] = [
    {
      label: 'Dashboard',
      route: '/dashboard',
      group: 'standalone',
      icon: 'M4 11.5 12 4l8 7.5M6 10v9a1 1 0 0 0 1 1h3v-6h4v6h3a1 1 0 0 0 1-1v-9',
    },
    {
      label: 'Applications',
      route: '/applications',
      group: 'build',
      icon: 'M4 5a2 2 0 0 1 2-2h4l2 2h6a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V5z',
    },
    {
      label: 'Document Types',
      route: '/document-types',
      group: 'build',
      icon: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zM8 13h8v2H8v-2zm0 4h5v2H8v-2zm5-9h5l-5-5v5z',
    },
    {
      label: 'Dictionaries',
      route: '/dictionaries',
      group: 'build',
      icon: 'M4 19.5A2.5 2.5 0 0 1 6.5 17H20M4 4.5A2.5 2.5 0 0 1 6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15z',
    },
    {
      label: 'Jobs & Workflows',
      route: '/workflows',
      group: 'automate',
      icon: 'M4 6h12l-3-3m3 3-3 3M20 18H8l3 3m-3-3 3-3',
    },
    {
      label: 'Connectors',
      route: '/connectors',
      group: 'automate',
      icon: 'M7 10V7a5 5 0 0 1 10 0v3m-1 4h-8a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2z',
    },
    {
      label: 'Test Bench',
      route: '/test-bench',
      group: 'automate',
      icon: 'M8 5v14l11-7L8 5z',
    },
    {
      label: 'Deployments',
      route: '/deployments',
      group: 'automate',
      icon: 'M12 3l8 4-8 4-8-4 8-4zm-8 9 8 4 8-4M4 17l8 4 8-4',
    },
    {
      label: 'Users & Access',
      route: '/users',
      group: 'manage',
      icon: 'M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm14 10v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75',
    },
    {
      label: 'Settings',
      route: '/settings',
      group: 'manage',
      icon: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm7.4-3a7.4 7.4 0 0 0-.1-1.2l2.1-1.6-2-3.5-2.5 1a7.5 7.5 0 0 0-2-1.2L14.5 3h-5l-.4 2.5a7.5 7.5 0 0 0-2 1.2l-2.5-1-2 3.5 2.1 1.6a7.4 7.4 0 0 0 0 2.4l-2.1 1.6 2 3.5 2.5-1a7.5 7.5 0 0 0 2 1.2L9.5 21h5l.4-2.5a7.5 7.5 0 0 0 2-1.2l2.5 1 2-3.5-2.1-1.6c.07-.4.1-.8.1-1.2z',
    },
  ];

  readonly standaloneItems = this.navItems.filter(i => i.group === 'standalone');
  readonly buildItems = this.navItems.filter(i => i.group === 'build');
  readonly automateItems = this.navItems.filter(i => i.group === 'automate');
  readonly manageItems = this.navItems.filter(i => i.group === 'manage');

  readonly userInitial = () => this.user().name[0]?.toUpperCase() ?? '?';
}
