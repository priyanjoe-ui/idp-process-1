import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, EventEmitter, Input, Output, computed, inject, signal } from '@angular/core';
import { ApplicationSummary } from '@akrify/shared';
import { StudioConfigService } from '../../../services/studio-config.service';

/**
 * Destructive, cascading delete — removes the Application row AND every
 * Document Type under it (backend cascades this in one call). Requires
 * typing the Application ID to confirm, rather than a plain Yes/No dialog,
 * since a mis-click here can't be undone.
 */
@Component({
  selector: 'app-delete-application-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './delete-application-modal.component.html',
  styleUrls: ['./delete-application-modal.component.scss'],
})
export class DeleteApplicationModalComponent {
  private readonly configService = inject(StudioConfigService);

  @Input({ required: true }) app!: ApplicationSummary;

  @Output() closed = new EventEmitter<void>();
  @Output() deleted = new EventEmitter<string>(); // emits appId

  readonly confirmText = signal('');
  readonly deleting = signal(false);
  readonly error = signal<string | null>(null);

  readonly canDelete = computed(() =>
    this.confirmText().trim() === this.app.appId && !this.deleting(),
  );

  onConfirmInput(v: string) {
    this.confirmText.set(v);
  }

  confirmDelete() {
    if (!this.canDelete()) return;
    this.deleting.set(true);
    this.error.set(null);
    this.configService.deleteApplication(this.app.appId).subscribe({
      next: () => {
        this.deleting.set(false);
        this.deleted.emit(this.app.appId);
      },
      error: err => {
        this.deleting.set(false);
        this.error.set(err?.message || 'Failed to delete application.');
      },
    });
  }

  cancel() {
    if (this.deleting()) return;
    this.closed.emit();
  }
}
