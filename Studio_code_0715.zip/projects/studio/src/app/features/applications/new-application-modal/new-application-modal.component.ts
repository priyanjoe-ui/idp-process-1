import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, EventEmitter, Output, inject, signal } from '@angular/core';
import { StudioConfigService } from '../../../services/studio-config.service';
import { ApplicationSummary } from '@akrify/shared';

/**
 * Minimal creation form — App ID and Display Name only. Classification Mode
 * defaults server-side to 'Sequential'; there's no per-app UI to change it
 * yet (not requested). If that's ever needed, add an Application settings
 * surface rather than growing this modal.
 */
@Component({
  selector: 'app-new-application-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './new-application-modal.component.html',
  styleUrls: ['./new-application-modal.component.scss'],
})
export class NewApplicationModalComponent {
  private readonly configService = inject(StudioConfigService);

  @Output() closed = new EventEmitter<void>();
  @Output() created = new EventEmitter<ApplicationSummary>();

  readonly appId = signal('');
  readonly name = signal('');
  readonly submitting = signal(false);
  readonly error = signal<string | null>(null);

  readonly idPattern = /^[A-Z0-9_]+$/;

  readonly idError = () => {
    const v = this.appId().trim();
    if (!v) return null;
    return this.idPattern.test(v) ? null : 'Use only uppercase letters, numbers, and underscores.';
  };

  readonly canSubmit = () =>
    this.appId().trim().length > 0 &&
    this.name().trim().length > 0 &&
    !this.idError() &&
    !this.submitting();

  onIdInput(raw: string) {
    this.appId.set(raw.toUpperCase().replace(/\s+/g, '_'));
  }

  submit() {
    if (!this.canSubmit()) return;
    this.submitting.set(true);
    this.error.set(null);
    this.configService.createApplication({
      appId: this.appId().trim(),
      name: this.name().trim(),
    }).subscribe({
      next: record => {
        this.submitting.set(false);
        this.created.emit(record);
      },
      error: err => {
        this.submitting.set(false);
        this.error.set(err?.message || 'Failed to create application.');
      },
    });
  }

  cancel() {
    if (this.submitting()) return;
    this.closed.emit();
  }
}
