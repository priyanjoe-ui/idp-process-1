import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, computed, inject, OnInit, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { ApplicationSummary } from '@akrify/shared';
import { StudioConfigService } from '../../../services/studio-config.service';
import { NewApplicationModalComponent } from '../new-application-modal/new-application-modal.component';
import { DeleteApplicationModalComponent } from '../delete-application-modal/delete-application-modal.component';

@Component({
  selector: 'app-applications-list',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, NewApplicationModalComponent, DeleteApplicationModalComponent],
  templateUrl: './applications-list.component.html',
  styleUrls: ['./applications-list.component.scss'],
})
export class ApplicationsListComponent implements OnInit {
  private readonly configService = inject(StudioConfigService);
  private readonly router = inject(Router);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly rows = signal<ApplicationSummary[]>([]);
  readonly search = signal('');
  readonly showCreateModal = signal(false);
  readonly pendingDelete = signal<ApplicationSummary | null>(null);

  readonly filtered = computed(() => {
    const q = this.search().trim().toLowerCase();
    if (!q) return this.rows();
    return this.rows().filter(
      a => a.name.toLowerCase().includes(q) || a.appId.toLowerCase().includes(q),
    );
  });

  ngOnInit() {
    this.load();
  }

  load() {
    this.loading.set(true);
    this.error.set(null);
    this.configService.listApplications().subscribe({
      next: rows => {
        this.rows.set(rows);
        this.loading.set(false);
      },
      error: err => {
        this.error.set(err?.message || 'Failed to load applications.');
        this.loading.set(false);
      },
    });
  }

  onSearchInput(v: string) { this.search.set(v); }

  openCreateModal()  { this.showCreateModal.set(true); }
  closeCreateModal() { this.showCreateModal.set(false); }

  /** After creating an application, go straight into its (empty) Document Types list. */
  onApplicationCreated(created: ApplicationSummary) {
    this.showCreateModal.set(false);
    this.router.navigate(['/applications', created.appId, 'document-types']);
  }

  /** Stops the card's routerLink navigation so the trash icon doesn't also open the app. */
  openDeleteModal(app: ApplicationSummary, event: Event) {
    event.preventDefault();
    event.stopPropagation();
    this.pendingDelete.set(app);
  }
  closeDeleteModal() { this.pendingDelete.set(null); }

  onApplicationDeleted(appId: string) {
    this.pendingDelete.set(null);
    this.rows.update(rows => rows.filter(a => a.appId !== appId));
  }

  /** Palette for the small colored app-glyph on each card. Deterministic per appId. */
  glyphColor(appId: string): string {
    const palette = ['#4F46E5', '#7C3AED', '#0891B2', '#059669', '#D97706', '#DB2777'];
    let hash = 0;
    for (let i = 0; i < appId.length; i++) hash = (hash * 31 + appId.charCodeAt(i)) >>> 0;
    return palette[hash % palette.length];
  }

  initial(name: string): string {
    return name.trim()[0]?.toUpperCase() ?? '?';
  }
}
