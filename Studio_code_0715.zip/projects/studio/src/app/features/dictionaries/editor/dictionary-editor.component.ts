import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, OnInit, inject, signal } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { FieldOption } from '@akrify/shared';
import { StudioConfigService, VersionConflictError } from '../../../services/studio-config.service';

@Component({
  selector: 'app-dictionary-editor',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './dictionary-editor.component.html',
  styleUrls: ['./dictionary-editor.component.scss'],
})
export class DictionaryEditorComponent implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly configService = inject(StudioConfigService);

  name!: string;

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly isNew = signal(false);

  /** null until we know the current version (existing dict); stays null for a brand-new one. */
  readonly version = signal<number | null>(null);
  readonly lastModifiedAt = signal<string | null>(null);

  readonly options = signal<FieldOption[]>([]);
  readonly dirty = signal(false);

  readonly saving = signal(false);
  readonly saveError = signal<string | null>(null);
  readonly conflict = signal<VersionConflictError | null>(null);

  ngOnInit() {
    this.name = this.route.snapshot.paramMap.get('name')!;
    this.load();
  }

  load() {
    this.loading.set(true);
    this.error.set(null);
    this.configService.getDictionary(this.name).subscribe({
      next: rec => {
        this.isNew.set(false);
        this.version.set(rec.version);
        this.lastModifiedAt.set(rec.lastModifiedAt);
        this.options.set(rec.options.map(o => ({ ...o })));
        this.dirty.set(false);
        this.loading.set(false);
      },
      error: err => {
        if (err?.status === 404) {
          // Brand new dictionary — nothing to load, start empty.
          this.isNew.set(true);
          this.version.set(null);
          this.options.set([]);
          this.dirty.set(false);
          this.loading.set(false);
        } else {
          this.error.set(err?.message || 'Failed to load dictionary.');
          this.loading.set(false);
        }
      },
    });
  }

  addOption() {
    this.options.update(opts => [...opts, { Value: '', Label: '' }]);
    this.dirty.set(true);
  }

  removeOption(index: number) {
    this.options.update(opts => opts.filter((_, i) => i !== index));
    this.dirty.set(true);
  }

  updateValue(index: number, value: string) {
    this.options.update(opts => opts.map((o, i) => (i === index ? { ...o, Value: value } : o)));
    this.dirty.set(true);
  }

  updateLabel(index: number, label: string) {
    this.options.update(opts => opts.map((o, i) => (i === index ? { ...o, Label: label } : o)));
    this.dirty.set(true);
  }

  save() {
    if (this.saving()) return;
    this.saving.set(true);
    this.saveError.set(null);
    this.conflict.set(null);

    this.configService.saveDictionary(this.name, this.options(), this.version()).subscribe({
      next: rec => {
        this.isNew.set(false);
        this.version.set(rec.version);
        this.lastModifiedAt.set(rec.lastModifiedAt);
        this.options.set(rec.options.map(o => ({ ...o })));
        this.dirty.set(false);
        this.saving.set(false);
      },
      error: err => {
        this.saving.set(false);
        if (err instanceof VersionConflictError) {
          this.conflict.set(err);
        } else {
          this.saveError.set(err?.message || 'Failed to save.');
        }
      },
    });
  }

  reloadAfterConflict() {
    this.conflict.set(null);
    this.load();
  }

  discardChanges() {
    if (this.isNew()) {
      this.options.set([]);
    } else {
      this.load();
    }
    this.dirty.set(false);
    this.saveError.set(null);
  }

  backToList() {
    this.router.navigate(['/dictionaries']);
  }
}
