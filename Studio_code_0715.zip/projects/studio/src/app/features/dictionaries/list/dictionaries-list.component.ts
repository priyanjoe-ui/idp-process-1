import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, computed, inject, OnInit, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { DictionaryRecord } from '@akrify/shared';
import { StudioConfigService } from '../../../services/studio-config.service';
import { NewDictionaryModalComponent } from '../new-dictionary-modal/new-dictionary-modal.component';

@Component({
  selector: 'app-dictionaries-list',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, NewDictionaryModalComponent],
  templateUrl: './dictionaries-list.component.html',
  styleUrls: ['./dictionaries-list.component.scss'],
})
export class DictionariesListComponent implements OnInit {
  private readonly configService = inject(StudioConfigService);
  private readonly router = inject(Router);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly rows = signal<DictionaryRecord[]>([]);
  readonly search = signal('');
  readonly showCreateModal = signal(false);

  readonly filtered = computed(() => {
    const q = this.search().trim().toLowerCase();
    if (!q) return this.rows();
    return this.rows().filter(d => d.name.toLowerCase().includes(q));
  });

  ngOnInit() {
    this.load();
  }

  load() {
    this.loading.set(true);
    this.error.set(null);
    this.configService.listDictionaries().subscribe({
      next: rows => {
        this.rows.set(rows);
        this.loading.set(false);
      },
      error: err => {
        this.error.set(err?.message || 'Failed to load dictionaries.');
        this.loading.set(false);
      },
    });
  }

  onSearchInput(v: string) { this.search.set(v); }

  existingNames(): string[] {
    return this.rows().map(d => d.name);
  }

  openCreateModal()  { this.showCreateModal.set(true); }
  closeCreateModal() { this.showCreateModal.set(false); }

  /** Modal just collects a name — navigate into the editor to actually add options. */
  onDictionaryNamed(name: string) {
    this.showCreateModal.set(false);
    this.router.navigate(['/dictionaries', name]);
  }
}
