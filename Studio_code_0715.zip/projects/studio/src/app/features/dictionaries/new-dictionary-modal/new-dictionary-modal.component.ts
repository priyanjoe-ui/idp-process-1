import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, EventEmitter, Input, Output, signal } from '@angular/core';

/**
 * Collects a dictionary name only — no HTTP call happens here. Dictionaries
 * are created by the editor's first Save (a PUT with no X-Expected-Version,
 * per the backend's create-if-missing contract), so this modal just picks
 * the name and hands off.
 */
@Component({
  selector: 'app-new-dictionary-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './new-dictionary-modal.component.html',
  styleUrls: ['./new-dictionary-modal.component.scss'],
})
export class NewDictionaryModalComponent {
  @Input() existingNames: string[] = [];

  @Output() closed = new EventEmitter<void>();
  @Output() named = new EventEmitter<string>();

  readonly name = signal('');

  readonly namePattern = /^[A-Za-z0-9_-]+$/;

  readonly nameError = () => {
    const v = this.name().trim();
    if (!v) return null;
    if (!this.namePattern.test(v)) return 'Use only letters, numbers, underscores, and hyphens.';
    if (this.existingNames.includes(v)) return 'A dictionary with this name already exists.';
    return null;
  };

  readonly canContinue = () => this.name().trim().length > 0 && !this.nameError();

  onNameInput(raw: string) {
    this.name.set(raw.replace(/\s+/g, ''));
  }

  continue() {
    if (!this.canContinue()) return;
    this.named.emit(this.name().trim());
  }

  cancel() {
    this.closed.emit();
  }
}
