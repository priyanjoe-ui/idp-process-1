import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, OnInit, inject, signal } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { forkJoin } from 'rxjs';
import { ApplicationRecord, ConnectorsRecord } from '@akrify/shared';
import { StudioConfigService, VersionConflictError } from '../../../services/studio-config.service';
import { S3LocationPickerComponent } from '../s3-location-picker/s3-location-picker.component';

@Component({
  selector: 'app-connectors-editor',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, S3LocationPickerComponent],
  templateUrl: './connectors-editor.component.html',
  styleUrls: ['./connectors-editor.component.scss'],
})
export class ConnectorsEditorComponent implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly configService = inject(StudioConfigService);

  appId!: string;

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly app = signal<ApplicationRecord | null>(null);
  readonly record = signal<ConnectorsRecord | null>(null);

  // Working (editable) copies — separate from `record()` so Save/Discard
  // has something to compare against and revert to.
  readonly importBucket = signal('');
  readonly importPrefix = signal('');
  readonly importSourceTypes = signal<string[]>([]);
  readonly newSourceType = signal('');

  readonly exportBucket = signal('');
  readonly exportPrefix = signal('');

  readonly dirty = signal(false);
  readonly saving = signal(false);
  readonly saveError = signal<string | null>(null);
  readonly saveSuccess = signal<string | null>(null);
  readonly conflict = signal<VersionConflictError | null>(null);

  ngOnInit() {
    this.appId = this.route.snapshot.paramMap.get('appId')!;
    this.load();
  }

  load() {
    this.loading.set(true);
    this.error.set(null);
    forkJoin({
      app: this.configService.getApplication(this.appId),
      connectors: this.configService.getConnectors(this.appId),
    }).subscribe({
      next: ({ app, connectors }) => {
        this.app.set(app);
        this.record.set(connectors);
        this.resetWorkingCopy(connectors);
        this.loading.set(false);
      },
      error: err => {
        this.error.set(err?.message || 'Failed to load connectors.');
        this.loading.set(false);
      },
    });
  }

  private resetWorkingCopy(rec: ConnectorsRecord) {
    this.importBucket.set(rec.importConfig?.bucket ?? '');
    this.importPrefix.set(rec.importConfig?.prefix ?? '');
    this.importSourceTypes.set([...(rec.importConfig?.sourceTypes ?? [])]);
    this.exportBucket.set(rec.exportConfig?.bucket ?? '');
    this.exportPrefix.set(rec.exportConfig?.prefix ?? '');
    this.dirty.set(false);
    this.saveError.set(null);
    this.saveSuccess.set(null);
  }

  /** Suggested parent path for "create new folder" when nothing's picked
   *  yet — a reasonable starting point matching the existing convention,
   *  not a hard requirement. */
  suggestedImportParent(): string {
    return `idp/applications/${this.appId}`;
  }
  suggestedExportParent(): string {
    return `idp/applications/${this.appId}`;
  }

  onImportBucketChange(bucket: string) {
    this.importBucket.set(bucket);
    this.dirty.set(true);
  }
  onImportPrefixChange(prefix: string) {
    this.importPrefix.set(prefix);
    this.dirty.set(true);
  }
  onExportBucketChange(bucket: string) {
    this.exportBucket.set(bucket);
    this.dirty.set(true);
  }
  onExportPrefixChange(prefix: string) {
    this.exportPrefix.set(prefix);
    this.dirty.set(true);
  }

  addSourceType() {
    const v = this.newSourceType().trim();
    if (!v) return;
    if (!this.importSourceTypes().includes(v)) {
      this.importSourceTypes.update(list => [...list, v]);
      this.dirty.set(true);
    }
    this.newSourceType.set('');
  }
  removeSourceType(v: string) {
    this.importSourceTypes.update(list => list.filter(s => s !== v));
    this.dirty.set(true);
  }

  canSave(): boolean {
    return this.dirty() && !this.saving();
  }

  save() {
    if (!this.canSave()) return;
    this.saving.set(true);
    this.saveError.set(null);
    this.saveSuccess.set(null);
    this.conflict.set(null);

    const importConfig = this.importBucket() && this.importPrefix()
      ? { bucket: this.importBucket(), prefix: this.importPrefix(), sourceTypes: this.importSourceTypes() }
      : undefined;
    const exportConfig = this.exportBucket() && this.exportPrefix()
      ? { bucket: this.exportBucket(), prefix: this.exportPrefix() }
      : undefined;

    const rec = this.record();
    const expectedVersion = rec?.lastModifiedAt ? (rec.version ?? null) : null;

    this.configService.updateConnectors(this.appId, { importConfig, exportConfig }, expectedVersion).subscribe({
      next: updated => {
        this.record.set(updated);
        this.resetWorkingCopy(updated);
        this.saving.set(false);
        this.saveSuccess.set('Saved.');
      },
      error: err => {
        this.saving.set(false);
        if (err instanceof VersionConflictError) {
          this.conflict.set(err);
        } else {
          this.saveError.set(err?.message || 'Failed to save.');
        }
      },
    });
  }

  discard() {
    const rec = this.record();
    if (rec) this.resetWorkingCopy(rec);
  }

  reloadAfterConflict() {
    this.conflict.set(null);
    this.load();
  }
}
