import { CommonModule } from '@angular/common';
import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { ApplicationSummary, ConnectorDirection, ConnectorRecord, ConnectorSummary } from '@akrify/shared';
import { forkJoin } from 'rxjs';
import { StudioConfigService } from '../../../services/studio-config.service';
import { NewConnectorModalComponent } from '../new-connector-modal/new-connector-modal.component';
import { DeleteConnectorModalComponent } from '../delete-connector-modal/delete-connector-modal.component';
import { ConnectorInspectorComponent } from '../inspector/connector-inspector.component';

@Component({
  selector: 'app-connectors-list',
  standalone: true,
  imports: [
    CommonModule,
    NewConnectorModalComponent,
    DeleteConnectorModalComponent,
    ConnectorInspectorComponent,
  ],
  templateUrl: './connectors-list.component.html',
  styleUrls: ['./connectors-list.component.scss'],
})
export class ConnectorsListComponent implements OnInit {
  private readonly configService = inject(StudioConfigService);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly rows = signal<ConnectorSummary[]>([]);
  readonly appNamesById = signal<Map<string, string>>(new Map());

  readonly activeTab = signal<ConnectorDirection>('import');

  readonly selectedConnectorId = signal<string | null>(null);
  readonly selectedConnector = signal<ConnectorRecord | null>(null);
  readonly selectedLoading = signal(false);

  readonly showCreateModal = signal(false);
  readonly pendingDelete = signal<ConnectorSummary | null>(null);

  readonly filtered = computed(() =>
    this.rows().filter(c => c.direction === this.activeTab()),
  );
  readonly importCount = computed(() => this.rows().filter(c => c.direction === 'import').length);
  readonly exportCount = computed(() => this.rows().filter(c => c.direction === 'export').length);

  ngOnInit() {
    this.load();
  }

  load() {
    this.loading.set(true);
    this.error.set(null);
    forkJoin({
      connectors: this.configService.listConnectors(),
      applications: this.configService.listApplications(),
    }).subscribe({
      next: ({ connectors, applications }) => {
        this.rows.set(connectors);
        this.appNamesById.set(new Map(applications.map((a: ApplicationSummary) => [a.appId, a.name])));
        this.loading.set(false);
        // First row of the active tab is selected by default, so the
        // inspector shows something immediately rather than an empty state.
        const first = this.filtered()[0];
        if (first) this.selectConnector(first.connectorId);
      },
      error: err => {
        this.error.set(err?.message || 'Failed to load connectors.');
        this.loading.set(false);
      },
    });
  }

  appNameFor(appId: string): string {
    return this.appNamesById().get(appId) ?? appId;
  }

  setTab(tab: ConnectorDirection) {
    this.activeTab.set(tab);
  }

  selectConnector(connectorId: string) {
    if (this.selectedConnectorId() === connectorId) return;
    this.selectedConnectorId.set(connectorId);
    this.selectedLoading.set(true);
    this.selectedConnector.set(null);
    this.configService.getConnector(connectorId).subscribe({
      next: record => {
        this.selectedConnector.set(record);
        this.selectedLoading.set(false);
      },
      error: () => {
        this.selectedLoading.set(false);
      },
    });
  }

  onConnectorUpdated(updated: ConnectorRecord) {
    this.selectedConnector.set(updated);
    this.rows.update(rows => rows.map(r => (r.connectorId === updated.connectorId ? { ...r, ...updated } : r)));
  }

  openCreateModal() { this.showCreateModal.set(true); }
  closeCreateModal() { this.showCreateModal.set(false); }

  onConnectorCreated(record: ConnectorRecord) {
    this.showCreateModal.set(false);
    this.rows.update(rows => [...rows, record]);
    this.activeTab.set(record.direction);
    this.selectConnector(record.connectorId);
  }

  openDeleteModal(c: ConnectorSummary, event: Event) {
    event.preventDefault();
    event.stopPropagation();
    this.pendingDelete.set(c);
  }
  closeDeleteModal() { this.pendingDelete.set(null); }
  onConnectorDeleted(connectorId: string) {
    this.pendingDelete.set(null);
    this.rows.update(rows => rows.filter(c => c.connectorId !== connectorId));
    if (this.selectedConnectorId() === connectorId) {
      this.selectedConnectorId.set(null);
      this.selectedConnector.set(null);
    }
  }
}
