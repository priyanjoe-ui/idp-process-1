import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output, inject, signal } from '@angular/core';
import { ConnectorSummary } from '@akrify/shared';
import { StudioConfigService } from '../../../services/studio-config.service';

@Component({
  selector: 'app-delete-connector-modal',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './delete-connector-modal.component.html',
  styleUrls: ['./delete-connector-modal.component.scss'],
})
export class DeleteConnectorModalComponent {
  private readonly configService = inject(StudioConfigService);

  @Input({ required: true }) connector!: ConnectorSummary;

  @Output() closed = new EventEmitter<void>();
  @Output() deleted = new EventEmitter<string>(); // emits connectorId

  readonly deleting = signal(false);
  readonly error = signal<string | null>(null);

  confirmDelete() {
    if (this.deleting()) return;
    this.deleting.set(true);
    this.error.set(null);
    this.configService.deleteConnector(this.connector.connectorId).subscribe({
      next: () => {
        this.deleting.set(false);
        this.deleted.emit(this.connector.connectorId);
      },
      error: err => {
        this.deleting.set(false);
        this.error.set(err?.message || 'Failed to delete connector.');
      },
    });
  }

  cancel() {
    if (this.deleting()) return;
    this.closed.emit();
  }
}
