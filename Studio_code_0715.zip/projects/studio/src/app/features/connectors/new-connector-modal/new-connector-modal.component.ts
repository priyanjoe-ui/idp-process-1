import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, EventEmitter, OnInit, Output, inject, signal } from '@angular/core';
import { ApplicationSummary, ConnectorDirection, ConnectorRecord } from '@akrify/shared';
import { StudioConfigService } from '../../../services/studio-config.service';

@Component({
  selector: 'app-new-connector-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './new-connector-modal.component.html',
  styleUrls: ['./new-connector-modal.component.scss'],
})
export class NewConnectorModalComponent implements OnInit {
  private readonly configService = inject(StudioConfigService);

  @Output() closed = new EventEmitter<void>();
  @Output() created = new EventEmitter<ConnectorRecord>();

  readonly name = signal('');
  readonly direction = signal<ConnectorDirection>('import');
  readonly appId = signal('');

  readonly applications = signal<ApplicationSummary[]>([]);
  readonly applicationsLoading = signal(true);

  readonly submitting = signal(false);
  readonly error = signal<string | null>(null);

  readonly canSubmit = () =>
    this.name().trim().length > 0 &&
    this.appId().length > 0 &&
    !this.submitting();

  ngOnInit() {
    this.configService.listApplications().subscribe({
      next: apps => {
        this.applications.set(apps);
        this.applicationsLoading.set(false);
      },
      error: () => this.applicationsLoading.set(false),
    });
  }

  submit() {
    if (!this.canSubmit()) return;
    this.submitting.set(true);
    this.error.set(null);
    this.configService.createConnector({
      name: this.name().trim(),
      direction: this.direction(),
      platform: 'S3',
      appId: this.appId(),
    }).subscribe({
      next: record => {
        this.submitting.set(false);
        this.created.emit(record);
      },
      error: err => {
        this.submitting.set(false);
        this.error.set(err?.message || 'Failed to create connector.');
      },
    });
  }

  cancel() {
    if (this.submitting()) return;
    this.closed.emit();
  }
}
