import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, inject, signal } from '@angular/core';
import { ConnectorRecord, ConnectorStatus } from '@akrify/shared';
import { StudioConfigService, VersionConflictError } from '../../../services/studio-config.service';
import { FolderBrowserModalComponent } from '../folder-browser-modal/folder-browser-modal.component';

/**
 * Shown only when a connector is selected in the list — this component
 * doesn't render anything of its own when there's nothing to inspect,
 * the parent list screen controls that with *ngIf.
 */
@Component({
  selector: 'app-connector-inspector',
  standalone: true,
  imports: [CommonModule, FormsModule, FolderBrowserModalComponent],
  templateUrl: './connector-inspector.component.html',
  styleUrls: ['./connector-inspector.component.scss'],
})
export class ConnectorInspectorComponent implements OnInit, OnChanges {
  private readonly configService = inject(StudioConfigService);

  @Input({ required: true }) connector!: ConnectorRecord;

  @Output() updated = new EventEmitter<ConnectorRecord>();

  // Real buckets in the account, fetched once — this doesn't depend on
  // which connector is being viewed, so it lives in ngOnInit (which only
  // ever runs once for this component's lifetime; the parent reuses the
  // same instance across different connector selections via *ngIf="x as y",
  // not destroying/recreating it), not ngOnChanges.
  readonly buckets = signal<string[]>([]);
  readonly bucketsLoading = signal(true);
  readonly bucketsError = signal<string | null>(null);

  // Working (editable) copies — separate from `connector` so Save/Discard
  // has something to compare against and revert to.
  readonly name = signal('');
  readonly bucket = signal('');
  readonly prefix = signal('');
  readonly fileTypes = signal<string[]>([]);
  readonly newFileType = signal('');
  readonly showFolderBrowser = signal(false);

  readonly dirty = signal(false);
  readonly saving = signal(false);
  readonly saveError = signal<string | null>(null);
  readonly saveSuccess = signal<string | null>(null);
  readonly conflict = signal<VersionConflictError | null>(null);

  readonly testing = signal(false);
  readonly testResult = signal<{ success: boolean; message: string } | null>(null);

  readonly togglingStatus = signal(false);

  ngOnInit() {
    this.configService.listS3Buckets().subscribe({
      next: list => {
        this.buckets.set(list.map(b => b.name));
        this.bucketsLoading.set(false);
      },
      error: err => {
        this.bucketsError.set(err?.message || 'Failed to list buckets.');
        this.bucketsLoading.set(false);
      },
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['connector']) {
      this.resetWorkingCopy();
    }
  }

  private resetWorkingCopy() {
    this.name.set(this.connector.name);
    this.bucket.set(this.connector.s3Config?.bucket ?? '');
    this.prefix.set(this.connector.s3Config?.prefix ?? '');
    this.fileTypes.set([...(this.connector.s3Config?.fileTypes ?? [])]);
    this.newFileType.set('');
    this.showFolderBrowser.set(false);
    this.dirty.set(false);
    this.saveError.set(null);
    this.saveSuccess.set(null);
    this.conflict.set(null);
    this.testResult.set(null);
  }

  onNameInput(v: string) {
    this.name.set(v);
    this.dirty.set(true);
  }

  onBucketSelected(v: string) {
    this.bucket.set(v);
    // A different bucket almost certainly has a different folder
    // structure — the previously chosen prefix wouldn't mean anything here.
    this.prefix.set('');
    this.dirty.set(true);
  }

  onPrefixInput(v: string) {
    this.prefix.set(v);
    this.dirty.set(true);
  }

  openFolderBrowser() {
    if (!this.bucket()) return;
    this.showFolderBrowser.set(true);
  }
  closeFolderBrowser() {
    this.showFolderBrowser.set(false);
  }
  onFolderSelected(prefix: string) {
    this.prefix.set(prefix);
    this.dirty.set(true);
    this.showFolderBrowser.set(false);
  }

  addFileType() {
    const v = this.newFileType().trim();
    if (!v) return;
    const normalized = v.startsWith('.') ? v : `.${v}`;
    if (!this.fileTypes().includes(normalized)) {
      this.fileTypes.update(list => [...list, normalized]);
      this.dirty.set(true);
    }
    this.newFileType.set('');
  }
  removeFileType(v: string) {
    this.fileTypes.update(list => list.filter(f => f !== v));
    this.dirty.set(true);
  }

  canSave(): boolean {
    return this.dirty() && !this.saving();
  }

  save() {
    if (!this.canSave()) return;
    this.saving.set(true);
    this.saveError.set(null);
    this.saveSuccess.set(null);
    this.conflict.set(null);

    // Only the bucket is required — an empty prefix is a legitimate choice
    // ("watch the whole bucket, no specific folder"), not something that
    // should silently drop the whole config.
    const s3Config = this.bucket()
      ? { bucket: this.bucket(), prefix: this.prefix(), fileTypes: this.fileTypes() }
      : undefined;

    this.configService.updateConnector(
      this.connector.connectorId,
      { name: this.name().trim() || this.connector.name, s3Config },
      this.connector.version,
    ).subscribe({
      next: updated => {
        this.saving.set(false);
        this.saveSuccess.set('Saved.');
        this.updated.emit(updated);
      },
      error: err => {
        this.saving.set(false);
        if (err instanceof VersionConflictError) {
          this.conflict.set(err);
        } else {
          this.saveError.set(err?.message || 'Failed to save.');
        }
      },
    });
  }

  discard() {
    this.resetWorkingCopy();
  }

  /** Tests whatever's currently in the form (bucket()/prefix() signals) —
   *  deliberately NOT tied to what's saved, so this works identically
   *  whether or not Save has been clicked yet. */
  testConnection() {
    if (this.testing()) return;
    if (!this.bucket()) {
      this.testResult.set({ success: false, message: 'Select a bucket first.' });
      return;
    }
    this.testing.set(true);
    this.testResult.set(null);
    this.configService.testS3Location(this.bucket(), this.prefix()).subscribe({
      next: result => {
        this.testing.set(false);
        this.testResult.set(result);
      },
      error: err => {
        this.testing.set(false);
        this.testResult.set({ success: false, message: err?.message || 'Test failed.' });
      },
    });
  }

  toggleEnabled() {
    if (this.togglingStatus()) return;
    const nextStatus: ConnectorStatus = this.connector.status === 'enabled' ? 'disabled' : 'enabled';
    this.togglingStatus.set(true);
    this.configService.updateConnector(
      this.connector.connectorId,
      { status: nextStatus },
      this.connector.version,
    ).subscribe({
      next: updated => {
        this.togglingStatus.set(false);
        this.updated.emit(updated);
      },
      error: err => {
        this.togglingStatus.set(false);
        if (err instanceof VersionConflictError) {
          this.conflict.set(err);
        } else {
          this.saveError.set(err?.message || 'Failed to update status.');
        }
      },
    });
  }
}
