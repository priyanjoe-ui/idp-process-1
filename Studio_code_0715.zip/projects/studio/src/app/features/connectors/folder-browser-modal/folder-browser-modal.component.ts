import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, EventEmitter, Input, OnInit, Output, inject, signal } from '@angular/core';
import { S3FolderSummary } from '@akrify/shared';
import { StudioConfigService } from '../../../services/studio-config.service';

@Component({
  selector: 'app-folder-browser-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './folder-browser-modal.component.html',
  styleUrls: ['./folder-browser-modal.component.scss'],
})
export class FolderBrowserModalComponent implements OnInit {
  private readonly configService = inject(StudioConfigService);

  /** Already chosen before this modal opens — this component only browses
   *  folders within it, it doesn't let you switch buckets. */
  @Input({ required: true }) bucket!: string;
  @Input() initialPrefix = '';

  @Output() closed = new EventEmitter<void>();
  /** Emits the chosen prefix and closes — selecting a folder is a single
   *  action here, matching a native OS "choose folder" dialog, not a
   *  separate select-then-confirm step. */
  @Output() selected = new EventEmitter<string>();

  readonly browsingPath = signal('');
  readonly folders = signal<S3FolderSummary[]>([]);
  readonly foldersLoading = signal(false);
  readonly foldersError = signal<string | null>(null);

  readonly showNewFolderInput = signal(false);
  readonly newFolderName = signal('');
  readonly creatingFolder = signal(false);
  readonly createFolderError = signal<string | null>(null);

  ngOnInit() {
    this.browsingPath.set(this.parentOf(this.initialPrefix));
    this.loadFolders();
  }

  private parentOf(path: string): string {
    const trimmed = path.endsWith('/') ? path.slice(0, -1) : path;
    if (!trimmed) return '';
    const idx = trimmed.lastIndexOf('/');
    return idx === -1 ? '' : trimmed.slice(0, idx + 1);
  }

  private loadFolders() {
    this.foldersLoading.set(true);
    this.foldersError.set(null);
    this.configService.listS3Folders(this.bucket, this.browsingPath()).subscribe({
      next: list => {
        this.folders.set(list);
        this.foldersLoading.set(false);
      },
      error: err => {
        this.foldersError.set(err?.message || 'Failed to list folders.');
        this.foldersLoading.set(false);
      },
    });
  }

  browseInto(folder: S3FolderSummary) {
    this.browsingPath.set(folder.prefix);
    this.loadFolders();
  }

  browseUp() {
    this.browsingPath.set(this.parentOf(this.browsingPath()));
    this.loadFolders();
  }

  isAtRoot(): boolean {
    return !this.browsingPath();
  }

  selectCurrentFolder() {
    this.selected.emit(this.browsingPath());
  }

  selectFolder(folder: S3FolderSummary) {
    this.selected.emit(folder.prefix);
  }

  openNewFolderInput() {
    this.newFolderName.set('');
    this.createFolderError.set(null);
    this.showNewFolderInput.set(true);
  }

  cancelNewFolder() {
    this.showNewFolderInput.set(false);
  }

  createFolder() {
    const name = this.newFolderName().trim();
    if (!name) return;
    this.creatingFolder.set(true);
    this.createFolderError.set(null);
    const base = this.browsingPath();
    const fullPrefix = base ? `${base.replace(/\/$/, '')}/${name}` : name;
    this.configService.createS3Folder(this.bucket, fullPrefix).subscribe({
      next: created => {
        this.creatingFolder.set(false);
        // A newly created folder is exactly what the person wants to use —
        // select it immediately rather than making them find and click it
        // again in the (now-refreshed) list.
        this.selected.emit(created.prefix);
      },
      error: err => {
        this.creatingFolder.set(false);
        this.createFolderError.set(err?.message || 'Failed to create folder.');
      },
    });
  }

  cancel() {
    this.closed.emit();
  }
}
