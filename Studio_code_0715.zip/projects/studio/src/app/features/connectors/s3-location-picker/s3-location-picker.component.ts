import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, EventEmitter, Input, OnInit, Output, inject, signal } from '@angular/core';
import { S3FolderSummary } from '@akrify/shared';
import { StudioConfigService } from '../../../services/studio-config.service';

/**
 * Bucket dropdown (populated live from the account's real buckets) +
 * folder browser (existing prefixes under the chosen bucket, via S3's
 * Delimiter listing) + a "create new folder" fallback when nothing
 * existing fits. Shared between Import and Export sections rather than
 * duplicated — unlike the small SVG-arrow duplication elsewhere in this
 * project, this carries real stateful logic (fetching, loading states,
 * folder creation) worth keeping in one place.
 *
 * Browsing (navigating deeper into the folder tree to look around) is
 * kept separate from selecting (confirming a specific folder as the
 * final chosen prefix) — clicking a folder name browses into it; a
 * separate "Use this folder" action is what actually emits prefixChange.
 */
@Component({
  selector: 'app-s3-location-picker',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './s3-location-picker.component.html',
  styleUrls: ['./s3-location-picker.component.scss'],
})
export class S3LocationPickerComponent implements OnInit {
  private readonly configService = inject(StudioConfigService);

  @Input() bucket = '';
  /** The confirmed/saved prefix, e.g. "idp/applications/AFLCOR/Import". */
  @Input() prefix = '';
  /** Pre-fills the "new folder" input's parent path when nothing's
   *  selected yet (e.g. "idp/applications/AFLCOR"). */
  @Input() suggestedParentPrefix = '';

  @Output() bucketChange = new EventEmitter<string>();
  @Output() prefixChange = new EventEmitter<string>();

  readonly buckets = signal<string[]>([]);
  readonly bucketsLoading = signal(true);
  readonly bucketsError = signal<string | null>(null);

  /** Path currently being browsed — independent of the confirmed `prefix`
   *  until "Use this folder" is clicked. */
  readonly browsingPath = signal('');
  readonly folders = signal<S3FolderSummary[]>([]);
  readonly foldersLoading = signal(false);
  readonly foldersError = signal<string | null>(null);

  readonly showNewFolderInput = signal(false);
  readonly newFolderName = signal('');
  readonly creatingFolder = signal(false);
  readonly createFolderError = signal<string | null>(null);

  ngOnInit() {
    this.configService.listS3Buckets().subscribe({
      next: list => {
        this.buckets.set(list.map(b => b.name));
        this.bucketsLoading.set(false);
      },
      error: err => {
        this.bucketsError.set(err?.message || 'Failed to list buckets.');
        this.bucketsLoading.set(false);
      },
    });
    if (this.bucket) {
      this.browsingPath.set(this.parentOf(this.prefix));
      this.loadFolders();
    }
  }

  private parentOf(path: string): string {
    const trimmed = path.endsWith('/') ? path.slice(0, -1) : path;
    if (!trimmed) return '';
    const idx = trimmed.lastIndexOf('/');
    return idx === -1 ? '' : trimmed.slice(0, idx + 1);
  }

  private loadFolders() {
    if (!this.bucket) {
      this.folders.set([]);
      return;
    }
    this.foldersLoading.set(true);
    this.foldersError.set(null);
    this.configService.listS3Folders(this.bucket, this.browsingPath()).subscribe({
      next: list => {
        this.folders.set(list);
        this.foldersLoading.set(false);
      },
      error: err => {
        this.foldersError.set(err?.message || 'Failed to list folders.');
        this.foldersLoading.set(false);
      },
    });
  }

  onBucketSelected(bucket: string) {
    this.bucket = bucket;
    this.bucketChange.emit(bucket);
    this.prefixChange.emit('');
    this.browsingPath.set('');
    this.loadFolders();
  }

  browseInto(folder: S3FolderSummary) {
    this.browsingPath.set(folder.prefix);
    this.loadFolders();
  }

  browseUp() {
    this.browsingPath.set(this.parentOf(this.browsingPath()));
    this.loadFolders();
  }

  isAtRoot(): boolean {
    return !this.browsingPath();
  }

  /** Confirms whatever folder is currently being browsed as the chosen prefix. */
  useCurrentFolder() {
    this.prefix = this.browsingPath();
    this.prefixChange.emit(this.browsingPath());
  }

  /** Confirms a specific listed folder directly, without first browsing into it. */
  useFolder(folder: S3FolderSummary) {
    this.prefix = folder.prefix;
    this.prefixChange.emit(folder.prefix);
  }

  isSelected(folder: S3FolderSummary): boolean {
    return this.prefix === folder.prefix;
  }

  openNewFolderInput() {
    this.newFolderName.set('');
    this.createFolderError.set(null);
    this.showNewFolderInput.set(true);
  }

  cancelNewFolder() {
    this.showNewFolderInput.set(false);
  }

  createFolder() {
    const name = this.newFolderName().trim();
    if (!name || !this.bucket) return;
    this.creatingFolder.set(true);
    this.createFolderError.set(null);
    const base = this.browsingPath() || this.suggestedParentPrefix;
    const fullPrefix = base ? `${base.replace(/\/$/, '')}/${name}` : name;
    this.configService.createS3Folder(this.bucket, fullPrefix).subscribe({
      next: created => {
        this.creatingFolder.set(false);
        this.showNewFolderInput.set(false);
        this.browsingPath.set(this.parentOf(created.prefix));
        this.loadFolders();
      },
      error: err => {
        this.creatingFolder.set(false);
        this.createFolderError.set(err?.message || 'Failed to create folder.');
      },
    });
  }
}
