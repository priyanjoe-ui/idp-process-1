import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, EventEmitter, Input, OnInit, Output, inject, signal } from '@angular/core';
import { ApplicationSummary, WorkflowRecord } from '@akrify/shared';
import { StudioConfigService, VersionConflictError } from '../../../services/studio-config.service';

/**
 * Application mapping is plain metadata, not part of the definition
 * draft — changes here save immediately (no Save/Discard/Deploy dance),
 * matching how Applications/Document Types work rather than the
 * draft/deployed model the canvas itself uses for the definition.
 */
@Component({
  selector: 'app-manage-applications-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './manage-applications-modal.component.html',
  styleUrls: ['./manage-applications-modal.component.scss'],
})
export class ManageApplicationsModalComponent implements OnInit {
  private readonly configService = inject(StudioConfigService);

  @Input({ required: true }) workflow!: WorkflowRecord;

  @Output() closed = new EventEmitter<void>();
  @Output() updated = new EventEmitter<WorkflowRecord>();

  readonly applications = signal<ApplicationSummary[]>([]);
  readonly applicationsLoading = signal(true);
  readonly selectedApplicationIds = signal<Set<string>>(new Set());

  readonly saving = signal(false);
  readonly error = signal<string | null>(null);

  ngOnInit() {
    this.selectedApplicationIds.set(new Set(this.workflow.mappedApplicationIds));
    this.configService.listApplications().subscribe({
      next: apps => {
        this.applications.set(apps);
        this.applicationsLoading.set(false);
      },
      error: () => this.applicationsLoading.set(false),
    });
  }

  isSelected(appId: string): boolean {
    return this.selectedApplicationIds().has(appId);
  }

  toggleApplication(appId: string, checked: boolean) {
    this.selectedApplicationIds.update(set => {
      const next = new Set(set);
      if (checked) next.add(appId); else next.delete(appId);
      return next;
    });
  }

  save() {
    if (this.saving()) return;
    this.saving.set(true);
    this.error.set(null);
    this.configService.updateWorkflow(
      this.workflow.workflowId,
      { mappedApplicationIds: Array.from(this.selectedApplicationIds()) },
      this.workflow.version,
    ).subscribe({
      next: updated => {
        this.saving.set(false);
        this.updated.emit(updated);
      },
      error: err => {
        this.saving.set(false);
        if (err instanceof VersionConflictError) {
          this.error.set('This workflow was modified elsewhere just now — close and reopen to try again.');
        } else {
          this.error.set(err?.message || 'Failed to update application mapping.');
        }
      },
    });
  }

  cancel() {
    if (this.saving()) return;
    this.closed.emit();
  }
}
