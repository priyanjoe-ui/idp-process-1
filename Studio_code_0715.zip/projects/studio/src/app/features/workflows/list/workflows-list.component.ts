import { CommonModule, DecimalPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, computed, inject, OnInit, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { forkJoin } from 'rxjs';
import { ApplicationSummary, WorkflowSummary } from '@akrify/shared';
import { StudioConfigService } from '../../../services/studio-config.service';
import { NewWorkflowModalComponent } from '../new-workflow-modal/new-workflow-modal.component';
import { DeleteWorkflowModalComponent } from '../delete-workflow-modal/delete-workflow-modal.component';

@Component({
  selector: 'app-workflows-list',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, DecimalPipe, NewWorkflowModalComponent, DeleteWorkflowModalComponent],
  templateUrl: './workflows-list.component.html',
  styleUrls: ['./workflows-list.component.scss'],
})
export class WorkflowsListComponent implements OnInit {
  private readonly configService = inject(StudioConfigService);
  private readonly router = inject(Router);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly rows = signal<WorkflowSummary[]>([]);

  /** appId -> display name, used to render mapped-application tags by name
   *  instead of raw id. A stale id (app deleted after mapping) falls back
   *  to showing the id itself rather than disappearing silently. */
  readonly appNamesById = signal<Map<string, string>>(new Map());

  readonly search = signal('');
  readonly showCreateModal = signal(false);
  readonly pendingDelete = signal<WorkflowSummary | null>(null);

  readonly filtered = computed(() => {
    const q = this.search().trim().toLowerCase();
    if (!q) return this.rows();
    return this.rows().filter(
      w => w.name.toLowerCase().includes(q) || w.workflowId.toLowerCase().includes(q),
    );
  });

  ngOnInit() {
    this.load();
  }

  load() {
    this.loading.set(true);
    this.error.set(null);
    forkJoin({
      workflows: this.configService.listWorkflows(),
      applications: this.configService.listApplications(),
    }).subscribe({
      next: ({ workflows, applications }) => {
        this.rows.set(workflows);
        this.appNamesById.set(new Map(applications.map((a: ApplicationSummary) => [a.appId, a.name])));
        this.loading.set(false);
      },
      error: err => {
        this.error.set(err?.message || 'Failed to load workflows.');
        this.loading.set(false);
      },
    });
  }

  appNameFor(appId: string): string {
    return this.appNamesById().get(appId) ?? appId;
  }

  onSearchInput(v: string) { this.search.set(v); }

  openCreateModal()  { this.showCreateModal.set(true); }
  closeCreateModal() { this.showCreateModal.set(false); }

  onWorkflowCreated(created: { workflowId: string }) {
    this.showCreateModal.set(false);
    this.router.navigate(['/workflows', created.workflowId]);
  }

  openDeleteModal(w: WorkflowSummary, event: Event) {
    event.preventDefault();
    event.stopPropagation();
    this.pendingDelete.set(w);
  }
  closeDeleteModal() { this.pendingDelete.set(null); }
  onWorkflowDeleted(workflowId: string) {
    this.pendingDelete.set(null);
    this.rows.update(rows => rows.filter(w => w.workflowId !== workflowId));
  }

  statusChipClass(status: WorkflowSummary['status']): string {
    return status === 'deployed' ? 'chip chip-success' : 'chip chip-neutral';
  }
}
