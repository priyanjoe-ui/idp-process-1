/**
 * The set of state types Studio can insert, shared between the two ways
 * to add one: click the "+" on a connector (opens AddStatePaletteComponent
 * as a CDK Overlay popup) and drag a palette item from the sidebar onto a
 * connector. Both read from this same list so their icons/labels/hints
 * can't drift apart.
 *
 * `category` groups them the way AWS's own Workflow Studio does — Actions
 * (Task-shaped, calls something) vs Flow (control-flow states). Only one
 * Flow entry exists today (Choice); Wait/Parallel/Map/Succeed/Fail would
 * land here too if/when they become editable.
 */
export type PaletteChoice = 'lambda-invoke' | 'lambda-wait-token' | 'choice';
export type PaletteCategory = 'actions' | 'flow';

export interface PaletteOption {
  key: PaletteChoice;
  label: string;
  hint: string;
  icon: string;
  category: PaletteCategory;
}

export const PALETTE_OPTIONS: PaletteOption[] = [
  {
    key: 'lambda-invoke',
    label: 'Lambda: Invoke',
    hint: 'Request/response — call and continue immediately.',
    icon: 'M13 3 4 14h7l-1 7 9-11h-7l1-7z',
    category: 'actions',
  },
  {
    key: 'lambda-wait-token',
    label: 'Lambda: Wait for Task Token',
    hint: 'Pause until the task reports success/failure (e.g. manual review).',
    icon: 'M12 8v4l3 2M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z',
    category: 'actions',
  },
  {
    key: 'choice',
    label: 'Choice',
    hint: 'Branch based on a condition.',
    icon: 'M12 3 3 12l9 9 9-9-9-9z',
    category: 'flow',
  },
];
