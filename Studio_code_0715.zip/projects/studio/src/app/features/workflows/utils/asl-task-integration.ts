import { AslState, TaskIntegrationPattern } from '@akrify/shared';

const WAIT_RESOURCE = 'arn:aws:states:::lambda:invoke.waitForTaskToken';
const SYNC_RESOURCE = 'arn:aws:states:::lambda:invoke.sync';

/** Infers the integration pattern from a Task state's Resource shape. */
export function detectIntegrationPattern(state: AslState): TaskIntegrationPattern {
  const resource = state.Resource ?? '';
  if (resource.includes('waitForTaskToken')) return 'WaitForTaskToken';
  if (resource.includes('invoke.sync') || resource.endsWith('.sync')) return 'RunAJob';
  return 'RequestResponse';
}

/** The underlying Lambda function ARN, regardless of which pattern wraps it. */
export function extractFunctionArn(state: AslState): string {
  const pattern = detectIntegrationPattern(state);
  if (pattern === 'RequestResponse') return state.Resource ?? '';
  return (state.Parameters?.['FunctionName'] as string) ?? '';
}

/**
 * Rewrites Resource (and Parameters, for the wrapped patterns) to match the
 * chosen integration pattern + function ARN. RequestResponse leaves any
 * existing Parameters untouched (direct payload style); the wrapped
 * patterns preserve an existing Payload object if there was one, only
 * ensuring FunctionName is correct and — for WaitForTaskToken — that
 * `taskToken.$` is present so the task can actually be resumed later.
 */
export function applyIntegrationPattern(
  state: AslState,
  pattern: TaskIntegrationPattern,
  functionArn: string,
): void {
  if (pattern === 'RequestResponse') {
    state.Resource = functionArn;
    return;
  }

  state.Resource = pattern === 'WaitForTaskToken' ? WAIT_RESOURCE : SYNC_RESOURCE;
  const existingPayload = { ...(state.Parameters?.['Payload'] as Record<string, unknown> | undefined) };
  if (pattern === 'WaitForTaskToken' && !('taskToken.$' in existingPayload)) {
    existingPayload['taskToken.$'] = '$$.Task.Token';
  }
  state.Parameters = { FunctionName: functionArn, Payload: existingPayload };
}
