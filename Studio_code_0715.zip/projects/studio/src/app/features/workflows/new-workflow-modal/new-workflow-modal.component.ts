import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, EventEmitter, OnInit, Output, inject, signal } from '@angular/core';
import { ApplicationSummary, WorkflowRecord } from '@akrify/shared';
import { StudioConfigService } from '../../../services/studio-config.service';

@Component({
  selector: 'app-new-workflow-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './new-workflow-modal.component.html',
  styleUrls: ['./new-workflow-modal.component.scss'],
})
export class NewWorkflowModalComponent implements OnInit {
  private readonly configService = inject(StudioConfigService);

  @Output() closed = new EventEmitter<void>();
  @Output() created = new EventEmitter<WorkflowRecord>();

  readonly workflowId = signal('');
  readonly name = signal('');
  readonly submitting = signal(false);
  readonly error = signal<string | null>(null);

  readonly applications = signal<ApplicationSummary[]>([]);
  readonly applicationsLoading = signal(true);
  readonly selectedApplicationIds = signal<Set<string>>(new Set());

  readonly idPattern = /^[A-Z0-9_]+$/;

  readonly idError = () => {
    const v = this.workflowId().trim();
    if (!v) return null;
    return this.idPattern.test(v) ? null : 'Use only uppercase letters, numbers, and underscores.';
  };

  readonly canSubmit = () =>
    this.workflowId().trim().length > 0 &&
    this.name().trim().length > 0 &&
    !this.idError() &&
    !this.submitting();

  ngOnInit() {
    this.configService.listApplications().subscribe({
      next: apps => {
        this.applications.set(apps);
        this.applicationsLoading.set(false);
      },
      error: () => this.applicationsLoading.set(false), // non-fatal — mapping can be added later via Manage Applications
    });
  }

  onIdInput(raw: string) {
    this.workflowId.set(raw.toUpperCase().replace(/\s+/g, '_'));
  }

  isSelected(appId: string): boolean {
    return this.selectedApplicationIds().has(appId);
  }

  toggleApplication(appId: string, checked: boolean) {
    this.selectedApplicationIds.update(set => {
      const next = new Set(set);
      if (checked) next.add(appId); else next.delete(appId);
      return next;
    });
  }

  submit() {
    if (!this.canSubmit()) return;
    this.submitting.set(true);
    this.error.set(null);
    this.configService.createWorkflow({
      workflowId: this.workflowId().trim(),
      name: this.name().trim(),
      applicationIds: Array.from(this.selectedApplicationIds()),
    }).subscribe({
      next: record => {
        this.submitting.set(false);
        this.created.emit(record);
      },
      error: err => {
        this.submitting.set(false);
        this.error.set(err?.message || 'Failed to create workflow.');
      },
    });
  }

  cancel() {
    if (this.submitting()) return;
    this.closed.emit();
  }
}
