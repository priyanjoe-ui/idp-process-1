import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output, inject, signal } from '@angular/core';
import { WorkflowSummary } from '@akrify/shared';
import { StudioConfigService } from '../../../services/studio-config.service';

@Component({
  selector: 'app-delete-workflow-modal',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './delete-workflow-modal.component.html',
  styleUrls: ['./delete-workflow-modal.component.scss'],
})
export class DeleteWorkflowModalComponent {
  private readonly configService = inject(StudioConfigService);

  @Input({ required: true }) workflow!: WorkflowSummary;

  @Output() closed = new EventEmitter<void>();
  @Output() deleted = new EventEmitter<string>(); // emits workflowId

  readonly deleting = signal(false);
  readonly error = signal<string | null>(null);

  confirmDelete() {
    if (this.deleting()) return;
    this.deleting.set(true);
    this.error.set(null);
    this.configService.deleteWorkflow(this.workflow.workflowId).subscribe({
      next: () => {
        this.deleting.set(false);
        this.deleted.emit(this.workflow.workflowId);
      },
      error: err => {
        this.deleting.set(false);
        this.error.set(err?.message || 'Failed to delete workflow.');
      },
    });
  }

  cancel() {
    if (this.deleting()) return;
    this.closed.emit();
  }
}
