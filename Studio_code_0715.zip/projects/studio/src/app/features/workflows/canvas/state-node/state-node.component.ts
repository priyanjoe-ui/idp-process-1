import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output, signal } from '@angular/core';
import { CdkDragDrop, DragDropModule } from '@angular/cdk/drag-drop';
import { AslState } from '@akrify/shared';
import { RenderChild, RenderNode, integrationLabel, subtreeIsAllTerminal } from '../../utils/asl-render-tree';
import { InsertionPoint } from '../../utils/asl-graph-edit';
import { PaletteChoice } from '../../utils/palette-options';

/**
 * Purely presentational — all graph-walking and convergence detection
 * already happened in buildRenderTree() before this component ever runs.
 * This just draws whatever RenderNode it's given and recurses into its
 * children. Standalone components can self-reference for recursive
 * templates, which is what makes the tree rendering possible without a
 * separate structural-directive-based recursion helper.
 *
 * Two ways to insert a state at any connector, both wired here:
 *   - Click the "+" button (opens the CDK Overlay popup in the parent)
 *   - Drag a palette item from the sidebar and drop it on the connector
 * Both ultimately call the same insertState() logic in the parent canvas
 * component — this component just reports *which* connector was used.
 */
@Component({
  selector: 'app-state-node',
  standalone: true,
  imports: [CommonModule, DragDropModule, StateNodeComponent],
  templateUrl: './state-node.component.html',
  styleUrls: ['./state-node.component.scss'],
})
export class StateNodeComponent {
  @Input({ required: true }) node!: RenderNode;
  @Input() selectedStateName: string | null = null;
  /** Set by a parent Choice when all of its branches terminate — suppresses
   *  this node's own End circle so a single shared one can be rendered
   *  instead, with all branches fanning into it (see allBranchesTerminal()). */
  @Input() hideEndCircle = false;

  @Output() select = new EventEmitter<string>();
  @Output() addAt = new EventEmitter<{ point: InsertionPoint; anchor: HTMLElement }>();
  @Output() paletteDropped = new EventEmitter<{ point: InsertionPoint; choice: PaletteChoice }>();

  /** Which connector (if any) currently has a drag hovering over it, for
   *  the highlight style. 'linear' for the single non-Choice connector,
   *  'branch-<i>' for a specific Choice branch's connector. */
  readonly dragOverKey = signal<string | null>(null);

  integrationLabel(state: AslState): string {
    return integrationLabel(state);
  }

  isTerminalState(): boolean {
    return this.node.kind === 'state' && this.node.children.length === 0;
  }

  /** True when every one of a Choice's branches is (recursively) all-terminal
   *  — an unfilled empty-slot, a real state with nothing after it, or a
   *  further-nested Choice whose own branches are themselves all-terminal,
   *  checked to any depth (see subtreeIsAllTerminal). When true, this
   *  Choice's branches fan into ONE shared End — rendered here only if no
   *  ancestor already claimed it (see hideEndCircle), otherwise this level
   *  just keeps the fan-in bar/filler going and lets the ancestor's own
   *  circle be the one the whole nested tree converges on. */
  allBranchesTerminal(children: RenderChild[]): boolean {
    return children.every(c => subtreeIsAllTerminal(c.node));
  }

  /** buildRenderTree() is deliberately uncached -- it runs fresh on every
   *  change-detection cycle, producing brand-new RenderChild/RenderNode
   *  objects every time even when nothing actually changed. Angular's
   *  *ngFor, with no trackBy, uses object identity by default -- seeing an
   *  entirely new set of objects on every tick, it was destroying and
   *  recreating every nested <app-state-node> (and the cdkDropList inside
   *  it) reached through a *ngFor on every single CD cycle, which is what
   *  broke drag-and-drop on anything past the outermost Choice (a
   *  change-detection tick firing mid-drag could swap the connector's DOM
   *  element out from under CDK's drag tracking). Branch count/order for a
   *  given Choice is stable across incidental re-renders -- only a real
   *  edit changes it -- so plain index is a safe, correct key: it tells
   *  Angular "position N is still logically the same branch", so it
   *  updates the existing component's inputs instead of tearing it down. */
  trackByIndex(index: number): number {
    return index;
  }

  onSelect(name: string) {
    this.select.emit(name);
  }

  onAddAfterState(stateName: string, event: MouseEvent) {
    this.addAt.emit({
      point: { kind: 'after-state', stateName },
      anchor: event.currentTarget as HTMLElement,
    });
  }

  onAddBranch(stateName: string, branchIndex: number, isDefault: boolean, event: MouseEvent) {
    const point: InsertionPoint = isDefault
      ? { kind: 'choice-default', stateName }
      : { kind: 'choice-branch', stateName, branchIndex };
    this.addAt.emit({ point, anchor: event.currentTarget as HTMLElement });
  }

  onDragEnter(key: string) {
    this.dragOverKey.set(key);
  }

  onDragExit(key: string) {
    if (this.dragOverKey() === key) this.dragOverKey.set(null);
  }

  onDropAfterState(stateName: string, event: CdkDragDrop<unknown, unknown, PaletteChoice>) {
    this.dragOverKey.set(null);
    this.paletteDropped.emit({
      point: { kind: 'after-state', stateName },
      choice: event.item.data,
    });
  }

  onDropBranch(
    stateName: string,
    branchIndex: number,
    isDefault: boolean,
    event: CdkDragDrop<unknown, unknown, PaletteChoice>,
  ) {
    this.dragOverKey.set(null);
    const point: InsertionPoint = isDefault
      ? { kind: 'choice-default', stateName }
      : { kind: 'choice-branch', stateName, branchIndex };
    this.paletteDropped.emit({ point, choice: event.item.data });
  }

  /** The empty-slot node already carries the exact InsertionPoint needed —
   *  computed once, in buildRenderTree(), at the point the empty reference
   *  was found — so these two just pass it straight through, unlike the
   *  other onAdd/onDrop methods above, which have to reconstruct the
   *  point from separate stateName/branchIndex/isDefault parameters. */
  onAddEmptySlot(point: InsertionPoint, event: MouseEvent) {
    this.addAt.emit({ point, anchor: event.currentTarget as HTMLElement });
  }

  onDropEmptySlot(point: InsertionPoint, event: CdkDragDrop<unknown, unknown, PaletteChoice>) {
    this.dragOverKey.set(null);
    this.paletteDropped.emit({ point, choice: event.item.data });
  }
}
