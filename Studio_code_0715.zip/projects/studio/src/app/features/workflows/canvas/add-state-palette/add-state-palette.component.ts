import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Output } from '@angular/core';
import { PALETTE_OPTIONS, PaletteChoice } from '../../utils/palette-options';

export type { PaletteChoice };

@Component({
  selector: 'app-add-state-palette',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './add-state-palette.component.html',
  styleUrls: ['./add-state-palette.component.scss'],
})
export class AddStatePaletteComponent {
  @Output() pick = new EventEmitter<PaletteChoice>();

  readonly options = PALETTE_OPTIONS;
}
