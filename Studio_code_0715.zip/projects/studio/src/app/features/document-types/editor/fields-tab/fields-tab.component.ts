import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, inject, signal } from '@angular/core';
import { DragDropModule, CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import {
  ConfigField,
  ConfigLineItemColumn,
  ConfigLineItems,
  ConfigPageType,
  DictionaryRecord,
  ExtractionMethod,
  FieldDataType,
  ValidationType,
} from '@akrify/shared';
import { StudioConfigService } from '../../../../services/studio-config.service';

/** Data types selectable on a regular field, including the special 'LineItem'
 *  marker that converts the field into one of the page's Line Items tables. */
const BASE_DATA_TYPES: FieldDataType[] = ['String', 'Number', 'Date', 'Currency', 'Dropdown', 'Boolean'];
const FIELD_DATA_TYPES: FieldDataType[] = [...BASE_DATA_TYPES, 'LineItem'];
/** Line Item columns can't themselves be line items — no nesting. */
const COLUMN_DATA_TYPES: FieldDataType[] = BASE_DATA_TYPES;

const EXTRACTION_METHODS: { key: ExtractionMethod; label: string; hint: string }[] = [
  { key: 'Anchor',   label: 'Anchor',   hint: 'Find value near a label/keyword' },
  { key: 'Position', label: 'Position', hint: 'Fixed coordinates on the page' },
  { key: 'Regex',    label: 'Regex',    hint: 'Pattern match on page text' },
  { key: 'AI',       label: 'AI',       hint: 'Bedrock model with a prompt' },
];
const VALIDATION_TYPES: { key: ValidationType; label: string; hint: string }[] = [
  { key: 'Format', label: 'Format', hint: 'Value must match a pattern (or date format)' },
  { key: 'Range',  label: 'Range',  hint: 'Value must fall within a min/max bound' },
];

let uid = 0;
let colUid = 0;

@Component({
  selector: 'app-fields-tab',
  standalone: true,
  imports: [CommonModule, FormsModule, DragDropModule],
  templateUrl: './fields-tab.component.html',
  styleUrls: ['./fields-tab.component.scss'],
})
export class FieldsTabComponent implements OnChanges, OnInit {
  private readonly configService = inject(StudioConfigService);

  @Input({ required: true }) pageTypes!: ConfigPageType[];
  @Input({ required: true }) selectedPageType!: string;

  @Output() selectPageType = new EventEmitter<string>();
  @Output() changed = new EventEmitter<void>();

  readonly dataTypes = FIELD_DATA_TYPES;
  readonly columnDataTypes = COLUMN_DATA_TYPES;
  readonly extractionMethods = EXTRACTION_METHODS;
  readonly validationTypes = VALIDATION_TYPES;

  readonly dictionaries = signal<DictionaryRecord[]>([]);

  readonly selectedFieldName = signal<string | null>(null);
  readonly newKeyword = signal('');
  readonly newExample = signal('');

  /** Index into the current page type's LineItems array, or null when a
   *  regular field (not a Line Items table) is selected. A page can have
   *  any number of Line Items tables, each independently selectable. */
  readonly viewingLineItemsIndex = signal<number | null>(null);
  readonly lineItemsNameError = signal<string | null>(null);

  ngOnInit() {
    this.configService.listDictionaries().subscribe({
      next: dicts => this.dictionaries.set(dicts),
      error: () => this.dictionaries.set([]), // non-fatal — dropdown fields just won't offer a dictionary picker
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['selectedPageType'] || changes['pageTypes']) {
      // Older/pre-migration data may still have LineItems as a single object
      // (the runtime schema only ever had one before this round of changes).
      // Fix it up in place BEFORE anything else touches it, so every other
      // method here can safely assume an array.
      this.normalizeLegacyLineItemsShape();

      // Reset selection if the current field no longer exists on this page type
      // (e.g. after switching page types).
      this.viewingLineItemsIndex.set(null);
      this.lineItemsNameError.set(null);
      const fields = this.currentFields();
      if (!fields.some(f => f.FieldName === this.selectedFieldName())) {
        this.selectedFieldName.set(fields[0]?.FieldName ?? null);
      }
    }
  }

  /** Walks every page type (not just the currently selected one, since any
   *  of them could hold legacy-shaped data) and wraps a single-object
   *  LineItems into a 1-element array. Idempotent — already-array data is
   *  left untouched, so this is safe to call on every change. Deliberately
   *  does NOT emit `changed`: this is a defensive shape fix, not a real
   *  edit, so it won't mark the draft dirty just from loading a page. The
   *  corrected shape gets persisted the next time any real edit is saved. */
  private normalizeLegacyLineItemsShape() {
    for (const pt of this.pageTypes) {
      const li: unknown = pt.LineItems;
      if (li && !Array.isArray(li)) {
        pt.LineItems = [li as ConfigLineItems];
      }
    }
  }

  currentPageType(): ConfigPageType | undefined {
    return this.pageTypes.find(p => p.PageType === this.selectedPageType) ?? this.pageTypes[0];
  }

  currentFields(): ConfigField[] {
    return this.currentPageType()?.Fields ?? [];
  }

  selectedField(): ConfigField | null {
    const name = this.selectedFieldName();
    if (!name) return null;
    return this.currentFields().find(f => f.FieldName === name) ?? null;
  }

  /** Every Line Items table on the currently selected page type. */
  lineItemsList(): ConfigLineItems[] {
    return this.currentPageType()?.LineItems ?? [];
  }

  /** Whichever Line Items table is currently open in the inspector, if any. */
  selectedLineItems(): ConfigLineItems | null {
    const idx = this.viewingLineItemsIndex();
    if (idx === null) return null;
    return this.lineItemsList()[idx] ?? null;
  }

  /** Same index as viewingLineItemsIndex(), but non-nullable for template use
   *  where it's only ever called after selectedLineItems() confirms one is
   *  selected — avoids relying on non-null assertions in the template. */
  selectedLineItemsIndexOrZero(): number {
    return this.viewingLineItemsIndex() ?? 0;
  }

  onPageTypeClick(name: string) {
    this.selectPageType.emit(name);
  }

  /** Hint text for the currently selected field's extraction method. Kept as
   *  a component method (not inline in the template) because Angular's
   *  template expression parser does not support arrow functions. */
  activeMethodHint(): string {
    const method = this.selectedField()?.ExtractionMethod;
    return this.extractionMethods.find(m => m.key === method)?.hint ?? '';
  }

  selectField(name: string) {
    this.viewingLineItemsIndex.set(null);
    this.selectedFieldName.set(name);
  }

  selectLineItems(index: number) {
    this.selectedFieldName.set(null);
    this.viewingLineItemsIndex.set(index);
    this.lineItemsNameError.set(null);
  }

  addField() {
    const pt = this.currentPageType();
    if (!pt) return;
    if (!pt.Fields) pt.Fields = [];
    const name = `NEW_FIELD_${++uid}`;
    pt.Fields.push({
      FieldName: name,
      Label: 'New Field',
      DataType: 'String',
      Required: false,
      ExtractionMethod: 'Regex',
    });
    this.selectField(name);
    this.changed.emit();
  }

  deleteField(name: string) {
    const pt = this.currentPageType();
    if (!pt?.Fields) return;
    const idx = pt.Fields.findIndex(f => f.FieldName === name);
    if (idx === -1) return;
    pt.Fields.splice(idx, 1);
    if (this.selectedFieldName() === name) {
      this.selectedFieldName.set(pt.Fields[0]?.FieldName ?? null);
    }
    this.changed.emit();
  }

  // ─── Inspector field updates ──────────────────────────────────────
  // Each setter mutates the field object in place (it's a reference into
  // the parent's draft tree) and emits `changed` so the shell marks dirty.

  updateFieldName(newName: string) {
    const f = this.selectedField();
    if (!f) return;
    const clean = newName.toUpperCase().replace(/\s+/g, '_');
    f.FieldName = clean;
    this.selectedFieldName.set(clean);
    this.changed.emit();
  }

  updateLabel(v: string)               { this.mutate(f => f.Label = v); }
  updateOptionsRef(v: string)          { this.mutate(f => f.OptionsRef = v || undefined); }
  updateRequired(v: boolean)           { this.mutate(f => f.Required = v); }
  updateDisabled(v: boolean)           { this.mutate(f => f.Disabled = v); }
  updateConfidence(v: string) {
    const n = parseFloat(v);
    this.mutate(f => f.ConfidenceScore = Number.isFinite(n) ? n : undefined);
  }

  /** 'LineItem' is a UI-only marker — it's never actually persisted as a
   *  field's DataType. Selecting it converts this field into a NEW entry in
   *  the page's Line Items array (matching the real runtime schema, which
   *  stores Line Items separately from Fields[]) rather than setting a
   *  literal DataType value on the field itself. A page can have any number
   *  of these — no cap, no "already has one" restriction. */
  updateDataType(v: FieldDataType) {
    if (v === 'LineItem') {
      this.convertFieldToLineItems();
      return;
    }
    this.mutate(f => f.DataType = v);
  }

  private convertFieldToLineItems() {
    const pt = this.currentPageType();
    const f = this.selectedField();
    if (!pt || !f) return;

    if (pt.Fields) {
      const idx = pt.Fields.findIndex(x => x.FieldName === f.FieldName);
      if (idx !== -1) pt.Fields.splice(idx, 1);
    }
    if (!pt.LineItems) pt.LineItems = [];
    pt.LineItems.push({
      Name: f.FieldName,
      EmptyText: 'No items to display',
      MinRows: 0,
      Columns: [],
    });
    this.selectedFieldName.set(null);
    this.viewingLineItemsIndex.set(pt.LineItems.length - 1);
    this.changed.emit();
  }

  updateExtractionMethod(method: ExtractionMethod) {
    this.mutate(f => {
      f.ExtractionMethod = method;
      // Ensure the method-specific structure exists so the panel has something to bind to.
      if (method === 'AI' && !f.AI) {
        f.AI = { Description: '', Examples: [], Fallback: 'Regex' };
      }
      if (method === 'Position' && !f.Position) {
        f.Position = { X: 0, Y: 0, Width: 100, Height: 20 };
      }
    });
  }

  // Regex panel (extraction only — validation moved to its own independent section below)
  updateExtractionRegex(v: string)  { this.mutate(f => f.ExtractionRegex = v); }

  // ─── Validation — independent of extraction method ─────────────────

  isValidationEnabled(): boolean {
    return this.selectedField()?.ValidationTypes != null;
  }

  toggleValidation(enabled: boolean) {
    this.mutate(f => {
      f.ValidationTypes = enabled ? [] : undefined;
    });
  }

  hasValidationType(type: ValidationType): boolean {
    return this.selectedField()?.ValidationTypes?.includes(type) ?? false;
  }

  toggleValidationType(type: ValidationType, checked: boolean) {
    this.mutate(f => {
      const current = f.ValidationTypes ?? [];
      f.ValidationTypes = checked
        ? [...current, type].filter((t, i, arr) => arr.indexOf(t) === i)
        : current.filter(t => t !== type);
    });
  }

  updateValidationRegex(v: string)  { this.mutate(f => f.ValidationRegex = v); }
  updateFormatString(v: string)     { this.mutate(f => f.Format = v); }
  updateMinValue(raw: string) {
    const n = parseFloat(raw);
    this.mutate(f => f.MinValue = raw === '' || !Number.isFinite(n) ? undefined : n);
  }
  updateMaxValue(raw: string) {
    const n = parseFloat(raw);
    this.mutate(f => f.MaxValue = raw === '' || !Number.isFinite(n) ? undefined : n);
  }

  // Anchor panel
  addKeyword() {
    const kw = this.newKeyword().trim();
    if (!kw) return;
    this.mutate(f => {
      if (!f.FieldKeywords) f.FieldKeywords = [];
      if (!f.FieldKeywords.includes(kw)) f.FieldKeywords.push(kw);
    });
    this.newKeyword.set('');
  }
  removeKeyword(kw: string) {
    this.mutate(f => { f.FieldKeywords = (f.FieldKeywords ?? []).filter(k => k !== kw); });
  }

  // Position panel
  updatePositionField(key: 'Page' | 'X' | 'Y' | 'Width' | 'Height', raw: string) {
    const n = parseFloat(raw);
    this.mutate(f => {
      if (!f.Position) f.Position = { X: 0, Y: 0, Width: 100, Height: 20 };
      (f.Position as any)[key] = Number.isFinite(n) ? n : (key === 'Page' ? undefined : 0);
    });
  }

  // AI panel
  updateAiDescription(v: string) { this.mutate(f => { if (f.AI) f.AI.Description = v; }); }
  updateAiModel(v: string)       { this.mutate(f => { if (f.AI) f.AI.Model = v || undefined; }); }
  updateAiFallback(v: string)    { this.mutate(f => { if (f.AI) f.AI.Fallback = v as any; }); }
  addExample() {
    const ex = this.newExample().trim();
    if (!ex) return;
    this.mutate(f => {
      if (!f.AI) return;
      if (!f.AI.Examples) f.AI.Examples = [];
      f.AI.Examples.push(ex);
    });
    this.newExample.set('');
  }
  removeExample(ex: string) {
    this.mutate(f => { if (f.AI?.Examples) f.AI.Examples = f.AI.Examples.filter(e => e !== ex); });
  }

  private mutate(fn: (f: ConfigField) => void) {
    const f = this.selectedField();
    if (!f) return;
    fn(f);
    this.changed.emit();
  }

  // ═══════════════════════════════════════════════════════════════════
  // Line Items — table-level settings and column management. All methods
  // operate on whichever entry `viewingLineItemsIndex` currently points to.
  // ═══════════════════════════════════════════════════════════════════

  deleteLineItems(index: number) {
    const pt = this.currentPageType();
    if (!pt?.LineItems) return;
    pt.LineItems.splice(index, 1);
    if (pt.LineItems.length === 0) pt.LineItems = undefined;

    const viewing = this.viewingLineItemsIndex();
    if (viewing === index) {
      this.viewingLineItemsIndex.set(null);
      this.selectedFieldName.set(this.currentFields()[0]?.FieldName ?? null);
    } else if (viewing !== null && viewing > index) {
      this.viewingLineItemsIndex.set(viewing - 1);
    }
    this.changed.emit();
  }

  updateLineItemsName(index: number, raw: string) {
    const pt = this.currentPageType();
    const li = pt?.LineItems?.[index];
    if (!pt || !li) return;
    const newName = raw.trim();
    if (!newName) {
      this.lineItemsNameError.set('Name cannot be empty.');
      return;
    }
    const collides =
      (pt.Fields ?? []).some(f => f.FieldName === newName) ||
      (pt.LineItems ?? []).some((other, i) => i !== index && other.Name === newName);
    if (collides) {
      this.lineItemsNameError.set('Another field or Line Items table already uses this name.');
      return;
    }
    this.lineItemsNameError.set(null);
    li.Name = newName;
    this.changed.emit();
  }

  updateLineItemsEmptyText(index: number, v: string) {
    this.mutateLineItemsAt(index, li => li.EmptyText = v);
  }

  updateLineItemsMinRows(index: number, raw: string) {
    const n = parseInt(raw, 10);
    this.mutateLineItemsAt(index, li => li.MinRows = Number.isFinite(n) && n >= 0 ? n : 0);
  }

  private mutateLineItemsAt(index: number, fn: (li: ConfigLineItems) => void) {
    const li = this.currentPageType()?.LineItems?.[index];
    if (!li) return;
    fn(li);
    this.changed.emit();
  }

  // ─── Columns ──────────────────────────────────────────────────────

  addColumn(liIndex: number) {
    const li = this.currentPageType()?.LineItems?.[liIndex];
    if (!li) return;
    const name = `COLUMN_${++colUid}`;
    li.Columns.push({ FieldName: name, Label: 'New Column', DataType: 'String', Required: false });
    this.changed.emit();
  }

  deleteColumn(liIndex: number, colIndex: number) {
    const li = this.currentPageType()?.LineItems?.[liIndex];
    if (!li) return;
    li.Columns.splice(colIndex, 1);
    this.changed.emit();
  }

  updateColumnFieldName(liIndex: number, colIndex: number, v: string) {
    const li = this.currentPageType()?.LineItems?.[liIndex];
    if (!li) return;
    li.Columns[colIndex].FieldName = v.toUpperCase().replace(/\s+/g, '_');
    this.changed.emit();
  }

  updateColumnLabel(liIndex: number, colIndex: number, v: string) {
    const li = this.currentPageType()?.LineItems?.[liIndex];
    if (!li) return;
    li.Columns[colIndex].Label = v;
    this.changed.emit();
  }

  updateColumnDataType(liIndex: number, colIndex: number, v: FieldDataType) {
    const li = this.currentPageType()?.LineItems?.[liIndex];
    if (!li) return;
    li.Columns[colIndex].DataType = v;
    if (v !== 'Dropdown') li.Columns[colIndex].OptionsRef = undefined;
    this.changed.emit();
  }

  updateColumnRequired(liIndex: number, colIndex: number, v: boolean) {
    const li = this.currentPageType()?.LineItems?.[liIndex];
    if (!li) return;
    li.Columns[colIndex].Required = v;
    this.changed.emit();
  }

  updateColumnOptionsRef(liIndex: number, colIndex: number, v: string) {
    const li = this.currentPageType()?.LineItems?.[liIndex];
    if (!li) return;
    li.Columns[colIndex].OptionsRef = v || undefined;
    this.changed.emit();
  }

  onColumnDrop(liIndex: number, event: CdkDragDrop<ConfigLineItemColumn[]>) {
    const li = this.currentPageType()?.LineItems?.[liIndex];
    if (!li) return;
    if (event.previousIndex === event.currentIndex) return;
    moveItemInArray(li.Columns, event.previousIndex, event.currentIndex);
    this.changed.emit();
  }
}
