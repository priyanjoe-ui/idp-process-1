import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges, signal } from '@angular/core';
import { DragDropModule, CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { ConfigPageType, PageIdentificationMethod } from '@akrify/shared';
import { AutoFocusSelectDirective } from '../../../../shared/directives/auto-focus-select.directive';

const IDENTIFICATION_METHODS: { key: PageIdentificationMethod; label: string; hint: string }[] = [
  { key: 'Sequential', label: 'Sequential', hint: 'Always the Nth page — position set by drag order in the list.' },
  { key: 'Keyword',    label: 'Keyword',    hint: 'Identified by matching keywords found on the page.' },
  { key: 'WordCount',  label: 'Word Count', hint: "Identified as blank when the page has fewer words than the threshold." },
];

let uid = 0;

@Component({
  selector: 'app-pages-tab',
  standalone: true,
  imports: [CommonModule, FormsModule, DragDropModule, AutoFocusSelectDirective],
  templateUrl: './pages-tab.component.html',
  styleUrls: ['./pages-tab.component.scss'],
})
export class PagesTabComponent implements OnChanges {
  @Input({ required: true }) pageTypes!: ConfigPageType[];

  @Output() changed = new EventEmitter<void>();
  /** Lets the editor shell keep the Fields tab's selected page type in sync. */
  @Output() renamed = new EventEmitter<{ oldName: string; newName: string }>();
  @Output() removed = new EventEmitter<string>();
  @Output() added = new EventEmitter<string>();

  readonly identificationMethods = IDENTIFICATION_METHODS;

  readonly selectedPageTypeName = signal<string | null>(null);
  readonly confirmingDeleteFor = signal<string | null>(null);
  readonly nameDraft = signal('');
  readonly nameError = signal<string | null>(null);
  readonly newKeyword = signal('');

  /** Name of the page type currently being renamed inline in the list row
   *  (double-click, or immediately after adding a new one) — separate from
   *  `selectedPageTypeName`, which just controls the inspector panel. */
  readonly renamingPageType = signal<string | null>(null);
  readonly renameDraft = signal('');

  ngOnChanges(changes: SimpleChanges) {
    if (changes['pageTypes'] && this.pageTypes.length && !this.selectedPageTypeName()) {
      this.selectedPageTypeName.set(this.pageTypes[0].PageType);
    }
    const sel = this.findSelected();
    this.nameDraft.set(sel?.PageType ?? '');
  }

  private findSelected(): ConfigPageType | null {
    const name = this.selectedPageTypeName();
    return this.pageTypes.find(p => p.PageType === name) ?? null;
  }

  selectedPageType(): ConfigPageType | null {
    return this.findSelected();
  }

  selectPageType(name: string) {
    this.confirmingDeleteFor.set(null);
    this.selectedPageTypeName.set(name);
    const pt = this.pageTypes.find(p => p.PageType === name);
    this.nameDraft.set(pt?.PageType ?? '');
    this.nameError.set(null);
  }

  methodHint(): string {
    const method = this.selectedPageType()?.IdentificationMethod ?? 'Keyword';
    return this.identificationMethods.find(m => m.key === method)?.hint ?? '';
  }

  onDrop(event: CdkDragDrop<ConfigPageType[]>) {
    if (event.previousIndex === event.currentIndex) return;
    moveItemInArray(this.pageTypes, event.previousIndex, event.currentIndex);
    this.renumber();
    this.changed.emit();
  }

  private renumber() {
    this.pageTypes.forEach((pt, i) => { pt.SequenceOrder = i + 1; });
  }

  addPageType() {
    const name = `NEW_PAGE_${++uid}`;
    this.pageTypes.push({
      PageType: name,
      IdentificationMethod: 'Keyword',
      SequenceOrder: this.pageTypes.length + 1,
      Fields: [],
      Keywords: [],
    });
    this.selectPageType(name);
    this.startRowRename(name);
    this.added.emit(name);
    this.changed.emit();
  }

  /** Double-click on a row's name, or right after adding a new page type. */
  startRename(pt: ConfigPageType, event: Event) {
    event.stopPropagation();
    this.startRowRename(pt.PageType);
  }

  private startRowRename(name: string) {
    this.renamingPageType.set(name);
    this.renameDraft.set(name);
  }

  onRenameDraftInput(v: string) {
    this.renameDraft.set(v);
  }

  /** Commits the inline row-rename. Invalid/duplicate names silently revert
   *  (the row has no room for detailed error text) — the inspector's own
   *  name field surfaces validation messages if more detail is needed. */
  commitRowRename(pt: ConfigPageType) {
    if (this.renamingPageType() !== pt.PageType) return; // already handled (e.g. Escape already fired)
    const newName = this.renameDraft().trim();
    const oldName = pt.PageType;
    this.renamingPageType.set(null);

    if (!newName) return;
    if (newName !== oldName && this.pageTypes.some(p => p.PageType === newName)) return;
    if (newName === oldName) return;

    pt.PageType = newName;
    if (this.selectedPageTypeName() === oldName) {
      this.selectedPageTypeName.set(newName);
      this.nameDraft.set(newName); // keep inspector's name field in sync too
    }
    this.renamed.emit({ oldName, newName });
    this.changed.emit();
  }

  cancelRowRename() {
    this.renamingPageType.set(null);
  }

  requestDelete(name: string, event: Event) {
    event.stopPropagation();
    this.confirmingDeleteFor.set(name);
  }
  cancelDelete(event: Event) {
    event.stopPropagation();
    this.confirmingDeleteFor.set(null);
  }
  confirmDelete(name: string, event: Event) {
    event.stopPropagation();
    const idx = this.pageTypes.findIndex(p => p.PageType === name);
    if (idx === -1) return;
    this.pageTypes.splice(idx, 1);
    this.renumber();
    this.confirmingDeleteFor.set(null);
    if (this.selectedPageTypeName() === name) {
      this.selectedPageTypeName.set(this.pageTypes[0]?.PageType ?? null);
    }
    this.removed.emit(name);
    this.changed.emit();
  }

  onNameInput(v: string) {
    this.nameDraft.set(v);
  }

  commitName() {
    const pt = this.selectedPageType();
    if (!pt) return;
    const newName = this.nameDraft().trim();
    const oldName = pt.PageType;
    if (!newName) {
      this.nameError.set('Name cannot be empty.');
      this.nameDraft.set(oldName);
      return;
    }
    if (newName !== oldName && this.pageTypes.some(p => p.PageType === newName)) {
      this.nameError.set('A page type with this name already exists.');
      this.nameDraft.set(oldName);
      return;
    }
    this.nameError.set(null);
    if (newName === oldName) return;
    pt.PageType = newName;
    this.selectedPageTypeName.set(newName);
    this.renamed.emit({ oldName, newName });
    this.changed.emit();
  }

  updateIdentificationMethod(method: PageIdentificationMethod) {
    this.mutate(pt => {
      pt.IdentificationMethod = method;
      if (method === 'WordCount' && pt.MaxWordCount == null) pt.MaxWordCount = 5;
      if (method === 'Keyword' && !pt.Keywords) pt.Keywords = [];
    });
  }

  updateMaxWordCount(raw: string) {
    const n = parseInt(raw, 10);
    this.mutate(pt => { pt.MaxWordCount = Number.isFinite(n) && n >= 0 ? n : 0; });
  }

  addKeyword() {
    const kw = this.newKeyword().trim();
    if (!kw) return;
    this.mutate(pt => {
      if (!pt.Keywords) pt.Keywords = [];
      if (!pt.Keywords.includes(kw)) pt.Keywords.push(kw);
    });
    this.newKeyword.set('');
  }
  removeKeyword(kw: string) {
    this.mutate(pt => { pt.Keywords = (pt.Keywords ?? []).filter(k => k !== kw); });
  }

  positionLabel(pt: ConfigPageType): number {
    return this.pageTypes.indexOf(pt) + 1;
  }

  private mutate(fn: (pt: ConfigPageType) => void) {
    const pt = this.selectedPageType();
    if (!pt) return;
    fn(pt);
    this.changed.emit();
  }
}
