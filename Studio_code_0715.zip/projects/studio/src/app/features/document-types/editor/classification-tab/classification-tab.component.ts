import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, EventEmitter, Input, Output, signal } from '@angular/core';
import { ClassificationConfig, ConfigDocumentType, DocumentClassificationMode } from '@akrify/shared';

@Component({
  selector: 'app-classification-tab',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './classification-tab.component.html',
  styleUrls: ['./classification-tab.component.scss'],
})
export class ClassificationTabComponent {
  @Input({ required: true }) documentType!: ConfigDocumentType;
  @Output() changed = new EventEmitter<void>();

  readonly newKeyword = signal('');

  keywords(): string[] {
    return this.documentType.Classification?.Keywords ?? [];
  }

  threshold(): number | null {
    return this.documentType.Classification?.ConfidenceThreshold ?? null;
  }

  addKeyword() {
    const kw = this.newKeyword().trim();
    if (!kw) return;
    const cls = this.ensureClassification();
    if (!cls.Keywords.includes(kw)) cls.Keywords.push(kw);
    this.newKeyword.set('');
    this.changed.emit();
  }

  removeKeyword(kw: string) {
    if (!this.documentType.Classification) return;
    this.documentType.Classification.Keywords = this.documentType.Classification.Keywords.filter(k => k !== kw);
    this.changed.emit();
  }

  updateThreshold(raw: string) {
    const n = parseFloat(raw);
    const cls = this.ensureClassification();
    cls.ConfidenceThreshold = raw === '' || !Number.isFinite(n) ? undefined : n;
    this.changed.emit();
  }

  /** Only creates the Classification object on an actual edit — just viewing
   *  this tab with nothing configured yet shouldn't mark the draft dirty. */
  private ensureClassification(): ClassificationConfig {
    if (!this.documentType.Classification) {
      this.documentType.Classification = { Keywords: [] };
    }
    return this.documentType.Classification;
  }

  // ─── Page classification defaults ──────────────────────────────────
  // These don't drive anything live — they're just the default seed for
  // NEW pages (used once, at document-type creation). Loaded here too so
  // editing an existing document type shows the same fields consistently,
  // whether or not it happened to be created before this feature existed.

  classificationMode(): DocumentClassificationMode {
    return this.documentType.ClassificationMode ?? 'Sequential';
  }

  updateClassificationMode(mode: DocumentClassificationMode) {
    this.documentType.ClassificationMode = mode;
    this.changed.emit();
  }

  blankPageMaxWordCount(): number {
    return this.documentType.BlankPageMaxWordCount ?? 5;
  }

  updateBlankPageMaxWordCount(raw: string) {
    const n = parseInt(raw, 10);
    this.documentType.BlankPageMaxWordCount = Number.isFinite(n) && n >= 0 ? n : 5;
    this.changed.emit();
  }
}
