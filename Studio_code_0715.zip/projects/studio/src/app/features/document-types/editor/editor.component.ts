import { CommonModule } from '@angular/common';
import { Component, computed, inject, OnInit, signal } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ConfigDocumentType, ConfigPageType, DocumentTypeRecord } from '@akrify/shared';
import { StudioConfigService, VersionConflictError } from '../../../services/studio-config.service';
import { FieldsTabComponent } from './fields-tab/fields-tab.component';
import { PagesTabComponent } from './pages-tab/pages-tab.component';
import { ClassificationTabComponent } from './classification-tab/classification-tab.component';
import { DeleteDocumentTypeModalComponent } from '../delete-document-type-modal/delete-document-type-modal.component';

type EditorTab = 'pages' | 'fields' | 'classification' | 'indexer-ui';

const TAB_KEYS: EditorTab[] = ['pages', 'fields', 'classification', 'indexer-ui'];

const TABS: { key: EditorTab; label: string }[] = [
  { key: 'pages',          label: 'Pages' },
  { key: 'fields',         label: 'Fields' },
  { key: 'classification', label: 'Classification' },
  { key: 'indexer-ui',     label: 'Indexer UI' },
];

@Component({
  selector: 'app-document-type-editor',
  standalone: true,
  imports: [CommonModule, RouterLink, FieldsTabComponent, PagesTabComponent, ClassificationTabComponent, DeleteDocumentTypeModalComponent],
  templateUrl: './editor.component.html',
  styleUrls: ['./editor.component.scss'],
})
export class DocumentTypeEditorComponent implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly configService = inject(StudioConfigService);

  appId!: string;
  docTypeId!: string;

  readonly tabs = TABS;
  // Pages is the default landing tab everywhere — page structure is what
  // Fields depends on, so it's the natural starting point whether this is
  // a brand-new Document Type or one opened from the list.
  readonly activeTab = signal<EditorTab>('pages');

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly record = signal<DocumentTypeRecord | null>(null);

  /** Local editable copy. Diverges from `record().body` once the user makes changes. */
  readonly draft = signal<ConfigDocumentType | null>(null);
  readonly dirty = signal(false);

  readonly saving = signal(false);
  readonly saveError = signal<string | null>(null);
  readonly conflict = signal<VersionConflictError | null>(null);

  readonly showDeleteModal = signal(false);

  readonly selectedPageType = signal<string>('MainPage');

  readonly pageTypeNames = computed(() => {
    const d = this.draft();
    return d ? d.PageTypes.map(p => p.PageType) : [];
  });

  readonly currentPageType = computed<ConfigPageType | null>(() => {
    const d = this.draft();
    if (!d) return null;
    return d.PageTypes.find(p => p.PageType === this.selectedPageType()) ?? d.PageTypes[0] ?? null;
  });

  ngOnInit() {
    this.appId = this.route.snapshot.paramMap.get('appId')!;
    this.docTypeId = this.route.snapshot.paramMap.get('docTypeId')!;

    // Still honored if present (e.g. an old bookmarked link), but the
    // default above already covers the common "land on Pages" case.
    const requestedTab = this.route.snapshot.queryParamMap.get('tab');
    if (requestedTab && (TAB_KEYS as string[]).includes(requestedTab)) {
      this.activeTab.set(requestedTab as EditorTab);
    }

    this.load();
  }

  load() {
    this.loading.set(true);
    this.error.set(null);
    this.configService.getDocumentType(this.appId, this.docTypeId).subscribe({
      next: rec => {
        this.record.set(rec);
        this.draft.set(structuredClone(rec.body));
        this.dirty.set(false);
        this.ensureValidSelectedPageType();
        this.loading.set(false);
      },
      error: err => {
        this.error.set(err?.message || 'Failed to load document type.');
        this.loading.set(false);
      },
    });
  }

  setTab(t: EditorTab) { this.activeTab.set(t); }
  selectPageType(name: string) { this.selectedPageType.set(name); }

  /** Called by child tabs whenever they mutate the draft in place. */
  onDraftChanged() {
    this.dirty.set(true);
  }

  /** Pages tab renamed a page type — keep Fields tab's selection pointed at it. */
  onPageTypeRenamed(evt: { oldName: string; newName: string }) {
    if (this.selectedPageType() === evt.oldName) {
      this.selectedPageType.set(evt.newName);
    }
  }

  /** Pages tab deleted a page type — fall back to the first remaining one if it was selected. */
  onPageTypeRemoved(name: string) {
    if (this.selectedPageType() === name) {
      const first = this.draft()?.PageTypes[0]?.PageType;
      if (first) this.selectedPageType.set(first);
    }
  }

  /**
   * Pages tab added a new page type — make it the selected one so switching
   * to Fields immediately shows it, rather than leaving Fields pointed at
   * whatever page was selected before (which made the new page technically
   * present as a pill, but easy to miss).
   */
  onPageTypeAdded(name: string) {
    this.selectedPageType.set(name);
  }

  /** Defensive: if the currently-selected page type no longer exists
   *  (stale after a load/save), fall back to the first available one. */
  private ensureValidSelectedPageType() {
    const pageTypes = this.draft()?.PageTypes ?? [];
    if (pageTypes.length === 0) return;
    const stillValid = pageTypes.some(p => p.PageType === this.selectedPageType());
    if (!stillValid) {
      this.selectedPageType.set(pageTypes[0].PageType);
    }
  }

  save() {
    const rec = this.record();
    const d = this.draft();
    if (!rec || !d || this.saving()) return;

    this.saving.set(true);
    this.saveError.set(null);
    this.conflict.set(null);

    this.configService.updateDocumentType(this.appId, this.docTypeId, d, rec.version).subscribe({
      next: updated => {
        this.record.set(updated);
        this.draft.set(structuredClone(updated.body));
        this.dirty.set(false);
        this.saving.set(false);
        this.ensureValidSelectedPageType();
      },
      error: err => {
        this.saving.set(false);
        if (err instanceof VersionConflictError) {
          this.conflict.set(err);
        } else {
          this.saveError.set(err?.message || 'Failed to save.');
        }
      },
    });
  }

  /** User chose to reload after a conflict, discarding local edits. */
  reloadAfterConflict() {
    this.conflict.set(null);
    this.load();
  }

  discardChanges() {
    const rec = this.record();
    if (!rec) return;
    this.draft.set(structuredClone(rec.body));
    this.dirty.set(false);
    this.saveError.set(null);
    this.ensureValidSelectedPageType();
  }

  openDeleteModal()  { this.showDeleteModal.set(true); }
  closeDeleteModal() { this.showDeleteModal.set(false); }

  onDocumentTypeDeleted() {
    this.router.navigate(['/applications', this.appId, 'document-types']);
  }

  backToList() {
    this.router.navigate(['/applications', this.appId, 'document-types']);
  }
}
