import { CommonModule, DecimalPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, computed, inject, Input, OnInit, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { ApplicationRecord, ConfigStatus, DocumentTypeSummary } from '@akrify/shared';
import { StudioConfigService } from '../../../services/studio-config.service';
import { forkJoin } from 'rxjs';
import { NewDocumentTypeModalComponent } from '../new-document-type-modal/new-document-type-modal.component';

type TabKey = 'all' | 'active' | 'draft' | 'archived';
type SortKey = 'name' | 'recent' | 'stp' | 'fields';

const PAGE_SIZE = 9;

@Component({
  selector: 'app-document-types-list',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, DecimalPipe, NewDocumentTypeModalComponent],
  templateUrl: './document-types-list.component.html',
  styleUrls: ['./document-types-list.component.scss'],
})
export class DocumentTypesListComponent implements OnInit {
  private readonly configService = inject(StudioConfigService);
  private readonly router = inject(Router);

  /** Route input: when set, restrict to this application's doc types. */
  @Input() appId?: string;

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly rows = signal<DocumentTypeSummary[]>([]);
  readonly app = signal<ApplicationRecord | null>(null);
  readonly showCreateModal = signal(false);

  readonly search = signal('');
  readonly tab = signal<TabKey>('all');
  readonly sort = signal<SortKey>('recent');
  readonly page = signal(1);

  readonly isScoped = computed(() => !!this.appId);

  readonly tabCounts = computed(() => {
    const all = this.rows();
    return {
      all: all.length,
      active:   all.filter(r => r.status === 'active').length,
      draft:    all.filter(r => r.status === 'draft').length,
      archived: all.filter(r => r.status === 'archived').length,
    };
  });

  readonly activeInWorkflows = computed(
    () => this.rows().filter(r => r.status === 'active' && r.jobCount > 0).length,
  );

  readonly filtered = computed(() => {
    const q = this.search().trim().toLowerCase();
    const tab = this.tab();
    return this.rows().filter(r => {
      if (tab !== 'all' && r.status !== tab) return false;
      if (!q) return true;
      return (
        r.name.toLowerCase().includes(q) ||
        r.docTypeId.toLowerCase().includes(q) ||
        r.appId.toLowerCase().includes(q)
      );
    });
  });

  readonly sorted = computed(() => {
    const rows = [...this.filtered()];
    const sort = this.sort();
    rows.sort((a, b) => {
      switch (sort) {
        case 'name':   return a.name.localeCompare(b.name);
        case 'stp':    return (b.stpRate ?? -1) - (a.stpRate ?? -1);
        case 'fields': return b.fieldCount - a.fieldCount;
        case 'recent': return recencyRank(a.lastModifiedLabel) - recencyRank(b.lastModifiedLabel);
      }
    });
    return rows;
  });

  readonly totalPages = computed(() => Math.max(1, Math.ceil(this.sorted().length / PAGE_SIZE)));

  readonly paged = computed(() => {
    const start = (this.page() - 1) * PAGE_SIZE;
    return this.sorted().slice(start, start + PAGE_SIZE);
  });

  readonly rangeLabel = computed(() => {
    const total = this.sorted().length;
    if (total === 0) return 'No document types match';
    const start = (this.page() - 1) * PAGE_SIZE + 1;
    const end = Math.min(this.page() * PAGE_SIZE, total);
    return `Showing ${start}–${end} of ${total}`;
  });

  ngOnInit() {
    this.load();
  }

  load() {
    this.loading.set(true);
    this.error.set(null);
    if (this.appId) {
      forkJoin({
        app:  this.configService.getApplication(this.appId),
        rows: this.configService.listDocumentTypes(this.appId),
      }).subscribe({
        next: ({ app, rows }) => {
          this.app.set(app);
          this.rows.set(rows);
          this.loading.set(false);
        },
        error: err => {
          this.error.set(err?.message || 'Failed to load document types.');
          this.loading.set(false);
        },
      });
    } else {
      this.configService.listAllDocumentTypes().subscribe({
        next: rows => {
          this.rows.set(rows);
          this.loading.set(false);
        },
        error: err => {
          this.error.set(err?.message || 'Failed to load document types.');
          this.loading.set(false);
        },
      });
    }
  }

  setTab(t: TabKey) { this.tab.set(t); this.page.set(1); }
  onSearchInput(v: string) { this.search.set(v); this.page.set(1); }
  onSortChange(v: string) { this.sort.set(v as SortKey); }
  prevPage() { if (this.page() > 1) this.page.update(p => p - 1); }
  nextPage() { if (this.page() < this.totalPages()) this.page.update(p => p + 1); }

  openCreateModal()  { this.showCreateModal.set(true); }
  closeCreateModal() { this.showCreateModal.set(false); }

  /** After a successful create, land on Pages first — nothing to attach fields to yet. */
  onDocumentTypeCreated(created: { appId: string; docTypeId: string }) {
    this.showCreateModal.set(false);
    this.router.navigate(
      ['/applications', created.appId, 'document-types', created.docTypeId],
      { queryParams: { tab: 'pages' } },
    );
  }

  statusChipClass(status: ConfigStatus): string {
    switch (status) {
      case 'active':   return 'chip chip-success';
      case 'draft':    return 'chip chip-neutral';
      case 'archived': return 'chip chip-neutral archived';
      default:         return 'chip chip-neutral';
    }
  }
}

function recencyRank(label?: string): number {
  if (!label) return 999;
  const l = label.toLowerCase();
  if (l.includes('today'))     return 0;
  if (l.includes('yesterday')) return 1;
  const days   = l.match(/(\d+)\s+days?/);   if (days)   return 2   + parseInt(days[1], 10);
  const weeks  = l.match(/(\d+)\s+weeks?/);  if (weeks)  return 30  + parseInt(weeks[1], 10) * 7;
  const months = l.match(/(\d+)\s+months?/); if (months) return 200 + parseInt(months[1], 10) * 30;
  return 500;
}
