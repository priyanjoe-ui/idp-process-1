import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output, inject, signal } from '@angular/core';
import { StudioConfigService } from '../../../services/studio-config.service';

/**
 * Deleting a Document Type destroys its page/field/extraction configuration,
 * but doesn't cascade to other entities the way an Application delete does
 * (which removes every Document Type underneath it). A single clear confirm
 * button is enough friction here — no typed confirmation required.
 */
@Component({
  selector: 'app-delete-document-type-modal',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './delete-document-type-modal.component.html',
  styleUrls: ['./delete-document-type-modal.component.scss'],
})
export class DeleteDocumentTypeModalComponent {
  private readonly configService = inject(StudioConfigService);

  @Input({ required: true }) appId!: string;
  @Input({ required: true }) docTypeId!: string;
  @Input() name = '';
  @Input() pageCount = 0;
  @Input() fieldCount = 0;

  @Output() closed = new EventEmitter<void>();
  @Output() deleted = new EventEmitter<void>();

  readonly deleting = signal(false);
  readonly error = signal<string | null>(null);

  confirmDelete() {
    if (this.deleting()) return;
    this.deleting.set(true);
    this.error.set(null);
    this.configService.deleteDocumentType(this.appId, this.docTypeId).subscribe({
      next: () => {
        this.deleting.set(false);
        this.deleted.emit();
      },
      error: err => {
        this.deleting.set(false);
        this.error.set(err?.message || 'Failed to delete document type.');
      },
    });
  }

  cancel() {
    if (this.deleting()) return;
    this.closed.emit();
  }
}
