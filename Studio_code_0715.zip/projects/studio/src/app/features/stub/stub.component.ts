import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-stub',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="stub">
      <div class="card stub-card">
        <div class="stub-badge">Coming next</div>
        <h1>{{ title }}</h1>
        <p>
          This section is planned but not yet built. See the roadmap for what ships next.
        </p>
      </div>
    </div>
  `,
  styles: [`
    :host { display: block; }
    .stub { max-width: 640px; }
    .stub-card {
      padding: var(--space-7);
      display: flex;
      flex-direction: column;
      gap: var(--space-3);
    }
    .stub-badge {
      display: inline-block;
      align-self: flex-start;
      padding: 2px 8px;
      background: var(--color-primary-soft);
      color: var(--color-primary);
      border-radius: var(--radius-pill);
      font-size: var(--fs-xs);
      font-weight: 600;
      letter-spacing: 0.02em;
      text-transform: uppercase;
    }
    h1 { margin: 0; font-size: var(--fs-3xl); font-weight: 600; letter-spacing: -0.01em; }
    p  { margin: 0; color: var(--color-text-muted); font-size: var(--fs-lg); line-height: 1.5; }
  `],
})
export class StubComponent {
  private readonly route = inject(ActivatedRoute);
  readonly title: string = this.route.snapshot.data['title'] ?? 'Coming soon';
}
