import { Routes } from '@angular/router';
import { ShellComponent } from './layout/shell/shell.component';

export const routes: Routes = [
  {
    path: '',
    component: ShellComponent,
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },

      {
        path: 'dashboard',
        loadComponent: () =>
          import('./features/dashboard/dashboard.component').then(m => m.DashboardComponent),
      },

      // Applications ------------------------------------------------
      {
        path: 'applications',
        loadComponent: () =>
          import('./features/applications/list/applications-list.component').then(
            m => m.ApplicationsListComponent,
          ),
      },
      {
        path: 'applications/:appId/document-types',
        loadComponent: () =>
          import('./features/document-types/list/document-types-list.component').then(
            m => m.DocumentTypesListComponent,
          ),
      },
      {
        path: 'applications/:appId/document-types/:docTypeId',
        loadComponent: () =>
          import('./features/document-types/editor/editor.component').then(
            m => m.DocumentTypeEditorComponent,
          ),
      },

      // Global document-types view (across all applications, powered by GSI)
      {
        path: 'document-types',
        loadComponent: () =>
          import('./features/document-types/list/document-types-list.component').then(
            m => m.DocumentTypesListComponent,
          ),
      },

      // Dictionaries ---------------------------------------------------
      {
        path: 'dictionaries',
        loadComponent: () =>
          import('./features/dictionaries/list/dictionaries-list.component').then(
            m => m.DictionariesListComponent,
          ),
      },
      {
        path: 'dictionaries/:name',
        loadComponent: () =>
          import('./features/dictionaries/editor/dictionary-editor.component').then(
            m => m.DictionaryEditorComponent,
          ),
      },

      // Workflows (Jobs & Workflow Builder) — a shared entity, not scoped
      // to one Application; mapping to Applications is editable data, not
      // part of the URL.
      {
        path: 'workflows',
        loadComponent: () =>
          import('./features/workflows/list/workflows-list.component').then(
            m => m.WorkflowsListComponent,
          ),
      },
      {
        path: 'workflows/:workflowId',
        loadComponent: () =>
          import('./features/workflows/canvas/workflow-canvas.component').then(
            m => m.WorkflowCanvasComponent,
          ),
      },

      // Connectors — top-level, global screen (matches the wireframe: a
      // list of independent connectors, each carrying its own Application,
      // not nested under one application's URL) --------------------------
      {
        path: 'connectors',
        loadComponent: () =>
          import('./features/connectors/list/connectors-list.component').then(
            m => m.ConnectorsListComponent,
          ),
      },

      // Stubs -------------------------------------------------------
      {
        path: 'test-bench',
        loadComponent: () =>
          import('./features/test-bench/test-bench.component').then(m => m.TestBenchComponent),
        data: { title: 'Test Bench' },
      },
      {
        path: 'deployments',
        loadComponent: () => import('./features/stub/stub.component').then(m => m.StubComponent),
        data: { title: 'Deployments' },
      },
      {
        path: 'users',
        loadComponent: () => import('./features/stub/stub.component').then(m => m.StubComponent),
        data: { title: 'Users & Access' },
      },
      {
        path: 'settings',
        loadComponent: () => import('./features/stub/stub.component').then(m => m.StubComponent),
        data: { title: 'Settings' },
      },
    ],
  },
  { path: '**', redirectTo: '' },
];
