import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { OperatorService } from './operator.service';

/**
 * Stamps X-Operator on every outgoing request -- the same header the
 * backend's getOperator(req) already reads for the reviewer app's
 * submit-review/hold actions. This is what makes every Studio CRUD write
 * (create/update/delete/deploy across Applications, Document Types,
 * Dictionaries, Connectors, Workflows) attribute correctly in both
 * lastModifiedBy and the new audit log, instead of the old fixed
 * STUDIO_USER placeholder string.
 */
export const operatorInterceptor: HttpInterceptorFn = (req, next) => {
  const operator = inject(OperatorService).current();
  const cloned = req.clone({
    setHeaders: { 'X-Operator': operator.name },
  });
  return next(cloned);
};
