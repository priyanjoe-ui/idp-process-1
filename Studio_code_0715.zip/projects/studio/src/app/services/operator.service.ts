import { Injectable, signal } from '@angular/core';
import { StudioUser } from '@akrify/shared';

const STORAGE_KEY = 'akrify-studio-operator';

/**
 * Single source of truth for "who is currently using Studio".
 *
 * Placeholder until real auth wires in -- same honest framing as the
 * hardcoded user this replaces in ShellComponent. The difference is this
 * is now the ONE place that value lives, read by both the top-bar display
 * and OperatorInterceptor (which stamps it on every outgoing request as
 * X-Operator, the same header the reviewer app's backend already trusts
 * for `getOperator(req)`). That's what lets Studio's audit log show a real
 * name instead of a fixed string for every entry.
 *
 * Persisted to localStorage so it survives a page reload -- appropriate
 * here since this is the real, deployed app running in a real browser,
 * not a sandboxed Artifact preview. No password, no verification: anyone
 * can type any name, exactly like the reviewer app's existing X-Operator
 * header today. Good enough to start capturing real "who did this" data;
 * swap for real auth later without touching any of the 17 call sites that
 * already read getOperator(req) on the backend.
 */
@Injectable({ providedIn: 'root' })
export class OperatorService {
  private readonly _current = signal<StudioUser>(this.loadInitial());

  readonly current = this._current.asReadonly();

  setName(name: string): void {
    const trimmed = name.trim();
    if (!trimmed) return;
    const next: StudioUser = { ...this._current(), id: trimmed.toLowerCase(), name: trimmed };
    this._current.set(next);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      // Storage can fail (private browsing, quota) -- the in-memory signal
      // still works for the rest of this session either way.
    }
  }

  private loadInitial(): StudioUser {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) return JSON.parse(raw) as StudioUser;
    } catch {
      // Fall through to default below.
    }
    return { id: 'shan', name: 'Shan', email: 'shan@studio.example', role: 'admin' };
  }
}
