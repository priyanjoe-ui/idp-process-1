import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { catchError, throwError } from 'rxjs';
import { VersionConflictError } from './studio-config.service';

/**
 * Global HTTP error interceptor.
 *
 * - 409 with { error: 'VersionConflict', kind, id, currentVersion } →
 *   throws typed VersionConflictError so components can prompt "reload".
 * - Any other HttpErrorResponse → passes through with a clean Error whose
 *   .message is the server-provided message when available.
 */
export const httpErrorInterceptor: HttpInterceptorFn = (req, next) => {
  return next(req).pipe(
    catchError((err: unknown) => {
      if (err instanceof HttpErrorResponse) {
        const body: any = err.error ?? {};
        if (err.status === 409 && body?.error === 'VersionConflict') {
          return throwError(() => new VersionConflictError(
            body.kind ?? 'UNKNOWN',
            body.id ?? '',
            typeof body.currentVersion === 'number' ? body.currentVersion : 0,
          ));
        }
        const message = body?.message || body?.error || err.message || 'Request failed';
        const wrapped = new Error(message);
        (wrapped as any).status = err.status;
        return throwError(() => wrapped);
      }
      return throwError(() => err);
    }),
  );
};
