import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, from, switchMap } from 'rxjs';
import { TestBenchRunResult } from '@akrify/shared';
import { environment } from '../../environments/environment';

/**
 * Talks to POST /api/test-bench/run -- the only endpoint this feature
 * needs of its own. Application/Document Type listing reuses
 * StudioConfigService.listApplications()/listDocumentTypes() directly
 * from the component, same as every other feature in Studio; this
 * service's only job is running a test.
 *
 * The file never touches S3 -- it's read client-side into a base64
 * string and sent straight through in the request body, matching
 * exactly what idp-test-bench's Lambda expects.
 */
@Injectable({ providedIn: 'root' })
export class TestBenchService {
  private readonly http = inject(HttpClient);
  private readonly baseUrl = environment.apiBaseUrl.replace(/\/+$/, '');

  runTest(applicationId: string, documentTypeId: string, file: File): Observable<TestBenchRunResult> {
    return from(this.fileToBase64(file)).pipe(
      switchMap(fileBase64 =>
        this.http.post<TestBenchRunResult>(`${this.baseUrl}/test-bench/run`, {
          applicationId,
          documentTypeId,
          fileName: file.name,
          fileBase64,
        }),
      ),
    );
  }

  /** Strips the "data:<mime>;base64," prefix FileReader.readAsDataURL adds --
   *  the backend wants the raw base64 payload, not a data URL. */
  private fileToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        const commaIdx = result.indexOf(',');
        resolve(commaIdx >= 0 ? result.slice(commaIdx + 1) : result);
      };
      reader.onerror = () => reject(reader.error ?? new Error('Failed to read file'));
      reader.readAsDataURL(file);
    });
  }
}
