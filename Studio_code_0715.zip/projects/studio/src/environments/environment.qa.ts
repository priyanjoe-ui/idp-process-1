export const environment = {
  production: false,
  envLabel: 'qa',
  envTone: 'warning' as 'neutral' | 'warning' | 'danger',
  apiBaseUrl: 'https://hjizjld6xj5x6qbtmiub55wdcu0kpqdv.lambda-url.us-east-2.on.aws/api',
};
