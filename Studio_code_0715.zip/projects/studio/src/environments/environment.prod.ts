export const environment = {
  production: true,
  envLabel: 'prod',
  envTone: 'danger' as 'neutral' | 'warning' | 'danger',
  apiBaseUrl: 'https://hjizjld6xj5x6qbtmiub55wdcu0kpqdv.lambda-url.us-east-2.on.aws/api',
};
