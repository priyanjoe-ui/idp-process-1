export const environment = {
  production: false,
  envLabel: 'dev',
  envTone: 'neutral' as 'neutral' | 'warning' | 'danger',
  /**
   * Base URL for the idp-api-proxy Lambda Function URL.
   * Update here if the Lambda is ever redeployed under a new URL.
   */
  apiBaseUrl: 'https://hjizjld6xj5x6qbtmiub55wdcu0kpqdv.lambda-url.us-east-2.on.aws/api',
};
