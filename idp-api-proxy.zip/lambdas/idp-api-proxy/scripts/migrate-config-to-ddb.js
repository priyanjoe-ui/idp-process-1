#!/usr/bin/env node
/**
 * migrate-config-to-ddb.js
 * ------------------------------------------------------------------
 * One-shot migration from S3-hosted document-config.json to the
 * idp-config DynamoDB table.
 *
 * Row layout produced:
 *   PK              SK             type          body
 *   "APP#<id>"      "META"         APPLICATION   { ApplicationName, DisplayName,
 *                                                  ClassificationMode, BlankPageMaxWordCount }
 *   "APP#<id>"      "DT#<id>"      DOC_TYPE      { DocumentTypeName, PageTypes: [...] }
 *   "DICT"          "<name>"       DICTIONARY    { options: [...] }
 *
 * Every row also carries:
 *   version         1
 *   lastModifiedAt  <ISO timestamp>
 *   lastModifiedBy  "migration"
 *
 * Usage
 * -----
 *   1. Fill in the CONFIG block below (S3 bucket/key, target table, region).
 *   2. In CloudShell (or anywhere with AWS creds) from this directory:
 *        cd idp-api-proxy
 *        npm install                    # once, if you haven't
 *        node scripts/migrate-config-to-ddb.js
 *
 * Behavior
 * --------
 *   - Idempotent: refuses to overwrite existing rows unless you pass --force.
 *   - Dry run: pass --dry-run to see what would be written without touching DDB.
 *   - Uses AWS credential chain (env vars, ~/.aws/credentials, instance role).
 * ------------------------------------------------------------------
 */

// ═══════════════════════════════════════════════════════════════════
// CONFIG — FILL THESE IN
// ═══════════════════════════════════════════════════════════════════
const CONFIG = {
  // Source: S3 location of the current document-config.json
  S3_BUCKET: '<YOUR_BUCKET_NAME>',              // e.g. 'idp-ecm-datacap-dev'
  S3_KEY:    '<YOUR_CONFIG_KEY>',               // e.g. 'idp/config/document-config.json'

  // Target: DDB table (must already exist with GSI 'type-lastModifiedAt-index')
  TABLE:     'idp-config',

  AWS_REGION: 'us-east-1',
};
// ═══════════════════════════════════════════════════════════════════

const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3');
const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const {
  DynamoDBDocumentClient,
  GetCommand,
  PutCommand,
} = require('@aws-sdk/lib-dynamodb');

const args = new Set(process.argv.slice(2));
const DRY_RUN = args.has('--dry-run');
const FORCE   = args.has('--force');

const s3  = new S3Client({ region: CONFIG.AWS_REGION });
const ddb = DynamoDBDocumentClient.from(
  new DynamoDBClient({ region: CONFIG.AWS_REGION }),
  { marshallOptions: { removeUndefinedValues: true } },
);

const NOW = new Date().toISOString();
const MIGRATION_USER = 'migration';

function log(...a)  { console.log(...a); }
function warn(...a) { console.warn('!', ...a); }
function die(msg)   { console.error('ERROR:', msg); process.exit(1); }

async function fetchConfigJson() {
  if (CONFIG.S3_BUCKET.startsWith('<') || CONFIG.S3_KEY.startsWith('<')) {
    die('Fill in CONFIG.S3_BUCKET and CONFIG.S3_KEY at the top of this file.');
  }
  log(`Fetching s3://${CONFIG.S3_BUCKET}/${CONFIG.S3_KEY}`);
  const resp = await s3.send(new GetObjectCommand({
    Bucket: CONFIG.S3_BUCKET,
    Key:    CONFIG.S3_KEY,
  }));
  const chunks = [];
  for await (const chunk of resp.Body) chunks.push(chunk);
  const text = Buffer.concat(chunks).toString('utf-8');
  return JSON.parse(text);
}

async function rowExists(pk, sk) {
  const resp = await ddb.send(new GetCommand({
    TableName: CONFIG.TABLE,
    Key: { PK: pk, SK: sk },
    ProjectionExpression: 'PK',
  }));
  return !!resp.Item;
}

async function writeRow(item, label) {
  if (DRY_RUN) {
    log(`  [dry-run]  ${label}   PK=${item.PK}  SK=${item.SK}`);
    return { skipped: false };
  }
  if (!FORCE && await rowExists(item.PK, item.SK)) {
    warn(`  skipping (exists) ${label}   PK=${item.PK}  SK=${item.SK}  (use --force to overwrite)`);
    return { skipped: true };
  }
  await ddb.send(new PutCommand({ TableName: CONFIG.TABLE, Item: item }));
  log(`  wrote      ${label}   PK=${item.PK}  SK=${item.SK}`);
  return { skipped: false };
}

function buildAppRow(app) {
  const appId = app.ApplicationName || app.applicationName;
  if (!appId) throw new Error('Application missing ApplicationName');
  return {
    PK:   `APP#${appId}`,
    SK:   'META',
    type: 'APPLICATION',
    body: {
      ApplicationName:       appId,
      DisplayName:           app.DisplayName || app.displayName || appId,
      ClassificationMode:    app.ClassificationMode || 'Sequential',
      BlankPageMaxWordCount: app.BlankPageMaxWordCount ?? 5,
    },
    version:        1,
    lastModifiedAt: NOW,
    lastModifiedBy: MIGRATION_USER,
  };
}

function buildDocTypeRow(appId, dt) {
  const docTypeId = dt.DocumentTypeName || dt.documentTypeName;
  if (!docTypeId) throw new Error(`Document type in ${appId} missing DocumentTypeName`);
  return {
    PK:   `APP#${appId}`,
    SK:   `DT#${docTypeId}`,
    type: 'DOC_TYPE',
    body: {
      DocumentTypeName: docTypeId,
      DisplayName:      dt.DisplayName || dt.displayName || docTypeId,
      PageTypes:        dt.PageTypes || dt.pageTypes || [],
    },
    status:         'active',
    version:        1,
    lastModifiedAt: NOW,
    lastModifiedBy: MIGRATION_USER,
  };
}

function buildDictionaryRow(name, options) {
  return {
    PK:   'DICT',
    SK:   name,
    type: 'DICTIONARY',
    body: { options: options || [] },
    version:        1,
    lastModifiedAt: NOW,
    lastModifiedBy: MIGRATION_USER,
  };
}

async function main() {
  log('══════════════════════════════════════════════════');
  log(' migrate-config-to-ddb.js');
  log(`   source :  s3://${CONFIG.S3_BUCKET}/${CONFIG.S3_KEY}`);
  log(`   target :  ${CONFIG.TABLE}  (${CONFIG.AWS_REGION})`);
  log(`   mode   :  ${DRY_RUN ? 'DRY RUN' : FORCE ? 'FORCE OVERWRITE' : 'skip-if-exists'}`);
  log('══════════════════════════════════════════════════');

  const cfg = await fetchConfigJson();
  const apps  = cfg.Applications  || cfg.applications  || [];
  const dicts = cfg.Dictionaries || cfg.dictionaries || {};

  let wrote = 0, skipped = 0;
  const record = ({ skipped: sk }) => { sk ? skipped++ : wrote++; };

  log(`\nApplications: ${apps.length}`);
  for (const app of apps) {
    const appId = app.ApplicationName || app.applicationName;
    log(`\n[${appId}]`);
    record(await writeRow(buildAppRow(app), 'APP  meta'));
    const docTypes = app.DocumentTypes || app.documentTypes || [];
    for (const dt of docTypes) {
      record(await writeRow(buildDocTypeRow(appId, dt), 'DT   row '));
    }
  }

  const dictNames = Object.keys(dicts);
  log(`\nDictionaries: ${dictNames.length}`);
  for (const name of dictNames) {
    const options = Array.isArray(dicts[name]) ? dicts[name] : (dicts[name]?.options || []);
    record(await writeRow(buildDictionaryRow(name, options), 'DICT row '));
  }

  log('\n══════════════════════════════════════════════════');
  log(` Done.  wrote=${wrote}  skipped=${skipped}${DRY_RUN ? '  (DRY RUN — no writes)' : ''}`);
  log('══════════════════════════════════════════════════');
}

main().catch(err => {
  console.error('\nMIGRATION FAILED:');
  console.error(err);
  process.exit(1);
});
