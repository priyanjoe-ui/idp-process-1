import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, catchError, forkJoin, map, of } from 'rxjs';
import { DashboardSnapshot, Environment, ServiceHealth, ServiceHealthState, StatusCount, TopDocumentTypeRow, VolumePoint } from '@akrify/shared';
import { environment } from '../../environments/environment';

/** Shape returned by GET /api/dashboard (the same endpoint the reviewer app's Job Monitor uses). */
interface RawDashboardResponse {
  filter: { application: string; from: string | null; to: string | null };
  totalIngested: number;
  pendingReview: number;
  stpBatches: number;
  abortedBatches: number;
  stpPercentage: number;
  byDocumentType: { type: string; count: number }[];
  byStatus: { status: string; count: number }[];
  recentTimeline: { bucket: string; processed: number; failed: number }[]; // bucket: "YYYY-MM-DD HH:00" (UTC)
}

/** Shape returned by GET /api/dashboard/service-health. */
interface RawServiceHealthResponse {
  rows: { service: string; label: string; status: string; detail: string }[];
  checkedAt: string;
}

const WINDOW_DAYS = 7;
const TOP_DOC_TYPES_LIMIT = 5;

/**
 * Dashboard data source.
 *
 * Backed by the real GET /api/dashboard endpoint — the same one the
 * reviewer app's Job Monitor tab already uses against the idp-batch-tracking
 * table — plus GET /api/dashboard/service-health for the five service-health
 * rows (Connectors, Intake Queue, Step Functions, Lambda, DynamoDB), each
 * independently checked so one AWS service being unreachable doesn't blank
 * out the others. Fields with no real source yet (trend deltas, active
 * indexers, avg processing time, activity feed) are left null/empty so the
 * UI shows an honest placeholder instead of a fabricated number.
 */
@Injectable({ providedIn: 'root' })
export class DashboardService {
  private readonly http = inject(HttpClient);
  private readonly baseUrl = environment.apiBaseUrl.replace(/\/+$/, '');

  getSnapshot(): Observable<DashboardSnapshot> {
    const now = new Date();
    const dayKeys = lastNDayKeysUtc(now, WINDOW_DAYS);
    const from = `${dayKeys[0]}T00:00:00.000Z`;
    const to = now.toISOString();

    return forkJoin({
      dashboard: this.http.get<RawDashboardResponse>(`${this.baseUrl}/dashboard`, { params: { from, to } }),
      // Falls back to empty (not a thrown error) if this fails — the main
      // dashboard is far more important than the health panel, and
      // shouldn't go blank just because one extra endpoint had a problem.
      serviceHealth: this.getServiceHealth().pipe(catchError(() => of<ServiceHealth[]>([]))),
    }).pipe(map(({ dashboard, serviceHealth }) => buildSnapshot(dashboard, serviceHealth, now, dayKeys, from, to)));
  }

  /** Kept separate from getSnapshot() so the dashboard can refresh just the
   *  health panel (e.g. a manual "recheck" action) without re-fetching the
   *  whole 7-day volume window too. */
  getServiceHealth(): Observable<ServiceHealth[]> {
    return this.http
      .get<RawServiceHealthResponse>(`${this.baseUrl}/dashboard/service-health`)
      .pipe(map(raw => raw.rows.map(toServiceHealth)));
  }
}

// ─── Derivation helpers ─────────────────────────────────────────────────

/** Backend statuses map directly except 'unknown' (a check itself failed)
 *  isn't a real ServiceHealthState value elsewhere in the app — mapped to
 *  'down' so it's still visually treated as needing attention, with the
 *  detail message explaining it was a check failure, not the service itself. */
function toServiceHealth(row: RawServiceHealthResponse['rows'][number]): ServiceHealth {
  const knownStates: ServiceHealthState[] = ['healthy', 'degraded', 'down', 'paused', 'info'];
  const state: ServiceHealthState = (knownStates as string[]).includes(row.status)
    ? (row.status as ServiceHealthState)
    : 'down';
  return { name: row.label, state, detail: row.detail };
}

function buildSnapshot(
  raw: RawDashboardResponse,
  serviceHealth: ServiceHealth[],
  now: Date,
  dayKeys: string[],
  from: string,
  to: string,
): DashboardSnapshot {
  const volume = rebucketDaily(raw.recentTimeline, dayKeys);
  const todayKey = dayKeys[dayKeys.length - 1];
  const todayPoint = volume.find(v => v.dayKey === todayKey);
  const documentsToday = todayPoint ? todayPoint.processed + todayPoint.failed : 0;

  const topDocumentTypes: TopDocumentTypeRow[] = [...raw.byDocumentType]
    .sort((a, b) => b.count - a.count)
    .slice(0, TOP_DOC_TYPES_LIMIT)
    .map(d => ({
      name: d.type,
      count: d.count,
      stpRate: null,      // not computed per-type by the backend yet
      confidence: null,
    }));

  const byStatus: StatusCount[] = [...raw.byStatus].sort((a, b) => b.count - a.count);

  return {
    environment: (environment.envLabel as Environment) ?? 'dev',
    lastSyncedAt: now.toISOString(),
    windowFrom: from,
    windowTo: to,
    kpis: {
      documentsToday,
      documentsTrendPct: null,
      stpRatePct: raw.stpPercentage,
      stpRateTrendPts: null,
      pendingReview: raw.pendingReview,
      activeIndexers: null,
      avgProcessingSec: null,
    },
    volume: volume.map(({ dayKey: _dayKey, ...v }) => v),
    byStatus,
    topDocumentTypes,
    activity: [],       // no activity logging yet — UI shows a placeholder
    serviceHealth,
  };
}

/** UTC calendar-date key, e.g. "2026-07-09". Matches the backend's bucket format. */
function utcDateKey(d: Date): string {
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
}

function lastNDayKeysUtc(now: Date, n: number): string[] {
  const keys: string[] = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setUTCDate(d.getUTCDate() - i);
    keys.push(utcDateKey(d));
  }
  return keys;
}

function weekdayLabel(dayKey: string): string {
  const d = new Date(`${dayKey}T00:00:00Z`);
  return d.toLocaleDateString('en-US', { weekday: 'short', timeZone: 'UTC' });
}

/** Sums hourly {bucket, processed, failed} rows into one point per day, zero-filled for days with no data. */
function rebucketDaily(
  hourly: RawDashboardResponse['recentTimeline'],
  dayKeys: string[],
): (VolumePoint & { dayKey: string })[] {
  const sums = new Map<string, { processed: number; failed: number }>();
  for (const key of dayKeys) sums.set(key, { processed: 0, failed: 0 });

  for (const row of hourly) {
    const dayKey = row.bucket.slice(0, 10);
    const bucket = sums.get(dayKey);
    if (!bucket) continue; // outside the requested window
    bucket.processed += row.processed;
    bucket.failed += row.failed;
  }

  return dayKeys.map(dayKey => {
    const sum = sums.get(dayKey)!;
    return { dayKey, day: weekdayLabel(dayKey), processed: sum.processed, failed: sum.failed };
  });
}
