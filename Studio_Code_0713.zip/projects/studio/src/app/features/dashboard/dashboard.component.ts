import { CommonModule, DecimalPipe } from '@angular/common';
import { Component, computed, inject, OnInit, signal } from '@angular/core';
import { DashboardSnapshot, ServiceHealthState, VolumePoint } from '@akrify/shared';
import { DashboardService } from '../../services/dashboard.service';

interface ChartBar {
  day: string;
  processedHeight: number;
  failedHeight: number;
  processedY: number;
  failedY: number;
  total: number;
}

const CHART_HEIGHT = 180;

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, DecimalPipe],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent implements OnInit {
  private readonly dashboardService = inject(DashboardService);

  readonly snapshot = signal<DashboardSnapshot | null>(null);
  readonly loading = signal(true);
  readonly error = signal<string | null>(null);

  readonly chart = computed(() => {
    const snap = this.snapshot();
    if (!snap) return { bars: [] as ChartBar[], max: 0, yTicks: [] as number[] };
    return buildChart(snap.volume);
  });

  ngOnInit() {
    this.load();
  }

  load() {
    this.loading.set(true);
    this.error.set(null);
    this.dashboardService.getSnapshot().subscribe({
      next: s => {
        this.snapshot.set(s);
        this.loading.set(false);
      },
      error: err => {
        this.error.set(err?.message || 'Failed to load dashboard data.');
        this.loading.set(false);
      },
    });
  }

  syncedAgoLabel(): string {
    const snap = this.snapshot();
    if (!snap) return '';
    const ms = Date.now() - new Date(snap.lastSyncedAt).getTime();
    const mins = Math.max(0, Math.round(ms / 60_000));
    if (mins < 1) return 'just now';
    if (mins === 1) return '1 minute ago';
    if (mins < 60) return `${mins} minutes ago`;
    const hours = Math.round(mins / 60);
    return hours === 1 ? '1 hour ago' : `${hours} hours ago`;
  }

  statusDotClass(status: string): string {
    const s = status.toLowerCase();
    if (s === 'jobdone' || s === 'done' || s === 'completed') return 'dot-success';
    if (s === 'failed' || s === 'aborted') return 'dot-danger';
    if (s === 'pending' || s === 'hold' || s === 'onhold') return 'dot-warning';
    return 'dot-neutral';
  }

  confidenceChipClass(c: 'high' | 'med' | 'low' | null): string {
    if (c === 'high') return 'chip chip-success';
    if (c === 'med')  return 'chip chip-warning';
    if (c === 'low')  return 'chip chip-danger';
    return 'chip chip-neutral';
  }

  healthDotClass(state: ServiceHealthState): string {
    if (state === 'healthy') return 'dot-success';
    if (state === 'degraded') return 'dot-warning';
    if (state === 'down' || state === 'unknown') return 'dot-danger';
    return 'dot-neutral'; // 'info' / 'paused'
  }

  healthTextClass(state: ServiceHealthState): string {
    if (state === 'healthy') return 'status-enabled';
    if (state === 'down' || state === 'unknown') return 'status-disabled';
    return ''; // degraded/info/paused use the default text color, not the enabled/disabled convention
  }

  healthStateLabel(state: ServiceHealthState): string {
    if (state === 'unknown') return 'check failed';
    return state;
  }
}

function buildChart(points: VolumePoint[]): { bars: ChartBar[]; max: number; yTicks: number[] } {
  const totals = points.map(p => p.processed + p.failed);
  const rawMax = Math.max(...totals, 1);
  const max = niceCeiling(rawMax);

  const bars: ChartBar[] = points.map(p => {
    const processedHeight = (p.processed / max) * CHART_HEIGHT;
    const failedHeight = (p.failed / max) * CHART_HEIGHT;
    const failedY = CHART_HEIGHT - failedHeight;
    const processedY = failedY - processedHeight;
    return { day: p.day, processedHeight, failedHeight, processedY, failedY, total: p.processed + p.failed };
  });

  const yTicks = [0, max * 0.25, max * 0.5, max * 0.75, max].map(v => Math.round(v));
  return { bars, max, yTicks };
}

function niceCeiling(n: number): number {
  const magnitude = Math.pow(10, Math.floor(Math.log10(n)));
  const scaled = n / magnitude;
  const nice = scaled <= 2 ? 2 : scaled <= 5 ? 5 : 10;
  return nice * magnitude;
}
