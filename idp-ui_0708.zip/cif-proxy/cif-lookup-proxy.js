// cif-lookup-proxy.js
// Local proxy for IDP CIF lookup. Supports both HTTP (no cert) and HTTPS (with cert).
// Sits in front of the on-prem IDP DataCap consumer API so the Angular app
// (running on :4200) can call it without CORS or client-cert headaches.
//
// Run: node cif-lookup-proxy.js
// Then in the Angular app, environment.cifLookupUrl points at http://localhost:5000
 
const express = require('express');
const cors = require('cors');
const http = require('http');
const https = require('https');
const fs = require('fs');
 
const app = express();
app.use(cors({ origin: 'http://localhost:4200' }));
app.use(express.json());
 
// ====== Configuration ======
// Empty CERT_PATH = skip client cert (matches .NET when certFileName is empty)
const CERT_PATH       = '';
const CERT_PASSWORD   = '';
// NOTE: the original paste had a stray "%27;" at the end of this URL (a
// URL-encoded apostrophe), which would have made every request 404. The
// real query value is just companyCode=01 — apostrophe removed.
const CIF_SERVICE_URL = 'http://ndi-d.nt.lab.com:9905/DataCapConsumerAPI2/insurance_agreement_holders/_indentifiedInHeaders?companyCode=01';
//const CIF_SERVICE_URL = 'https://ndi-s.nt.lab.com:10348/DataCapConsumerAPI2/insurance_agreement_holders/_indentifiedInHeaders?companyCode=01';
const REJECT_UNAUTHORIZED = false;
 
// ====== Endpoint ======
// POST /cif-lookup
// Body: { type: 'policy_number' | 'ssn' | 'cif_number', value: 'X' }
app.post('/cif-lookup', (req, res) => {
  const { type, value } = req.body || {};
  if (!type || !value) {
    return res.status(400).json({ error: 'type and value required' });
  }
 
  // Build the identity fields array (matches .NET serialization)
  const identityFields = [{ name: type, type: 'string', value }];
  const headerJson = JSON.stringify(identityFields);
 
  console.log(`[CIF Lookup] type=${type} value=${value}`);
  console.log(`[CIF Lookup] header: ${headerJson}`);
 
  // Parse URL and pick http vs https module
  const url = new URL(CIF_SERVICE_URL);
  const isHttps = url.protocol === 'https:';
  const client = isHttps ? https : http;
 
  const options = {
    hostname: url.hostname,
    port: url.port || (isHttps ? 443 : 80),
    path: url.pathname + url.search,
    method: 'GET',
    headers: {
      'Content-Type': 'application/xml;charset=UTF8',
      'idp-identity-fields': headerJson,
    },
  };
 
  // Load client cert only if path provided AND we're using HTTPS
  if (isHttps && CERT_PATH && CERT_PATH.trim()) {
    try {
      options.pfx = fs.readFileSync(CERT_PATH);
      if (CERT_PASSWORD) options.passphrase = CERT_PASSWORD;
      options.rejectUnauthorized = REJECT_UNAUTHORIZED;
      options.secureProtocol = 'TLSv1_2_method';
      console.log('[CIF Lookup] using client cert from', CERT_PATH);
    } catch (e) {
      console.error('Failed to read cert:', e.message);
      return res.status(500).json({ error: 'Cert file not found', detail: e.message });
    }
  } else if (isHttps) {
    options.rejectUnauthorized = REJECT_UNAUTHORIZED;
    console.log('[CIF Lookup] HTTPS without client cert');
  } else {
    console.log('[CIF Lookup] HTTP - no cert needed');
  }
 
  // Make the call
  const idpReq = client.request(options, (idpRes) => {
    let data = '';
    idpRes.on('data', (chunk) => { data += chunk; });
    idpRes.on('end', () => {
      console.log(`[CIF Lookup] response status=${idpRes.statusCode}`);
      console.log(`[CIF Lookup] response body (first 300 chars):`, data.slice(0, 300));
      res.status(idpRes.statusCode || 200)
         .set('Content-Type', idpRes.headers['content-type'] || 'application/xml')
         .send(data);
    });
  });
 
  idpReq.on('error', (err) => {
    console.error('[CIF Lookup] error:', err.message);
    res.status(500).json({ error: 'IDP lookup failed', detail: err.message });
  });
 
  idpReq.end();
});
 
// Health check
app.get('/health', (req, res) => res.json({ ok: true, service: 'cif-lookup-proxy' }));
 
const PORT = 5000;
app.listen(PORT, () => {
  console.log(`CIF Lookup proxy running on http://localhost:${PORT}`);
  console.log(`Target: ${CIF_SERVICE_URL}`);
  console.log(`Cert: ${CERT_PATH || '(none)'}`);
});