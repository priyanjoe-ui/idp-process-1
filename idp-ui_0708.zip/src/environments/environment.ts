export const environment = {
  production: false,
  // /api is proxied by Angular dev server (proxy.conf.json) to local-api-proxy.js on :3001
  apiBaseUrl: 'https://hjizjld6xj5x6qbtmiub55wdcu0kpqdv.lambda-url.us-east-2.on.aws/api',
  dataSource: 'api' as 'mock' | 'api',
  defaultApplication: 'AFLCOR',
  defaultPageSize: 100,
  // Local Node proxy (cif-lookup-proxy.js) that forwards to the on-prem
  // IDP CIF service. Runs on :5000 because of firewall + client cert
  // constraints that make a direct browser call impossible.
  cifLookupUrl: 'http://localhost:5000',
};