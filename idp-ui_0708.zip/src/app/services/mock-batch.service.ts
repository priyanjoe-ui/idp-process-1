import { Injectable } from '@angular/core';
import { Observable, of, delay } from 'rxjs';
 
import {
  Application,
  ApplicationsResponse,
  BatchDetail,
  BatchListQuery,
  BatchPage_DTO,
  BatchRow,
  ExtractedField,
  JobSummary,
  SubmitReviewResponse,
} from '../models/document.model';
 
/**
 * In-memory fake data for offline development.
 * Toggle via environment.dataSource = 'mock'.
 */
 
const NOW = new Date();
const iso = (offsetMin: number) =>
  new Date(NOW.getTime() + offsetMin * 60_000).toISOString();
 
function mkField(
  fieldName: string,
  value: string | null,
  confidence: number | null,
  validationPassed: boolean,
  extra: Partial<ExtractedField> = {},
): ExtractedField {
  return {
    fieldName,
    value,
    confidence,
    validationPassed,
    sourcePageId: extra.sourcePageId ?? null,
    required: true,
    dataType: 'String',
    validationError: extra.validationError ?? null,
    correctedBy: null,
    correctedAt: null,
    ...extra,
  };
}
 
const MOCK_BATCHES: BatchRow[] = [
  {
    queueId: 1,
    batchId: 'CORREMAIL.9.20250910115113',
    batchNumber: '20260513.000001',
    application: 'AFLCOR',
    source: 'Email',
    jobName: 'AFLCOR-ImportJob',
    currentTask: 'Export',
    status: 'JobDone',
    jobStartTime: iso(-120),
    jobTime: 120 * 60,
    jobDuration: 95000,
    operator: 'system',
    documentCount: 1,
    pageCount: 1,
    updatedAt: iso(-119),
  },
  {
    queueId: 2,
    batchId: 'CORREMAIL.10.20250911120000',
    batchNumber: '20260513.000002',
    application: 'AFLCOR',
    source: 'Email',
    jobName: 'AFLCOR-ImportJob',
    currentTask: 'ManualReview',
    status: 'OnHold',
    jobStartTime: iso(-30),
    jobTime: 30 * 60,
    jobDuration: null,
    operator: 'system',
    documentCount: 1,
    pageCount: 3,
    updatedAt: iso(-28),
  },
  {
    queueId: 3,
    batchId: 'CORRFAX.1.20250912100000',
    batchNumber: '20260513.000003',
    application: 'AFLCOR',
    source: 'Fax',
    jobName: 'AFLCOR-ImportJob',
    currentTask: 'Extraction',
    status: 'Running',
    jobStartTime: iso(-5),
    jobTime: 5 * 60,
    jobDuration: null,
    operator: 'system',
    documentCount: 1,
    pageCount: 6,
    updatedAt: iso(-1),
  },
  {
    queueId: 4,
    batchId: 'CORREMAIL.11.20250913090000',
    batchNumber: '20260513.000004',
    application: 'AFLCOR',
    source: 'Email',
    jobName: 'AFLCOR-ImportJob',
    currentTask: 'Export',
    status: 'JobDone',
    jobStartTime: iso(-200),
    jobTime: 200 * 60,
    jobDuration: 88000,
    operator: 'system',
    documentCount: 1,
    pageCount: 2,
    updatedAt: iso(-199),
  },
];
 
const MOCK_DETAIL_2: BatchDetail = {
  batch: {
    ...MOCK_BATCHES[1],
    sourceZipKey: 'idp/applications/AFLCOR/Import/Email/CORREMAIL.10.20250911120000.zip',
    xmlMetadata: {
      Doc_Class: 'CORRDOC',
      EFROM: 'sender@example.com',
      EMAILTO: 'recipient@example.com',
      DocOrigin: 'EMAIL',
    },
    holdSource: 'manualReview',
    holdReason: null,
    manualReviewStartedAt: iso(-28),
    manualReviewCompletedAt: null,
    createdAt: iso(-30),
  },
  documents: [{
    documentId: 'mock-doc-2',
    documentType: 'CORRDOC',
    validationStatus: 'NeedsReview',
    pageIds: ['mock-page-2a', 'mock-page-2b', 'mock-page-2c'],
    extractedFields: [
      mkField('PolicyNumber', 'B0676120', 98.5, true, { sourcePageId: 'mock-page-2a' }),
      mkField('CustomerName', null, null, false, { validationError: 'Empty value' }),
      mkField('SSN', null, null, false, { validationError: 'Empty value' }),
      mkField('CIF', 'ABC123', 65.2, false, {
        sourcePageId: 'mock-page-2a',
        validationError: 'Confidence 65.20 below threshold 95.00',
      }),
    ],
    createdAt: iso(-30),
    updatedAt: iso(-28),
  }],
  pages: [
    { pageId: 'mock-page-2a', pageNumber: 1, pageType: 'MainPage', pageStatus: 'Extracted',
      wordCount: 142, s3Key: 'mock', ocrTextS3Key: 'mock',
      imageUrl: '/api/batches/2/pages/mock-page-2a/image',
      createdAt: iso(-30), updatedAt: iso(-29) },
    { pageId: 'mock-page-2b', pageNumber: 2, pageType: 'TrailingPage', pageStatus: 'Extracted',
      wordCount: 89, s3Key: 'mock', ocrTextS3Key: 'mock',
      imageUrl: '/api/batches/2/pages/mock-page-2b/image',
      createdAt: iso(-30), updatedAt: iso(-29) },
    { pageId: 'mock-page-2c', pageNumber: 3, pageType: 'BlankPage', pageStatus: 'Extracted',
      wordCount: 2, s3Key: 'mock', ocrTextS3Key: 'mock',
      imageUrl: '/api/batches/2/pages/mock-page-2c/image',
      createdAt: iso(-30), updatedAt: iso(-29) },
  ],
  taskHistory: [
    { taskName: 'Ingestion', status: 'Completed', startTime: iso(-30), endTime: iso(-30), operator: 'system', durationMs: 500 },
    { taskName: 'Classification', status: 'Completed', startTime: iso(-30), endTime: iso(-30), operator: 'system', durationMs: 200 },
    { taskName: 'Extraction', status: 'Completed', startTime: iso(-30), endTime: iso(-29), operator: 'system', durationMs: 22000 },
    { taskName: 'Validation', status: 'Completed', startTime: iso(-29), endTime: iso(-29), operator: 'system', durationMs: 300 },
    { taskName: 'ManualReview', status: 'WaitingForReviewer', startTime: iso(-28), endTime: iso(-28), operator: 'system', durationMs: 0 },
  ],
  textractJobs: [
    { jobId: 'mock-job-2a', pageId: 'mock-page-2a', status: 'Completed', createdAt: iso(-30), completedAt: iso(-29), durationMs: 18000, resultS3Key: 'mock', errorMessage: null },
    { jobId: 'mock-job-2b', pageId: 'mock-page-2b', status: 'Completed', createdAt: iso(-30), completedAt: iso(-29), durationMs: 12000, resultS3Key: 'mock', errorMessage: null },
    { jobId: 'mock-job-2c', pageId: 'mock-page-2c', status: 'Completed', createdAt: iso(-30), completedAt: iso(-29), durationMs: 9000, resultS3Key: 'mock', errorMessage: null },
  ],
};
 
@Injectable({ providedIn: 'root' })
export class MockBatchService {
 
  listApplications(): Observable<ApplicationsResponse> {
    return of({
      applications: [{
        name: 'AFLCOR',
        displayName: 'IDP Document',
        classificationMode: 'Sequential',
        documentTypes: ['CORRDOC'],
      }],
      dictionaries: {},
    } as ApplicationsResponse).pipe(delay(50));
  }
 
  listJobs(_application: string): Observable<{ application: string; jobs: JobSummary[] }> {
    const counts: Record<string, number> = { total: MOCK_BATCHES.length };
    for (const b of MOCK_BATCHES) {
      counts[b.status] = (counts[b.status] || 0) + 1;
    }
    return of({
      application: 'AFLCOR',
      jobs: [{ jobName: 'AFLCOR-ImportJob', counts: counts as any }],
    }).pipe(delay(50));
  }
 
  listBatches(q: BatchListQuery): Observable<BatchPage_DTO> {
    let items = MOCK_BATCHES.filter(b => b.application === q.application);
    if (q.status) {
      const statuses = q.status.split(',').map(s => s.trim()).filter(Boolean);
      items = items.filter(b => statuses.includes(b.status));
    }
    if (q.search) {
      const rx = new RegExp(
        '^' + q.search.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*') + '$',
        'i',
      );
      items = items.filter(b => rx.test(b.batchId) || rx.test(b.batchNumber));
    }
    items.sort((a, b) => b.jobStartTime.localeCompare(a.jobStartTime));
    const page = q.page ?? 1;
    const pageSize = q.pageSize ?? 25;
    const start = (page - 1) * pageSize;
    return of({
      page,
      pageSize,
      totalCount: items.length,
      totalPages: Math.max(1, Math.ceil(items.length / pageSize)),
      batches: items.slice(start, start + pageSize),
    }).pipe(delay(50));
  }
 
  getBatch(queueId: number): Observable<BatchDetail> {
    if (queueId === 2) return of(MOCK_DETAIL_2).pipe(delay(50));
    // For other queueIds, synthesize a generic detail
    const row = MOCK_BATCHES.find(b => b.queueId === queueId);
    if (!row) throw new Error(`Mock: no batch ${queueId}`);
    return of<BatchDetail>({
      batch: {
        ...row,
        sourceZipKey: null,
        xmlMetadata: {},
        createdAt: row.jobStartTime,
      },
      documents: [{
        documentId: `mock-doc-${queueId}`,
        documentType: 'CORRDOC',
        validationStatus: row.status === 'JobDone' ? 'Passed' : 'Pending',
        pageIds: [`mock-page-${queueId}`],
        extractedFields: [
          mkField('PolicyNumber', 'B0676120', 98.5, true, { sourcePageId: `mock-page-${queueId}` }),
          mkField('CustomerName', 'Acme Corp', 95.0, true, { sourcePageId: `mock-page-${queueId}` }),
        ],
        createdAt: row.jobStartTime,
        updatedAt: row.updatedAt,
      }],
      pages: [{
        pageId: `mock-page-${queueId}`,
        pageNumber: 1,
        pageType: 'MainPage',
        pageStatus: 'Extracted',
        wordCount: 200,
        s3Key: 'mock',
        ocrTextS3Key: 'mock',
        imageUrl: `/api/batches/${queueId}/pages/mock-page-${queueId}/image`,
        createdAt: row.jobStartTime,
        updatedAt: row.updatedAt,
      }],
      taskHistory: [],
      textractJobs: [],
    }).pipe(delay(50));
  }
 
  submitReview(queueId: number, _body: any): Observable<SubmitReviewResponse> {
    return of<SubmitReviewResponse>({
      queueId,
      status: 'Resumed',
      reviewer: 'mock',
      correctionCount: 0,
      message: 'Mock submit',
    }).pipe(delay(80));
  }
}