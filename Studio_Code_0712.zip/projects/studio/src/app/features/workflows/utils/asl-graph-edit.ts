import { AslDefinition, AslState } from '@akrify/shared';

/**
 * Identifies exactly which outgoing pointer an "insert here" click refers
 * to, so the new state can be spliced into the right spot and every
 * affected pointer rewired to keep the graph connected.
 */
export type InsertionPoint =
  /** Insert right after StartAt, before the current first state. */
  | { kind: 'before-start' }
  /** Insert on a plain Next edge, or after a terminal state (End: true). */
  | { kind: 'after-state'; stateName: string }
  /** Insert on a specific Choice branch's edge (a Choices[i].Next). */
  | { kind: 'choice-branch'; stateName: string; branchIndex: number }
  /** Insert on a Choice's Default edge. */
  | { kind: 'choice-default'; stateName: string };

let newStateCounter = 0;

/** Generates a state name guaranteed not to collide with any existing one. */
export function generateStateName(states: Record<string, AslState>, base = 'NewState'): string {
  let name = `${base}${++newStateCounter}`;
  while (states[name]) {
    name = `${base}${++newStateCounter}`;
  }
  return name;
}

/**
 * Inserts `newStateName` (with `newState` as its definition) at the given
 * insertion point, rewiring pointers so the graph stays connected:
 *   - Whatever the insertion point used to point at becomes the new
 *     state's Next (unless the new state is itself terminal by design).
 *   - The insertion point itself is redirected to the new state.
 * Mutates `definition` in place, matching the rest of the editor's pattern.
 */
export function insertState(
  definition: AslDefinition,
  point: InsertionPoint,
  newStateName: string,
  newState: AslState,
): void {
  switch (point.kind) {
    case 'before-start': {
      const oldStart = definition.StartAt;
      definition.StartAt = newStateName;
      wireNewStateForward(newState, oldStart);
      break;
    }
    case 'after-state': {
      const parent = definition.States[point.stateName];
      if (!parent) return;
      if (parent.End) {
        // Was terminal — the new state takes over as terminal, parent now points forward.
        delete parent.End;
        parent.Next = newStateName;
        // newState keeps whatever End/Next it was given by the caller (typically terminal).
      } else if (parent.Next) {
        const oldNext = parent.Next;
        parent.Next = newStateName;
        wireNewStateForward(newState, oldNext);
      } else {
        // Parent had neither Next nor End (Choice/Succeed/Fail with no forward edge) —
        // just point it forward.
        parent.Next = newStateName;
      }
      break;
    }
    case 'choice-branch': {
      const parent = definition.States[point.stateName];
      const rule = parent?.Choices?.[point.branchIndex];
      if (!rule) return;
      const oldNext = rule.Next;
      rule.Next = newStateName;
      wireNewStateForward(newState, oldNext);
      break;
    }
    case 'choice-default': {
      const parent = definition.States[point.stateName];
      if (!parent || !parent.Default) return;
      const oldDefault = parent.Default;
      parent.Default = newStateName;
      wireNewStateForward(newState, oldDefault);
      break;
    }
  }
  definition.States[newStateName] = newState;
}

/** Points the new state at whatever the insertion point used to point at,
 *  unless the caller already gave it an explicit terminal shape (End/Choice). */
function wireNewStateForward(newState: AslState, forwardTo: string) {
  if (newState.Type === 'Choice' || newState.End) return;
  newState.Next = forwardTo;
}

/** Removes a state from the map and reroutes anything that pointed at it
 *  to whatever it pointed at itself (so deleting a middle state doesn't
 *  break the chain). Choice states pointing at the deleted state via a
 *  branch are rewired the same way; if the deleted state had no forward
 *  edge, incoming pointers are cleared to End: true instead. */
export function removeState(definition: AslDefinition, stateName: string): void {
  const removed = definition.States[stateName];
  if (!removed) return;
  const forwardTo = removed.Type !== 'Choice' ? removed.Next : undefined;

  if (definition.StartAt === stateName) {
    if (forwardTo) definition.StartAt = forwardTo;
    // else: leave StartAt pointing at a name that no longer exists — the
    // renderer shows this as 'dangling' so it's visibly wrong rather than
    // silently guessing a new start state.
  }

  for (const [name, s] of Object.entries(definition.States)) {
    if (name === stateName) continue;
    if (s.Next === stateName) {
      if (forwardTo) s.Next = forwardTo;
      else { delete s.Next; s.End = true; }
    }
    if (s.Choices) {
      for (const rule of s.Choices) {
        if (rule.Next === stateName && forwardTo) rule.Next = forwardTo;
      }
    }
    if (s.Default === stateName && forwardTo) {
      s.Default = forwardTo;
    }
  }

  delete definition.States[stateName];
}
