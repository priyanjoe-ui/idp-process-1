import { AslChoiceRule, AslState } from '@akrify/shared';

/**
 * One child edge out of a rendered state — a branch label (for Choice) or
 * null (for a plain Next). Carries the child subtree.
 */
export interface RenderChild {
  label: string | null;
  node: RenderNode;
}

/** A single prefix state private to one branch of a converging Choice —
 *  simple by construction (see findJoinPoint's scoping note below), so
 *  this is just a flat state+label, not a further recursive RenderNode. */
export interface PrefixState {
  name: string;
  state: AslState;
}

export interface RenderBranch {
  label: string;
  /** States unique to this branch before it reaches the shared join point.
   *  Can be empty — a branch may lead straight into the join with nothing
   *  of its own (e.g. a Default branch that just falls through). */
  prefix: PrefixState[];
}

/**
 * The result of walking the ASL graph from StartAt. ASL is a DAG, not a
 * strict tree — two branches can converge on the same downstream state.
 * This is computed fresh from `states` on every call; it's a pure
 * function of the current definition, nothing is cached or mutated, so
 * there's no risk of a stale tree after an edit.
 */
export type RenderNode =
  | { kind: 'state'; name: string; state: AslState; children: RenderChild[] }
  /**
   * A Choice whose branches were detected to all converge back onto the
   * same downstream state — rendered as a real fan-in (matching AWS
   * Workflow Studio), not a text stub. Each branch shows only its own
   * private prefix; the shared state (and everything after it) renders
   * exactly once, in `joined`, positioned below all branches.
   */
  | { kind: 'choice-join'; name: string; state: AslState; branches: RenderBranch[]; joined: RenderNode }
  /** A branch reached a state that's already been rendered elsewhere in
   *  this tree, and it wasn't resolved into a 'choice-join' (see scoping
   *  note on findJoinPoint — partial convergence, convergence with an
   *  unrelated part of the graph, or a nested Choice in the way all fall
   *  back to this simpler stub rather than attempting a fan-in). Render a
   *  short stub pointing at it instead of a duplicate box, and stop —
   *  whatever's downstream of the shared state was already rendered the
   *  first time it was reached. */
  | { kind: 'merge'; name: string }
  /** A branch pointed at a state name that doesn't exist in `states` —
   *  shown so a bad edit is visible on the canvas instead of silently
   *  vanishing. */
  | { kind: 'dangling'; name: string }
  /** No outgoing edge (End: true, or Succeed/Fail with nothing after). */
  | { kind: 'terminal' };

/**
 * Walks the ASL graph starting at `startAt`, tracking every state name
 * already rendered in a single Set threaded through the whole walk.
 *
 * For a Choice, first tries to detect a shared join point across ALL of
 * its own branches (see findJoinPoint) and render a real fan-in if found.
 * If not — the branches genuinely diverge, or convergence only happens
 * elsewhere/later in a way this scoped detection doesn't attempt to
 * unify — falls back to the simpler behavior verified earlier: the FIRST
 * branch to reach a given state renders it in full; any LATER branch
 * reaching the same state renders a 'merge' stub and does not re-walk
 * past it. Both paths were verified against the reference pipeline's
 * NeedsReviewChoice → ManualReview/Export case — the join-point path
 * gives the real fan-in there, since both branches converge on Export.
 */
export function buildRenderTree(startAt: string, states: Record<string, AslState>): RenderNode {
  const visited = new Set<string>();

  function walk(stateName: string): RenderNode {
    if (visited.has(stateName)) {
      return { kind: 'merge', name: stateName };
    }
    const state = states[stateName];
    if (!state) {
      return { kind: 'dangling', name: stateName };
    }

    if (state.Type === 'Choice') {
      const joinNode = tryBuildChoiceJoin(stateName, state);
      if (joinNode) return joinNode;
    }

    visited.add(stateName);
    const children: RenderChild[] = [];

    if (state.Type === 'Choice') {
      for (const rule of state.Choices ?? []) {
        children.push({ label: describeChoiceRule(rule), node: walk(rule.Next) });
      }
      if (state.Default) {
        children.push({ label: 'Default', node: walk(state.Default) });
      }
    } else if (state.Next) {
      children.push({ label: null, node: walk(state.Next) });
    }
    // else: terminal — End: true, or a Succeed/Fail/Task with no Next and no End.

    return { kind: 'state', name: stateName, state, children };
  }

  /**
   * Attempts to resolve a Choice into a real fan-in. Returns null (caller
   * falls back to independent per-branch walks) when:
   *   - fewer than 2 branches (nothing to converge)
   *   - the branches don't ALL share a common downstream state (partial
   *     convergence isn't attempted — all-or-nothing, to keep the visual
   *     shape simple and unambiguous)
   *   - a branch's own prefix hits a nested Choice before reaching the
   *     join (prefixes must be simple linear chains by design — a nested
   *     Choice inside a branch is its own, separate case, not unified
   *     into the outer fan-in)
   *   - the candidate join point was already visited elsewhere (would
   *     produce a duplicate render; the ordinary merge-stub path handles
   *     that correctly instead)
   */
  function tryBuildChoiceJoin(stateName: string, state: AslState): RenderNode | null {
    const branchTargets = [
      ...(state.Choices ?? []).map(r => ({ label: describeChoiceRule(r), next: r.Next })),
      ...(state.Default ? [{ label: 'Default', next: state.Default }] : []),
    ];
    if (branchTargets.length < 2) return null;

    const chains = branchTargets.map(b => collectLinearChain(b.next, states));
    const joinName = findJoinPoint(chains);
    if (!joinName || visited.has(joinName)) return null;

    visited.add(stateName);
    const branches: RenderBranch[] = branchTargets.map((b, i) => {
      const idx = chains[i].indexOf(joinName);
      const prefixNames = chains[i].slice(0, idx);
      return {
        label: b.label,
        prefix: prefixNames.map(n => ({ name: n, state: states[n] })),
      };
    });
    for (const b of branches) {
      for (const p of b.prefix) visited.add(p.name);
    }

    const joined = walk(joinName);
    return { kind: 'choice-join', name: stateName, state, branches, joined };
  }

  return walk(startAt);
}

/** Walks a single branch as a flat chain of state names, stopping at a
 *  terminal, a dangling reference, or a nested Choice (prefixes feeding
 *  into a fan-in must be simple — a Choice found mid-prefix means this
 *  branch doesn't qualify for join detection; the caller's search for a
 *  common join point simply won't find this branch's continuation past
 *  that point, which correctly prevents a join from being detected in
 *  that case). Defensively guards against revisiting the same name
 *  within one branch (a malformed/cyclic Next chain shouldn't hang). */
function collectLinearChain(startName: string, states: Record<string, AslState>): string[] {
  const chain: string[] = [];
  const localSeen = new Set<string>();
  let current: string | undefined = startName;
  while (current && !localSeen.has(current)) {
    localSeen.add(current);
    const state: AslState | undefined = states[current];
    if (!state) break;
    chain.push(current);
    if (state.Type === 'Choice') break;
    current = state.Next;
  }
  return chain;
}

/** Finds the earliest state name that appears in EVERY branch's chain —
 *  the point where all of a Choice's branches genuinely reconverge.
 *  Walks all chains in lockstep so it finds the shallowest valid join
 *  even when branches have different-length prefixes (e.g. one branch
 *  jumps straight to the join with no prefix of its own, per the
 *  reference pipeline's Default branch). Returns null if no state is
 *  common to all branches. */
function findJoinPoint(chains: string[][]): string | null {
  if (chains.length < 2) return null;
  const sets = chains.map(c => new Set(c));
  const maxLen = Math.max(...chains.map(c => c.length));
  for (let step = 0; step < maxLen; step++) {
    for (const chain of chains) {
      const candidate = chain[step];
      if (candidate && sets.every(s => s.has(candidate))) {
        return candidate;
      }
    }
  }
  return null;
}

/** Every state name actually reachable from StartAt (used to detect
 *  orphaned states that exist in the map but nothing points to). */
export function reachableStateNames(startAt: string, states: Record<string, AslState>): Set<string> {
  const seen = new Set<string>();
  function walk(name: string) {
    if (seen.has(name) || !states[name]) return;
    seen.add(name);
    const state = states[name];
    if (state.Type === 'Choice') {
      for (const rule of state.Choices ?? []) walk(rule.Next);
      if (state.Default) walk(state.Default);
    } else if (state.Next) {
      walk(state.Next);
    }
  }
  walk(startAt);
  return seen;
}

/** Human-readable label for a Choice branch, e.g.
 *  "$.validationResult.needsManualReview == true". */
export function describeChoiceRule(rule: AslChoiceRule): string {
  if (rule.BooleanEquals !== undefined) return `${rule.Variable} == ${rule.BooleanEquals}`;
  if (rule.StringEquals !== undefined)  return `${rule.Variable} == "${rule.StringEquals}"`;
  if (rule.NumericEquals !== undefined) return `${rule.Variable} == ${rule.NumericEquals}`;
  return rule.Variable;
}

/** Short label shown above a Task state box, matching the AWS Workflow
 *  Studio convention (e.g. "Lambda: Invoke", "Lambda: waitForTaskToken"). */
export function integrationLabel(state: AslState): string {
  if (state.Type !== 'Task') return state.Type;
  const resource = state.Resource ?? '';
  if (resource.includes('waitForTaskToken')) return 'Lambda: waitForTaskToken';
  if (resource.includes('lambda:invoke.sync') || resource.endsWith('.sync')) return 'Lambda: Run a Job (.sync)';
  if (resource.includes(':lambda:')) return 'Lambda: Invoke';
  return 'Task';
}
