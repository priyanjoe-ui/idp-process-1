import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output, signal } from '@angular/core';
import { CdkDragDrop, DragDropModule } from '@angular/cdk/drag-drop';
import { AslState } from '@akrify/shared';
import { RenderNode, integrationLabel } from '../../utils/asl-render-tree';
import { InsertionPoint } from '../../utils/asl-graph-edit';
import { PaletteChoice } from '../../utils/palette-options';

/**
 * Purely presentational — all graph-walking and convergence detection
 * already happened in buildRenderTree() before this component ever runs.
 * This just draws whatever RenderNode it's given and recurses into its
 * children. Standalone components can self-reference for recursive
 * templates, which is what makes the tree rendering possible without a
 * separate structural-directive-based recursion helper.
 *
 * Two ways to insert a state at any connector, both wired here:
 *   - Click the "+" button (opens the CDK Overlay popup in the parent)
 *   - Drag a palette item from the sidebar and drop it on the connector
 * Both ultimately call the same insertState() logic in the parent canvas
 * component — this component just reports *which* connector was used.
 */
@Component({
  selector: 'app-state-node',
  standalone: true,
  imports: [CommonModule, DragDropModule, StateNodeComponent],
  templateUrl: './state-node.component.html',
  styleUrls: ['./state-node.component.scss'],
})
export class StateNodeComponent {
  @Input({ required: true }) node!: RenderNode;
  @Input() selectedStateName: string | null = null;

  @Output() select = new EventEmitter<string>();
  @Output() addAt = new EventEmitter<{ point: InsertionPoint; anchor: HTMLElement }>();
  @Output() paletteDropped = new EventEmitter<{ point: InsertionPoint; choice: PaletteChoice }>();

  /** Which connector (if any) currently has a drag hovering over it, for
   *  the highlight style. 'linear' for the single non-Choice connector,
   *  'branch-<i>' for a specific Choice branch's connector. */
  readonly dragOverKey = signal<string | null>(null);

  integrationLabel(state: AslState): string {
    return integrationLabel(state);
  }

  isTerminalState(): boolean {
    return this.node.kind === 'state' && this.node.children.length === 0;
  }

  onSelect(name: string) {
    this.select.emit(name);
  }

  onAddAfterState(stateName: string, event: MouseEvent) {
    this.addAt.emit({
      point: { kind: 'after-state', stateName },
      anchor: event.currentTarget as HTMLElement,
    });
  }

  onAddBranch(stateName: string, branchIndex: number, isDefault: boolean, event: MouseEvent) {
    const point: InsertionPoint = isDefault
      ? { kind: 'choice-default', stateName }
      : { kind: 'choice-branch', stateName, branchIndex };
    this.addAt.emit({ point, anchor: event.currentTarget as HTMLElement });
  }

  onDragEnter(key: string) {
    this.dragOverKey.set(key);
  }

  onDragExit(key: string) {
    if (this.dragOverKey() === key) this.dragOverKey.set(null);
  }

  onDropAfterState(stateName: string, event: CdkDragDrop<unknown, unknown, PaletteChoice>) {
    this.dragOverKey.set(null);
    this.paletteDropped.emit({
      point: { kind: 'after-state', stateName },
      choice: event.item.data,
    });
  }

  onDropBranch(
    stateName: string,
    branchIndex: number,
    isDefault: boolean,
    event: CdkDragDrop<unknown, unknown, PaletteChoice>,
  ) {
    this.dragOverKey.set(null);
    const point: InsertionPoint = isDefault
      ? { kind: 'choice-default', stateName }
      : { kind: 'choice-branch', stateName, branchIndex };
    this.paletteDropped.emit({ point, choice: event.item.data });
  }
}
