# Akrify Studio

Workflow designer for the IDP platform. Analogous to IBM Datacap Studio, but native to AWS + Bedrock.

Studio produces configuration; the runtime IDP pipeline consumes it. Same JSON schema on both sides.

## Repo layout

```
akrify-studio/
├── projects/
│   ├── studio/          # Studio Angular app
│   └── shared/          # Shared lib: domain models
├── angular.json         # Multi-project workspace
├── tsconfig.json        # Path map so studio consumes @akrify/shared by source
└── package.json
```

## Getting started

```bash
npm install
npm run start           # ng serve on :4300 (dev environment)
```

Open http://localhost:4300 — lands on the Dashboard.

## Environments

One Angular build per environment; each deploys as its own stack. No cross-environment access from the browser.

```bash
npm run build:dev       # dev  build (default when serving)
npm run build:qa        # qa   build → environment.qa.ts
npm run build:prod      # prod build → environment.prod.ts
```

The topbar shows an environment chip driven by `environment.envLabel`:
- **dev** — neutral grey
- **qa** — amber, with a thin amber strip across the top of the app
- **prod** — red, with a red strip across the top

The strip is intentional visual friction: if you're about to change something in prod, you should see red before you click save.

## Data model (DynamoDB, one table per environment)

No `tenantId` — one stack per environment means "the environment" is implicit in which stack you hit.

```
Main table (e.g. IDP_Config_dev, IDP_Config_qa, IDP_Config_prod):

  PK                 SK              Row shape                  type
  ─────────────────  ──────────────  ─────────────────────────  ───────────
  "APP#LOANS"        "META"          ApplicationRecord          APPLICATION
  "APP#LOANS"        "DT#LOAN_APP"   DocumentTypeRecord         DOC_TYPE
  "APP#LOANS"        "DT#ID_PROOF"   DocumentTypeRecord         DOC_TYPE
  "APP#CLAIMS"       "META"          ApplicationRecord          APPLICATION
  "APP#CLAIMS"       "DT#CLAIM_FORM" DocumentTypeRecord         DOC_TYPE
  "DICT"             "TransCodes"    DictionaryRecord           DICTIONARY

GSI 1: type-lastModifiedAt-index
  PK: type              → "APPLICATION" | "DOC_TYPE" | "DICTIONARY"
  SK: lastModifiedAt

  Used by:
    - listApplications()       → Query type = "APPLICATION"
    - listAllDocumentTypes()   → Query type = "DOC_TYPE"
```

**Row envelope** — every row carries:
- `type` (feeds the GSI)
- `version` (integer, incremented per save)
- `lastModifiedAt` (ISO timestamp)
- `lastModifiedBy` (server-populated from JWT claim; stubbed as `"studio-admin"` today)

**Optimistic concurrency** — every `PUT` includes an `expectedVersion`. Backend uses
`ConditionExpression: "version = :expected"`. On mismatch, backend returns 409;
Studio surfaces "This was modified by someone else — reload."

Single source of truth. No draft/publish separation. Whoever saves last wins,
protected against silent overwrites by the version check.

## Studio hierarchy

The UI mirrors the data model:

```
Applications              /applications              Card grid
  └─ Document Types       /applications/:appId/document-types   Table
       └─ Editor          /applications/:appId/document-types/:id   (next round)
```

A **global** doc-types view lives at `/document-types` — reads via the GSI so it doesn't Scan.
Useful for search across applications.

## Backend integration

Applications endpoints are wired to the `idp-api-proxy` Lambda (Node.js/Express). Point `apiBaseUrl` in `environment.ts` at the proxy — locally `http://localhost:3001/api`, deployed `https://<function-url>/api`.

See `idp-api-proxy/STUDIO-SETUP.md` for the full backend setup: creating the `idp-config` DynamoDB table, IAM policy for the Lambda, and running the one-shot migration script that seeds DDB from the existing S3 `document-config.json`.

**What's live vs. mocked in the frontend:**

| Section | Frontend | Backend |
|---|---|---|
| Applications CRUD | ✅ Live HTTP | ✅ Live |
| Document Types CRUD | ✅ Live HTTP | ✅ Live |
| Document Type editor — Pages tab | ✅ Live (Sequential/Keyword/WordCount identification, drag-drop reorder) | ✅ Live (via update endpoint) |
| Document Type editor — Fields tab (incl. Validation) | ✅ Live (Anchor/Position/Regex/AI extraction methods; Format/Range validation) | ✅ Live (via update endpoint) |
| Document Type editor — Classification | ✅ Live | ✅ Live (via update endpoint) |
| Document Type editor — Indexer UI | 🟡 Placeholder panel | ✅ Backend supports arbitrary body; UI not built |
| Dictionaries | ✅ Live HTTP | ✅ Live |
| Dashboard | ✅ Live — reuses the reviewer app's existing `GET /api/dashboard` (queries `idp-batch-tracking` directly) | ✅ Already existed; no changes needed |

Nothing in the frontend is mocked anymore. The Dashboard deserves a callout: it doesn't have its own backend — it calls the same `/api/dashboard` endpoint the reviewer app's Job Monitor tab already uses, scoped to the last 7 days. Fields with no real data source yet (day-over-day trend, active indexer count, avg processing time, activity feed, service health) show honest "not available yet" placeholders rather than fabricated numbers. See `DashboardService` for the exact mapping and `DashboardKpis`/`DashboardSnapshot` in `@akrify/shared` for which fields are nullable as a result.

## Screens

| Screen | Route | Status |
|---|---|---|
| Dashboard | `/dashboard` | ✅ Live — real KPIs/chart/status breakdown; trend/activity/health sections are labeled placeholders |
| Applications | `/applications` | ✅ Card grid, search, create, **cascading delete (typed confirm)** |
| Document Types (per app) | `/applications/:appId/document-types` | ✅ Table, search, tabs, sort, pagination, breadcrumb |
| Document Types (global) | `/document-types` | ✅ Same table, adds Application column |
| Document Type editor | `/applications/:appId/document-types/:id` | ✅ Shell + Pages/Fields (incl. Validation)/Classification tabs live, delete option; Indexer UI still a placeholder (Preview dropped, Validation folded into Fields) |
| Dictionaries | `/dictionaries` | ✅ List + editor, live HTTP |
| Jobs & Workflows | `/workflows` (single list, no scoping), `/workflows/:workflowId` (canvas) | ✅ Live — list + full visual builder (see below) |
| Connectors | `/connectors` | 🟡 Stub |
| Test Bench | `/test-bench` | 🟡 Stub |
| Deployments | `/deployments` | 🟡 Stub |
| Users & Access | `/users` | 🟡 Stub |
| Settings | `/settings` | 🟡 Stub |

## Backend contract

Every method on `StudioConfigService` maps 1:1 to a REST endpoint. The mock service simulates the wire behavior (delays, version conflicts, cascades) so components exercise the same code paths they will in production.

```
Applications
  GET    /applications                                        -> ApplicationSummary[]
  GET    /applications/:appId                                 -> ApplicationRecord
  POST   /applications                                        -> ApplicationRecord
  PUT    /applications/:appId                                 -> ApplicationRecord
  DELETE /applications/:appId                                 -> 204

Document Types
  GET    /applications/:appId/document-types                  -> DocumentTypeSummary[]
  GET    /document-types                                      -> DocumentTypeSummary[]   (GSI)
  GET    /applications/:appId/document-types/:docTypeId       -> DocumentTypeRecord
  POST   /applications/:appId/document-types                  -> DocumentTypeRecord
  PUT    /applications/:appId/document-types/:docTypeId       -> DocumentTypeRecord
  DELETE /applications/:appId/document-types/:docTypeId       -> 204

Dictionaries
  GET    /dictionaries                                        -> DictionaryRecord[]
  GET    /dictionaries/:name                                  -> DictionaryRecord
  PUT    /dictionaries/:name                                  -> DictionaryRecord

All PUT and DELETE requests carry an X-Expected-Version header. Backend enforces
via DynamoDB ConditionExpression.
```

## Design decisions locked in this round

- **Separate Angular app**, shared lib for domain models. Two personas, two apps, one schema.
- **DynamoDB single-state** — no draft/publish separation. Optimistic concurrency (`expectedVersion`) prevents silent overwrites.
- **Applications are visible in the UI** as a top-level workspace. Doc types nest under them.
- **One AWS stack per environment.** Environment shown as a chip + top strip in the UI; not selectable at runtime.
- **`lastModifiedBy` is server-populated** from JWT claims. UI never sends it. Stubbed as `"studio-admin"` until auth wires in.
- **Creation flows are modals, not pages** — both "New Application" and "New Document Type" are small, focused forms. Real configuration happens in the editor, not the creation form.
- **"New Document Type" only appears in the scoped list** (`/applications/:appId/document-types`), not the global cross-app list. Creating a doc type requires knowing which application it belongs to.
- **Field mutations happen in place** on the editor's local draft copy (`structuredClone` of the loaded body). Both the Fields and Pages tabs receive their slice of the tree by reference and mutate it directly, emitting a `changed` event so the shell tracks a dirty flag — avoids re-serializing the whole tree on every keystroke.
- **Position extraction method** required adding a `FieldPosition` type (`Page`, `X`, `Y`, `Width`, `Height`) to the shared model — additive and optional, existing configs unaffected.
- **Application creation is minimal by design** — just App ID and Display Name. Classification Mode defaults server-side to `Sequential`; there's no UI to change it post-creation yet (not requested — would need an Application settings surface if that becomes necessary).
- **`BlankPageMaxWordCount` moved from Application to Page Type.** The original runtime schema had this as an app-wide setting; it's now `MaxWordCount` on a page type using the `WordCount` identification method (typically the `BlankPage` type). **This is a breaking change from the original schema** — if any runtime Lambda reads `Applications[i].BlankPageMaxWordCount` from the config API, it will no longer find it there. The migration script warns (doesn't silently drop) when source data has this field, so it can be manually re-applied per Document Type after migration.
- **Page Type identification methods**: `Sequential` (position-based, set by drag order), `Keyword` (matches text on the page), `WordCount` (page has fewer than N words — the blank-page case). Every new Document Type is scaffolded with `MainPage` (Sequential) and `BlankPage` (WordCount, threshold 5) by default.
- **Page reordering uses Angular CDK drag-and-drop** (`@angular/cdk`, new dependency — run `npm install` after pulling this update). Dragging a row updates every page type's `SequenceOrder` to match its new position.
- **Deleting an Application requires typing its ID to confirm** — this cascades to every Document Type underneath it, so a plain Yes/No dialog isn't enough friction for an unrecoverable action. Deleting a single Page Type (non-cascading, much smaller blast radius) uses a lighter inline Confirm/Cancel instead.
- **New Document Types land on the Pages tab**, not Fields — via a `?tab=pages` query param set only by the creation flow. Opening an existing Document Type from a list row still defaults to Fields, since page structure is presumably already set up.

## What's next

Fields, Pages, Classification, Dictionaries, Dashboard, and now Jobs & Workflows are all live. Preview was dropped from the Document Type editor's tab list entirely (rather than kept as a placeholder) — it needs a real document + live extraction run, which converges with Test Bench, so it'll be built there instead of twice. Validation was redesigned away from being its own tab (see below). Indexer UI is still a placeholder tab; see the design notes for what it'll do. Connectors, Test Bench, Deployments, Users & Access, Settings are all still stubs.

### Jobs & Workflow Builder — live, visual Step Functions editor

The core design decision: **the canvas's data model IS Amazon States Language, directly** — no custom graph schema that gets translated into ASL later. What you edit on the canvas is exactly what gets sent to `CreateStateMachine`/`UpdateStateMachine` on Deploy. This mirrors how AWS's own Step Functions Workflow Studio works.

**Data model** (`@akrify/shared/asl.model.ts`) — `AslState`, `AslDefinition`, `AslChoiceRule`, `AslRetry`, `AslCatch` mirror ASL's real JSON shape field-for-field. Scoped initially to `Task` and `Choice` (what the IDP pipeline actually uses); other types (`Wait`, `Parallel`, `Map`, `Succeed`, `Fail`) are typed for forward compatibility and render correctly if present, but aren't yet editable in the inspector.

**Convergence detection** — ASL is a DAG, not a strict tree: two Choice branches can point at the same downstream state (e.g. a `ManualReview` path and a `Default` path both eventually reaching `Export`). `buildRenderTree()` (`utils/asl-render-tree.ts`) tracks every state name rendered in a single `Set` threaded through the walk; the first branch to reach a shared state renders it in full, any later branch renders a short "merges into `X`" stub instead of a duplicate box. This was verified by actually running the algorithm (not just reading it) against the reference pipeline's `NeedsReviewChoice → ManualReview/Export` case before building anything on top of it — `Export` renders exactly once. Also since re-verified against a real imported production pipeline (see "Workflows are shared" below), not just the reference fixture.

**Rendering** — `StateNodeComponent` is a purely presentational, self-referencing recursive standalone component. All graph-walking already happened in `buildRenderTree()`; this component just draws whatever `RenderNode` it's handed and recurses into `children`. Deliberately recomputed on every change-detection cycle rather than cached behind a `computed()` signal — the definition is mutated in place (same pattern as the Document Type editor), so there's no signal-reference change to key a memoized computation off of, and workflow graphs are small enough that this is cheap.

**Add-state interaction** — a "+" button on every connector (including each Choice branch) opens a small popup via Angular CDK Overlay, anchored to the clicked button. Picking a type calls `insertState()` (`utils/asl-graph-edit.ts`), which splices the new state into the `States` map and rewires whatever pointer (`Next`, a specific `Choices[i].Next`, or `Default`) the connector represented, preserving the rest of the chain.

**CDK Overlay CSS is inlined, not loaded from `node_modules`.** Originally referenced `node_modules/@angular/cdk/overlay-prebuilt.css` from `angular.json`'s `styles` array — this built without error but the popup's *positioning* rules weren't reliably ending up in the bundle (the popup's own content rendered fine — its component styles are self-contained — but it landed in normal document flow at the bottom of the page instead of anchored near the "+" button, since the base `.cdk-overlay-container { position: fixed; ... }` rule wasn't applying). Fixed by copying the small, stable set of overlay positioning rules directly into `styles.scss` instead of depending on that path resolving correctly at build time. Drag-drop (used in Pages tab) never needed this — only Overlay's positioning CSS was the gap.

**Inspector** (right panel) — form fields conditional on the selected state's `Type`. For Task states, an "Integration Pattern" selector (Request Response / Wait for Task Token / Run a Job) does more than toggle a flag — `Resource` and `Parameters` are structurally different per pattern (e.g. Wait for Task Token wraps the function ARN inside `Parameters.FunctionName` with a `taskToken.$` in the payload, rather than `Resource` being the function ARN directly), so switching patterns actively rewrites the state's shape via `applyIntegrationPattern()` (`utils/asl-task-integration.ts`). Retry/Catch rules use a comma-separated `ErrorEquals` text field rather than a full tag-pill UI — a deliberate simplification given these lists are typically short. Parameters has a raw JSON textarea as an escape hatch for anything the structured fields don't cover, matching the brief's "acceptable for v1."

**Workflows are shared, independent entities — not owned by one Application.** This was a real redesign after the first pass: originally a workflow lived *inside* an Application (`PK: APP#<appId>, SK: WORKFLOW#<id>`), with a scoped list (`/applications/:appId/workflows`) alongside a separate global list. Rebuilt so a workflow can be mapped to **any number** of Applications, editable after creation (not fixed at creation time):

- **Storage**: flat partition, same pattern Dictionaries already use — `PK: 'WORKFLOW'`, `SK: <workflowId>`, plus a `mappedApplicationIds: string[]` field. Listing every workflow is a plain `Query PK = 'WORKFLOW'` — no GSI needed at all for this, simpler than before.
- **Routes**: flat — `/workflows` (the only list, no scoped variant) and `/workflows/:workflowId` (canvas). The list's "Applications" column shows every mapped app as its own tag, resolved from name via a client-side lookup against the Applications list (falls back to showing the raw id if an app was deleted after mapping, rather than silently dropping it).
- **Creating** a workflow includes an optional multi-select checklist of Applications (`New Workflow` modal) — mapping isn't required at creation, can be added later.
- **Editing the mapping later** — a "Manage Applications" modal, reachable from the canvas header. This is a separate save path from the definition's Save/Discard/Deploy flow: mapping is plain metadata, saves immediately on its own `PUT`, no draft concept (matching how Applications/Document Types work, not the draft/deployed model the *definition* itself uses).
- **Deleting an Application** doesn't delete workflows mapped to it — it strips that Application's id out of every workflow's `mappedApplicationIds` (best-effort, non-fatal if a rare concurrent edit conflicts with the cleanup) so nothing dangling is left behind, since other Applications may still be using the same workflow.
- State machine naming lost its app prefix accordingly: `idp-<workflowId>` instead of `idp-<appId>-<workflowId>`.

**Data model — one row per workflow, not two.** The original brief proposed separate draft/production rows (`#draft` / `#v<n>`). Built it simpler: **one row**, with a `status` field (`draft` | `deployed`) and an optional `stateMachineArn`. `definition` *is* the draft — there's no separate frozen "production" copy to keep in sync, since the real running definition lives in Step Functions itself, not duplicated in DynamoDB. This still gets the safety property that mattered (`PUT` — Save — never touches Step Functions; only `POST .../deploy` does) with less mechanism than maintaining two rows.

**Deploy** = save the draft, then create-or-update the real state machine from what was just saved — never skips the save step, so "deployed" and "draft" can't silently drift apart. Uses `WORKFLOW_ROLE_ARN` (defaults to `arn:aws:iam::651720177345:role/LambdaExecutionRole`) — an **existing** role, reused as-is. The account's IAM boundary policy denies `iam:CreateRole`; this Lambda never attempts to create one.

**Discard navigates back to the list**, unlike the Document Type editor's Discard (which reverts in place and stays on the page) — a deliberate difference, since this screen's canvas is heavier and "start over from the list" was the requested behavior here specifically.

**Deleting a workflow in Studio does not delete the real state machine.** If a workflow has been deployed, removing its Studio record only makes Studio forget about it — the actual Step Functions state machine keeps running and processing documents until separately stopped/deleted in the AWS Console. The delete confirmation modal says this explicitly.

**Importing an existing, already-deployed state machine** — `scripts/migrate-workflow-to-ddb.js` (same CONFIG-block-then-run pattern as `migrate-config-to-ddb.js`). Read-only against Step Functions (`DescribeStateMachine` only, never `Create`/`UpdateStateMachine`), so it can't affect a real running pipeline. Pulls whatever is *actually* deployed right now rather than a stale copy from a design doc, and lands with `status: 'deployed'` and the real `stateMachineArn` already set, plus whichever Applications you list in `CONFIG.APP_IDS` (can be empty, mapped later via Manage Applications). See `STUDIO-SETUP.md` for the full run instructions.

**Deferred, deliberately** — per the person's call, the multi-application *ingestion* architecture (how files landing in different S3 prefixes get routed to the right state machine) wasn't decided yet; that's Connectors + an `idp-ingestion` Lambda update, revisited after the canvas itself was in hand. Nothing in this build blocks on that decision — each workflow's own identity (and its mapping to Applications) is already fully independent of however ingestion ends up routing to it.

### Line Items — live, configured from the Fields tab

Line Items already existed in the shared model (`ConfigLineItems`/`ConfigLineItemColumn`) but had never been surfaced in any Studio screen. Checked the real migrated `document-config.json` before building: one real example, `CORRDOC`'s `MainPage`, a 16-column table (`Name: "lineitem"`) where every column uses just `FieldName`/`Label`/`DataType`/`Required`, occasionally `OptionsRef` for a Dictionary reference — no extraction method, no validation config on any column. That shaped the design:

- **`LineItem` is a selectable Data Type on a field**, not a separate screen. Setting a field's Data Type to `LineItem` converts it into an entry in the page's Line Items array — removed from `Fields[]`, added to `LineItems[]` — matching how the real runtime schema actually separates the two. Loading an existing page with a Line Items table works automatically through the same code path: it's just data, no special-cased "migration" logic needed in the UI.
- **A page can have any number of Line Items tables** — no cap, no "one per page" restriction. Each shows as its own entry in the field list, individually selectable.
- **Columns are deliberately simpler than top-level fields** — Field Name, Label, Data Type, Required, and a Dictionary picker when Data Type is Dropdown. No extraction method or validation config per column, matching what the real data actually uses (a Line Items table is a repeating grid, almost certainly populated via Textract table detection, not per-field regex/anchor/AI extraction). The model doesn't restrict this — `ConfigLineItemColumn extends ConfigField` — so more could be exposed later if a real need shows up.
- **Rows aren't configured in Studio** — they're populated at runtime from the extracted table. Studio only defines the column schema.
- Columns are drag-reorderable (same CDK pattern as Pages).

**Model change**: `ConfigPageType.LineItems` changed from a single object to an array (`ConfigLineItems[]`). This is a real wire-format change worth knowing about:

- **Migration script** (`migrate-config-to-ddb.js`) now wraps the old single-object shape into a 1-element array when reading from S3, so existing data (like `CORRDOC`) loads into Studio with nothing lost or duplicated — same table, same 16 columns, just in the new container shape.
- **`GET /api/applications`** (the endpoint the reviewer app calls) now returns `lineItems` as an array instead of a single object or `null`. If the reviewer app (`idp-ui`, a separate project) has any code today that reads `pageType.lineItems.columns` directly, it will need updating to iterate the array instead — flagging this the same way as other reviewer-app-adjacent changes in this project, since it's out of scope for Studio itself but worth knowing before deploying.

### Recent fixes

- **Pages is now the default landing tab** for the editor, regardless of entry point (previously only true for freshly-created Document Types via a query param; now true everywhere, matching what actually made sense given Fields depends on Pages).
- **Adding a page type in the Pages tab now auto-selects it for the Fields tab too** — previously the newly added page was technically present as a pill in Fields but easy to miss, since Fields' selection state wasn't synced to Pages' add action (only rename/remove were). A defensive `ensureValidSelectedPageType()` check also runs after every load/save/discard so the selection can never point at a page type that no longer exists.
- **Document Type delete** — a Delete button in the editor header opens a confirm modal (single-entity delete, no cascade across other entities, so no typed confirmation required — unlike Application delete).
- **Dropdown fields can now reference a Dictionary** — when a field's Data Type is set to Dropdown, the inspector shows a Dictionary picker bound to the field's existing `OptionsRef` property, populated from whatever's been created on the Dictionaries screen.
- **Classification tab is live** — document-type-level keyword set + confidence threshold, deciding which document type a batch belongs to (distinct from Pages' per-page-type identification). Along the way, removed `ClassificationKeywords` from `ConfigPageType` — confirmed as legacy duplication from the original schema, never wired to any logic, so it was dead weight rather than a real second concept.
- **Double-click to rename a page type** in the Pages list, with the same auto-focus-and-select-text behavior applied to freshly-added pages so you can immediately type over the default name. New reusable `AutoFocusSelectDirective` (`appAutoFocusSelect`) backs this.
- **Page context is now always visible in the Fields tab**, even when a document type has only one page — previously the page-selector pills were hidden below 2 page types, leaving no indication of which page's fields you were editing.

### Validation — redesigned, now live (not a separate tab)

Originally planned as a fifth tab for cross-field rules. Before building it, checked what the real migrated `document-config.json` actually validates: mostly nothing (most fields have no validation at all), and where it exists, it's exactly two mechanisms — `ValidationRegex` (4 fields: PolicyNumber, CIFNumber, SSN, CustomerName) and a plain `Format` string used once, on `ReceivedDate` (`"YYYYMMDD"`). `Format` existed in the shared model but had never been surfaced in any Studio UI until now.

That real-data check reshaped the design entirely:

- **No separate tab.** Validation is a per-field concern, not something needing its own workspace — it's now a collapsible "Validation" section inside the Fields tab inspector, right below Extraction Method.
- **Off by default, per field** — a toggle ("Required" / "Not required") matches the real data, where validation is the exception, not the rule.
- **Two validation types when enabled**: **Format** (regex for most types; a date-format string like `YYYYMMDD` when DataType is `Date` — reuses the existing `ValidationRegex`/`Format` fields, no new storage needed) and **Range** (min/max bounds — needed two new fields, `MinValue`/`MaxValue`). A third type, **Length**, was considered and dropped: a regex like `{6,12}` already encodes length as part of the pattern, so Format subsumes it.
- **Structural fix**: `Validation Regex` used to only appear in the inspector when Extraction Method was set to `Regex` — which was backwards, since validation should apply regardless of *how* a value was extracted (AI, Anchor, whatever). It's now fully independent.

### Plan for the remaining editor tab

- **Indexer UI** — controls field layout in the reviewer app's Verify screen (order, grouping, default visibility). Planned design: three new properties directly on `ConfigField` (`IndexerOrder`, `IndexerVisible`, `IndexerGroup`) rather than a parallel list, so a field deleted in Fields tab can't go stale in a separate structure. The tab itself becomes a flattened, drag-reorderable view over every field across all page types, reusing the CDK drag-drop pattern from Pages.
- **Important caveat, confirmed with the person during design**: this (and Validation) is Studio-side config only. The reviewer app (`idp-ui`, a separate Angular project) doesn't yet read `IndexerOrder`/`IndexerVisible`, and the runtime's validation Lambda doesn't yet enforce `ValidationTypes`/`MinValue`/`MaxValue`. Studio stores well-structured config; making the reviewer app and runtime pipeline act on it is separate work, out of scope for this pass.
