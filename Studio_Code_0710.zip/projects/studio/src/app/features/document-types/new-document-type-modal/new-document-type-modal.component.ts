import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, EventEmitter, Input, Output, signal } from '@angular/core';
import { inject } from '@angular/core';
import { StudioConfigService } from '../../../services/studio-config.service';

/**
 * Minimal creation form — intentionally shallow. Pages, fields, extraction
 * rules all belong in the editor, not here. This modal exists only to get
 * a new doc type row into existence so the user can jump into the editor.
 */
@Component({
  selector: 'app-new-document-type-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './new-document-type-modal.component.html',
  styleUrls: ['./new-document-type-modal.component.scss'],
})
export class NewDocumentTypeModalComponent {
  private readonly configService = inject(StudioConfigService);

  /** Application this doc type will be created under. */
  @Input({ required: true }) appId!: string;
  @Input() appName = '';

  @Output() closed = new EventEmitter<void>();
  @Output() created = new EventEmitter<{ appId: string; docTypeId: string }>();

  readonly docTypeId = signal('');
  readonly name = signal('');
  readonly submitting = signal(false);
  readonly error = signal<string | null>(null);

  readonly idPattern = /^[A-Z0-9_]+$/;

  readonly idError = () => {
    const v = this.docTypeId().trim();
    if (!v) return null;
    return this.idPattern.test(v) ? null : 'Use only uppercase letters, numbers, and underscores.';
  };

  readonly canSubmit = () =>
    this.docTypeId().trim().length > 0 &&
    this.name().trim().length > 0 &&
    !this.idError() &&
    !this.submitting();

  onIdInput(raw: string) {
    // Auto-uppercase and swap spaces for underscores — reduces friction,
    // still shows validation if the user types something odd.
    this.docTypeId.set(raw.toUpperCase().replace(/\s+/g, '_'));
  }

  submit() {
    if (!this.canSubmit()) return;
    this.submitting.set(true);
    this.error.set(null);
    this.configService.createDocumentType(this.appId, {
      docTypeId: this.docTypeId().trim(),
      name: this.name().trim(),
    }).subscribe({
      next: record => {
        this.submitting.set(false);
        this.created.emit({ appId: record.appId, docTypeId: record.docTypeId });
      },
      error: err => {
        this.submitting.set(false);
        this.error.set(err?.message || 'Failed to create document type.');
      },
    });
  }

  cancel() {
    if (this.submitting()) return;
    this.closed.emit();
  }
}
