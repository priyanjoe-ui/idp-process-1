import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Output } from '@angular/core';

export type PaletteChoice = 'lambda-invoke' | 'lambda-wait-token' | 'choice';

interface PaletteOption {
  key: PaletteChoice;
  label: string;
  hint: string;
  icon: string;
}

const OPTIONS: PaletteOption[] = [
  {
    key: 'lambda-invoke',
    label: 'Lambda: Invoke',
    hint: 'Request/response — call and continue immediately.',
    icon: 'M13 3 4 14h7l-1 7 9-11h-7l1-7z',
  },
  {
    key: 'lambda-wait-token',
    label: 'Lambda: Wait for Task Token',
    hint: 'Pause until the task reports success/failure (e.g. manual review).',
    icon: 'M12 8v4l3 2M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z',
  },
  {
    key: 'choice',
    label: 'Choice',
    hint: 'Branch based on a condition.',
    icon: 'M12 3 3 12l9 9 9-9-9-9z',
  },
];

@Component({
  selector: 'app-add-state-palette',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './add-state-palette.component.html',
  styleUrls: ['./add-state-palette.component.scss'],
})
export class AddStatePaletteComponent {
  @Output() pick = new EventEmitter<PaletteChoice>();

  readonly options = OPTIONS;
}
