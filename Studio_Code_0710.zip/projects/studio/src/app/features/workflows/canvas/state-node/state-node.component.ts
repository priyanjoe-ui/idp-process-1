import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { AslState } from '@akrify/shared';
import { RenderNode, integrationLabel } from '../../utils/asl-render-tree';
import { InsertionPoint } from '../../utils/asl-graph-edit';

/**
 * Purely presentational — all graph-walking and convergence detection
 * already happened in buildRenderTree() before this component ever runs.
 * This just draws whatever RenderNode it's given and recurses into its
 * children. Standalone components can self-reference for recursive
 * templates, which is what makes the tree rendering possible without a
 * separate structural-directive-based recursion helper.
 */
@Component({
  selector: 'app-state-node',
  standalone: true,
  imports: [CommonModule, StateNodeComponent],
  templateUrl: './state-node.component.html',
  styleUrls: ['./state-node.component.scss'],
})
export class StateNodeComponent {
  @Input({ required: true }) node!: RenderNode;
  @Input() selectedStateName: string | null = null;

  @Output() select = new EventEmitter<string>();
  @Output() addAt = new EventEmitter<{ point: InsertionPoint; anchor: HTMLElement }>();

  integrationLabel(state: AslState): string {
    return integrationLabel(state);
  }

  isTerminalState(): boolean {
    return this.node.kind === 'state' && this.node.children.length === 0;
  }

  onSelect(name: string) {
    this.select.emit(name);
  }

  onAddAfterState(stateName: string, event: MouseEvent) {
    this.addAt.emit({
      point: { kind: 'after-state', stateName },
      anchor: event.currentTarget as HTMLElement,
    });
  }

  onAddBranch(stateName: string, branchIndex: number, isDefault: boolean, event: MouseEvent) {
    const point: InsertionPoint = isDefault
      ? { kind: 'choice-default', stateName }
      : { kind: 'choice-branch', stateName, branchIndex };
    this.addAt.emit({ point, anchor: event.currentTarget as HTMLElement });
  }
}
