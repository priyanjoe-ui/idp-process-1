import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit, inject, signal } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { Overlay, OverlayRef } from '@angular/cdk/overlay';
import { ComponentPortal } from '@angular/cdk/portal';
import { switchMap } from 'rxjs';
import { AslDefinition, AslState, WorkflowRecord } from '@akrify/shared';
import { StudioConfigService, VersionConflictError } from '../../../services/studio-config.service';
import { StateNodeComponent } from './state-node/state-node.component';
import { WorkflowInspectorComponent } from './inspector/workflow-inspector.component';
import { AddStatePaletteComponent, PaletteChoice } from './add-state-palette/add-state-palette.component';
import { ManageApplicationsModalComponent } from '../manage-applications-modal/manage-applications-modal.component';
import { RenderNode, buildRenderTree } from '../utils/asl-render-tree';
import { InsertionPoint, generateStateName, insertState, removeState } from '../utils/asl-graph-edit';

@Component({
  selector: 'app-workflow-canvas',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    StateNodeComponent,
    WorkflowInspectorComponent,
    ManageApplicationsModalComponent,
  ],
  templateUrl: './workflow-canvas.component.html',
  styleUrls: ['./workflow-canvas.component.scss'],
})
export class WorkflowCanvasComponent implements OnInit, OnDestroy {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly configService = inject(StudioConfigService);
  private readonly overlay = inject(Overlay);

  workflowId!: string;

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly record = signal<WorkflowRecord | null>(null);
  readonly definition = signal<AslDefinition | null>(null);
  readonly dirty = signal(false);

  readonly selectedStateName = signal<string | null>(null);
  readonly conflict = signal<VersionConflictError | null>(null);

  readonly saving = signal(false);
  readonly saveError = signal<string | null>(null);

  readonly deploying = signal(false);
  readonly deployError = signal<string | null>(null);
  readonly deploySuccessMessage = signal<string | null>(null);

  readonly showManageApplications = signal(false);

  private overlayRef: OverlayRef | null = null;
  private pendingInsertionPoint: InsertionPoint | null = null;

  ngOnInit() {
    this.workflowId = this.route.snapshot.paramMap.get('workflowId')!;
    this.load();
  }

  ngOnDestroy() {
    this.closeAddPalette();
  }

  load() {
    this.loading.set(true);
    this.error.set(null);
    this.configService.getWorkflow(this.workflowId).subscribe({
      next: rec => {
        this.record.set(rec);
        this.definition.set(structuredClone(rec.definition));
        this.dirty.set(false);
        this.selectedStateName.set(null);
        this.loading.set(false);
      },
      error: err => {
        this.error.set(err?.message || 'Failed to load workflow.');
        this.loading.set(false);
      },
    });
  }

  /** Recomputed on every check, not cached — the definition is mutated in
   *  place (same pattern as the Document Type editor's tabs), so there's
   *  no signal-reference change to key a computed() off of. Workflow
   *  graphs are small; recomputing this walk every CD cycle is cheap. */
  renderTree(): RenderNode | null {
    const d = this.definition();
    if (!d) return null;
    return buildRenderTree(d.StartAt, d.States);
  }

  selectState(name: string) {
    this.selectedStateName.set(name);
  }

  onDraftChanged() {
    this.dirty.set(true);
  }

  onStateRenamed(evt: { oldName: string; newName: string }) {
    if (this.selectedStateName() === evt.oldName) {
      this.selectedStateName.set(evt.newName);
    }
  }

  onStateDeleted(name: string) {
    const d = this.definition();
    if (!d) return;
    removeState(d, name);
    if (this.selectedStateName() === name) {
      this.selectedStateName.set(null);
    }
    this.dirty.set(true);
  }

  // ─── Manage Applications ─────────────────────────────────────────────

  openManageApplications()  { this.showManageApplications.set(true); }
  closeManageApplications() { this.showManageApplications.set(false); }

  onApplicationsUpdated(updated: WorkflowRecord) {
    this.record.set(updated);
    this.showManageApplications.set(false);
  }

  // ─── Add-state overlay ─────────────────────────────────────────────

  openAddPalette(evt: { point: InsertionPoint; anchor: HTMLElement }) {
    this.closeAddPalette();
    this.pendingInsertionPoint = evt.point;

    const positionStrategy = this.overlay
      .position()
      .flexibleConnectedTo(evt.anchor)
      .withPositions([
        { originX: 'center', originY: 'bottom', overlayX: 'center', overlayY: 'top', offsetY: 8 },
        { originX: 'center', originY: 'top', overlayX: 'center', overlayY: 'bottom', offsetY: -8 },
      ]);

    this.overlayRef = this.overlay.create({
      positionStrategy,
      hasBackdrop: true,
      backdropClass: 'workflow-add-palette-backdrop',
      scrollStrategy: this.overlay.scrollStrategies.reposition(),
    });

    this.overlayRef.backdropClick().subscribe(() => this.closeAddPalette());

    const portal = new ComponentPortal(AddStatePaletteComponent);
    const componentRef = this.overlayRef.attach(portal);
    componentRef.instance.pick.subscribe((choice: PaletteChoice) => {
      this.handlePaletteChoice(choice);
      this.closeAddPalette();
    });
  }

  private closeAddPalette() {
    this.overlayRef?.dispose();
    this.overlayRef = null;
    this.pendingInsertionPoint = null;
  }

  private handlePaletteChoice(choice: PaletteChoice) {
    const d = this.definition();
    const point = this.pendingInsertionPoint;
    if (!d || !point) return;

    const name = generateStateName(d.States, choice === 'choice' ? 'Choice' : 'Task');
    const newState: AslState = buildStarterState(choice, name);

    insertState(d, point, name, newState);
    this.selectedStateName.set(name);
    this.dirty.set(true);
  }

  // ─── Save / Discard / Deploy ─────────────────────────────────────────

  save() {
    const d = this.definition();
    const rec = this.record();
    if (!d || !rec || this.saving()) return;
    this.saving.set(true);
    this.saveError.set(null);
    this.conflict.set(null);

    this.configService.updateWorkflow(this.workflowId, { definition: d }, rec.version).subscribe({
      next: updated => {
        this.record.set(updated);
        this.definition.set(structuredClone(updated.definition));
        this.dirty.set(false);
        this.saving.set(false);
      },
      error: err => {
        this.saving.set(false);
        if (err instanceof VersionConflictError) {
          this.conflict.set(err);
        } else {
          this.saveError.set(err?.message || 'Failed to save.');
        }
      },
    });
  }

  /** Discard leaves the canvas entirely, back to the list — unlike the
   *  Document Type editor's Discard, which reverts in place and stays. */
  discard() {
    this.router.navigate(['/workflows']);
  }

  reloadAfterConflict() {
    this.conflict.set(null);
    this.load();
  }

  /** Deploy = save the draft, then create-or-update the real state machine
   *  from what was just saved. Never skips the save step, so "deployed"
   *  and "draft" can never silently drift apart. */
  deploy() {
    const d = this.definition();
    const rec = this.record();
    if (!d || !rec || this.deploying()) return;
    this.deploying.set(true);
    this.deployError.set(null);
    this.deploySuccessMessage.set(null);

    this.configService
      .updateWorkflow(this.workflowId, { definition: d }, rec.version)
      .pipe(
        switchMap(saved => {
          this.record.set(saved);
          this.dirty.set(false);
          return this.configService.deployWorkflow(this.workflowId, saved.version);
        }),
      )
      .subscribe({
        next: result => {
          this.deploying.set(false);
          this.deploySuccessMessage.set(
            `${result.action === 'created' ? 'Created' : 'Updated'} state machine — now at v${result.version}.`,
          );
          this.load(); // refresh to pick up the new stateMachineArn/status/version
        },
        error: err => {
          this.deploying.set(false);
          if (err instanceof VersionConflictError) {
            this.conflict.set(err);
          } else {
            this.deployError.set(err?.message || 'Deploy failed.');
          }
        },
      });
  }

  backToList() {
    this.router.navigate(['/workflows']);
  }
}

function buildStarterState(choice: PaletteChoice, name: string): AslState {
  if (choice === 'choice') {
    return { Type: 'Choice', Choices: [] };
  }
  if (choice === 'lambda-wait-token') {
    return {
      Type: 'Task',
      Resource: 'arn:aws:states:::lambda:invoke.waitForTaskToken',
      Parameters: { FunctionName: '', Payload: { 'taskToken.$': '$$.Task.Token' } },
      TimeoutSeconds: 3600,
      ResultPath: `$.${name}Result`,
    };
  }
  return { Type: 'Task', Resource: '', ResultPath: `$.${name}Result` };
}
