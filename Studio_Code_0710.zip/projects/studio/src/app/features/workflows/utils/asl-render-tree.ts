import { AslChoiceRule, AslState } from '@akrify/shared';

/**
 * One child edge out of a rendered state — a branch label (for Choice) or
 * null (for a plain Next). Carries the child subtree.
 */
export interface RenderChild {
  label: string | null;
  node: RenderNode;
}

/**
 * The result of walking the ASL graph from StartAt. ASL is a DAG, not a
 * strict tree — two branches can converge on the same downstream state
 * (see 'merge' below). This is computed fresh from `states` on every call;
 * it's a pure function of the current definition, nothing is cached or
 * mutated, so there's no risk of a stale tree after an edit.
 */
export type RenderNode =
  | { kind: 'state'; name: string; state: AslState; children: RenderChild[] }
  /** A branch reached a state that's already been rendered elsewhere in
   *  this tree (the convergence case). Render a short stub pointing at it
   *  instead of a duplicate box, and stop — whatever's downstream of the
   *  shared state was already rendered the first time it was reached. */
  | { kind: 'merge'; name: string }
  /** A branch pointed at a state name that doesn't exist in `states` —
   *  shown so a bad edit is visible on the canvas instead of silently
   *  vanishing. */
  | { kind: 'dangling'; name: string }
  /** No outgoing edge (End: true, or Succeed/Fail with nothing after). */
  | { kind: 'terminal' };

/**
 * Walks the ASL graph starting at `startAt`, tracking every state name
 * already rendered in a single Set threaded through the whole walk. The
 * FIRST branch to reach a given state renders it (and everything
 * downstream of it); any LATER branch reaching the same state renders a
 * 'merge' stub and does not re-walk past it.
 *
 * This is the entire convergence-detection algorithm — deliberately kept
 * this simple rather than a full graph-layout/dominance computation, and
 * verified against the reference pipeline's
 * NeedsReviewChoice → ManualReview/Export case: both branches must reach
 * Export, but Export must render exactly once.
 */
export function buildRenderTree(startAt: string, states: Record<string, AslState>): RenderNode {
  const visited = new Set<string>();

  function walk(stateName: string): RenderNode {
    if (visited.has(stateName)) {
      return { kind: 'merge', name: stateName };
    }
    const state = states[stateName];
    if (!state) {
      return { kind: 'dangling', name: stateName };
    }
    visited.add(stateName);

    const children: RenderChild[] = [];

    if (state.Type === 'Choice') {
      for (const rule of state.Choices ?? []) {
        children.push({ label: describeChoiceRule(rule), node: walk(rule.Next) });
      }
      if (state.Default) {
        children.push({ label: 'Default', node: walk(state.Default) });
      }
    } else if (state.Next) {
      children.push({ label: null, node: walk(state.Next) });
    }
    // else: terminal — End: true, or a Succeed/Fail/Task with no Next and no End.

    return { kind: 'state', name: stateName, state, children };
  }

  return walk(startAt);
}

/** Every state name actually reachable from StartAt (used to detect
 *  orphaned states that exist in the map but nothing points to). */
export function reachableStateNames(startAt: string, states: Record<string, AslState>): Set<string> {
  const seen = new Set<string>();
  function walk(name: string) {
    if (seen.has(name) || !states[name]) return;
    seen.add(name);
    const state = states[name];
    if (state.Type === 'Choice') {
      for (const rule of state.Choices ?? []) walk(rule.Next);
      if (state.Default) walk(state.Default);
    } else if (state.Next) {
      walk(state.Next);
    }
  }
  walk(startAt);
  return seen;
}

/** Human-readable label for a Choice branch, e.g.
 *  "$.validationResult.needsManualReview == true". */
export function describeChoiceRule(rule: AslChoiceRule): string {
  if (rule.BooleanEquals !== undefined) return `${rule.Variable} == ${rule.BooleanEquals}`;
  if (rule.StringEquals !== undefined)  return `${rule.Variable} == "${rule.StringEquals}"`;
  if (rule.NumericEquals !== undefined) return `${rule.Variable} == ${rule.NumericEquals}`;
  return rule.Variable;
}

/** Short label shown above a Task state box, matching the AWS Workflow
 *  Studio convention (e.g. "Lambda: Invoke", "Lambda: waitForTaskToken"). */
export function integrationLabel(state: AslState): string {
  if (state.Type !== 'Task') return state.Type;
  const resource = state.Resource ?? '';
  if (resource.includes('waitForTaskToken')) return 'Lambda: waitForTaskToken';
  if (resource.includes('lambda:invoke.sync') || resource.endsWith('.sync')) return 'Lambda: Run a Job (.sync)';
  if (resource.includes(':lambda:')) return 'Lambda: Invoke';
  return 'Task';
}
