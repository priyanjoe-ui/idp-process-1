# idp-api-proxy — Studio additions

This file documents only the **new** work for Akrify Studio. Existing reviewer/runtime routes are unchanged.

## What's new

- `index.js` — modified. `loadConfig()` now reads from DynamoDB (was S3). New Studio endpoints appended.
- `scripts/migrate-config-to-ddb.js` — new. One-shot migration from the S3 config file to DDB.
- `scripts/migrate-workflow-to-ddb.js` — new. One-shot import of an existing, already-deployed Step Functions state machine into DDB (read-only against Step Functions — never modifies the real state machine).
- No new npm dependencies.

## New environment variables

Add these to the Lambda's environment (or export before `node index.js` locally):

| Name | Default | What it is |
|---|---|---|
| `IDP_CONFIG_TABLE` | `idp-config` | DynamoDB table holding Studio config |
| `IDP_CONFIG_TYPE_INDEX` | `type-lastModifiedAt-index` | GSI name on that table |
| `STUDIO_USER` | `studio-admin` | Stubbed identity for `lastModifiedBy`. Replace with JWT claim later. |
| `WORKFLOW_ROLE_ARN` | `arn:aws:iam::651720177345:role/LambdaExecutionRole` | Reused for `CreateStateMachine`'s `roleArn`. **Must already exist and already trust `states.amazonaws.com`** — the account's IAM boundary policy denies `iam:CreateRole`, so this Lambda never creates a role. |

The existing `DOCS_BUCKET` and `CONFIG_KEY` env vars are no longer read by `loadConfig()`, but stay in place — the migration script uses them if you don't override in the script's CONFIG block.

## Step 1 — Create the DynamoDB table

Console → DynamoDB → **Create table**:

- **Table name:** `idp-config`
- **Partition key:** `PK` (String)
- **Sort key:** `SK` (String)
- **Capacity:** On-demand (recommended)

Then **Indexes → Create index**:

- **Index name:** `type-lastModifiedAt-index`
- **Partition key:** `type` (String)
- **Sort key:** `lastModifiedAt` (String)
- **Projected attributes:** All

Wait until the GSI status is **Active** before running the migration.

## Step 2 — Grant the proxy Lambda access to the new table

Console → Lambda → your proxy function → **Configuration → Permissions** → click the execution role → **Add permissions → Attach inline policy**. Paste this (replace the account ID + region):

```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Action": [
      "dynamodb:GetItem",
      "dynamodb:PutItem",
      "dynamodb:UpdateItem",
      "dynamodb:DeleteItem",
      "dynamodb:Query"
    ],
    "Resource": [
      "arn:aws:dynamodb:<region>:<account-id>:table/idp-config",
      "arn:aws:dynamodb:<region>:<account-id>:table/idp-config/index/*"
    ]
  }]
}
```

## Step 3 — Run the migration

From CloudShell (or anywhere with AWS creds):

```bash
# Pull the code down and install deps
git clone <repo>            # or upload the folder
cd idp-api-proxy
npm install

# Open scripts/migrate-config-to-ddb.js, fill in the CONFIG block:
#   S3_BUCKET   (bucket holding your current document-config.json)
#   S3_KEY      (key of that file)
#   TABLE       (defaults to 'idp-config')
#   AWS_REGION  (defaults to 'us-east-1')

# Dry run first — no writes, just shows what would happen
node scripts/migrate-config-to-ddb.js --dry-run

# Real run
node scripts/migrate-config-to-ddb.js

# If you need to re-run and overwrite existing rows:
node scripts/migrate-config-to-ddb.js --force
```

Expected output for the AFLCOR sample:
```
[AFLCOR]
  wrote      APP  meta   PK=APP#AFLCOR  SK=META
  wrote      DT   row    PK=APP#AFLCOR  SK=DT#CORRDOC

Dictionaries: 1
  wrote      DICT row    PK=DICT        SK=TransCodes
```

## Step 3b — Import an existing, already-deployed state machine (optional)

If you already have a real Step Functions state machine running for an application (e.g. an existing `idp-ingestion` pipeline), bring it into Studio's Jobs & Workflow Builder with `migrate-workflow-to-ddb.js`. This is read-only against Step Functions — it only calls `DescribeStateMachine`, never `CreateStateMachine`/`UpdateStateMachine`, so it cannot affect the real running pipeline.

```bash
# Open scripts/migrate-workflow-to-ddb.js, fill in the CONFIG block:
#   STATE_MACHINE_ARN  (the existing state machine to import)
#   APP_ID             (must already exist as an Application in Studio, e.g. 'AFLCOR')
#   WORKFLOW_ID        (uppercase alphanumerics/underscores — becomes the Studio workflow ID)
#   NAME               (display name shown in Studio)
#   TABLE, AWS_REGION  (defaults: 'idp-config', 'us-east-2')

# Dry run first — shows what would be written, including the full definition pulled from AWS
node scripts/migrate-workflow-to-ddb.js --dry-run

# Real run
node scripts/migrate-workflow-to-ddb.js
```

The imported workflow lands with `status: 'deployed'` and its real `stateMachineArn` already set — Studio treats it exactly as if it had been deployed from the canvas. Opening it will render your actual current pipeline, which doubles as a good real-world check of the canvas's convergence-detection logic against a real branching pipeline rather than just the reference example.

Run this again later with different `CONFIG` values to bring in additional existing pipelines as you onboard more applications — same script, one state machine at a time.

## Step 4 — Deploy the updated Lambda

Standard flow — zip the folder, upload to the Lambda:

```bash
zip -r lambda-deployment.zip . \
  -x '*.git*' -x 'lambda-deployment.zip' -x '*.md' -x 'scripts/*'
```

Upload via Console: Lambda → your proxy function → **Code source → Upload from → .zip file**.

The migration script is intentionally excluded from the deploy zip — it's a one-shot admin tool, not runtime code.

## Step 5 — Verify

```bash
# Existing reviewer endpoint — should still return the nested config,
# now assembled from DDB instead of loaded from S3.
curl https://<function-url>/api/applications

# New Studio endpoint — should return the flat summary list.
curl https://<function-url>/api/applications/summary
```

If both return sensible data, you're done. Reviewer app keeps working with no code changes on its side; Studio can now read and write against the same source of truth.

## API additions — quick reference

Every write endpoint uses **optimistic concurrency** via the `X-Expected-Version` header. On version mismatch, response is `409 VersionConflict` with the current version in the body.

**Applications**
```
GET    /api/applications                          (existing — reviewer runtime read, now DDB-backed)
GET    /api/applications/summary                  (new — Studio list)
GET    /api/applications/:appId                   (new — one app + its doc type summaries)
POST   /api/applications                          (new)
PUT    /api/applications/:appId                   (new)  X-Expected-Version required
DELETE /api/applications/:appId                   (new — cascade to doc types)
```

**Document Types**
```
GET    /api/document-types                                    (new — global list, uses GSI)
GET    /api/applications/:appId/document-types                (new)
GET    /api/applications/:appId/document-types/:docTypeId     (new)
POST   /api/applications/:appId/document-types                (new)
PUT    /api/applications/:appId/document-types/:docTypeId     (new)  X-Expected-Version required
DELETE /api/applications/:appId/document-types/:docTypeId     (new)
```

**Dictionaries**
```
GET    /api/dictionaries                          (new)
GET    /api/dictionaries/:name                    (new)
PUT    /api/dictionaries/:name                    (new — creates if missing; X-Expected-Version required for updates)
```

**Workflows (Jobs & Workflow Builder)**
```
GET    /api/applications/:appId/workflows                               (new)
GET    /api/workflows                                                   (new — global list, uses GSI)
GET    /api/applications/:appId/workflows/:workflowId                   (new)
POST   /api/applications/:appId/workflows                               (new)
PUT    /api/applications/:appId/workflows/:workflowId                   (new — SAVE DRAFT ONLY, never calls Step Functions)  X-Expected-Version required
DELETE /api/applications/:appId/workflows/:workflowId                   (new — Studio record only; does NOT delete the real state machine)
POST   /api/applications/:appId/workflows/:workflowId/deploy            (new — the only route that calls Step Functions)  X-Expected-Version required
```

## Step 6 — IAM setup for Workflow deploys

The Deploy endpoint calls `CreateStateMachine`/`UpdateStateMachine`. Two things to verify before it'll work:

1. **The proxy Lambda's own execution role** needs permission to call Step Functions:
   ```json
   {
     "Effect": "Allow",
     "Action": ["states:CreateStateMachine", "states:UpdateStateMachine", "states:DescribeStateMachine"],
     "Resource": "arn:aws:states:us-east-2:651720177345:stateMachine:*"
   }
   ```
   Add this as another statement in the same inline policy from Step 2, or a new one on the same role.

2. **`WORKFLOW_ROLE_ARN`** (the role state machines will assume at runtime — separate from the proxy Lambda's own role) must:
   - Already exist — this Lambda never calls `iam:CreateRole` (the account's boundary policy denies it)
   - Have a trust policy that allows `states.amazonaws.com` to assume it
   - Not be blocked by the boundary policy on `iam:PassRole` — if Deploy fails with an IAM error, run `aws iam simulate-principal-policy` against the proxy Lambda's role for the `iam:PassRole` action on `WORKFLOW_ROLE_ARN` to confirm before digging further.

   Default value points at `arn:aws:iam::651720177345:role/LambdaExecutionRole` — the same role the existing `idp-ingestion` pipeline already uses. Override via the `WORKFLOW_ROLE_ARN` env var if a different role should be used.

## Rollback

If something goes wrong, the S3 `document-config.json` is still there and unchanged. To revert:

1. Restore the old `loadConfig()` in `index.js` (the S3 version — see git history).
2. Re-deploy the Lambda.

Reviewer app returns to reading from S3. The `idp-config` DDB table can stay in place for the next attempt.
