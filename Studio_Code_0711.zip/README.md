# Akrify Studio

Workflow designer for the IDP platform. Analogous to IBM Datacap Studio, but native to AWS + Bedrock.

Studio produces configuration; the runtime IDP pipeline consumes it. Same JSON schema on both sides.

## Repo layout

```
akrify-studio/
├── projects/
│   ├── studio/          # Studio Angular app
│   └── shared/          # Shared lib: domain models
├── angular.json         # Multi-project workspace
├── tsconfig.json        # Path map so studio consumes @akrify/shared by source
└── package.json
```

## Getting started

```bash
npm install
npm run start           # ng serve on :4300 (dev environment)
```

Open http://localhost:4300 — lands on the Dashboard.

## Environments

One Angular build per environment; each deploys as its own stack. No cross-environment access from the browser.

```bash
npm run build:dev       # dev  build (default when serving)
npm run build:qa        # qa   build → environment.qa.ts
npm run build:prod      # prod build → environment.prod.ts
```

The topbar shows an environment chip driven by `environment.envLabel`:
- **dev** — neutral grey
- **qa** — amber, with a thin amber strip across the top of the app
- **prod** — red, with a red strip across the top

The strip is intentional visual friction: if you're about to change something in prod, you should see red before you click save.

## Data model (DynamoDB, one table per environment)

No `tenantId` — one stack per environment means "the environment" is implicit in which stack you hit.

```
Main table (e.g. IDP_Config_dev, IDP_Config_qa, IDP_Config_prod):

  PK                 SK              Row shape                  type
  ─────────────────  ──────────────  ─────────────────────────  ───────────
  "APP#LOANS"        "META"          ApplicationRecord          APPLICATION
  "APP#LOANS"        "DT#LOAN_APP"   DocumentTypeRecord         DOC_TYPE
  "APP#LOANS"        "DT#ID_PROOF"   DocumentTypeRecord         DOC_TYPE
  "APP#CLAIMS"       "META"          ApplicationRecord          APPLICATION
  "APP#CLAIMS"       "DT#CLAIM_FORM" DocumentTypeRecord         DOC_TYPE
  "DICT"             "TransCodes"    DictionaryRecord           DICTIONARY

GSI 1: type-lastModifiedAt-index
  PK: type              → "APPLICATION" | "DOC_TYPE" | "DICTIONARY"
  SK: lastModifiedAt

  Used by:
    - listApplications()       → Query type = "APPLICATION"
    - listAllDocumentTypes()   → Query type = "DOC_TYPE"
```

**Row envelope** — every row carries:
- `type` (feeds the GSI)
- `version` (integer, incremented per save)
- `lastModifiedAt` (ISO timestamp)
- `lastModifiedBy` (server-populated from JWT claim; stubbed as `"studio-admin"` today)

**Optimistic concurrency** — every `PUT` includes an `expectedVersion`. Backend uses
`ConditionExpression: "version = :expected"`. On mismatch, backend returns 409;
Studio surfaces "This was modified by someone else — reload."

Single source of truth. No draft/publish separation. Whoever saves last wins,
protected against silent overwrites by the version check.

## Studio hierarchy

The UI mirrors the data model:

```
Applications              /applications              Card grid
  └─ Document Types       /applications/:appId/document-types   Table
       └─ Editor          /applications/:appId/document-types/:id   (next round)
```

A **global** doc-types view lives at `/document-types` — reads via the GSI so it doesn't Scan.
Useful for search across applications.

## Backend integration

Applications endpoints are wired to the `idp-api-proxy` Lambda (Node.js/Express). Point `apiBaseUrl` in `environment.ts` at the proxy — locally `http://localhost:3001/api`, deployed `https://<function-url>/api`.

See `idp-api-proxy/STUDIO-SETUP.md` for the full backend setup: creating the `idp-config` DynamoDB table, IAM policy for the Lambda, and running the one-shot migration script that seeds DDB from the existing S3 `document-config.json`.

**What's live vs. mocked in the frontend:**

| Section | Frontend | Backend |
|---|---|---|
| Applications CRUD | ✅ Live HTTP | ✅ Live |
| Document Types CRUD | ✅ Live HTTP | ✅ Live |
| Document Type editor — Pages tab | ✅ Live (Sequential/Keyword/WordCount identification, drag-drop reorder) | ✅ Live (via update endpoint) |
| Document Type editor — Fields tab (incl. Validation) | ✅ Live (Anchor/Position/Regex/AI extraction methods; Format/Range validation) | ✅ Live (via update endpoint) |
| Document Type editor — Classification | ✅ Live | ✅ Live (via update endpoint) |
| Document Type editor — Indexer UI | 🟡 Placeholder panel | ✅ Backend supports arbitrary body; UI not built |
| Dictionaries | ✅ Live HTTP | ✅ Live |
| Dashboard | ✅ Live — reuses the reviewer app's existing `GET /api/dashboard` (queries `idp-batch-tracking` directly) | ✅ Already existed; no changes needed |

Nothing in the frontend is mocked anymore. The Dashboard deserves a callout: it doesn't have its own backend — it calls the same `/api/dashboard` endpoint the reviewer app's Job Monitor tab already uses, scoped to the last 7 days. Fields with no real data source yet (day-over-day trend, active indexer count, avg processing time, activity feed, service health) show honest "not available yet" placeholders rather than fabricated numbers. See `DashboardService` for the exact mapping and `DashboardKpis`/`DashboardSnapshot` in `@akrify/shared` for which fields are nullable as a result.

## Screens

| Screen | Route | Status |
|---|---|---|
| Dashboard | `/dashboard` | ✅ Live — real KPIs/chart/status breakdown; trend/activity/health sections are labeled placeholders |
| Applications | `/applications` | ✅ Card grid, search, create, **cascading delete (typed confirm)** |
| Document Types (per app) | `/applications/:appId/document-types` | ✅ Table, search, tabs, sort, pagination, breadcrumb |
| Document Types (global) | `/document-types` | ✅ Same table, adds Application column |
| Document Type editor | `/applications/:appId/document-types/:id` | ✅ Shell + Pages/Fields (incl. Validation)/Classification tabs live, delete option; Indexer UI still a placeholder (Preview dropped, Validation folded into Fields) |
| Dictionaries | `/dictionaries` | ✅ List + editor, live HTTP |
| Jobs & Workflows | `/workflows` (single list, no scoping), `/workflows/:workflowId` (canvas) | ✅ Live — list + full visual builder (see below) |
| Connectors | `/connectors` | 🟡 Stub |
| Test Bench | `/test-bench` | 🟡 Stub |
| Deployments | `/deployments` | 🟡 Stub |
| Users & Access | `/users` | 🟡 Stub |
| Settings | `/settings` | 🟡 Stub |

## Backend contract

Every method on `StudioConfigService` maps 1:1 to a REST endpoint. The mock service simulates the wire behavior (delays, version conflicts, cascades) so components exercise the same code paths they will in production.

```
Applications
  GET    /applications                                        -> ApplicationSummary[]
  GET    /applications/:appId                                 -> ApplicationRecord
  POST   /applications                                        -> ApplicationRecord
  PUT    /applications/:appId                                 -> ApplicationRecord
  DELETE /applications/:appId                                 -> 204

Document Types
  GET    /applications/:appId/document-types                  -> DocumentTypeSummary[]
  GET    /document-types                                      -> DocumentTypeSummary[]   (GSI)
  GET    /applications/:appId/document-types/:docTypeId       -> DocumentTypeRecord
  POST   /applications/:appId/document-types                  -> DocumentTypeRecord
  PUT    /applications/:appId/document-types/:docTypeId       -> DocumentTypeRecord
  DELETE /applications/:appId/document-types/:docTypeId       -> 204

Dictionaries
  GET    /dictionaries                                        -> DictionaryRecord[]
  GET    /dictionaries/:name                                  -> DictionaryRecord
  PUT    /dictionaries/:name                                  -> DictionaryRecord

All PUT and DELETE requests carry an X-Expected-Version header. Backend enforces
via DynamoDB ConditionExpression.
```

## Design decisions locked in this round

- **Separate Angular app**, shared lib for domain models. Two personas, two apps, one schema.
- **DynamoDB single-state** — no draft/publish separation. Optimistic concurrency (`expectedVersion`) prevents silent overwrites.
- **Applications are visible in the UI** as a top-level workspace. Doc types nest under them.
- **One AWS stack per environment.** Environment shown as a chip + top strip in the UI; not selectable at runtime.
- **`lastModifiedBy` is server-populated** from JWT claims. UI never sends it. Stubbed as `"studio-admin"` until auth wires in.
- **Creation flows are modals, not pages** — both "New Application" and "New Document Type" are small, focused forms. Real configuration happens in the editor, not the creation form.
- **"New Document Type" only appears in the scoped list** (`/applications/:appId/document-types`), not the global cross-app list. Creating a doc type requires knowing which application it belongs to.
- **Field mutations happen in place** on the editor's local draft copy (`structuredClone` of the loaded body). Both the Fields and Pages tabs receive their slice of the tree by reference and mutate it directly, emitting a `changed` event so the shell tracks a dirty flag — avoids re-serializing the whole tree on every keystroke.
- **Position extraction method** required adding a `FieldPosition` type (`Page`, `X`, `Y`, `Width`, `Height`) to the shared model — additive and optional, existing configs unaffected.
- **Application creation is minimal by design** — just App ID and Display Name. Classification Mode defaults server-side to `Sequential`; there's no UI to change it post-creation yet (not requested — would need an Application settings surface if that becomes necessary).
- **`BlankPageMaxWordCount` moved from Application to Page Type.** The original runtime schema had this as an app-wide setting; it's now `MaxWordCount` on a page type using the `WordCount` identification method (typically the `BlankPage` type). **This is a breaking change from the original schema** — if any runtime Lambda reads `Applications[i].BlankPageMaxWordCount` from the config API, it will no longer find it there. The migration script warns (doesn't silently drop) when source data has this field, so it can be manually re-applied per Document Type after migration.
- **Page Type identification methods**: `Sequential` (position-based, set by drag order), `Keyword` (matches text on the page), `WordCount` (page has fewer than N words — the blank-page case). Every new Document Type is scaffolded with `MainPage` (Sequential) and `BlankPage` (WordCount, threshold 5) by default.
- **Page reordering uses Angular CDK drag-and-drop** (`@angular/cdk`, new dependency — run `npm install` after pulling this update). Dragging a row updates every page type's `SequenceOrder` to match its new position.
- **Deleting an Application requires typing its ID to confirm** — this cascades to every Document Type underneath it, so a plain Yes/No dialog isn't enough friction for an unrecoverable action. Deleting a single Page Type (non-cascading, much smaller blast radius) uses a lighter inline Confirm/Cancel instead.
- **New Document Types land on the Pages tab**, not Fields — via a `?tab=pages` query param set only by the creation flow. Opening an existing Document Type from a list row still defaults to Fields, since page structure is presumably already set up.

## What's next

Fields, Pages, Classification, Dictionaries, Dashboard, and now Jobs & Workflows are all live. Preview was dropped from the Document Type editor's tab list entirely (rather than kept as a placeholder) — it needs a real document + live extraction run, which converges with Test Bench, so it'll be built there instead of twice. Validation was redesigned away from being its own tab (see below). Indexer UI is still a placeholder tab; see the design notes for what it'll do. Connectors, Test Bench, Deployments, Users & Access, Settings are all still stubs.

### Jobs & Workflow Builder — live, visual Step Functions editor

**Canvas visual/interaction polish** (against the real AWS Workflow Studio reference): real SVG connector lines with arrowheads instead of plain colored divs, a redesigned left palette (search box, grouped "Actions"/"Flow" sections, icon + label + hint per row, matching AWS's own layout), and drag-and-drop insertion — drag a palette item straight onto any connector instead of only click-to-open-a-popup.

- **Shared palette data** (`utils/palette-options.ts`) — the click-popup and the draggable sidebar read from the exact same option list (icons, labels, hints, category), so they can't drift out of sync with each other.
- **Both insertion methods stay, deliberately** — click-the-"+"-then-pick and drag-from-sidebar both call the same `insertNewState()` in the canvas component. Kept both rather than replacing click with drag-only: drag-and-drop is less discoverable and doesn't work well for keyboard-only use, so the click flow stays as a reliable fallback alongside the new primary interaction.
- **Drop targets, not a reorderable list** — every connector became a CDK `cdkDropList` accepting drags from the palette's `cdkDrag` items, connected via one `cdkDropListGroup` wrapping the whole builder (palette + canvas), which Angular resolves correctly across the recursive `StateNodeComponent` tree even though each drop zone lives in a different, deeply-nested component instance. Each connector's list has zero real items in it — it's a pure drop *target*, not something being reordered — so `cdkDropListDropped`'s `previousIndex`/`currentIndex` are ignored entirely; only `event.item.data` (which palette choice) and the connector's own known `InsertionPoint` context matter.
- **Fixed a real gap along the way**: the very first connector (between the Start circle and the first state) never had a "+" button at all in the original build — only connectors *between* states did. Now has both a working "+" and a drop target, consistent with every other connector.
- **Connector arrow SVG is duplicated across `StateNodeComponent` and `WorkflowCanvasComponent`, not shared via a component.** Both files draw the identical small arrow (a line + triangular arrowhead) — with only two usage sites and no dynamic per-instance data needed, a shared component felt like more machinery than the markup justified, matching the project's existing bias toward duplicating small, stable snippets over forcing an abstraction (see Fields/Pages tabs' tag-list patterns).
- **Choice fan-out connector, fixed after initial review** — the individual branch connectors got the arrowhead treatment, but the point where they actually split off from the Choice box was missed the first time: branches sat side-by-side with a gap and no line tying them back to the box above, so the Default branch in particular looked orphaned. Fixed CSS-only, no JS pixel measurement — each branch draws its own left/right half of the horizontal bar relative to its own box width (the classic "org-chart connector" technique), so it's correct for any number of branches, and for branches of different widths, without needing to know exact pixel positions. A single-branch Choice correctly collapses to one straight line (both the "first child" and "last child" rules hide their line simultaneously, since there's nothing beside it to connect to).
- **A second gap found on real review, not guesswork** — even after the fan-out fix, the branch condition label (`$.foo == true`) had its own `margin-bottom`, leaving a literal few-pixel stretch with nothing drawn between the pill and the connector below it. Confirmed by grepping the actual CSS rather than assuming, then removed — the connector's own line already starts at the very top of its box, so it now sits flush against the label with zero gap.
- **Real merge lines, not a text stub** — "merges into X" was an honest v1 simplification (drawing an actual connecting line to a box that might be rendered anywhere else on the canvas needs to know that box's real on-screen position, which pure CSS/flexbox can't provide). Rather than adding runtime DOM measurement (`getBoundingClientRect` + a recomputed SVG overlay, kept in sync on every layout change — a fragile, much bigger architectural addition), solved it by extending the render-tree algorithm itself: `buildRenderTree()` now detects when a Choice's own branches share a common downstream state and restructures the tree around it — a new `choice-join` node kind carries each branch's private prefix states plus the single shared state (`joined`), rendered once, positioned below all branches. Same reliable pure-CSS/flexbox approach as the rest of the canvas, no measurement needed. **Verified against the real compiled algorithm, not a re-implementation**, for two cases: the reference pipeline's `NeedsReviewChoice → ManualReview/Export` (produces a real `choice-join`, `Export` rendered once, `ManualReview` branch gets a 1-item prefix, `Default` branch gets an empty prefix) and a genuinely-divergent two-branch Choice (correctly stays a plain `state` node, no false-positive join).
  - **Branches of different lengths reach the fan-in bar at the same height via a flexbox-stretched filler line, not invisible spacer boxes.** First attempt used invisible spacer slots shaped like real prefix items (`visibility: hidden` boxes matching real content's dimensions) — this got the *height* right but left a real, visible break in the shorter branch's line, since nothing was drawn through the hidden spacer's space. Fixed by giving `.branches.fan-in` `align-items: stretch` (so every branch column shares the same real height, driven by actual content) and adding one `.branch-filler` element per branch with `flex: 1` — the browser's own layout engine computes exactly how much the filler needs to grow (zero for whichever branch is tallest, more for shorter ones), and it's a real visible line the whole way, not padding with a gap in it.
  - **Scoped deliberately, not attempting full generality**: join detection requires ALL of a Choice's branches to converge at the same point (partial convergence falls back to the old merge-stub) and each branch's prefix must be a simple linear chain (a nested Choice partway down a branch isn't unified into the outer fan-in). Both are honest, stated limits — real convergence patterns outside this scope still render correctly via the original merge-stub, just without the fuller visual treatment.

The core design decision: **the canvas's data model IS Amazon States Language, directly** — no custom graph schema that gets translated into ASL later. What you edit on the canvas is exactly what gets sent to `CreateStateMachine`/`UpdateStateMachine` on Deploy. This mirrors how AWS's own Step Functions Workflow Studio works.

**Data model** (`@akrify/shared/asl.model.ts`) — `AslState`, `AslDefinition`, `AslChoiceRule`, `AslRetry`, `AslCatch` mirror ASL's real JSON shape field-for-field. Scoped initially to `Task` and `Choice` (what the IDP pipeline actually uses); other types (`Wait`, `Parallel`, `Map`, `Succeed`, `Fail`) are typed for forward compatibility and render correctly if present, but aren't yet editable in the inspector.

**Convergence detection** — ASL is a DAG, not a strict tree: two Choice branches can point at the same downstream state (e.g. a `ManualReview` path and a `Default` path both eventually reaching `Export`). `buildRenderTree()` (`utils/asl-render-tree.ts`) tracks every state name rendered in a single `Set` threaded through the walk; the first branch to reach a shared state renders it in full, any later branch renders a short "merges into `X`" stub instead of a duplicate box. This was verified by actually running the algorithm (not just reading it) against the reference pipeline's `NeedsReviewChoice → ManualReview/Export` case before building anything on top of it — `Export` renders exactly once. Also since re-verified against a real imported production pipeline (see "Workflows are shared" below), not just the reference fixture.

**Rendering** — `StateNodeComponent` is a purely presentational, self-referencing recursive standalone component. All graph-walking already happened in `buildRenderTree()`; this component just draws whatever `RenderNode` it's handed and recurses into `children`. Deliberately recomputed on every change-detection cycle rather than cached behind a `computed()` signal — the definition is mutated in place (same pattern as the Document Type editor), so there's no signal-reference change to key a memoized computation off of, and workflow graphs are small enough that this is cheap.

**Add-state interaction** — a "+" button on every connector (including each Choice branch) opens a small popup via Angular CDK Overlay, anchored to the clicked button. Picking a type calls `insertState()` (`utils/asl-graph-edit.ts`), which splices the new state into the `States` map and rewires whatever pointer (`Next`, a specific `Choices[i].Next`, or `Default`) the connector represented, preserving the rest of the chain.

**CDK Overlay CSS is inlined, not loaded from `node_modules`.** Originally referenced `node_modules/@angular/cdk/overlay-prebuilt.css` from `angular.json`'s `styles` array — this built without error but the popup's *positioning* rules weren't reliably ending up in the bundle (the popup's own content rendered fine — its component styles are self-contained — but it landed in normal document flow at the bottom of the page instead of anchored near the "+" button, since the base `.cdk-overlay-container { position: fixed; ... }` rule wasn't applying). Fixed by copying the small, stable set of overlay positioning rules directly into `styles.scss` instead of depending on that path resolving correctly at build time. Drag-drop (used in Pages tab) never needed this — only Overlay's positioning CSS was the gap.

**Inspector** (right panel) — form fields conditional on the selected state's `Type`. For Task states, an "Integration Pattern" selector (Request Response / Wait for Task Token / Run a Job) does more than toggle a flag — `Resource` and `Parameters` are structurally different per pattern (e.g. Wait for Task Token wraps the function ARN inside `Parameters.FunctionName` with a `taskToken.$` in the payload, rather than `Resource` being the function ARN directly), so switching patterns actively rewrites the state's shape via `applyIntegrationPattern()` (`utils/asl-task-integration.ts`). Retry/Catch rules use a comma-separated `ErrorEquals` text field rather than a full tag-pill UI — a deliberate simplification given these lists are typically short. Parameters has a raw JSON textarea as an escape hatch for anything the structured fields don't cover, matching the brief's "acceptable for v1."

**Workflows are shared, independent entities — not owned by one Application.** This was a real redesign after the first pass: originally a workflow lived *inside* an Application (`PK: APP#<appId>, SK: WORKFLOW#<id>`), with a scoped list (`/applications/:appId/workflows`) alongside a separate global list. Rebuilt so a workflow can be mapped to **any number** of Applications, editable after creation (not fixed at creation time):

- **Storage**: flat partition, same pattern Dictionaries already use — `PK: 'WORKFLOW'`, `SK: <workflowId>`, plus a `mappedApplicationIds: string[]` field. Listing every workflow is a plain `Query PK = 'WORKFLOW'` — no GSI needed at all for this, simpler than before.
- **Routes**: flat — `/workflows` (the only list, no scoped variant) and `/workflows/:workflowId` (canvas). The list's "Applications" column shows every mapped app as its own tag, resolved from name via a client-side lookup against the Applications list (falls back to showing the raw id if an app was deleted after mapping, rather than silently dropping it).
- **Creating** a workflow includes an optional multi-select checklist of Applications (`New Workflow` modal) — mapping isn't required at creation, can be added later.
- **Editing the mapping later** — a "Manage Applications" modal, reachable from the canvas header. This is a separate save path from the definition's Save/Discard/Deploy flow: mapping is plain metadata, saves immediately on its own `PUT`, no draft concept (matching how Applications/Document Types work, not the draft/deployed model the *definition* itself uses).
- **Deleting an Application** doesn't delete workflows mapped to it — it strips that Application's id out of every workflow's `mappedApplicationIds` (best-effort, non-fatal if a rare concurrent edit conflicts with the cleanup) so nothing dangling is left behind, since other Applications may still be using the same workflow.
- State machine naming lost its app prefix accordingly: `idp-<workflowId>` instead of `idp-<appId>-<workflowId>`.

**Data model — one row per workflow, not two.** The original brief proposed separate draft/production rows (`#draft` / `#v<n>`). Built it simpler: **one row**, with a `status` field (`draft` | `deployed`) and an optional `stateMachineArn`. `definition` *is* the draft — there's no separate frozen "production" copy to keep in sync, since the real running definition lives in Step Functions itself, not duplicated in DynamoDB. This still gets the safety property that mattered (`PUT` — Save — never touches Step Functions; only `POST .../deploy` does) with less mechanism than maintaining two rows.

**Deploy** = save the draft, then create-or-update the real state machine from what was just saved — never skips the save step, so "deployed" and "draft" can't silently drift apart. Uses `WORKFLOW_ROLE_ARN` (defaults to `arn:aws:iam::651720177345:role/LambdaExecutionRole`) — an **existing** role, reused as-is. The account's IAM boundary policy denies `iam:CreateRole`; this Lambda never attempts to create one.

**Discard navigates back to the list**, unlike the Document Type editor's Discard (which reverts in place and stays on the page) — a deliberate difference, since this screen's canvas is heavier and "start over from the list" was the requested behavior here specifically.

**Deleting a workflow in Studio does not delete the real state machine.** If a workflow has been deployed, removing its Studio record only makes Studio forget about it — the actual Step Functions state machine keeps running and processing documents until separately stopped/deleted in the AWS Console. The delete confirmation modal says this explicitly.

**Importing an existing, already-deployed state machine** — `scripts/migrate-workflow-to-ddb.js` (same CONFIG-block-then-run pattern as `migrate-config-to-ddb.js`). Read-only against Step Functions (`DescribeStateMachine` only, never `Create`/`UpdateStateMachine`), so it can't affect a real running pipeline. Pulls whatever is *actually* deployed right now rather than a stale copy from a design doc, and lands with `status: 'deployed'` and the real `stateMachineArn` already set, plus whichever Applications you list in `CONFIG.APP_IDS` (can be empty, mapped later via Manage Applications). See `STUDIO-SETUP.md` for the full run instructions.

**Deferred, deliberately** — per the person's call, the multi-application *ingestion* architecture (how files landing in different S3 prefixes get routed to the right state machine) wasn't decided yet; that's Connectors + an `idp-ingestion` Lambda update, revisited after the canvas itself was in hand. Nothing in this build blocks on that decision — each workflow's own identity (and its mapping to Applications) is already fully independent of however ingestion ends up routing to it.

**Also deferred, from the same AWS-parity discussion** — the toolbar (Undo/Redo/Zoom/Center/Duplicate), a raw-JSON "Code" mode alongside the visual canvas, and dragging an *existing* state to a different position in the graph (as opposed to inserting a *new* one, which is done). Undo/Redo needs a real definition-snapshot history stack — nothing like that exists yet. Reordering an existing state is the most DAG-edge-case-prone of the three (a moved Choice state's own branches, anything still pointing at it via `Catch`, etc.) and was intentionally left for last for that reason. Zoom/Center and Duplicate are comparatively cheap once picked back up — the layout is pure CSS/flexbox, not absolute-positioned, so zoom is just a `transform: scale()` on the canvas container.

### Line Items — live, configured from the Fields tab

Line Items already existed in the shared model (`ConfigLineItems`/`ConfigLineItemColumn`) but had never been surfaced in any Studio screen. Checked the real migrated `document-config.json` before building: one real example, `CORRDOC`'s `MainPage`, a 16-column table (`Name: "lineitem"`) where every column uses just `FieldName`/`Label`/`DataType`/`Required`, occasionally `OptionsRef` for a Dictionary reference — no extraction method, no validation config on any column. That shaped the design:

- **`LineItem` is a selectable Data Type on a field**, not a separate screen. Setting a field's Data Type to `LineItem` converts it into an entry in the page's Line Items array — removed from `Fields[]`, added to `LineItems[]` — matching how the real runtime schema actually separates the two. Loading an existing page with a Line Items table works automatically through the same code path: it's just data, no special-cased "migration" logic needed in the UI.
- **A page can have any number of Line Items tables** — no cap, no "one per page" restriction. Each shows as its own entry in the field list, individually selectable.
- **Columns are deliberately simpler than top-level fields** — Field Name, Label, Data Type, Required, and a Dictionary picker when Data Type is Dropdown. No extraction method or validation config per column, matching what the real data actually uses (a Line Items table is a repeating grid, almost certainly populated via Textract table detection, not per-field regex/anchor/AI extraction). The model doesn't restrict this — `ConfigLineItemColumn extends ConfigField` — so more could be exposed later if a real need shows up.
- **Rows aren't configured in Studio** — they're populated at runtime from the extracted table. Studio only defines the column schema.
- Columns are drag-reorderable (same CDK pattern as Pages).

**Model change**: `ConfigPageType.LineItems` changed from a single object to an array (`ConfigLineItems[]`). This is a real wire-format change worth knowing about:

- **Migration script** (`migrate-config-to-ddb.js`) now wraps the old single-object shape into a 1-element array when reading from S3, so existing data (like `CORRDOC`) loads into Studio with nothing lost or duplicated — same table, same 16 columns, just in the new container shape.
- **`GET /api/applications`** (the endpoint the reviewer app calls) now returns `lineItems` as an array instead of a single object or `null`. If the reviewer app (`idp-ui`, a separate project) has any code today that reads `pageType.lineItems.columns` directly, it will need updating to iterate the array instead — flagging this the same way as other reviewer-app-adjacent changes in this project, since it's out of scope for Studio itself but worth knowing before deploying.

### Recent fixes

- **Pages is now the default landing tab** for the editor, regardless of entry point (previously only true for freshly-created Document Types via a query param; now true everywhere, matching what actually made sense given Fields depends on Pages).
- **Adding a page type in the Pages tab now auto-selects it for the Fields tab too** — previously the newly added page was technically present as a pill in Fields but easy to miss, since Fields' selection state wasn't synced to Pages' add action (only rename/remove were). A defensive `ensureValidSelectedPageType()` check also runs after every load/save/discard so the selection can never point at a page type that no longer exists.
- **Document Type delete** — a Delete button in the editor header opens a confirm modal (single-entity delete, no cascade across other entities, so no typed confirmation required — unlike Application delete).
- **Dropdown fields can now reference a Dictionary** — when a field's Data Type is set to Dropdown, the inspector shows a Dictionary picker bound to the field's existing `OptionsRef` property, populated from whatever's been created on the Dictionaries screen.
- **Classification tab is live** — document-type-level keyword set + confidence threshold, deciding which document type a batch belongs to (distinct from Pages' per-page-type identification). Along the way, removed `ClassificationKeywords` from `ConfigPageType` — confirmed as legacy duplication from the original schema, never wired to any logic, so it was dead weight rather than a real second concept.

### Connectors — rebuilt to match a wireframe that existed the whole time

**A real mistake, worth documenting plainly rather than glossing over.** The first pass at this screen was built entirely from my own judgment — a per-Application editor, reached by clicking into an app first — while an actual wireframe deck (`CapturePlatform_Studio_Wireframes.pptx`, uploaded at the very start of this whole engagement) had a specific design for this exact screen that was never opened or checked. The person caught this directly, and rightly: "never do anything on your own without confirmation" had already been said once before in this project, and it applied here too. Read the wireframe properly this time — both the extracted text and a full-resolution render of the actual slide — before rebuilding anything.

**What the wireframe actually shows**: Connectors as a top-level screen (sidebar → straight there, same as Dashboard or Workflows, no application picker in between), three tabs (`Ingestion`, `Export`, `Custom SDK` — scoped down to just the first two per the person's instruction), a left list of connector cards (icon, name, status badge, one-line summary), and a right inspector panel that appears *only* when a card is selected — Test Connection, a status toggle, Delete.

**Rebuilt data model to match**: connectors are independent entities (`PK: 'CONNECTOR', SK: <connectorId>`), not one config object per Application — the wireframe shows four separate Ingestion connectors and five separate Export ones, confirming an application can have more than one (e.g. distinct connectors for Fax vs Email intake into the same app). Flat partition, same pattern Workflows already uses — listing every connector is a plain primary-key Query, no GSI needed.

**New Connector flow, per explicit instruction**: Type (Import/Export) → Platform (S3 only for now — modeled as a real union type so adding a second platform later is a compiler-checked change, not a silent string typo) → Application → Name → Create. Lands in the list, on the right tab, inspector opens for it automatically.

**Inspector panel** — two fields added on top of what the wireframe shows, per explicit request:
- **Bucket/Folder are directly, plainly editable text inputs** — not gated behind mandatory browsing. A collapsible "Browse buckets / folders" reveals `S3LocationPickerComponent` (built in an earlier round) for anyone who'd rather browse than type a path they already know.
- **File Types** — a tag list of extensions to watch for (`.pdf`, `.tif`, `.zip`), matching the wireframe's "Suffix filter" field under clearer wording.
- **Enable/Disable, worded exactly as asked** (not the wireframe's "Pause") — new connectors start disabled until someone configures and enables them on purpose; toggling flips both the connector's live status and the button's own label/action.
- **Test Connection is real, not decorative** — a new backend endpoint (`POST /api/connectors/:connectorId/test`) runs a scoped `ListObjectsV2` (`MaxKeys: 1`) against the configured bucket/prefix, proving the bucket is genuinely reachable rather than just displaying a static success message.

**A real nested-`<button>` bug caught before shipping, not after.** The connector list row was originally a `<button>` containing the delete icon as *another* `<button>` — invalid HTML that browsers handle unpredictably (often silently hoisting the inner button out of the outer one, breaking click semantics entirely). Caught by an automated tag-balance sweep during review, not by manually eyeballing the template — fixed by making the row a `<div>` with explicit `role="button"`/`tabindex="0"`/`(keydown.enter)` for keyboard accessibility, and the delete icon stays a real, independent `<button>` inside it.

**Confirmed, not assumed: the Angular frontend never touches AWS SDK directly.** `StudioConfigService` only ever calls the proxy's own REST endpoints over plain HTTP; `@aws-sdk/client-s3` is imported and called exclusively in the backend Lambda. No AWS credentials exist anywhere in the Angular bundle — this was already true before this rebuild and didn't need to change.

#### Closing the loop on the ingestion routing question

Traced the real `idp-ingestion` code end-to-end before proposing anything (not from memory): routing to an application happened by parsing the S3 object key itself — `idp/applications/<App>/Import/<Source>/<file>.zip`, application ID hardcoded to position 2 of the split path, no separate routing table. One shared state machine (`STATE_MACHINE_ARN`, a single env var) handles every application; `application` is just passed through as execution input data, never used to select a different pipeline.

**A real, live bug was found and fixed along the way, independent of Connectors.** The reference Lambda code initially read didn't unwrap SQS's message envelope — `record["s3"]["bucket"]["name"]` directly, when a real SQS-delivered record has the S3 event JSON-encoded inside `record["body"]`, one level deeper. Confirmed via real CloudWatch logs (the person pulled the exact event, showing the SQS wrapper with a nested `Records` array) that this was a genuine, live issue — then the person supplied the actual current Lambda code, which already had the correct unwrap logic. Diffed the two files directly to confirm that was the *only* difference.

**`_parse_key_path()` → `_resolve_application_and_source()`, additive not a hard cutover.** The new function tries a Connectors-config lookup first — checks every *enabled* import connector's stored `(bucket, prefix)` against the incoming key, across every application, using whichever one matches as a prefix. `source_type` becomes whatever path segment follows the matched prefix, rather than a fixed absolute position. A disabled connector is excluded from the lookup entirely (filtered before the matching function ever sees it), so toggling one off in Studio immediately stops it from routing anything. If nothing matches (an application that hasn't configured a Connector yet, or has one but it's disabled), falls straight back to the original hardcoded parsing.

**Verified against real and synthetic scenarios, actual code run not just read**, both before and after the schema was corrected mid-build (connectors moved from a per-Application dict to a flat, independent-entity list — the lookup function's return shape changed accordingly, so everything was re-verified against the corrected version, not left validated against a stale draft): the exact real key from a live CloudWatch log with a matching connector — resolves correctly; the same real key with no connector configured — falls back, zero regression for un-migrated apps; **two enabled import connectors on the *same* application** (confirming multiple connectors per app resolve independently, not just first-match-wins on the application as a whole); a disabled connector correctly excluded, falling back rather than silently routing through something switched off; and a completely custom bucket/prefix that doesn't follow the old convention at all, which would have failed outright under the old hardcoded parser — confirming genuine new capability, not just a re-routed version of the same thing.

**IAM simplified along with the schema correction**: since connectors live in their own flat partition, `idp-ingestion` only needs a direct `dynamodb:Query` on the `idp-config` table itself — no GSI permission needed, unlike the type-index the proxy uses elsewhere. Documented in `STUDIO-SETUP.md` Step 7, along with the proxy's `s3:ListAllMyBuckets`/`ListBucket`/`PutObject` needs for the bucket/folder picker.

### Document Type creation — page-classification defaults, seeded not bound

New Document Type now asks for two more things beyond ID/name: **Page Classification** (`Sequential` | `Keyword`) and **Blank Page — Max Word Count** (default 5). These drive the auto-created page scaffold:

- **MainPage** and **TrailingPage** get `IdentificationMethod: 'Sequential'` (with `SequenceOrder` 1/2) if the mode is Sequential, or `IdentificationMethod: 'Keyword'` (with an empty `Keywords` array to fill in) if Keyword — matching whichever mode was chosen, rather than always defaulting to one regardless of what was asked for.
- **BlankPage** always gets `IdentificationMethod: 'WordCount'` with `MaxWordCount` set to the entered value, **regardless of Page Classification mode** — blank-page detection is a word-count threshold either way, it's not something Sequential vs Keyword mode changes.
- Scaffold verified by actually running the backend logic (`buildDocumentTypeScaffold()`) against three cases — Sequential, Keyword, and no input (defaults) — confirming each produces the exact expected shape before shipping, not just eyeballed.

**Seeded, not a live binding, on purpose.** `ClassificationMode`/`BlankPageMaxWordCount` are now real, persisted fields on `ConfigDocumentType` — editable later via a new "Page Classification Defaults" panel on the Classification tab, so both newly-created and pre-existing document types (like the migrated `CORRDOC`, which predates this feature and simply shows the defaults) get the same fields, same UI. Deliberately **not** a live/retroactive binding: changing the mode later doesn't reach back and rewrite any page's already-configured `IdentificationMethod`. They're a starting point for pages created *from this point forward*, not a rule the system silently re-enforces — avoiding a surprising, destructive side effect if someone has already hand-tuned a page's identification method independently.

**Found and left alone, on purpose**: `ConfigApplication.ClassificationMode` already existed in the shared model from early scaffolding — confirmed via search that `ConfigApplication` isn't used anywhere in the live app, so it's unrelated dead code, not a conflict with this new document-type-level field.
- **Double-click to rename a page type** in the Pages list, with the same auto-focus-and-select-text behavior applied to freshly-added pages so you can immediately type over the default name. New reusable `AutoFocusSelectDirective` (`appAutoFocusSelect`) backs this.
- **Page context is now always visible in the Fields tab**, even when a document type has only one page — previously the page-selector pills were hidden below 2 page types, leaving no indication of which page's fields you were editing.

### Validation — redesigned, now live (not a separate tab)

Originally planned as a fifth tab for cross-field rules. Before building it, checked what the real migrated `document-config.json` actually validates: mostly nothing (most fields have no validation at all), and where it exists, it's exactly two mechanisms — `ValidationRegex` (4 fields: PolicyNumber, CIFNumber, SSN, CustomerName) and a plain `Format` string used once, on `ReceivedDate` (`"YYYYMMDD"`). `Format` existed in the shared model but had never been surfaced in any Studio UI until now.

That real-data check reshaped the design entirely:

- **No separate tab.** Validation is a per-field concern, not something needing its own workspace — it's now a collapsible "Validation" section inside the Fields tab inspector, right below Extraction Method.
- **Off by default, per field** — a toggle ("Required" / "Not required") matches the real data, where validation is the exception, not the rule.
- **Two validation types when enabled**: **Format** (regex for most types; a date-format string like `YYYYMMDD` when DataType is `Date` — reuses the existing `ValidationRegex`/`Format` fields, no new storage needed) and **Range** (min/max bounds — needed two new fields, `MinValue`/`MaxValue`). A third type, **Length**, was considered and dropped: a regex like `{6,12}` already encodes length as part of the pattern, so Format subsumes it.
- **Structural fix**: `Validation Regex` used to only appear in the inspector when Extraction Method was set to `Regex` — which was backwards, since validation should apply regardless of *how* a value was extracted (AI, Anchor, whatever). It's now fully independent.

### Plan for the remaining editor tab

- **Indexer UI** — controls field layout in the reviewer app's Verify screen (order, grouping, default visibility). Planned design: three new properties directly on `ConfigField` (`IndexerOrder`, `IndexerVisible`, `IndexerGroup`) rather than a parallel list, so a field deleted in Fields tab can't go stale in a separate structure. The tab itself becomes a flattened, drag-reorderable view over every field across all page types, reusing the CDK drag-drop pattern from Pages.
- **Important caveat, confirmed with the person during design**: this (and Validation) is Studio-side config only. The reviewer app (`idp-ui`, a separate Angular project) doesn't yet read `IndexerOrder`/`IndexerVisible`, and the runtime's validation Lambda doesn't yet enforce `ValidationTypes`/`MinValue`/`MaxValue`. Studio stores well-structured config; making the reviewer app and runtime pipeline act on it is separate work, out of scope for this pass.
