import { CommonModule } from '@angular/common';
import { Component, signal } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { StudioUser } from '@akrify/shared';
import { environment } from '../../../environments/environment';

interface NavItem {
  label: string;
  route: string;
  icon: string;
}

@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, RouterOutlet],
  templateUrl: './shell.component.html',
  styleUrls: ['./shell.component.scss'],
})
export class ShellComponent {
  readonly envLabel = environment.envLabel;
  readonly envTone = environment.envTone;

  // Placeholder until auth wires in; backend supplies real identity.
  readonly user = signal<StudioUser>({
    id: 'shan',
    name: 'Shan',
    email: 'shan@studio.example',
    role: 'admin',
  });

  readonly version = 'v0.5.0 · Bedrock';

  readonly navItems: NavItem[] = [
    {
      label: 'Dashboard',
      route: '/dashboard',
      icon: 'M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z',
    },
    {
      label: 'Applications',
      route: '/applications',
      icon: 'M4 5a2 2 0 0 1 2-2h4l2 2h6a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V5z',
    },
    {
      label: 'Document Types',
      route: '/document-types',
      icon: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zM8 13h8v2H8v-2zm0 4h5v2H8v-2zm5-9h5l-5-5v5z',
    },
    {
      label: 'Dictionaries',
      route: '/dictionaries',
      icon: 'M4 19.5A2.5 2.5 0 0 1 6.5 17H20M4 4.5A2.5 2.5 0 0 1 6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15z',
    },
    {
      label: 'Jobs & Workflows',
      route: '/workflows',
      icon: 'M4 6h12l-3-3m3 3-3 3M20 18H8l3 3m-3-3 3-3',
    },
    {
      label: 'Connectors',
      route: '/connectors',
      icon: 'M7 10V7a5 5 0 0 1 10 0v3m-1 4h-8a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2z',
    },
    {
      label: 'Test Bench',
      route: '/test-bench',
      icon: 'M8 5v14l11-7L8 5z',
    },
    {
      label: 'Deployments',
      route: '/deployments',
      icon: 'M12 3l8 4-8 4-8-4 8-4zm-8 9 8 4 8-4M4 17l8 4 8-4',
    },
    {
      label: 'Users & Access',
      route: '/users',
      icon: 'M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm14 10v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75',
    },
    {
      label: 'Settings',
      route: '/settings',
      icon: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm7.4-3a7.4 7.4 0 0 0-.1-1.2l2.1-1.6-2-3.5-2.5 1a7.5 7.5 0 0 0-2-1.2L14.5 3h-5l-.4 2.5a7.5 7.5 0 0 0-2 1.2l-2.5-1-2 3.5 2.1 1.6a7.4 7.4 0 0 0 0 2.4l-2.1 1.6 2 3.5 2.5-1a7.5 7.5 0 0 0 2 1.2L9.5 21h5l.4-2.5a7.5 7.5 0 0 0 2-1.2l2.5 1 2-3.5-2.1-1.6c.07-.4.1-.8.1-1.2z',
    },
  ];

  readonly userInitial = () => this.user().name[0]?.toUpperCase() ?? '?';
}
