import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, EventEmitter, Input, Output, signal } from '@angular/core';
import { AslChoiceRule, AslDefinition, AslState, TaskIntegrationPattern } from '@akrify/shared';
import { applyIntegrationPattern, detectIntegrationPattern, extractFunctionArn } from '../../utils/asl-task-integration';

type ChoiceComparator = 'BooleanEquals' | 'StringEquals' | 'NumericEquals';

const INTEGRATION_PATTERNS: { key: TaskIntegrationPattern; label: string; hint: string }[] = [
  { key: 'RequestResponse',  label: 'Request Response',      hint: 'Invoke and continue immediately with the result.' },
  { key: 'WaitForTaskToken', label: 'Wait for Task Token',   hint: 'Pause until the task calls SendTaskSuccess/Failure (e.g. manual review).' },
  { key: 'RunAJob',          label: 'Run a Job (.sync)',     hint: 'Wait for the invoked job to finish before continuing.' },
];

const COMPARATORS: { key: ChoiceComparator; label: string }[] = [
  { key: 'BooleanEquals', label: 'Boolean equals' },
  { key: 'StringEquals',  label: 'String equals' },
  { key: 'NumericEquals', label: 'Number equals' },
];

@Component({
  selector: 'app-workflow-inspector',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './workflow-inspector.component.html',
  styleUrls: ['./workflow-inspector.component.scss'],
})
export class WorkflowInspectorComponent {
  @Input({ required: true }) definition!: AslDefinition;
  @Input() selectedStateName: string | null = null;

  @Output() changed = new EventEmitter<void>();
  @Output() renamed = new EventEmitter<{ oldName: string; newName: string }>();
  @Output() deleted = new EventEmitter<string>();

  readonly integrationPatterns = INTEGRATION_PATTERNS;
  readonly comparators = COMPARATORS;

  readonly nameDraft = signal('');
  readonly nameError = signal<string | null>(null);
  readonly parametersJsonDraft = signal('');
  readonly parametersJsonError = signal<string | null>(null);

  private lastBoundStateName: string | null = null;

  selectedState(): AslState | null {
    if (!this.selectedStateName) return null;
    const state = this.definition.States[this.selectedStateName] ?? null;
    // Reset local edit buffers whenever the selection changes.
    if (state && this.selectedStateName !== this.lastBoundStateName) {
      this.lastBoundStateName = this.selectedStateName;
      this.nameDraft.set(this.selectedStateName);
      this.nameError.set(null);
      this.parametersJsonDraft.set(JSON.stringify(state.Parameters ?? {}, null, 2));
      this.parametersJsonError.set(null);
    }
    return state;
  }

  allStateNames(): string[] {
    return Object.keys(this.definition.States);
  }

  otherStateNames(): string[] {
    return this.allStateNames().filter(n => n !== this.selectedStateName);
  }

  currentPattern(): TaskIntegrationPattern {
    const s = this.selectedState();
    return s ? detectIntegrationPattern(s) : 'RequestResponse';
  }

  currentFunctionArn(): string {
    const s = this.selectedState();
    return s ? extractFunctionArn(s) : '';
  }

  // ─── Name / Comment ────────────────────────────────────────────────

  onNameInput(v: string) {
    this.nameDraft.set(v);
  }

  commitName() {
    const oldName = this.selectedStateName;
    const s = this.selectedState();
    if (!oldName || !s) return;
    const newName = this.nameDraft().trim();
    if (!newName) {
      this.nameError.set('Name cannot be empty.');
      this.nameDraft.set(oldName);
      return;
    }
    if (newName !== oldName && this.definition.States[newName]) {
      this.nameError.set('Another state already uses this name.');
      this.nameDraft.set(oldName);
      return;
    }
    this.nameError.set(null);
    if (newName === oldName) return;

    // Rename the key in the States map, and rewire every reference to it.
    delete this.definition.States[oldName];
    this.definition.States[newName] = s;
    if (this.definition.StartAt === oldName) this.definition.StartAt = newName;
    for (const st of Object.values(this.definition.States)) {
      if (st.Next === oldName) st.Next = newName;
      if (st.Default === oldName) st.Default = newName;
      for (const rule of st.Choices ?? []) {
        if (rule.Next === oldName) rule.Next = newName;
      }
      for (const c of st.Catch ?? []) {
        if (c.Next === oldName) c.Next = newName;
      }
    }
    this.lastBoundStateName = newName;
    this.renamed.emit({ oldName, newName });
    this.changed.emit();
  }

  updateComment(v: string) {
    this.mutate(s => s.Comment = v || undefined);
  }

  deleteState() {
    if (!this.selectedStateName) return;
    this.deleted.emit(this.selectedStateName);
  }

  // ─── Task ────────────────────────────────────────────────────────

  updateIntegrationPattern(pattern: TaskIntegrationPattern) {
    this.mutate(s => applyIntegrationPattern(s, pattern, extractFunctionArn(s)));
    const s = this.selectedState();
    if (s) this.parametersJsonDraft.set(JSON.stringify(s.Parameters ?? {}, null, 2));
  }

  updateFunctionArn(v: string) {
    this.mutate(s => applyIntegrationPattern(s, detectIntegrationPattern(s), v));
    const s = this.selectedState();
    if (s) this.parametersJsonDraft.set(JSON.stringify(s.Parameters ?? {}, null, 2));
  }

  onParametersJsonInput(v: string) {
    this.parametersJsonDraft.set(v);
  }

  commitParametersJson() {
    const s = this.selectedState();
    if (!s) return;
    try {
      const parsed = this.parametersJsonDraft().trim() === '' ? {} : JSON.parse(this.parametersJsonDraft());
      s.Parameters = parsed;
      this.parametersJsonError.set(null);
      this.changed.emit();
    } catch {
      this.parametersJsonError.set('Invalid JSON — not saved. Fix the syntax and try again.');
    }
  }

  updateResultPath(v: string)  { this.mutate(s => s.ResultPath = v || undefined); }
  updateTimeoutSeconds(raw: string) {
    const n = parseInt(raw, 10);
    this.mutate(s => s.TimeoutSeconds = raw === '' || !Number.isFinite(n) ? undefined : n);
  }

  // ─── Retry ────────────────────────────────────────────────────────

  addRetryRule() {
    this.mutate(s => {
      if (!s.Retry) s.Retry = [];
      s.Retry.push({ ErrorEquals: ['States.ALL'], IntervalSeconds: 5, MaxAttempts: 2, BackoffRate: 2 });
    });
  }
  removeRetryRule(index: number) {
    this.mutate(s => s.Retry?.splice(index, 1));
  }
  updateRetryErrorEquals(index: number, text: string) {
    this.mutate(s => {
      const rule = s.Retry?.[index];
      if (rule) rule.ErrorEquals = splitTags(text);
    });
  }
  updateRetryInterval(index: number, raw: string) {
    const n = parseFloat(raw);
    this.mutate(s => { const rule = s.Retry?.[index]; if (rule && Number.isFinite(n)) rule.IntervalSeconds = n; });
  }
  updateRetryMaxAttempts(index: number, raw: string) {
    const n = parseFloat(raw);
    this.mutate(s => { const rule = s.Retry?.[index]; if (rule && Number.isFinite(n)) rule.MaxAttempts = n; });
  }
  updateRetryBackoff(index: number, raw: string) {
    const n = parseFloat(raw);
    this.mutate(s => { const rule = s.Retry?.[index]; if (rule && Number.isFinite(n)) rule.BackoffRate = n; });
  }

  // ─── Catch ────────────────────────────────────────────────────────

  addCatchRule() {
    this.mutate(s => {
      if (!s.Catch) s.Catch = [];
      const fallback = this.allStateNames()[0] ?? '';
      s.Catch.push({ ErrorEquals: ['States.ALL'], Next: fallback });
    });
  }
  removeCatchRule(index: number) {
    this.mutate(s => s.Catch?.splice(index, 1));
  }
  updateCatchErrorEquals(index: number, text: string) {
    this.mutate(s => {
      const rule = s.Catch?.[index];
      if (rule) rule.ErrorEquals = splitTags(text);
    });
  }
  updateCatchNext(index: number, next: string) {
    this.mutate(s => {
      const rule = s.Catch?.[index];
      if (rule) rule.Next = next;
    });
  }

  // ─── Choice ────────────────────────────────────────────────────────

  addChoiceRule() {
    const fallback = this.allStateNames()[0] ?? '';
    this.mutate(s => {
      if (!s.Choices) s.Choices = [];
      s.Choices.push({ Variable: '$.result', BooleanEquals: true, Next: fallback });
    });
  }
  removeChoiceRule(index: number) {
    this.mutate(s => s.Choices?.splice(index, 1));
  }
  updateChoiceVariable(index: number, v: string) {
    this.mutate(s => {
      const rule = s.Choices?.[index];
      if (rule) rule.Variable = v;
    });
  }
  choiceComparator(rule: AslChoiceRule): ChoiceComparator {
    if (rule.StringEquals !== undefined) return 'StringEquals';
    if (rule.NumericEquals !== undefined) return 'NumericEquals';
    return 'BooleanEquals';
  }
  choiceValueDisplay(rule: AslChoiceRule): string {
    const c = this.choiceComparator(rule);
    if (c === 'BooleanEquals') return String(rule.BooleanEquals ?? true);
    if (c === 'StringEquals')  return rule.StringEquals ?? '';
    return String(rule.NumericEquals ?? 0);
  }
  updateChoiceComparator(index: number, comparator: ChoiceComparator) {
    this.mutate(s => {
      const rule = s.Choices?.[index];
      if (!rule) return;
      delete rule.BooleanEquals;
      delete rule.StringEquals;
      delete rule.NumericEquals;
      if (comparator === 'BooleanEquals') rule.BooleanEquals = true;
      if (comparator === 'StringEquals')  rule.StringEquals = '';
      if (comparator === 'NumericEquals') rule.NumericEquals = 0;
    });
  }
  updateChoiceValue(index: number, raw: string) {
    this.mutate(s => {
      const rule = s.Choices?.[index];
      if (!rule) return;
      const c = this.choiceComparator(rule);
      if (c === 'BooleanEquals') rule.BooleanEquals = raw === 'true';
      if (c === 'StringEquals')  rule.StringEquals = raw;
      if (c === 'NumericEquals') rule.NumericEquals = parseFloat(raw) || 0;
    });
  }
  updateChoiceNext(index: number, next: string) {
    this.mutate(s => {
      const rule = s.Choices?.[index];
      if (rule) rule.Next = next;
    });
  }
  updateDefault(v: string) {
    this.mutate(s => s.Default = v || undefined);
  }

  private mutate(fn: (s: AslState) => void) {
    const s = this.selectedState();
    if (!s) return;
    fn(s);
    this.changed.emit();
  }
}

function splitTags(text: string): string[] {
  return text.split(',').map(t => t.trim()).filter(Boolean);
}
