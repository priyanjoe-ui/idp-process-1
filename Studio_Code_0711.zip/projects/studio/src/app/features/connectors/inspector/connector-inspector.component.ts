import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges, inject, signal } from '@angular/core';
import { ConnectorRecord, ConnectorStatus } from '@akrify/shared';
import { StudioConfigService, VersionConflictError } from '../../../services/studio-config.service';
import { S3LocationPickerComponent } from '../s3-location-picker/s3-location-picker.component';

/**
 * Shown only when a connector is selected in the list — this component
 * doesn't render anything of its own when there's nothing to inspect,
 * the parent list screen controls that with *ngIf.
 */
@Component({
  selector: 'app-connector-inspector',
  standalone: true,
  imports: [CommonModule, FormsModule, S3LocationPickerComponent],
  templateUrl: './connector-inspector.component.html',
  styleUrls: ['./connector-inspector.component.scss'],
})
export class ConnectorInspectorComponent implements OnChanges {
  private readonly configService = inject(StudioConfigService);

  @Input({ required: true }) connector!: ConnectorRecord;

  @Output() updated = new EventEmitter<ConnectorRecord>();
  @Output() deleteRequested = new EventEmitter<void>();

  // Working (editable) copies — separate from `connector` so Save/Discard
  // has something to compare against and revert to.
  readonly name = signal('');
  readonly bucket = signal('');
  readonly prefix = signal('');
  readonly fileTypes = signal<string[]>([]);
  readonly newFileType = signal('');
  readonly showBrowse = signal(false);

  readonly dirty = signal(false);
  readonly saving = signal(false);
  readonly saveError = signal<string | null>(null);
  readonly saveSuccess = signal<string | null>(null);
  readonly conflict = signal<VersionConflictError | null>(null);

  readonly testing = signal(false);
  readonly testResult = signal<{ success: boolean; message: string } | null>(null);

  readonly togglingStatus = signal(false);

  ngOnChanges(changes: SimpleChanges) {
    if (changes['connector']) {
      this.resetWorkingCopy();
    }
  }

  private resetWorkingCopy() {
    this.name.set(this.connector.name);
    this.bucket.set(this.connector.s3Config?.bucket ?? '');
    this.prefix.set(this.connector.s3Config?.prefix ?? '');
    this.fileTypes.set([...(this.connector.s3Config?.fileTypes ?? [])]);
    this.newFileType.set('');
    this.showBrowse.set(false);
    this.dirty.set(false);
    this.saveError.set(null);
    this.saveSuccess.set(null);
    this.conflict.set(null);
    this.testResult.set(null);
  }

  onNameInput(v: string) {
    this.name.set(v);
    this.dirty.set(true);
  }
  onBucketInput(v: string) {
    this.bucket.set(v);
    this.dirty.set(true);
  }
  onPrefixInput(v: string) {
    this.prefix.set(v);
    this.dirty.set(true);
  }

  toggleBrowse() {
    this.showBrowse.update(v => !v);
  }

  addFileType() {
    const v = this.newFileType().trim();
    if (!v) return;
    const normalized = v.startsWith('.') ? v : `.${v}`;
    if (!this.fileTypes().includes(normalized)) {
      this.fileTypes.update(list => [...list, normalized]);
      this.dirty.set(true);
    }
    this.newFileType.set('');
  }
  removeFileType(v: string) {
    this.fileTypes.update(list => list.filter(f => f !== v));
    this.dirty.set(true);
  }

  canSave(): boolean {
    return this.dirty() && !this.saving();
  }

  save() {
    if (!this.canSave()) return;
    this.saving.set(true);
    this.saveError.set(null);
    this.saveSuccess.set(null);
    this.conflict.set(null);

    // Only the bucket is required — an empty prefix is a legitimate choice
    // ("watch the whole bucket, no specific folder"), not something that
    // should silently drop the whole config. The backend's Test Connection
    // already treats an empty prefix this way; this just matches it.
    const s3Config = this.bucket()
      ? { bucket: this.bucket(), prefix: this.prefix(), fileTypes: this.fileTypes() }
      : undefined;

    this.configService.updateConnector(
      this.connector.connectorId,
      { name: this.name().trim() || this.connector.name, s3Config },
      this.connector.version,
    ).subscribe({
      next: updated => {
        this.saving.set(false);
        this.saveSuccess.set('Saved.');
        this.updated.emit(updated);
      },
      error: err => {
        this.saving.set(false);
        if (err instanceof VersionConflictError) {
          this.conflict.set(err);
        } else {
          this.saveError.set(err?.message || 'Failed to save.');
        }
      },
    });
  }

  discard() {
    this.resetWorkingCopy();
  }

  testConnection() {
    if (this.testing()) return;
    this.testing.set(true);
    this.testResult.set(null);
    this.configService.testConnector(this.connector.connectorId).subscribe({
      next: result => {
        this.testing.set(false);
        this.testResult.set(result);
      },
      error: err => {
        this.testing.set(false);
        this.testResult.set({ success: false, message: err?.message || 'Test failed.' });
      },
    });
  }

  toggleEnabled() {
    if (this.togglingStatus()) return;
    const nextStatus: ConnectorStatus = this.connector.status === 'enabled' ? 'disabled' : 'enabled';
    this.togglingStatus.set(true);
    this.configService.updateConnector(
      this.connector.connectorId,
      { status: nextStatus },
      this.connector.version,
    ).subscribe({
      next: updated => {
        this.togglingStatus.set(false);
        this.updated.emit(updated);
      },
      error: err => {
        this.togglingStatus.set(false);
        if (err instanceof VersionConflictError) {
          this.conflict.set(err);
        } else {
          this.saveError.set(err?.message || 'Failed to update status.');
        }
      },
    });
  }

  requestDelete() {
    this.deleteRequested.emit();
  }
}
