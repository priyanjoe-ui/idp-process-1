import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';
import { DashboardSnapshot, Environment, StatusCount, TopDocumentTypeRow, VolumePoint } from '@akrify/shared';
import { environment } from '../../environments/environment';

/** Shape returned by GET /api/dashboard (the same endpoint the reviewer app's Job Monitor uses). */
interface RawDashboardResponse {
  filter: { application: string; from: string | null; to: string | null };
  totalIngested: number;
  pendingReview: number;
  stpBatches: number;
  abortedBatches: number;
  stpPercentage: number;
  byDocumentType: { type: string; count: number }[];
  byStatus: { status: string; count: number }[];
  recentTimeline: { bucket: string; processed: number; failed: number }[]; // bucket: "YYYY-MM-DD HH:00" (UTC)
}

const WINDOW_DAYS = 7;
const TOP_DOC_TYPES_LIMIT = 5;

/**
 * Dashboard data source.
 *
 * Backed by the real GET /api/dashboard endpoint — the same one the
 * reviewer app's Job Monitor tab already uses against the idp-batch-tracking
 * table. No mock data here; fields with no real source yet (trend deltas,
 * active indexers, avg processing time, activity feed, service health) are
 * left null/empty so the UI can show an honest placeholder instead of a
 * fabricated number.
 */
@Injectable({ providedIn: 'root' })
export class DashboardService {
  private readonly http = inject(HttpClient);
  private readonly baseUrl = environment.apiBaseUrl.replace(/\/+$/, '');

  getSnapshot(): Observable<DashboardSnapshot> {
    const now = new Date();
    const dayKeys = lastNDayKeysUtc(now, WINDOW_DAYS);
    const from = `${dayKeys[0]}T00:00:00.000Z`;
    const to = now.toISOString();

    return this.http
      .get<RawDashboardResponse>(`${this.baseUrl}/dashboard`, { params: { from, to } })
      .pipe(map(raw => buildSnapshot(raw, now, dayKeys, from, to)));
  }
}

// ─── Derivation helpers ─────────────────────────────────────────────────

function buildSnapshot(
  raw: RawDashboardResponse,
  now: Date,
  dayKeys: string[],
  from: string,
  to: string,
): DashboardSnapshot {
  const volume = rebucketDaily(raw.recentTimeline, dayKeys);
  const todayKey = dayKeys[dayKeys.length - 1];
  const todayPoint = volume.find(v => v.dayKey === todayKey);
  const documentsToday = todayPoint ? todayPoint.processed + todayPoint.failed : 0;

  const topDocumentTypes: TopDocumentTypeRow[] = [...raw.byDocumentType]
    .sort((a, b) => b.count - a.count)
    .slice(0, TOP_DOC_TYPES_LIMIT)
    .map(d => ({
      name: d.type,
      count: d.count,
      stpRate: null,      // not computed per-type by the backend yet
      confidence: null,
    }));

  const byStatus: StatusCount[] = [...raw.byStatus].sort((a, b) => b.count - a.count);

  return {
    environment: (environment.envLabel as Environment) ?? 'dev',
    lastSyncedAt: now.toISOString(),
    windowFrom: from,
    windowTo: to,
    kpis: {
      documentsToday,
      documentsTrendPct: null,
      stpRatePct: raw.stpPercentage,
      stpRateTrendPts: null,
      pendingReview: raw.pendingReview,
      activeIndexers: null,
      avgProcessingSec: null,
    },
    volume: volume.map(({ dayKey: _dayKey, ...v }) => v),
    byStatus,
    topDocumentTypes,
    activity: [],       // no activity logging yet — UI shows a placeholder
    serviceHealth: [],  // no infra health checks yet — UI shows a placeholder
  };
}

/** UTC calendar-date key, e.g. "2026-07-09". Matches the backend's bucket format. */
function utcDateKey(d: Date): string {
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
}

function lastNDayKeysUtc(now: Date, n: number): string[] {
  const keys: string[] = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setUTCDate(d.getUTCDate() - i);
    keys.push(utcDateKey(d));
  }
  return keys;
}

function weekdayLabel(dayKey: string): string {
  const d = new Date(`${dayKey}T00:00:00Z`);
  return d.toLocaleDateString('en-US', { weekday: 'short', timeZone: 'UTC' });
}

/** Sums hourly {bucket, processed, failed} rows into one point per day, zero-filled for days with no data. */
function rebucketDaily(
  hourly: RawDashboardResponse['recentTimeline'],
  dayKeys: string[],
): (VolumePoint & { dayKey: string })[] {
  const sums = new Map<string, { processed: number; failed: number }>();
  for (const key of dayKeys) sums.set(key, { processed: 0, failed: 0 });

  for (const row of hourly) {
    const dayKey = row.bucket.slice(0, 10);
    const bucket = sums.get(dayKey);
    if (!bucket) continue; // outside the requested window
    bucket.processed += row.processed;
    bucket.failed += row.failed;
  }

  return dayKeys.map(dayKey => {
    const sum = sums.get(dayKey)!;
    return { dayKey, day: weekdayLabel(dayKey), processed: sum.processed, failed: sum.failed };
  });
}
