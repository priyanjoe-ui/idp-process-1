import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';
import {
  ApplicationRecord,
  ApplicationSummary,
  ConfigDocumentType,
  ConnectorRecord,
  ConnectorSummary,
  DeployWorkflowResult,
  DictionaryRecord,
  DocumentTypeRecord,
  DocumentTypeSummary,
  FieldOption,
  NewApplicationInput,
  NewConnectorInput,
  NewDocumentTypeInput,
  NewWorkflowInput,
  S3BucketSummary,
  S3FolderSummary,
  TestConnectorResult,
  UpdateApplicationInput,
  UpdateConnectorInput,
  UpdateWorkflowInput,
  WorkflowRecord,
  WorkflowSummary,
} from '@akrify/shared';
import { environment } from '../../environments/environment';

/**
 * Studio config service.
 *
 * Applications, Document Types, and Dictionaries are all wired to the real
 * idp-api-proxy backend. No mocked sections remain.
 *
 * Backend (all under environment.apiBaseUrl):
 *
 *   Applications
 *     GET    /applications                                → nested tree (reviewer app only; Studio doesn't call)
 *     GET    /applications/summary                        → { applications: ApplicationSummary[] }
 *     GET    /applications/:appId                         → ApplicationRecord
 *     POST   /applications                                → 201 ApplicationRecord
 *     PUT    /applications/:appId                         → ApplicationRecord   (X-Expected-Version)
 *     DELETE /applications/:appId                         → 204
 *
 *   Document Types
 *     GET    /applications/:appId/document-types           → { documentTypes: DocumentTypeSummary[] }
 *     GET    /document-types                               → { documentTypes: DocumentTypeSummary[] }  (global, GSI)
 *     GET    /applications/:appId/document-types/:docTypeId → DocumentTypeRecord
 *     POST   /applications/:appId/document-types           → 201 DocumentTypeRecord
 *     PUT    /applications/:appId/document-types/:docTypeId → DocumentTypeRecord (X-Expected-Version)
 *     DELETE /applications/:appId/document-types/:docTypeId → 204
 *
 *   Dictionaries
 *     GET    /dictionaries                                 → { dictionaries: DictionaryRecord[] }
 *     GET    /dictionaries/:name                           → DictionaryRecord (404 if not created yet)
 *     PUT    /dictionaries/:name                           → DictionaryRecord (creates if missing; X-Expected-Version required when updating)
 */
@Injectable({ providedIn: 'root' })
export class StudioConfigService {
  private readonly http = inject(HttpClient);
  private readonly baseUrl = environment.apiBaseUrl.replace(/\/+$/, '');

  // ═══════════════════════════════════════════════════════════════════
  // Applications — LIVE
  // ═══════════════════════════════════════════════════════════════════

  listApplications(): Observable<ApplicationSummary[]> {
    return this.http
      .get<{ applications: ApplicationSummary[] }>(`${this.baseUrl}/applications/summary`)
      .pipe(map(r => r.applications ?? []));
  }

  getApplication(appId: string): Observable<ApplicationRecord> {
    return this.http.get<ApplicationRecord>(`${this.baseUrl}/applications/${encodeURIComponent(appId)}`);
  }

  createApplication(input: NewApplicationInput): Observable<ApplicationRecord> {
    return this.http.post<ApplicationRecord>(`${this.baseUrl}/applications`, input);
  }

  updateApplication(
    appId: string,
    input: UpdateApplicationInput,
    expectedVersion: number,
  ): Observable<ApplicationRecord> {
    return this.http.put<ApplicationRecord>(
      `${this.baseUrl}/applications/${encodeURIComponent(appId)}`,
      input,
      { headers: versionHeader(expectedVersion) },
    );
  }

  deleteApplication(appId: string): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/applications/${encodeURIComponent(appId)}`);
  }

  // ═══════════════════════════════════════════════════════════════════
  // Document Types — LIVE
  // ═══════════════════════════════════════════════════════════════════

  listDocumentTypes(appId: string): Observable<DocumentTypeSummary[]> {
    return this.http
      .get<{ documentTypes: DocumentTypeSummary[] }>(
        `${this.baseUrl}/applications/${encodeURIComponent(appId)}/document-types`,
      )
      .pipe(map(r => r.documentTypes ?? []));
  }

  listAllDocumentTypes(): Observable<DocumentTypeSummary[]> {
    return this.http
      .get<{ documentTypes: DocumentTypeSummary[] }>(`${this.baseUrl}/document-types`)
      .pipe(map(r => r.documentTypes ?? []));
  }

  getDocumentType(appId: string, docTypeId: string): Observable<DocumentTypeRecord> {
    return this.http.get<DocumentTypeRecord>(
      `${this.baseUrl}/applications/${encodeURIComponent(appId)}/document-types/${encodeURIComponent(docTypeId)}`,
    );
  }

  createDocumentType(appId: string, input: NewDocumentTypeInput): Observable<DocumentTypeRecord> {
    return this.http.post<DocumentTypeRecord>(
      `${this.baseUrl}/applications/${encodeURIComponent(appId)}/document-types`,
      input,
    );
  }

  updateDocumentType(
    appId: string,
    docTypeId: string,
    body: ConfigDocumentType,
    expectedVersion: number,
  ): Observable<DocumentTypeRecord> {
    return this.http.put<DocumentTypeRecord>(
      `${this.baseUrl}/applications/${encodeURIComponent(appId)}/document-types/${encodeURIComponent(docTypeId)}`,
      { body },
      { headers: versionHeader(expectedVersion) },
    );
  }

  deleteDocumentType(appId: string, docTypeId: string): Observable<void> {
    return this.http.delete<void>(
      `${this.baseUrl}/applications/${encodeURIComponent(appId)}/document-types/${encodeURIComponent(docTypeId)}`,
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // Dictionaries — LIVE
  // ═══════════════════════════════════════════════════════════════════

  listDictionaries(): Observable<DictionaryRecord[]> {
    return this.http
      .get<{ dictionaries: DictionaryRecord[] }>(`${this.baseUrl}/dictionaries`)
      .pipe(map(r => r.dictionaries ?? []));
  }

  getDictionary(name: string): Observable<DictionaryRecord> {
    return this.http.get<DictionaryRecord>(`${this.baseUrl}/dictionaries/${encodeURIComponent(name)}`);
  }

  /**
   * Creates or updates a dictionary. Pass `expectedVersion: null` when the
   * dictionary doesn't exist yet (backend creates it unconditionally in that
   * case); pass the current version to update an existing one — the backend
   * requires the X-Expected-Version header whenever the row already exists.
   */
  saveDictionary(
    name: string,
    options: FieldOption[],
    expectedVersion: number | null,
  ): Observable<DictionaryRecord> {
    const headers = expectedVersion != null ? versionHeader(expectedVersion) : undefined;
    return this.http.put<DictionaryRecord>(
      `${this.baseUrl}/dictionaries/${encodeURIComponent(name)}`,
      { options },
      headers ? { headers } : {},
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // Workflows (Jobs & Workflow Builder) — LIVE
  //
  // A Workflow is a shared, independent entity — not owned by one
  // Application. Any number of Applications can be mapped to reuse the
  // same pipeline, and the mapping is editable after creation via
  // updateWorkflow's `mappedApplicationIds`.
  //
  // Unlike everything else in this service, Workflows have a real
  // draft/deployed split. `updateWorkflow` (Save) only ever touches the
  // draft row in DynamoDB — it never calls Step Functions. `deployWorkflow`
  // is the only method that does: it calls CreateStateMachine or
  // UpdateStateMachine depending on whether stateMachineArn already exists.
  // ═══════════════════════════════════════════════════════════════════

  listWorkflows(): Observable<WorkflowSummary[]> {
    return this.http
      .get<{ workflows: WorkflowSummary[] }>(`${this.baseUrl}/workflows`)
      .pipe(map(r => r.workflows ?? []));
  }

  getWorkflow(workflowId: string): Observable<WorkflowRecord> {
    return this.http.get<WorkflowRecord>(`${this.baseUrl}/workflows/${encodeURIComponent(workflowId)}`);
  }

  createWorkflow(input: NewWorkflowInput): Observable<WorkflowRecord> {
    return this.http.post<WorkflowRecord>(`${this.baseUrl}/workflows`, input);
  }

  /**
   * Partial update — writes to DynamoDB only, never touches the live state
   * machine. Pass `definition` (canvas Save), `mappedApplicationIds`
   * (Manage Applications modal), or both.
   */
  updateWorkflow(
    workflowId: string,
    input: UpdateWorkflowInput,
    expectedVersion: number,
  ): Observable<WorkflowRecord> {
    return this.http.put<WorkflowRecord>(
      `${this.baseUrl}/workflows/${encodeURIComponent(workflowId)}`,
      input,
      { headers: versionHeader(expectedVersion) },
    );
  }

  /** Create-or-update the real Step Functions state machine from the current draft. */
  deployWorkflow(workflowId: string, expectedVersion: number): Observable<DeployWorkflowResult> {
    return this.http.post<DeployWorkflowResult>(
      `${this.baseUrl}/workflows/${encodeURIComponent(workflowId)}/deploy`,
      {},
      { headers: versionHeader(expectedVersion) },
    );
  }

  deleteWorkflow(workflowId: string): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/workflows/${encodeURIComponent(workflowId)}`);
  }

  // ═══════════════════════════════════════════════════════════════════
  // Connectors — LIVE. Each connector is its own independent entity, not
  // one config object per Application. Immediately persisted, no draft
  // concept, matching Applications/Document Types rather than Workflows'
  // draft/deployed model — this is plain configuration metadata read by
  // idp-ingestion at runtime, not something with a deploy step.
  // ═══════════════════════════════════════════════════════════════════

  listConnectors(): Observable<ConnectorSummary[]> {
    return this.http
      .get<{ connectors: ConnectorSummary[] }>(`${this.baseUrl}/connectors`)
      .pipe(map(r => r.connectors ?? []));
  }

  getConnector(connectorId: string): Observable<ConnectorRecord> {
    return this.http.get<ConnectorRecord>(`${this.baseUrl}/connectors/${encodeURIComponent(connectorId)}`);
  }

  createConnector(input: NewConnectorInput): Observable<ConnectorRecord> {
    return this.http.post<ConnectorRecord>(`${this.baseUrl}/connectors`, input);
  }

  updateConnector(
    connectorId: string,
    input: UpdateConnectorInput,
    expectedVersion: number,
  ): Observable<ConnectorRecord> {
    return this.http.put<ConnectorRecord>(
      `${this.baseUrl}/connectors/${encodeURIComponent(connectorId)}`,
      input,
      { headers: versionHeader(expectedVersion) },
    );
  }

  deleteConnector(connectorId: string): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/connectors/${encodeURIComponent(connectorId)}`);
  }

  testConnector(connectorId: string): Observable<TestConnectorResult> {
    return this.http.post<TestConnectorResult>(
      `${this.baseUrl}/connectors/${encodeURIComponent(connectorId)}/test`,
      {},
    );
  }

  // ─── S3 browsing (backs the bucket/folder picker) ───────────────────

  listS3Buckets(): Observable<S3BucketSummary[]> {
    return this.http
      .get<{ buckets: S3BucketSummary[] }>(`${this.baseUrl}/s3/buckets`)
      .pipe(map(r => r.buckets ?? []));
  }

  listS3Folders(bucket: string, prefix: string): Observable<S3FolderSummary[]> {
    const params = prefix ? `?prefix=${encodeURIComponent(prefix)}` : '';
    return this.http
      .get<{ folders: S3FolderSummary[] }>(
        `${this.baseUrl}/s3/buckets/${encodeURIComponent(bucket)}/folders${params}`,
      )
      .pipe(map(r => r.folders ?? []));
  }

  createS3Folder(bucket: string, prefix: string): Observable<S3FolderSummary> {
    return this.http.post<S3FolderSummary>(
      `${this.baseUrl}/s3/buckets/${encodeURIComponent(bucket)}/folders`,
      { prefix },
    );
  }
}

// ─── Errors ───────────────────────────────────────────────────────────

/**
 * Thrown when a save's expectedVersion doesn't match the current row.
 * Produced by the HTTP interceptor when the backend returns 409.
 */
export class VersionConflictError extends Error {
  constructor(
    public readonly kind: 'APPLICATION' | 'DOC_TYPE' | 'DICTIONARY' | string,
    public readonly id: string,
    public readonly currentVersion: number,
  ) {
    super(`${kind} ${id} was modified by someone else (now at v${currentVersion}).`);
    this.name = 'VersionConflictError';
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────

function versionHeader(v: number): HttpHeaders {
  return new HttpHeaders({ 'X-Expected-Version': String(v) });
}
