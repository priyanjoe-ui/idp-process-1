"""
Shared field-extraction logic.

Extracted out of idp-extraction-callback so it has exactly ONE caller for
its core matching logic -- idp-extraction-callback (the real pipeline,
Textract blocks fetched via GetDocumentAnalysis after an async job) and
idp-test-bench (Textract blocks from a synchronous AnalyzeDocument call
on an uploaded page) both import from here.

Every function below is unchanged from idp-extraction-callback's old
private versions (_summarize_blocks, _extract_form_kvs, _safe_compile,
_match_field_via_kvs, _confidence_for_value, _match_field_via_text,
_extract_fields_for_page) -- same bodies, just relocated and renamed
without the leading underscore now that they're genuinely shared rather
than private to one Lambda. None of them touch DynamoDB or S3; they only
ever operate on a page's Textract blocks and a Page Type's config, which
is exactly what makes them safe to share.
"""
import logging
import re
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger()

FIELD_VALUE_WINDOW = 120


def summarize_blocks(blocks: List[Dict[str, Any]]) -> Tuple[str, List[Dict[str, Any]], int]:
    lines: List[Dict[str, Any]] = []
    word_count = 0
    for b in blocks:
        bt = b.get("BlockType")
        if bt == "LINE":
            lines.append({"text": b.get("Text", ""), "confidence": float(b.get("Confidence", 0.0))})
        elif bt == "WORD":
            word_count += 1
    joined = "\n".join(line["text"] for line in lines)
    return joined, lines, word_count


def extract_form_kvs(blocks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    by_id = {b["Id"]: b for b in blocks if b.get("Id")}

    def _get_text_for_block(block):
        rels = block.get("Relationships") or []
        word_texts = []
        confidences = []
        for r in rels:
            if r.get("Type") != "CHILD":
                continue
            for child_id in r.get("Ids", []) or []:
                child = by_id.get(child_id)
                if not child:
                    continue
                if child.get("BlockType") == "WORD":
                    word_texts.append(child.get("Text", ""))
                    confidences.append(float(child.get("Confidence", 0.0)))
                elif child.get("BlockType") == "SELECTION_ELEMENT":
                    word_texts.append("X" if child.get("SelectionStatus") == "SELECTED" else "")
        text = " ".join(t for t in word_texts if t).strip()
        conf = sum(confidences) / len(confidences) if confidences else float(block.get("Confidence", 0.0))
        return text, conf

    out = []
    for b in blocks:
        if b.get("BlockType") != "KEY_VALUE_SET":
            continue
        if "KEY" not in (b.get("EntityTypes") or []):
            continue
        key_text, key_conf = _get_text_for_block(b)
        value_text = ""
        value_conf = 0.0
        for r in b.get("Relationships") or []:
            if r.get("Type") != "VALUE":
                continue
            for value_id in r.get("Ids", []) or []:
                vb = by_id.get(value_id)
                if vb:
                    value_text, value_conf = _get_text_for_block(vb)
        if key_text:
            out.append({
                "key_text": key_text,
                "key_confidence": round(key_conf, 2),
                "value_text": value_text,
                "value_confidence": round(value_conf, 2),
            })
    return out


def safe_compile(pattern: Optional[str], field_name: str):
    if not pattern:
        return None
    try:
        return re.compile(pattern)
    except re.error:
        logger.warning("Bad ExtractionRegex for field %s: %r", field_name, pattern)
        return None


def match_field_via_kvs(field_cfg, keywords, kv_pairs):
    regex = safe_compile(field_cfg.get("ExtractionRegex"), field_cfg.get("FieldName"))
    for kw in keywords:
        kw_lower = kw.lower()
        for kv in kv_pairs:
            if kw_lower not in (kv.get("key_text") or "").lower():
                continue
            value_text = (kv.get("value_text") or "").strip()
            if not value_text:
                continue
            if regex:
                m = regex.search(value_text)
                if not m:
                    continue
                value = m.group(0).strip()
            else:
                value = value_text
            if not value:
                continue
            return {
                "value": value,
                "confidence": kv.get("value_confidence", 0.0),
                "matchedKeyword": kw,
                "source": "FORMS",
            }
    return None


def confidence_for_value(value, lines):
    confidences = [line["confidence"] for line in lines if value and value.lower() in line["text"].lower()]
    if confidences:
        return round(sum(confidences) / len(confidences), 2)
    if lines:
        return round(max(line["confidence"] for line in lines), 2)
    return 0.0


def match_field_via_text(field_cfg, keywords, text, lines):
    regex = safe_compile(field_cfg.get("ExtractionRegex"), field_cfg.get("FieldName"))
    if not regex:
        return None
    text_lower = text.lower()
    for kw in keywords:
        idx = text_lower.find(kw.lower())
        if idx < 0:
            continue
        window = text[idx + len(kw):idx + len(kw) + FIELD_VALUE_WINDOW]
        m = regex.search(window)
        if not m:
            continue
        value = m.group(0).strip()
        if not value:
            continue
        return {
            "value": value,
            "confidence": confidence_for_value(value, lines),
            "matchedKeyword": kw,
            "source": "TEXT",
        }
    return None


def extract_fields_for_page(blocks, main_page_cfg):
    fields = main_page_cfg.get("Fields", []) or []
    if not fields:
        return {}
    kv_pairs = extract_form_kvs(blocks)
    text, lines, _ = summarize_blocks(blocks)
    results = {}
    for f in fields:
        name = f["FieldName"]
        keywords = [k for k in (f.get("FieldKeywords") or []) if k]
        if not keywords:
            continue
        kv_match = match_field_via_kvs(f, keywords, kv_pairs)
        if kv_match:
            results[name] = kv_match
            continue
        text_match = match_field_via_text(f, keywords, text, lines)
        if text_match:
            results[name] = text_match
    return results
