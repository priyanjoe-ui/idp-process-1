"""
Shared classification logic.

Extracted out of idp-classification so it has exactly ONE caller for its
core matching logic, not two copies that can quietly drift apart --
idp-classification (the real pipeline, DynamoDB PAGE rows + S3 keys) and
idp-test-bench (an uploaded sample, raw bytes, no DynamoDB/S3 at all)
both import from here.

classify_sequential() and classify_ocr() are drop-in replacements for
idp-classification's old private _classify_sequential()/_classify_ocr() --
same behavior, same signatures, just relocated. classify_ocr_words() is
new: the pure keyword-matching core factored out of classify_ocr(), for a
caller (Test Bench) that has OCR words already in hand but no S3 key to
fetch them from.
"""
import logging
from typing import Any, Dict, List, Optional

import boto3

logger = logging.getLogger()

_textract = boto3.client("textract")


def classify_sequential(pages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """First page -> MainPage, every page after -> TrailingPage."""
    results = []
    for idx, p in enumerate(pages):
        page_type = "MainPage" if idx == 0 else "TrailingPage"
        results.append({
            "pageId": p["pageId"],
            "pageNumber": int(p["pageNumber"]),
            "pageType": page_type,
        })
    return results


def ocr_words(*, bucket: Optional[str] = None, key: Optional[str] = None,
              image_bytes: Optional[bytes] = None) -> List[str]:
    """
    Runs Textract's plain OCR (DetectDocumentText) and returns every
    detected word. Exactly one of (bucket, key) -- an S3-resident page,
    the real pipeline's case -- or image_bytes -- a page Test Bench has
    directly in memory, since it deliberately never writes the uploaded
    file to S3 -- should be provided.
    """
    if image_bytes is not None:
        document = {"Bytes": image_bytes}
    elif bucket and key:
        document = {"S3Object": {"Bucket": bucket, "Name": key}}
    else:
        raise ValueError("ocr_words needs either image_bytes or both bucket and key")
    resp = _textract.detect_document_text(Document=document)
    return [b["Text"] for b in resp.get("Blocks", []) if b.get("BlockType") == "WORD"]


def classify_ocr_words(words: List[str], page_types: List[Dict[str, Any]]) -> str:
    """
    Pure keyword-matching core: given a page's OCR words and a Document
    Type's configured PageTypes (each with an optional Keywords list),
    returns the best-matching PageType name (falling back to 'MainPage'
    if nothing scores above zero). No DynamoDB, no S3 -- just words and
    config -- which is exactly why Test Bench can call this directly per
    uploaded page, with no PAGE row or S3 key involved at all.
    """
    text_lower = " ".join(words).lower()
    best_type = "MainPage"
    best_score = -1
    for pt in page_types:
        keywords = [k.lower() for k in (pt.get("Keywords") or [])]
        if not keywords:
            continue
        hits = sum(1 for k in keywords if k in text_lower)
        if hits > best_score:
            best_score = hits
            best_type = pt["PageType"]
    return best_type


def classify_ocr(pages: List[Dict[str, Any]], doc_type: Dict[str, Any],
                  docs_bucket: str) -> List[Dict[str, Any]]:
    """
    The real pipeline's entry point -- pages are DynamoDB PAGE rows
    (already ingested, each with an s3Key). Fetches OCR words per page
    from S3, then defers to classify_ocr_words() for the actual matching
    decision, so that one piece of logic is never duplicated.
    """
    page_types = doc_type.get("PageTypes", [])
    results = []
    for p in pages:
        words = ocr_words(bucket=docs_bucket, key=p["s3Key"])
        best_type = classify_ocr_words(words, page_types)
        results.append({
            "pageId": p["pageId"],
            "pageNumber": int(p["pageNumber"]),
            "pageType": best_type,
        })
    return results
