"""
Classification Lambda (idp-classification).
Shared code is loaded from the idp-shared Lambda Layer.
"""
import json
import logging
import os
from decimal import Decimal
from typing import Any, Dict, List
import boto3
from shared import classification_logic, config_loader, ddb
logger = logging.getLogger()
logger.setLevel(logging.INFO)
class _DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, Decimal):
            if o == o.to_integral_value():
                return int(o)
            return float(o)
        return super().default(o)
def _json(obj: Any) -> str:
    return json.dumps(obj, cls=_DecimalEncoder)
def lambda_handler(event: Dict[str, Any], _context: Any) -> Dict[str, Any]:
    logger.info("Event: %s", _json(event))
    queue_id = int(event["queueId"])
    application = event["application"]
    start_time = ddb.now_iso()
    ddb.update_batch_status(queue_id, status="Running", current_task="Classification")
    try:
        app_cfg = config_loader.get_application(application)
        mode = app_cfg.get("ClassificationMode", "Sequential")
        doc_types = app_cfg.get("DocumentTypes", [])
        if not doc_types:
            raise RuntimeError(f"No DocumentTypes in config for {application}")
        doc_type = doc_types[0]
        pages = ddb.list_pages(queue_id)
        if not pages:
            raise RuntimeError(f"No pages found for queueId={queue_id}")
        if mode == "Sequential":
            decisions = classification_logic.classify_sequential(pages)
        elif mode == "OCR":
            decisions = classification_logic.classify_ocr(pages, doc_type, os.environ["DOCS_BUCKET"])
        else:
            logger.warning("Unknown ClassificationMode %r, falling back to Sequential", mode)
            decisions = classification_logic.classify_sequential(pages)
        for d in decisions:
            ddb.update_page_type(queue_id, d["pageId"], d["pageType"])
        ddb.append_task_history(queue_id=queue_id, task_name="Classification",
                                status="Completed", start_time=start_time,
                                end_time=ddb.now_iso(), operator="system")
        summary = {
            "queueId": queue_id,
            "application": application,
            "mode": mode,
            "pagesClassified": len(decisions),
            "decisions": decisions,
        }
        logger.info("Classification result: %s", _json(summary))
        return summary
    except Exception:
        logger.exception("Classification failed")
        ddb.append_task_history(queue_id=queue_id, task_name="Classification",
                                status="Failed", start_time=start_time,
                                end_time=ddb.now_iso(), operator="system")
        raise