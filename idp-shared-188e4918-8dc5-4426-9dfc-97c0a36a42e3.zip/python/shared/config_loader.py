"""
Config loader for the IDP pipeline.
 
Reads document-config.json from S3 once per Lambda cold start
and caches it in module scope. To force a refresh without
redeploying, recycle the Lambda (publish a new version, or
update an env var) or call invalidate() from a manual handler.
"""
 
import json
import logging
import os
from typing import Any, Dict, Optional
 
import boto3
 
logger = logging.getLogger()
 
_s3 = boto3.client("s3")
_CACHE: Optional[Dict[str, Any]] = None
_CACHE_ETAG: Optional[str] = None
 
 
def _bucket() -> str:
    return os.environ["CONFIG_BUCKET"]
 
 
def _key() -> str:
    return os.environ["CONFIG_KEY"]
 
 
def load_config(force_refresh: bool = False) -> Dict[str, Any]:
    """Return the parsed config dict, using cold-start cache."""
    global _CACHE, _CACHE_ETAG
    if _CACHE is not None and not force_refresh:
        return _CACHE
 
    logger.info("Loading config from s3://%s/%s", _bucket(), _key())
    resp = _s3.get_object(Bucket=_bucket(), Key=_key())
    body = resp["Body"].read().decode("utf-8")
    _CACHE = json.loads(body)
    _CACHE_ETAG = resp.get("ETag")
    logger.info("Config loaded, etag=%s", _CACHE_ETAG)
    return _CACHE
 
 
def get_application(app_name: str) -> Dict[str, Any]:
    """
    Return the application block for `app_name`.
 
    The config file supports two shapes:
      1. {"Applications": [ {ApplicationName: ...}, ... ]}
      2. {"ApplicationName": "...", "DocumentTypes": [...]}   (single-app)
 
    Both are handled.
    """
    cfg = load_config()
    if "Applications" in cfg:
        for app in cfg["Applications"]:
            if app.get("ApplicationName") == app_name:
                return app
        raise KeyError(f"Application '{app_name}' not in config")
    if cfg.get("ApplicationName") == app_name:
        return cfg
    raise KeyError(f"Application '{app_name}' not in config (single-app shape)")
 
 
def invalidate() -> None:
    """Drop the cache. Next call to load_config() will re-fetch."""
    global _CACHE, _CACHE_ETAG
    _CACHE = None
    _CACHE_ETAG = None