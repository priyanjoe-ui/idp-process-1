"""
DynamoDB helpers for the IDP single-table schema.
Phase 2A-revised: adds TEXTRACTJOB rows, GSI3 lookup, atomic counter.
Phase 2C-revised: adds lastTaskUpdatedAt freeze point for Job Time calculation.
"""
import os
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any, Dict, List, Optional
import boto3
from boto3.dynamodb.conditions import Key
_ddb = boto3.resource("dynamodb")
 
def _table():
    return _ddb.Table(os.environ["IDP_TABLE"])
 
def _counter_table():
    return _ddb.Table(os.environ["IDP_COUNTER_TABLE"])
 
def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()
 
def to_ddb(value: Any) -> Any:
    if isinstance(value, float):
        return Decimal(str(value))
    if isinstance(value, list):
        return [to_ddb(v) for v in value]
    if isinstance(value, dict):
        return {k: to_ddb(v) for k, v in value.items()}
    return value
 
_to_ddb = to_ddb
 
def next_queue_id() -> int:
    resp = _counter_table().update_item(
        Key={"CounterKey": "QUEUE_GLOBAL"},
        UpdateExpression="SET #v = if_not_exists(#v, :zero) + :one",
        ExpressionAttributeNames={"#v": "value"},
        ExpressionAttributeValues={":zero": Decimal(0), ":one": Decimal(1)},
        ReturnValues="UPDATED_NEW",
    )
    return int(resp["Attributes"]["value"])
 
def next_batch_number(application: str, date_str: str) -> str:
    counter_key = f"{application}#{date_str}"
    resp = _counter_table().update_item(
        Key={"CounterKey": counter_key},
        UpdateExpression="SET #v = if_not_exists(#v, :zero) + :one",
        ExpressionAttributeNames={"#v": "value"},
        ExpressionAttributeValues={":zero": Decimal(0), ":one": Decimal(1)},
        ReturnValues="UPDATED_NEW",
    )
    n = int(resp["Attributes"]["value"])
    return f"{date_str}.{n:06d}"
 
def put_batch(item: Dict[str, Any]) -> None:
    queue_id = item["queueId"]
    status = item["status"]
    app = item["application"]
    job_start = item.get("jobStartTime", now_iso())
    full = {
        **item,
        "PK": f"BATCH#{queue_id}",
        "SK": "META",
        "Type": "BATCH",
        "GSI1PK": f"STATUS#{status}",
        "GSI1SK": job_start,
        "GSI2PK": f"APP#{app}",
        "GSI2SK": job_start,
        "jobStartTime": job_start,
        # Initialize lastTaskUpdatedAt = jobStartTime so newly created batches
        # start with a meaningful freeze point.
        "lastTaskUpdatedAt": job_start,
        "updatedAt": now_iso(),
    }
    _table().put_item(Item=to_ddb(full))
 
def put_document(queue_id: int, doc_id: str, document_type: str,
                 page_ids: List[str], extracted_fields: List[Dict[str, Any]]) -> None:
    item = {
        "PK": f"BATCH#{queue_id}",
        "SK": f"DOC#{doc_id}",
        "Type": "DOCUMENT",
        "queueId": queue_id,
        "documentId": doc_id,
        "documentType": document_type,
        "pageIds": page_ids,
        "extractedFields": extracted_fields,
        "validationStatus": "Pending",
        "createdAt": now_iso(),
        "updatedAt": now_iso(),
    }
    _table().put_item(Item=to_ddb(item))
 
def put_page(queue_id: int, page_id: str, page_number: int,
             s3_key: str, page_type: str = "Unclassified",
             display_id: Optional[str] = None) -> None:
    item = {
        "PK": f"BATCH#{queue_id}",
        "SK": f"PAGE#{page_id}",
        "Type": "PAGE",
        "queueId": queue_id,
        "pageId": page_id,
        "pageNumber": page_number,
        "pageType": page_type,
        "s3Key": s3_key,
        "ocrTextS3Key": None,
        "wordCount": None,
        "pageStatus": "Pending",
        "displayId": display_id,
        "createdAt": now_iso(),
        "updatedAt": now_iso(),
    }
    _table().put_item(Item=to_ddb(item))
 
def append_task_history(queue_id: int, task_name: str, status: str,
                        start_time: Optional[str] = None,
                        end_time: Optional[str] = None,
                        operator: str = "system",
                        details: Optional[Dict[str, Any]] = None) -> None:
    end_ts = end_time or now_iso()
    item = {
        "PK": f"BATCH#{queue_id}",
        "SK": f"TASK#{end_ts}#{task_name}",
        "Type": "TASKHIST",
        "queueId": queue_id,
        "taskName": task_name,
        "status": status,
        "startTime": start_time or end_ts,
        "endTime": end_ts,
        "operator": operator,
    }
    if details:
        item["details"] = details
    _table().put_item(Item=to_ddb(item))
 
    # Stamp lastTaskUpdatedAt on BATCH/META so the proxy can compute Job Time
    # as a frozen value when the batch is not actively Running.
    # This runs every time a task completes (Ingestion, Classification, etc.).
    try:
        _table().update_item(
            Key={"PK": f"BATCH#{queue_id}", "SK": "META"},
            UpdateExpression="SET lastTaskUpdatedAt = :t, updatedAt = :t",
            ExpressionAttributeValues={":t": end_ts},
        )
    except Exception:
        # Defensive: don't let the freeze-point write fail the task history.
        pass
 
def put_textract_job(queue_id: int, job_id: str, page_id: str,
                     task_token: str, page_s3_key: str) -> None:
    item = {
        "PK": f"BATCH#{queue_id}",
        "SK": f"TEXTRACTJOB#{job_id}",
        "Type": "TEXTRACTJOB",
        "GSI3PK": f"TEXTRACTJOB#{job_id}",
        "GSI3SK": "META",
        "queueId": queue_id,
        "jobId": job_id,
        "pageId": page_id,
        "pageS3Key": page_s3_key,
        "taskToken": task_token,
        "status": "Pending",
        "createdAt": now_iso(),
        "updatedAt": now_iso(),
    }
    _table().put_item(Item=to_ddb(item))
 
def get_textract_job_by_id(job_id: str) -> Optional[Dict[str, Any]]:
    resp = _table().query(
        IndexName="GSI3-TextractJobById",
        KeyConditionExpression=Key("GSI3PK").eq(f"TEXTRACTJOB#{job_id}"),
        Limit=1,
    )
    items = resp.get("Items", [])
    return items[0] if items else None
 
def update_textract_job_status(queue_id: int, job_id: str,
                               status: str,
                               completed_at: Optional[str] = None,
                               result_s3_key: Optional[str] = None,
                               error_message: Optional[str] = None) -> None:
    parts = ["#s = :s", "updatedAt = :now"]
    names = {"#s": "status"}
    values = {":s": status, ":now": now_iso()}
    if completed_at:
        parts.append("completedAt = :ca")
        values[":ca"] = completed_at
    if result_s3_key:
        parts.append("resultS3Key = :rk")
        values[":rk"] = result_s3_key
    if error_message:
        parts.append("errorMessage = :em")
        values[":em"] = error_message
    _table().update_item(
        Key={"PK": f"BATCH#{queue_id}", "SK": f"TEXTRACTJOB#{job_id}"},
        UpdateExpression="SET " + ", ".join(parts),
        ExpressionAttributeNames=names,
        ExpressionAttributeValues=values,
    )
 
def init_pending_pages_count(queue_id: int, count: int,
                             task_token: str) -> None:
    _table().update_item(
        Key={"PK": f"BATCH#{queue_id}", "SK": "META"},
        UpdateExpression=(
            "SET pendingPagesCount = :c, "
            "extractionTaskToken = :tt, "
            "extractionStartedAt = :now, "
            "updatedAt = :now"
        ),
        ExpressionAttributeValues={
            ":c": Decimal(count),
            ":tt": task_token,
            ":now": now_iso(),
        },
    )
 
def decrement_pending_pages_count(queue_id: int) -> int:
    resp = _table().update_item(
        Key={"PK": f"BATCH#{queue_id}", "SK": "META"},
        UpdateExpression="ADD pendingPagesCount :neg_one SET updatedAt = :now",
        ExpressionAttributeValues={
            ":neg_one": Decimal(-1),
            ":now": now_iso(),
        },
        ReturnValues="UPDATED_NEW",
    )
    return int(resp["Attributes"]["pendingPagesCount"])
 
def get_extraction_task_token(queue_id: int) -> Optional[str]:
    resp = _table().get_item(
        Key={"PK": f"BATCH#{queue_id}", "SK": "META"},
        ProjectionExpression="extractionTaskToken",
    )
    item = resp.get("Item", {})
    return item.get("extractionTaskToken")
 
def update_batch_status(queue_id: int, status: str,
                        current_task: Optional[str] = None,
                        operator: Optional[str] = None) -> None:
    resp = _table().get_item(
        Key={"PK": f"BATCH#{queue_id}", "SK": "META"},
        ProjectionExpression="jobStartTime",
    )
    job_start = resp.get("Item", {}).get("jobStartTime", now_iso())
    now = now_iso()
    parts = [
        "#s = :s",
        "GSI1PK = :gsi1pk",
        "GSI1SK = :gsi1sk",
        "updatedAt = :now",
        # Advance lastTaskUpdatedAt on every status change so Job Time
        # captures the transition moment.
        "lastTaskUpdatedAt = :now",
    ]
    names = {"#s": "status"}
    values = {
        ":s": status,
        ":gsi1pk": f"STATUS#{status}",
        ":gsi1sk": job_start,
        ":now": now,
    }
    if current_task is not None:
        parts.append("currentTask = :ct")
        values[":ct"] = current_task
    if operator is not None:
        parts.append("#op = :op")
        names["#op"] = "operator"
        values[":op"] = operator
    _table().update_item(
        Key={"PK": f"BATCH#{queue_id}", "SK": "META"},
        UpdateExpression="SET " + ", ".join(parts),
        ExpressionAttributeNames=names,
        ExpressionAttributeValues=values,
    )
 
def update_page_type(queue_id: int, page_id: str, page_type: str) -> None:
    _table().update_item(
        Key={"PK": f"BATCH#{queue_id}", "SK": f"PAGE#{page_id}"},
        UpdateExpression="SET pageType = :pt, updatedAt = :now",
        ExpressionAttributeValues={":pt": page_type, ":now": now_iso()},
    )
 
def update_page_after_ocr(queue_id: int, page_id: str,
                          ocr_text_s3_key: str, word_count: int,
                          page_type: Optional[str] = None,
                          page_status: str = "Extracted") -> None:
    parts = [
        "ocrTextS3Key = :ock",
        "wordCount = :wc",
        "pageStatus = :ps",
        "updatedAt = :now",
    ]
    values = {
        ":ock": ocr_text_s3_key,
        ":wc": word_count,
        ":ps": page_status,
        ":now": now_iso(),
    }
    if page_type is not None:
        parts.append("pageType = :pt")
        values[":pt"] = page_type
    _table().update_item(
        Key={"PK": f"BATCH#{queue_id}", "SK": f"PAGE#{page_id}"},
        UpdateExpression="SET " + ", ".join(parts),
        ExpressionAttributeValues=to_ddb(values),
    )
 
def update_document_fields(queue_id: int, doc_id: str,
                           extracted_fields: List[Dict[str, Any]],
                           validation_status: Optional[str] = None) -> None:
    parts = ["extractedFields = :ef", "updatedAt = :now"]
    values = {":ef": extracted_fields, ":now": now_iso()}
    if validation_status is not None:
        parts.append("validationStatus = :vs")
        values[":vs"] = validation_status
    _table().update_item(
        Key={"PK": f"BATCH#{queue_id}", "SK": f"DOC#{doc_id}"},
        UpdateExpression="SET " + ", ".join(parts),
        ExpressionAttributeValues=to_ddb(values),
    )
 
def get_batch(queue_id: int) -> Optional[Dict[str, Any]]:
    resp = _table().get_item(Key={"PK": f"BATCH#{queue_id}", "SK": "META"})
    return resp.get("Item")
 
def list_pages(queue_id: int) -> List[Dict[str, Any]]:
    resp = _table().query(
        KeyConditionExpression=Key("PK").eq(f"BATCH#{queue_id}")
& Key("SK").begins_with("PAGE#"),
    )
    items = resp.get("Items", [])
    items.sort(key=lambda it: int(it.get("pageNumber", 0)))
    return items
 
def list_documents(queue_id: int) -> List[Dict[str, Any]]:
    resp = _table().query(
        KeyConditionExpression=Key("PK").eq(f"BATCH#{queue_id}")
& Key("SK").begins_with("DOC#"),
    )
    return resp.get("Items", [])
 
def get_first_document(queue_id: int) -> Optional[Dict[str, Any]]:
    docs = list_documents(queue_id)
    return docs[0] if docs else None
 
def get_page(queue_id: int, page_id: str) -> Optional[Dict[str, Any]]:
    resp = _table().get_item(
        Key={"PK": f"BATCH#{queue_id}", "SK": f"PAGE#{page_id}"},
    )
    return resp.get("Item")
 
# ---------------------------------------------------------------
# Manual Review (Phase 2B Sub-step 1)
# ---------------------------------------------------------------
def set_manual_review_pending(queue_id: int, task_token: str) -> None:
    """Stash the Step Function task token so the API can resume later."""
    _table().update_item(
        Key={"PK": f"BATCH#{queue_id}", "SK": "META"},
        UpdateExpression=(
            "SET manualReviewTaskToken = :tt, "
            "manualReviewStartedAt = :now, "
            "lastTaskUpdatedAt = :now, "
            "updatedAt = :now"
        ),
        ExpressionAttributeValues={
            ":tt": task_token,
            ":now": now_iso(),
        },
    )
 
def get_manual_review_task_token(queue_id: int) -> Optional[str]:
    resp = _table().get_item(
        Key={"PK": f"BATCH#{queue_id}", "SK": "META"},
        ProjectionExpression="manualReviewTaskToken",
    )
    item = resp.get("Item", {})
    return item.get("manualReviewTaskToken")
 
def clear_manual_review_pending(queue_id: int) -> None:
    """Called after SendTaskSuccess to free the row from holding the token."""
    _table().update_item(
        Key={"PK": f"BATCH#{queue_id}", "SK": "META"},
        UpdateExpression=(
            "REMOVE manualReviewTaskToken "
            "SET manualReviewCompletedAt = :now, "
            "lastTaskUpdatedAt = :now, "
            "updatedAt = :now"
        ),
        ExpressionAttributeValues={":now": now_iso()},
    )
 
def apply_review_corrections(queue_id: int, doc_id: str,
                             corrections: List[Dict[str, Any]],
                             reviewer: str) -> List[Dict[str, Any]]:
    """
    Apply reviewer-corrected field values to the document.
    corrections is a list of {fieldName, value} from the UI.
    Each existing field gets its value updated if present in corrections,
    validationPassed=True, confidence=100.0 (human-entered).
    Returns the new merged extractedFields list.
    """
    resp = _table().get_item(
        Key={"PK": f"BATCH#{queue_id}", "SK": f"DOC#{doc_id}"},
    )
    document = resp.get("Item")
    if not document:
        raise RuntimeError(f"No document for queueId={queue_id} docId={doc_id}")
    current_fields = document.get("extractedFields") or []
    correction_map = {c.get("fieldName"): c for c in corrections if c.get("fieldName")}
    new_fields = []
    for fld in current_fields:
        updated = dict(fld)
        name = updated.get("fieldName")
        if name in correction_map:
            c = correction_map[name]
            updated["value"] = c.get("value")
            updated["confidence"] = Decimal("100.0")
            updated["validationPassed"] = True
            updated["correctedBy"] = reviewer
            updated["correctedAt"] = now_iso()
            updated.pop("validationError", None)
        new_fields.append(updated)
    update_document_fields(
        queue_id=queue_id,
        doc_id=doc_id,
        extracted_fields=new_fields,
        validation_status="Reviewed",
    )
    return new_fields